package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AreaTecnicaPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AnagAreaTecnicaHandler extends AbstractFlussoHandler<AreaTecnicaPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AreaTecnicaPayloadDto> getDtoClass() {
        return AreaTecnicaPayloadDto.class;
    }

    @Override
    protected void handle(AreaTecnicaPayloadDto dto) {
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAnagAreaTecnica(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteAnagAreaTecnica(dto.data().getFirst().codiceArea());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}
    	
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ANAG_AREA_TECNICA_FLOW;
    }
}