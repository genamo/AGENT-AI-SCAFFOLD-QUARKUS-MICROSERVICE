package it.eng.snam.pmr.batchintegrazione.dto;

import lombok.Builder;

@Builder
public record FlowTriggerResponseDTO(
    String flow,
    String resolvedTopic,
    String transactionId,
    String messageKey,
    String status
) {}
