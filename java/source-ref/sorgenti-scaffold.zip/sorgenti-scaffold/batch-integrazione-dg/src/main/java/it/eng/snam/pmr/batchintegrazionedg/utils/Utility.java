package it.eng.snam.pmr.batchintegrazionedg.utils;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import it.eng.snam.pmr.batchintegrazionedg.exception.RemoteCallException;
import jakarta.ws.rs.core.Response;

public class Utility {

    // =========================
    // Helpers
    // =========================

    public static String defaultUuidIfBlank(String v) {
        return (v == null || v.isBlank())
                ? UUID.randomUUID().toString()
                : v;
    }

    public static boolean parseBooleanOrDefault(String v, boolean defaultValue) {
        if (v == null || v.isBlank()) return defaultValue;
        return switch (v.trim().toLowerCase()) {
            case "true" -> true;
            case "false" -> false;
            default -> defaultValue;
        };
    }

    public static String defaultIfBlank(String value, String defaultValue) {
        return (value == null || value.isBlank())
                ? defaultValue
                : value;
    }

    // =========================
    // Headers
    // =========================

    public static Response.ResponseBuilder withCommonHeaders(
            Response.ResponseBuilder rb,
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType
    ) {
        return rb
                .header(Constants.Headers.KEYLOGIC, keyLogic)
                .header(Constants.Headers.TRANSACTION_ID, transactionId)
                .header(Constants.Headers.MOD_ASYNC, String.valueOf(modAsync))
                .header(Constants.Headers.PROCESS_TYPE, processType);
    }

    // =========================
    // Success responses
    // =========================

    public static <T> Response ok(
            T data,
            String path,
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType,
            long startNanos
    ) {
        return withCommonHeaders(
                Response.ok(data),
                keyLogic, transactionId, modAsync, processType
        ).build();
    }

    public static <T> Response created(
            T data,
            String path,
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType,
            long startNanos
    ) {
        return withCommonHeaders(
                Response.status(Response.Status.CREATED).entity(data),
                keyLogic, transactionId, modAsync, processType
        ).build();
    }

    public static <T> Response okOrEmpty(
            List<T> list,
            String path,
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType,
            long startNanos
    ) {
        return ok(
                list == null ? List.of() : list,
                path, keyLogic, transactionId, modAsync, processType, startNanos
        );
    }

    public static <T> Response okOrNoContent(
            List<T> list,
            String path,
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType,
            long startNanos
    ) {
        return (list == null || list.isEmpty())
                ? noContentOnlyHeaders(keyLogic, transactionId, modAsync, processType)
                : ok(list, path, keyLogic, transactionId, modAsync, processType, startNanos);
    }

    public static <T> Response okOrNotFound(
            Optional<T> opt,
            String notFoundMessage,
            String path,
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType,
            long startNanos
    ) {
        return opt
                .map(value -> ok(value, path, keyLogic, transactionId, modAsync, processType, startNanos))
                .orElseGet(() -> notFound(
                        notFoundMessage, path,
                        keyLogic, transactionId, modAsync, processType, startNanos
                ));
    }

    public static Response noContentOnlyHeaders(
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType
    ) {
        return withCommonHeaders(
                Response.noContent(),
                keyLogic, transactionId, modAsync, processType
        ).build();
    }

    // =========================
    // Error responses
    // =========================

    public record ErrorPayload(
            String messageType,
            String messageCode,
            String messageDescription
    ) {}

    public static Response badRequest(
            String message,
            String path,
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType,
            long startNanos
    ) {
        return error(Response.Status.BAD_REQUEST, "BAD_REQUEST", message,
                keyLogic, transactionId, modAsync, processType);
    }

    public static Response notFound(
            String message,
            String path,
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType,
            long startNanos
    ) {
        return error(Response.Status.NOT_FOUND, "NOT_FOUND", message,
                keyLogic, transactionId, modAsync, processType);
    }

    public static Response badGateway(
            RemoteCallException e,
            String path,
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType,
            long startNanos
    ) {
        return error(Response.Status.BAD_GATEWAY, "BAD_GATEWAY",
                e.getMessage(),
                keyLogic, transactionId, modAsync, processType);
    }

    private static Response error(
            Response.Status status,
            String code,
            String message,
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType
    ) {
        ErrorPayload payload = new ErrorPayload("ERROR", code, message);

        return withCommonHeaders(
                Response.status(status).entity(payload),
                keyLogic, transactionId, modAsync, processType
        ).build();
    }

    // =========================
    // Logging helpers
    // =========================

    public static long elapsedMs(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }

    public static String safe(Object v) {
        if (v == null) return "null";
        String s = String.valueOf(v).trim();
        if (s.isEmpty()) return "blank";
        return s.length() > 120 ? s.substring(0, 120) + "..." : s;
    }
    
    
    public static enum FlussiStatus {
        INIT(0, "INIT"),
        BEGIN(100, "BEGIN"),
        PROGRESS(120, "IN ELABORAZIONE"),
        COMPLETED(220, "ACQUISITO"),
        ERROR(400, "ERROR");

        public final int code;
        public final String description;

        FlussiStatus(int code, String description) {
            this.code = code;
            this.description = description;
        }
    }
    
    public static int toDayNumber(LocalDate date) {
        return date.getYear() * 10000 + date.getMonthValue() * 100 + date.getDayOfMonth();
    }

    public static int toMonthNumber(LocalDate date) {
        return date.getYear() * 100 + date.getMonthValue();
    }

    public static String encodeToBase64(String jsonFile) {
        if (jsonFile == null) {
            return null;
        }
        return Base64.getEncoder().encodeToString(jsonFile.getBytes(StandardCharsets.UTF_8));
    }
}