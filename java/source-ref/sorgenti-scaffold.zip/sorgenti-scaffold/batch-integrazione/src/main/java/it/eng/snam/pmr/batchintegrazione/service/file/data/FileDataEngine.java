package it.eng.snam.pmr.batchintegrazione.service.file.data;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import it.eng.snam.pmr.batchintegrazione.config.async.TaskExecutorConfig;
import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.BlobUploadStatus;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileDataRequest;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileReference;
import it.eng.snam.pmr.batchintegrazione.service.blob.storage.BlobStorageUploader;
import it.eng.snam.pmr.batchintegrazione.utils.blob.storage.BlobUploadStatusInitializer;
import it.eng.snam.pmr.batchintegrazione.utils.file.data.FileDataEngineDomain;
import it.eng.snam.pmr.batchintegrazione.utils.file.data.FileDataRequestValidator;
import it.eng.snam.pmr.common.config.async.TaskExecutorQualifier;
import it.eng.snam.pmr.common.util.exception.ExceptionUnwrapper;
import it.eng.snam.pmr.common.util.retry.RetryableProcessExecutor;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
public class FileDataEngine {

    private final Executor executor;
    private final FileDataTransformer transformer;
    private final BlobStorageUploader uploader;

    public FileDataEngine(@TaskExecutorQualifier(TaskExecutorConfig.BLOB_UPLOAD_EXECUTOR) Executor executor, FileDataTransformer transformer, BlobStorageUploader uploader) {
        this.executor = executor;
        this.transformer = transformer;
        this.uploader = uploader;
    }

    public BlobUploadStatus powerUp(FileDataRequest request) {
        return CompletableFuture.supplyAsync(() -> execute(request), executor)
                                .exceptionally(throwable -> handleError(request, throwable))
                                .join();
    }

    private BlobUploadStatus execute(FileDataRequest request) {
        FileDataRequestValidator.validate(request);
        return RetryableProcessExecutor.execute(FileDataEngineDomain.ENGINE, () -> uploader.uploadAndVerify(transformer.transform(request)));
    }

    private BlobUploadStatus handleError(FileDataRequest request, Throwable throwable) {
        Throwable cause = ExceptionUnwrapper.unwrapCompletion(throwable);
        log.error("Error executing engine: executioner={} - activity={} - sourceSystem={} - fileReferences={}",
                  request.getExecutioner(), request.getActivity(), request.getSourceSystem(),
                  request.getFileReferences().stream().map(FileReference::getFileName).toList(), cause);

        return BlobUploadStatusInitializer.initialize(cause);
    }
}
