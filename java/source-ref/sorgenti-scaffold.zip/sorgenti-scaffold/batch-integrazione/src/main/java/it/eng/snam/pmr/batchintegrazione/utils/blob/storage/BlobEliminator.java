package it.eng.snam.pmr.batchintegrazione.utils.blob.storage;

import com.azure.storage.blob.BlobClient;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class BlobEliminator {

    public void eliminate(BlobClient blobClient, Throwable cause) {
        log.warn("Deleting blob '{}' due to an unexpected error: {}", blobClient.getBlobName(), cause.getMessage());
        blobClient.deleteIfExists();
    }
}
