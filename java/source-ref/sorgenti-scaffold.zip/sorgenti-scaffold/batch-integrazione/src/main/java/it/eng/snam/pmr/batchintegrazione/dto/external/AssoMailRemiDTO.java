package it.eng.snam.pmr.batchintegrazione.dto.external;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AssoMailRemiDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 6354246489513959050L;

    private Long idMail;
    private String codiceCliente;
    private String funzione;
    private String ruolo;

    private String prefissoRiferimento2;
    private String tipo;
    @JsonFormat(pattern = "yyyy-MM")
    private YearMonth meseCompetenza;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dataEmissione;
    private String nomeFile;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSSSSS")
    private LocalDateTime dataUltimoAggiornamento;

    private String statoInvio;
    private List<String> mailList;
}