package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AssRemiTipoBilancioTecnicoDto(
        String remiAssoluto,
        LocalDateTime dataInizio,
        Long dataInizioInt,
        LocalDateTime dataFine,
        Long dataFineInt,
        String tipoBilancioTecnico,
        String descrizioneBilancio,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {}