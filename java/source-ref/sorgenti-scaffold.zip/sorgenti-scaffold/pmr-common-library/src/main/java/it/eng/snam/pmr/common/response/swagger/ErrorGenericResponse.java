package it.eng.snam.pmr.common.response.swagger;

import java.io.Serial;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import it.eng.snam.pmr.common.response.GenericResponse;

@Schema(name = "ErrorGenericResponse")
public class ErrorGenericResponse extends GenericResponse<Object> {
    @Serial
    private static final long serialVersionUID = -4631924427519390989L;
}
