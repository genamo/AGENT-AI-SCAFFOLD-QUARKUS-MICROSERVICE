package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AnalisiQualitaGasGiornPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.DatiPrimariService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AnalisiQualitaGasGiornHandler extends AbstractFlussoHandler<AnalisiQualitaGasGiornPayloadDto> {

    @Inject
    DatiPrimariService datiPrimariService;

    @Override
    protected Class<AnalisiQualitaGasGiornPayloadDto> getDtoClass() {
        return AnalisiQualitaGasGiornPayloadDto.class;
    }

    @Override
    protected void handle(AnalisiQualitaGasGiornPayloadDto dto) {
        if (dto.operation() != null && !dto.operation().isEmpty()) {
            switch (dto.operation()) {
                case "INSERT":
                    if (dto.data() != null && !dto.data().isEmpty()) {
                        datiPrimariService.saveAnalisiQualitaGasGiorn(dto.data().getFirst());
                    }
                    break;

                case "DELETE":
                    if (dto.data() != null && !dto.data().isEmpty()) {
                        datiPrimariService.deleteAnalisiQualitaGasGiorn(
                                dto.data().getFirst().remiAssoluto(),
                                dto.data().getFirst().dataIniAnalisi()
                        );
                    }
                    break;

                default:
                    throw new IllegalArgumentException("Invalid operation: " + dto.operation());
            }
        } else {
            throw new IllegalArgumentException("Operation field is required");
        }
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ANALISI_QUALITA_GASDAY_FLOW;
    }
}
