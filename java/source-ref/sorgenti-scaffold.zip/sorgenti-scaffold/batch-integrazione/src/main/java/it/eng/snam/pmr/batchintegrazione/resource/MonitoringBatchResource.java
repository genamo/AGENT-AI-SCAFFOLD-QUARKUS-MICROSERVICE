package it.eng.snam.pmr.batchintegrazione.resource;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringBatchDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringBatchSearchDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringBatchService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import it.eng.snam.pmr.common.annotation.AuthzRead;
import it.eng.snam.pmr.common.annotation.AuthzWrite;
import it.eng.snam.pmr.common.annotation.LogPmr;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.response.swagger.CommonApiErrorResponses;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;

@Path("/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RunOnVirtualThread
@LogPmr
@RequiredArgsConstructor(onConstructor_ = @Inject)
@Tag(name = "MonitoringBatchResource", description = "API per il monitoraggio e la consultazione dei batch")
public class MonitoringBatchResource {

	private final MonitoringBatchService batchService;
	private final Utility utility;

	@GET
	@AuthzRead
	@Path("/bi_monitoring-batch_getall")
	@Operation(summary = "Recupera tutti i batch monitorati")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Lista batch recuperata correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringBatchListGenericResponse.class)))
	public Response getAll() {
		return handle(() -> utility.okOrEmpty(batchService.getAll()));
	}

	@GET
	@Path("/bi_monitoring-batch_id/{id}")
	@AuthzRead
	@Operation(summary = "Recupera un batch tramite identificativo")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Batch recuperato correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringBatchGenericResponse.class)))
	public Response getById(

			@PathParam("id") @Parameter(description = "Identificativo del batch", required = true, example = "1", schema = @Schema(type = SchemaType.INTEGER)) Long identifier

	) {

		Response validationError = validateIdentifier(identifier);
		if (validationError != null) {
			return validationError;
		}

		return handle(() -> {
			Optional<MonitoringBatchDTO> result = batchService.getById(identifier);
			return utility.okOrNotFound(result, buildIdNotFoundMessage(identifier));
		});
	}

	@GET
	@Path("/bi_monitoring-batch_transaction/{transactionId}")
	@AuthzRead
	@Operation(summary = "Recupera un batch tramite transactionId")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Batch recuperato correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringBatchGenericResponse.class)))
	public Response getByTransactionId(

			@PathParam("transactionId") @Parameter(description = "Transaction identifier", required = true, example = "TX123456", schema = @Schema(type = SchemaType.STRING)) String transaction

	) {

		Response validationError = validateTransactionId(transaction);
		if (validationError != null) {
			return validationError;
		}

		return handle(() -> {
			Optional<MonitoringBatchDTO> found = batchService.getByTransactionId(transaction);
			return utility.okOrNotFound(found, buildTransactionNotFoundMessage(transaction));
		});
	}

	@GET
	@Path("/bi_monitoring-batch_last-executions")
	@AuthzRead
	@Operation(summary = "Recupera le ultime esecuzioni batch")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Ultime esecuzioni recuperate correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringBatchListGenericResponse.class)))
	public Response getLastExecutions(

			@QueryParam("limit") @Parameter(description = "Numero massimo di risultati", required = false, example = "10", schema = @Schema(type = SchemaType.INTEGER)) Integer limitValue

	) {

		Integer validatedLimit = normalizeLimit(limitValue);
		if (validatedLimit == null) {
			return utility.badRequest("limit deve essere maggiore di 0");
		}

		return handle(() -> utility.okOrEmpty(batchService.getLastExecutions(validatedLimit)));
	}

	@GET
	@Path("/bi_monitoring-batch_period")
	@AuthzRead
	@Operation(summary = "Recupera i batch filtrati per periodo")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Batch recuperati correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringBatchListGenericResponse.class)))
	public Response getByPeriod(

			@QueryParam("monthNumber") @Parameter(description = "Numero del mese", required = false, example = "7") Integer monthParam,

			@QueryParam("dayNumber") @Parameter(description = "Numero del giorno", required = false, example = "15") Integer dayParam

	) {
		return handle(() -> utility.okOrEmpty(batchService.getByPeriod(monthParam, dayParam)));
	}

	@POST
	@Path("/bi_monitoring-batch_save")
	@AuthzWrite
	@Operation(summary = "Salva un nuovo record di monitoring batch")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Batch salvato correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringBatchGenericResponse.class)))
	public Response save(

			@RequestBody(description = "Payload del batch", required = true, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringBatchDTO.class))) MonitoringBatchDTO payload

	) {

		if (payload == null) {
			return utility.badRequest("Body non valido");
		}

		return handle(() -> utility.ok(batchService.save(payload)));
	}

	@POST
	@Path("/bi_monitoring-batch_search")
	@AuthzRead
	@Operation(summary = "Ricerca batch tramite criteri avanzati")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Ricerca completata correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringBatchListGenericResponse.class)))
	public Response search(

			@RequestBody(description = "Criteri di ricerca", required = true, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringBatchSearchDTO.class))) MonitoringBatchSearchDTO criteria

	) {

		if (criteria == null) {
			return utility.badRequest("Search body nullo");
		}

		return handle(() -> utility.okOrEmpty(batchService.findByCustomSearch(criteria)));
	}

	private Response handle(Supplier<Response> action) {
		try {
			return action.get();
		} catch (IllegalArgumentException e) {
			return utility.badRequest(e.getMessage());
		} catch (RemoteCallException e) {
			return utility.badGateway(e);
		}
	}

	private Response validateIdentifier(Long identifier) {
		if (identifier == null || identifier <= 0) {
			return utility.badRequest("Parametro id non valido");
		}
		return null;
	}

	private Response validateTransactionId(String transactionId) {
		if (transactionId == null || transactionId.trim().isEmpty()) {
			return utility.badRequest("transactionId non valido");
		}
		return null;
	}

	private Integer normalizeLimit(Integer limitValue) {
		int max = (limitValue == null) ? 10 : limitValue;
		return max > 0 ? max : null;
	}

	private String buildIdNotFoundMessage(Long identifier) {
		return "Batch non trovato per id=" + identifier;
	}

	private String buildTransactionNotFoundMessage(String transaction) {
		return "Nessun batch per transactionId=" + transaction;
	}

	@Schema(name = "MonitoringBatchGenericResponse")
	public static class MonitoringBatchGenericResponse extends GenericResponse<MonitoringBatchDTO> {

		private static final long serialVersionUID = 1L;
	}

	@Schema(name = "MonitoringBatchListGenericResponse")
	public static class MonitoringBatchListGenericResponse extends GenericResponse<List<MonitoringBatchDTO>> {

		private static final long serialVersionUID = 1L;
	}
}
