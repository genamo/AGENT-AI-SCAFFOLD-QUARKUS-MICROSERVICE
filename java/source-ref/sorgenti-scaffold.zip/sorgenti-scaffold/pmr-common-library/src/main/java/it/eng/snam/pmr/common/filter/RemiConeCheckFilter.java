package it.eng.snam.pmr.common.filter;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.jboss.logging.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import it.eng.snam.pmr.common.annotation.RemiConeCheck;
import it.eng.snam.pmr.common.cache.AuthzAnnotationCache;
import it.eng.snam.pmr.common.dto.RemiConeDTO;
import it.eng.snam.pmr.common.service.RemiConeValidationService;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.ext.Provider;


/**
 * Filtro trasversale per la validazione del cono dati (remiAssoluto).
 *
 * <p>Si attiva sui metodi annotati con {@link RemiConeCheck}.
 * Gira sempre DOPO {@code AuthzReadFilter} / {@code AuthzWriteFilter}
 * (priority {@code AUTHORIZATION + 10}) per avere userId e UserType già disponibili in MDC.
 *
 * <p>Modalità supportate:
 * <ul>
 *   <li>{@code REQUEST} – verifica che il/i remi passati in input appartengano al cono utente.</li>
 *   <li>{@code RESPONSE} – filtra l'array di risposta rimuovendo i remi fuori cono.</li>
 *   <li>{@code REQUEST_AND_RESPONSE} – entrambe.</li>
 * </ul>
 *
 * <p><b>Nota per il developer</b>: annotare il metodo con
 * {@code @RemiConeCheck} insieme a {@code @AuthzRead} o {@code @AuthzWrite}.
 * Non usare in assenza di un filtro Authz: il cono verrebbe risolto senza userId.
 */
@Provider
@RemiConeCheck
@Priority(Priorities.AUTHORIZATION + 10)
public class RemiConeCheckFilter implements ContainerRequestFilter, ContainerResponseFilter {

    private static final Logger LOG = Logger.getLogger(RemiConeCheckFilter.class);

    @Context
    ResourceInfo resourceInfo;

    @Inject
    RemiConeValidationService coneValidationService;

    @Inject
    ObjectMapper objectMapper;

    // =========================================================
    // REQUEST PHASE
    // =========================================================

    @Override
    public void filter(ContainerRequestContext req) throws IOException {
        RemiConeCheck annotation = getAnnotation();
        if (annotation == null) return;

        req.setProperty(
                RemiConeValidationService.PMR_REMI_MODULE_CODES_PROP,
                Arrays.stream(annotation.moduleCodes())
                        .filter(Objects::nonNull)
                        .map(String::trim)
                        .filter(s -> !s.isBlank())
                        .map(s -> s.toUpperCase(Locale.ROOT))
                        .collect(Collectors.toCollection(LinkedHashSet::new))
        );

        // Risolve il cono e lo salva nella request per il RESPONSE phase
        RemiConeDTO cone = coneValidationService.resolveAndCache(req);

        // Solo RESPONSE → non validiamo l'input
        if (annotation.mode() == RemiConeCheck.Mode.RESPONSE) return;

        if (cone.fullAccess()) return;

        // --- validazione query param singolo ---
        String singleRemi = req.getUriInfo().getQueryParameters().getFirst(annotation.queryParam());
        if (singleRemi != null && !singleRemi.isBlank()) {
            if (!cone.allows(singleRemi)) {
                LOG.warnf("RemiConeCheck DENIED: queryParam %s=%s non nel cono utente",
                        annotation.queryParam(), singleRemi);
                throw new ForbiddenException("REMI_NOT_AUTHORIZED");
            }
            return;
        }

        // --- validazione query param lista ---
        List<String> remiList = req.getUriInfo().getQueryParameters().get(annotation.queryListParam());
        if (remiList != null && !remiList.isEmpty()) {
            if (!cone.allowsAll(remiList)) {
                LOG.warnf("RemiConeCheck DENIED: queryParam %s non completamente nel cono utente",
                        annotation.queryListParam());
                throw new ForbiddenException("REMI_LIST_NOT_AUTHORIZED");
            }
            return;
        }

        // --- validazione body JSON (POST/PUT) ---
        String method = req.getMethod();
        if ("POST".equalsIgnoreCase(method) || "PUT".equalsIgnoreCase(method)) {
            validateBodyRemi(req, cone, annotation);
        }
    }



    private void validateBodyRemi(ContainerRequestContext req, RemiConeDTO cone,
            RemiConeCheck annotation) throws IOException {

        InputStream is = req.getEntityStream();
        if (is == null) return;

        byte[] bytes = is.readAllBytes();
        if (bytes.length == 0) return;

        // Ripristina lo stream per il downstream (business method)
        req.setEntityStream(new ByteArrayInputStream(bytes));

        try {
            JsonNode body = objectMapper.readTree(bytes);
            if (body == null || body.isNull()) return;

            // Singolo remi nel body
            JsonNode singleNode = body.path(annotation.singleField());
            if (singleNode.isTextual()) {
                String remi = singleNode.asText();
                if (!cone.allows(remi)) {
                    LOG.warnf("RemiConeCheck DENIED (body): campo '%s'=%s non nel cono utente",
                            annotation.singleField(), remi);
                    throw new ForbiddenException("REMI_NOT_AUTHORIZED");
                }
                return;
            }

            // Lista di remi nel body
            JsonNode listNode = body.path(annotation.listField());
            if (listNode.isArray()) {
                List<String> remiList = objectMapper.convertValue(listNode,
                        objectMapper.getTypeFactory().constructCollectionType(List.class, String.class));
                if (!cone.allowsAll(remiList)) {
                    LOG.warnf("RemiConeCheck DENIED (body): campo '%s' non completamente nel cono utente",
                            annotation.listField());
                    throw new ForbiddenException("REMI_LIST_NOT_AUTHORIZED");
                }
            }

        } catch (ForbiddenException e) {
            throw e;
        } catch (Exception e) {
            LOG.warnf(e, "RemiConeCheck: errore lettura body, skip validazione remi");
        }
    }

    // =========================================================
    // RESPONSE PHASE
    // =========================================================

    @Override
    public void filter(ContainerRequestContext req, ContainerResponseContext resp) throws IOException {
        RemiConeCheck annotation = getAnnotation();
        if (annotation == null) return;

        if (annotation.mode() == RemiConeCheck.Mode.REQUEST) return;
        if (resp.getStatus() != 200) return;

        Object entity = resp.getEntity();
        if (entity == null) return;

        // Il cono è sempre risolto nella REQUEST phase (resolveAndCache è chiamato prima del check sul mode).
        // Il null-check è solo una guardia difensiva.
        RemiConeDTO cone = (RemiConeDTO) req.getProperty(RemiConeValidationService.PMR_REMI_CONE_PROP);
        if (cone == null) {
            cone = coneValidationService.resolveAndCache(req);
        }
        if (cone.fullAccess()) return;

        try {
            filterResponseEntity(resp, entity, cone, annotation.responseField());
        } catch (Exception e) {
            LOG.warnf(e, "RemiConeCheck: errore filtro response, entità restituita invariata");
        }
    }

    /**
     * Naviga il wrapper {@code GenericResponse} → campo {@code data} (array) e
     * rimuove gli elementi il cui {@code remiAssoluto} non è nel cono.
     * Aggiorna anche {@code numberOfElements}.
     */
    private void filterResponseEntity(ContainerResponseContext resp, Object entity,
            RemiConeDTO cone, String remiField) throws Exception {

        JsonNode tree = objectMapper.valueToTree(entity);
        JsonNode dataNode = tree.path("data");

        if (dataNode.isArray()) {
            filterArrayResponse((ObjectNode) tree, (ArrayNode) dataNode, cone, remiField);
            Map<?, ?> result = objectMapper.convertValue(tree, Map.class);
            resp.setEntity(result, resp.getEntityAnnotations(), MediaType.APPLICATION_JSON_TYPE);
            return;
        }

        if (dataNode.isObject()) {
            filterSingleObjectResponse((ObjectNode) tree, (ObjectNode) dataNode, cone, remiField);
            Map<?, ?> result = objectMapper.convertValue(tree, Map.class);
            resp.setEntity(result, resp.getEntityAnnotations(), MediaType.APPLICATION_JSON_TYPE);
            return;
        }

        LOG.debugf("RemiConeCheck RESPONSE: campo 'data' assente o non compatibile, skip filtro");
    }


    // =========================================================
    // HELPERS
    // =========================================================

    private void filterArrayResponse(ObjectNode tree, ArrayNode dataNode,
            RemiConeDTO cone, String remiField) {

        Set<String> allowed = cone.normalizedSet();
        ArrayNode filtered = objectMapper.createArrayNode();

        for (JsonNode item : dataNode) {
            JsonNode remiNode = item.path(remiField);
            if (!remiNode.isTextual()) {
                filtered.add(item); // safe default invariato
                continue;
            }

            String remiVal = remiNode.asText().trim().toUpperCase(java.util.Locale.ROOT);
            if (allowed.contains(remiVal)) {
                filtered.add(item);
            }
        }

        LOG.debugf("RemiConeCheck RESPONSE ARRAY: da %d a %d elementi dopo filtro cono",
                dataNode.size(), filtered.size());

        tree.set("data", filtered);
        tree.put("numberOfElements", filtered.size());
    }
    
    private void filterSingleObjectResponse(ObjectNode tree, ObjectNode dataNode,
            RemiConeDTO cone, String remiField) {

        JsonNode remiNode = dataNode.path(remiField);

        if (!remiNode.isTextual()) {
            LOG.debugf("RemiConeCheck RESPONSE OBJECT: campo '%s' assente o non testuale, skip filtro",
                    remiField);
            return; // safe default coerente con l'array
        }

        String remiVal = remiNode.asText().trim().toUpperCase(java.util.Locale.ROOT);

        if (cone.normalizedSet().contains(remiVal)) {
            LOG.debugf("RemiConeCheck RESPONSE OBJECT: remi %s autorizzato", remiVal);
            return;
        }

        LOG.debugf("RemiConeCheck RESPONSE OBJECT: remi %s non autorizzato, response svuotata", remiVal);

        tree.putNull("data");
        tree.put("numberOfElements", 0);
    }


    
    private RemiConeCheck getAnnotation() {
        if (resourceInfo == null || resourceInfo.getResourceMethod() == null) return null;
        return AuthzAnnotationCache.getRemiConeCheck(resourceInfo);
    }
}
