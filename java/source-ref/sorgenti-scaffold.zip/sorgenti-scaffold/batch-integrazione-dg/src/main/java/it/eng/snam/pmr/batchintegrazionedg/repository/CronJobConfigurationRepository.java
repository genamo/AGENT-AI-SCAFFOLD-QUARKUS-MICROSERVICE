package it.eng.snam.pmr.batchintegrazionedg.repository;


import java.util.List;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import it.eng.snam.pmr.batchintegrazionedg.domain.CronJobConfiguration;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class CronJobConfigurationRepository implements PanacheRepository<CronJobConfiguration> {

    public CronJobConfiguration findByJobName(String jobName) {
        return find("jobName", jobName).firstResult();
    }

    public List<CronJobConfiguration> listAllJobs() {
        return listAll();
    }
}