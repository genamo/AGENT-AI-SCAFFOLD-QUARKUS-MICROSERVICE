package it.eng.snam.pmr.common.annotation;

import static org.assertj.core.api.Assertions.assertThat;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.reflect.Method;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

import jakarta.ws.rs.NameBinding;

class RemiConeCheckTest {

    @RemiConeCheck
    static class DefaultAnnotatedClass {
    }

    static class CustomAnnotatedClass {
        @RemiConeCheck(
                mode = RemiConeCheck.Mode.RESPONSE,
                singleField = "code",
                listField = "codes",
                queryParam = "code",
                queryListParam = "codes",
                responseField = "meterCode",
                moduleCodes = {"PDM", "ABC"}
        )
        void method() {
        }
    }

    @Test
    void annotation_hasExpectedMetaAnnotations() {
        assertThat(RemiConeCheck.class.getAnnotation(NameBinding.class)).isNotNull();

        Retention retention = RemiConeCheck.class.getAnnotation(Retention.class);
        assertThat(retention).isNotNull();
        assertThat(retention.value().name()).isEqualTo("RUNTIME");

        Target target = RemiConeCheck.class.getAnnotation(Target.class);
        assertThat(target).isNotNull();
        assertThat(Arrays.asList(target.value()))
                .contains(java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.METHOD);
    }

    @Test
    void defaultValues_areCorrect() {
        RemiConeCheck annotation = DefaultAnnotatedClass.class.getAnnotation(RemiConeCheck.class);

        assertThat(annotation).isNotNull();
        assertThat(annotation.mode()).isEqualTo(RemiConeCheck.Mode.REQUEST);
        assertThat(annotation.singleField()).isEqualTo("remiAssoluto");
        assertThat(annotation.listField()).isEqualTo("remiAssoluti");
        assertThat(annotation.queryParam()).isEqualTo("remiAssoluto");
        assertThat(annotation.queryListParam()).isEqualTo("remiAssoluti");
        assertThat(annotation.responseField()).isEqualTo("remiAssoluto");
        assertThat(annotation.moduleCodes()).isEmpty();
    }

    @Test
    void customValues_onMethod_areExposedCorrectly() throws Exception {
        Method method = CustomAnnotatedClass.class.getDeclaredMethod("method");
        RemiConeCheck annotation = method.getAnnotation(RemiConeCheck.class);

        assertThat(annotation).isNotNull();
        assertThat(annotation.mode()).isEqualTo(RemiConeCheck.Mode.RESPONSE);
        assertThat(annotation.singleField()).isEqualTo("code");
        assertThat(annotation.listField()).isEqualTo("codes");
        assertThat(annotation.queryParam()).isEqualTo("code");
        assertThat(annotation.queryListParam()).isEqualTo("codes");
        assertThat(annotation.responseField()).isEqualTo("meterCode");
        assertThat(annotation.moduleCodes()).containsExactly("PDM", "ABC");
    }
}
