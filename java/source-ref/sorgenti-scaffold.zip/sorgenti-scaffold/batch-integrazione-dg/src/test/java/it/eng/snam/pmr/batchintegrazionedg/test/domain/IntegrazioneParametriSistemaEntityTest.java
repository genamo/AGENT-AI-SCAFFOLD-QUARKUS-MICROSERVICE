package it.eng.snam.pmr.batchintegrazionedg.test.domain;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import it.eng.snam.pmr.batchintegrazionedg.domain.IntegrazioneParametriSistema;
import java.time.LocalDate;
import java.time.LocalDateTime;

class IntegrazioneParametriSistemaEntityTest {

    @Test
    void gettersAndSetters_workCorrectly() {
        IntegrazioneParametriSistema e = new IntegrazioneParametriSistema();
        LocalDate today = LocalDate.now();
        LocalDate tomorrow = today.plusDays(1);
        LocalDateTime now = LocalDateTime.now();

        e.setId(100L);
        e.setCodice("PARAM_001");
        e.setValore("valore_test");
        e.setDataInizio(today);
        e.setDataFine(tomorrow);
        e.setActionDate(now);
        e.setUserAction("SYSTEM");
        e.setIsDeleted(0);

        assertEquals(100L, e.getId());
        assertEquals("PARAM_001", e.getCodice());
        assertEquals("valore_test", e.getValore());
        assertEquals(today, e.getDataInizio());
        assertEquals(tomorrow, e.getDataFine());
        assertEquals(now, e.getActionDate());
        assertEquals("SYSTEM", e.getUserAction());
        assertEquals(0, e.getIsDeleted());
    }

    @Test
    void defaultIsDeleted_isZero() {
        IntegrazioneParametriSistema e = new IntegrazioneParametriSistema();
        assertEquals(0, e.getIsDeleted());
    }
}
