package it.eng.snam.pmr.batchintegrazionedg.service;

import java.util.List;

import org.jboss.logging.Logger;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.domain.DlqFlusso;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoRequestDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoResponseDTO;
import it.eng.snam.pmr.batchintegrazionedg.repository.DlqFlussoRepository;
import it.eng.snam.pmr.batchintegrazionedg.service.abstracts.AbstractPersistenceRetryService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.transaction.Transactional.TxType;

@ApplicationScoped
@RunOnVirtualThread
public class DlqFlussoService
        extends AbstractPersistenceRetryService<DlqFlussoRequestDTO, DlqFlussoResponseDTO> {

    private static final Logger LOG = Logger.getLogger(DlqFlussoService.class);

    private static final String DEFAULT_STATUS = "RECEIVED";
    private static final String DEFAULT_USER_ACTION = "SYSTEM";

    @Inject
    DlqFlussoRepository repository;

    public DlqFlussoResponseDTO save(DlqFlussoRequestDTO request) {
        return executeWithRetry(request, this::saveAttempt, "SAVE");
    }

    public List<DlqFlussoDTO> findAllByTransactionId(String transactionId) {
        return repository.findAllByTransactionId(transactionId)
                .stream()
                .map(this::mapToDto)
                .toList();
    }

    public List<DlqFlussoDTO> findByStatus(String status) {
        return repository.findByStatus(status)
                .stream()
                .map(this::mapToDto)
                .toList();
    }

    public List<DlqFlussoDTO> findLatest(int limit) {
        return repository.findLatest(limit)
                .stream()
                .map(this::mapToDto)
                .toList();
    }

    public List<DlqFlussoDTO> findByControlKey(String controlKey) {
        return repository.findByControlKey(controlKey)
                .stream()
                .map(this::mapToDto)
                .toList();
    }

    public long countByControlKey(String controlKey) {
        return repository.countByControlKey(controlKey);
    }

    @Transactional(TxType.REQUIRES_NEW)
    protected DlqFlussoResponseDTO saveAttempt(DlqFlussoRequestDTO request) {
        DlqFlusso entity = mapToEntity(request);

        repository.persistAndFlush(entity);

        return new DlqFlussoResponseDTO(
                true,
                entity.getId(),
                entity.getTransactionId(),
                entity.getStatus()
        );
    }

    private DlqFlusso mapToEntity(DlqFlussoRequestDTO request) {
        DlqFlusso entity = new DlqFlusso();

        entity.setTransactionId(truncate(request.transactionId(), 50));
        entity.setFlowId(truncate(request.flowId(), 50));
        entity.setKeyLogic(truncate(request.keyLogic(), 255));
        entity.setOriginalTopic(truncate(request.originalTopic(), 255));
        entity.setOriginalPartition(request.originalPartition());
        entity.setOriginalOffset(request.originalOffset());
        entity.setProcessType(truncate(request.processType(), 100));
        entity.setMessageKey(truncate(request.messageKey(), 255));
        entity.setErrorType(truncate(request.errorType(), 100));
        entity.setErrorMessage(truncate(request.errorMessage(), 2000));
        entity.setPayload(request.payload());
        entity.setControlKey(truncate(request.controlKey(), 64));

        entity.setStatus(
                request.status() == null || request.status().isBlank()
                        ? DEFAULT_STATUS
                        : request.status()
        );

        entity.setUserAction(DEFAULT_USER_ACTION);
        entity.setIsDeleted(0);

        return entity;
    }

    private DlqFlussoDTO mapToDto(DlqFlusso entity) {
        if (entity == null) {
            return null;
        }

        return new DlqFlussoDTO(
                entity.getId(),
                entity.getTransactionId(),
                entity.getFlowId(),
                entity.getControlKey(),
                entity.getKeyLogic(),
                entity.getOriginalTopic(),
                entity.getOriginalPartition(),
                entity.getOriginalOffset(),
                entity.getProcessType(),
                entity.getMessageKey(),
                entity.getErrorType(),
                entity.getErrorMessage(),
                entity.getPayload(),
                entity.getStatus(),
                entity.getCreatedAt(),
                entity.getUpdatedAt()
        );
    }

    private String truncate(String value, int maxLen) {
        if (value == null) {
            return null;
        }
        return value.length() <= maxLen ? value : value.substring(0, maxLen);
    }

    @Override
    protected Logger logger() {
        return LOG;
    }

    @Override
    protected String transactionIdOf(DlqFlussoRequestDTO request) {
        return request == null ? null : request.transactionId();
    }

    @Override
    protected DlqFlussoResponseDTO fallbackError(DlqFlussoRequestDTO request, String reason) {
        return new DlqFlussoResponseDTO(
                false,
                null,
                request == null ? null : request.transactionId(),
                "ERROR_" + reason
        );
    }

    @Override
    protected String interruptedRetryLogMessage() {
        return "Retry DB DLQ interrotto";
    }
}
