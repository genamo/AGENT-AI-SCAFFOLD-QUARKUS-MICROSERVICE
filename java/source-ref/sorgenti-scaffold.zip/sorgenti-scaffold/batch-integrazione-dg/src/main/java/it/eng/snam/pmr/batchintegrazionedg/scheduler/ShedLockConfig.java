package it.eng.snam.pmr.batchintegrazionedg.scheduler;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import jakarta.inject.Inject;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;

@ApplicationScoped
public class ShedLockConfig {

    @Inject
    DataSource dataSource;

    @Produces
    @ApplicationScoped
    LockProvider lockProvider() {
        return new JdbcTemplateLockProvider(
                JdbcTemplateLockProvider.Configuration.builder()
                        .withJdbcTemplate(new JdbcTemplate(dataSource))
                        .usingDbTime()
                        .build()
        );
    }
}
