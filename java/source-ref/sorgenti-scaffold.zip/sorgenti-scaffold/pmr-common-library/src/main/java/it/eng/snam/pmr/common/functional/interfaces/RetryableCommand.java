package it.eng.snam.pmr.common.functional.interfaces;

@FunctionalInterface
public interface RetryableCommand<T> {

    T execute();

    static RetryableCommand<Void> ofVoid(Runnable runnable) {
        return () -> {
            runnable.run();
            return null;
        };
    }
}
