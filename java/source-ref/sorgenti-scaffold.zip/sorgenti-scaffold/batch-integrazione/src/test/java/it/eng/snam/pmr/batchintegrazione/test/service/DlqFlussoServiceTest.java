package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.List;

import org.jboss.resteasy.reactive.ClientWebApplicationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.DlqFlussoDTO;
import it.eng.snam.pmr.batchintegrazione.dto.DlqFlussoRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.DlqFlussoResponseDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.DlqFlussoService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class DlqFlussoServiceTest {

    @Mock BatchIntegrazioneDgClient client;
    @Mock ObjectMapper objectMapper;
    @Mock RequestHeadersContext headersCtx;

    @InjectMocks
    DlqFlussoService service;

    @BeforeEach
    void setUp() throws Exception {
        setAbstractField("headersCtx", headersCtx);
        setAbstractField("objectMapper", objectMapper);
    }

    private void setAbstractField(String fieldName, Object value) throws Exception {
        Field f = AbstractService.class.getDeclaredField(fieldName);
        f.setAccessible(true);
        f.set(service, value);
    }


    private Response mockResp(int status) {
        Response r = mock(Response.class);
        when(r.getStatus()).thenReturn(status);
        return r;
    }

    private void mockHeadersForRemoteError() {
        when(headersCtx.getKeyLogic()).thenReturn("kl");
        when(headersCtx.getTransactionId()).thenReturn("tx");
        when(headersCtx.getProcessType()).thenReturn("PT");
    }

    @Test
    void save_200_validJson_returnsDto() throws Exception {
        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder().transactionId("tx1").build();

        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("{\"saved\":true,\"id\":1,\"transactionId\":\"tx1\",\"status\":\"NEW\"}");
        when(client.saveDlqFlusso(request)).thenReturn(resp);

        DlqFlussoResponseDTO dto = new DlqFlussoResponseDTO(true, 1L, "tx1", "NEW");
        when(objectMapper.readValue("{\"saved\":true,\"id\":1,\"transactionId\":\"tx1\",\"status\":\"NEW\"}", DlqFlussoResponseDTO.class))
            .thenReturn(dto);

        DlqFlussoResponseDTO result = service.save(request);

        assertEquals(true, result.saved());
        assertEquals(1L, result.id());
        assertEquals("tx1", result.transactionId());
        assertEquals("NEW", result.status());
    }

    @Test
    void save_200_blankBody_throwsRemoteCallException() {
        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder().transactionId("tx1").build();

        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn(" ");
        when(client.saveDlqFlusso(request)).thenReturn(resp);

        RemoteCallException ex = assertThrows(RemoteCallException.class, () -> service.save(request));
        assertTrue(ex.getMessage().contains("Risposta vuota da dlq-flussi/save"));
    }

    @Test
    void save_400_blankBody_throwsIllegalArgumentException() {
        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder().transactionId("tx1").build();

        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.saveDlqFlusso(request)).thenReturn(resp);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> service.save(request));
        assertEquals("DLQ save 400: Bad Request", ex.getMessage());
    }

    @Test
    void save_500_throwsRemoteCallException() {
        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder().transactionId("tx1").build();

        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.saveDlqFlusso(request)).thenReturn(resp);

        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.save(request));
    }

    @Test
    @SuppressWarnings("unchecked")
    void findByTransactionId_200_validJson_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(client.findDlqFlussiByTransactionId("tx1")).thenReturn(resp);

        DlqFlussoDTO dto = DlqFlussoDTO.builder().transactionId("tx1").flowId("PMR001A").build();
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(dto));

        List<DlqFlussoDTO> result = service.findByTransactionId("tx1");

        assertEquals(1, result.size());
        assertEquals("tx1", result.get(0).transactionId());
    }

    @Test
    void findByTransactionId_200_blankJson_returnsEmpty() {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("");
        when(client.findDlqFlussiByTransactionId("tx1")).thenReturn(resp);

        assertTrue(service.findByTransactionId("tx1").isEmpty());
    }

    @Test
    void findByTransactionId_404_returnsEmpty() {
        Response resp = mockResp(404);
        when(client.findDlqFlussiByTransactionId("tx1")).thenReturn(resp);

        assertTrue(service.findByTransactionId("tx1").isEmpty());
    }

    @Test
    void findByTransactionId_400_throwsIllegalArgumentException() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findDlqFlussiByTransactionId("tx1")).thenReturn(resp);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
            () -> service.findByTransactionId("tx1"));
        assertEquals("DLQ search by transactionId 400: Bad Request", ex.getMessage());
    }

    @Test
    void findByTransactionId_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findDlqFlussiByTransactionId("tx1")).thenReturn(resp);

        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.findByTransactionId("tx1"));
    }

    @Test
    void findByTransactionId_client404Exception_returnsEmpty() {
        Response r404 = mockResp(404);

        ClientWebApplicationException ex = mock(ClientWebApplicationException.class);
        when(ex.getResponse()).thenReturn(r404);
        when(client.findDlqFlussiByTransactionId("tx1")).thenThrow(ex);

        assertTrue(service.findByTransactionId("tx1").isEmpty());
    }

    @Test
    void findByTransactionId_clientExceptionWithNullResponse_rethrows() {
        ClientWebApplicationException ex = mock(ClientWebApplicationException.class);
        when(ex.getResponse()).thenReturn(null);
        when(client.findDlqFlussiByTransactionId("tx1")).thenThrow(ex);

        assertThrows(ClientWebApplicationException.class, () -> service.findByTransactionId("tx1"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void findByControlKey_200_validJson_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(client.findDlqFlussiByControlKey("ck1")).thenReturn(resp);

        DlqFlussoDTO dto = DlqFlussoDTO.builder().controlKey("ck1").build();
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(dto));

        List<DlqFlussoDTO> result = service.findByControlKey("ck1");

        assertEquals(1, result.size());
        assertEquals("ck1", result.get(0).controlKey());
    }

    @Test
    void findByControlKey_404_returnsEmpty() {
        Response resp = mockResp(404);
        when(client.findDlqFlussiByControlKey("ck1")).thenReturn(resp);

        assertTrue(service.findByControlKey("ck1").isEmpty());
    }

    @Test
    void findByControlKey_400_throwsIllegalArgumentException() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findDlqFlussiByControlKey("ck1")).thenReturn(resp);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
            () -> service.findByControlKey("ck1"));
        assertEquals("DLQ search by controlKey 400: Bad Request", ex.getMessage());
    }

    @Test
    void findByControlKey_client500Exception_rethrows() {
        ClientWebApplicationException ex = mock(ClientWebApplicationException.class);
        Response r500 = mockResp(500);
        when(ex.getResponse()).thenReturn(r500);
        when(client.findDlqFlussiByControlKey("ck1")).thenThrow(ex);

        assertThrows(ClientWebApplicationException.class, () -> service.findByControlKey("ck1"));
    }

    @Test
    void countByControlKey_200_jsonLong_returnsValue() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("5");
        when(client.countDlqFlussiByControlKey("ck1")).thenReturn(resp);
        when(objectMapper.readValue("5", Long.class)).thenReturn(5L);

        assertEquals(5L, service.countByControlKey("ck1"));
    }

    @Test
    void countByControlKey_200_blankBody_returnsZero() {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn(" ");
        when(client.countDlqFlussiByControlKey("ck1")).thenReturn(resp);

        assertEquals(0L, service.countByControlKey("ck1"));
    }

    @Test
    void countByControlKey_200_fallbackParseLong_returnsValue() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn(" 15 ");
        when(client.countDlqFlussiByControlKey("ck1")).thenReturn(resp);
        when(objectMapper.readValue(" 15 ", Long.class)).thenThrow(new RuntimeException("boom"));

        assertEquals(15L, service.countByControlKey("ck1"));
    }

    @Test
    void countByControlKey_200_invalidBody_throwsRemoteCallException() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("abc");
        when(client.countDlqFlussiByControlKey("ck1")).thenReturn(resp);
        when(objectMapper.readValue("abc", Long.class)).thenThrow(new RuntimeException("boom"));

        assertThrows(RemoteCallException.class, () -> service.countByControlKey("ck1"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void findByStatus_200_validJson_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(client.findDlqFlussiByStatus("ERROR")).thenReturn(resp);

        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class)))
            .thenReturn(List.of(DlqFlussoDTO.builder().status("ERROR").build()));

        assertEquals(1, service.findByStatus("ERROR").size());
    }

    @Test
    void findByStatus_400_throwsIllegalArgumentException() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findDlqFlussiByStatus("ERROR")).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.findByStatus("ERROR"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void findLatest_200_validJson_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(client.findLatestDlqFlussi(10)).thenReturn(resp);

        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class)))
            .thenReturn(List.of(DlqFlussoDTO.builder().id(1L).build()));

        assertEquals(1, service.findLatest(10).size());
    }

    @Test
    void findLatest_400_throwsIllegalArgumentException() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findLatestDlqFlussi(10)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.findLatest(10));
    }

    @Test
    void findLatest_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findLatestDlqFlussi(10)).thenReturn(resp);

        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.findLatest(10));
    }
}
