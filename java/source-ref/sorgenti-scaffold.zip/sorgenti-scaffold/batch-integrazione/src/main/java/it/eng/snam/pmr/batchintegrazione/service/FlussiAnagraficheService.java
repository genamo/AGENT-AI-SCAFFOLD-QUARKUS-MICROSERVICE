package it.eng.snam.pmr.batchintegrazione.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class FlussiAnagraficheService extends AbstractService {

    @Inject
    FlussoRegistry registry;
    

	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");


    public void process(String flow, String payload) {
    	String timestamp = LocalDateTime.now().format(FORMATTER);
    	if(headersCtx.getTransactionId() == null) {
    		headersCtx.setTransactionId(flow + "_" + timestamp);	
    	}
    	
    	var handler = registry.get(flow);
        
        if (handler == null) {
            throw new IllegalArgumentException("Flow non gestito: " + flow);
        }

        handler.process(payload);
    }
}