package it.eng.snam.pmr.common.dto;

import java.time.Instant;

public record UserCustomerOrganizationDTO(
        Long organizationId,
        Long organizationCode,
        String roleDescription,
        Long flowId,
        Long entityId,
        Instant datastamp,
        String customerOrganizationCode,
        String telephoneNumber,
        String userCode,
        Long userCustomerOrganizationId,
        String positionDescription,
        String userTypeDescription,
        String pkSource,
        Integer denominatore,
        Integer penalita,
        String idErrore,
        String userTypeCode,
        String userDescription,
        Integer cancelledFlag
) {}
