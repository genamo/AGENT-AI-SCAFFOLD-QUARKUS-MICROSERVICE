package it.eng.snam.pmr.common.response.swagger;

import java.io.Serial;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import it.eng.snam.pmr.common.response.GenericResponse;

@Schema(name = "StringResponse")
public class StringResponse extends GenericResponse<String> {
    @Serial
    private static final long serialVersionUID = 378272888596814445L;
}
