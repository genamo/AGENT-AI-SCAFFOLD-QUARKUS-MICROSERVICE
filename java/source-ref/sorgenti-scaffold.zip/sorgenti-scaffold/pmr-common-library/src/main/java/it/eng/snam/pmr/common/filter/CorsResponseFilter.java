package it.eng.snam.pmr.common.filter;

import java.io.IOException;
import java.util.Optional;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.annotation.Priority;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.ext.Provider;

@Provider
@Priority(Priorities.HEADER_DECORATOR)
public class CorsResponseFilter implements ContainerResponseFilter {

    public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

    @ConfigProperty(name = "pmr.cors.allow-origin")
    Optional<String> allowOrigin;

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException {
        allowOrigin
            .map(String::trim)
            .filter(value -> !value.isEmpty())
            .ifPresent(value -> responseContext.getHeaders().putSingle(ACCESS_CONTROL_ALLOW_ORIGIN, value));
    }
}
