package it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration;

import java.io.Serial;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class MonitoringIntegrationOutcome extends MonitoringIntegration {

    @Serial
    private static final long serialVersionUID = -6189147615010664613L;

    private Integer responseStatusCode;
    private String responseStatus;
    private String responseBody;
    private String contentType;
}
