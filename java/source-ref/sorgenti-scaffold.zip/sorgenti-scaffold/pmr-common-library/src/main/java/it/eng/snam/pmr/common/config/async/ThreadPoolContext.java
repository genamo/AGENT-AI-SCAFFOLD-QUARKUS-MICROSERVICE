package it.eng.snam.pmr.common.config.async;

import java.util.concurrent.ThreadFactory;

import lombok.Value;

@Value(staticConstructor = "of")
public class ThreadPoolContext {

    int corePoolSize;
    int maximumPoolSize;
    long keepAliveTime;
    int queueCapacity;
    ThreadFactory threadFactory;
}
