package it.eng.snam.pmr.batchintegrazione.service.handler;

import java.time.format.DateTimeFormatter;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AssStatoRemiPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AssStatoRemiHandler extends AbstractFlussoHandler<AssStatoRemiPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AssStatoRemiPayloadDto> getDtoClass() {
        return AssStatoRemiPayloadDto.class;
    }

    @Override
    protected void handle(AssStatoRemiPayloadDto dto) {
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAssStatoRemi(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
					if(dto.data().getFirst().dataEvento() == null) {
						throw new IllegalArgumentException("dataEvento field is required for DELETE operation");
					}else {
						String dataEvento = null;
						try {
							dataEvento = dto.data().getFirst().dataEvento().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
						} catch (Exception e) {
							throw new IllegalArgumentException("dataEvento field must be in ISO_LOCAL_DATE_TIME format");
						}
						anagraficheService.deleteAssStatoRemi(dto.data().getFirst().remiAssoluto(), dataEvento);
					}
						
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}	
    	
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ASS_STATO_REMI_FLOW;
    }
}