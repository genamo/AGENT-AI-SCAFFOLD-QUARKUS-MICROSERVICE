package it.eng.snam.pmr.batchintegrazione.utils.blob.storage;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.CompletionException;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.models.BlobHttpHeaders;

import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.FileDataContext;
import it.eng.snam.pmr.batchintegrazione.exception.BlobUploadException;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class BlobStorageExecutor {

    public void upload(FileDataContext resource, BlobClient blobClient) {
        try (InputStream inputStream = resource.getInputStream();
             OutputStream blobOutputStream = blobClient.getBlockBlobClient().getBlobOutputStream(true)) {
            byte[] buffer = BlobUploadProperties.BUFFER;
            int read;

            while ((read = inputStream.read(buffer)) != -1)
                blobOutputStream.write(buffer, 0, read);

            blobOutputStream.flush();
        } catch (Exception e) {
            BlobEliminator.eliminate(blobClient, e);
            log.error("Error while writing blob stream: {}", e.getMessage());
            throw new BlobUploadException("Error while writing blob stream: " + e.getMessage(), e);
        }
    }

    public void verifyWriterCompleted(FileDataContext resource, BlobClient blobClient) {
        if (resource.getWriterFuture() == null)
            return;

        try {
            resource.getWriterFuture().join();
        } catch (CompletionException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            BlobEliminator.eliminate(blobClient, cause);
            log.error("ZIP writer verification failed: {}", cause.getMessage());
            throw new BlobUploadException("ZIP writer verification failed: " + cause.getMessage(), cause);
        }
    }

    public void applyBlobProperties(FileDataContext resource, BlobClient blobClient) {
        try {
            if (resource.getContentType() != null)
                blobClient.setHttpHeaders(new BlobHttpHeaders().setContentType(resource.getContentType()));

            if (resource.getMetadata() != null && !resource.getMetadata().isEmpty())
                blobClient.setMetadata(resource.getMetadata());
        } catch (Exception e) {
            BlobEliminator.eliminate(blobClient, e);
            log.error("Blob uploaded but failed while setting metadata: {}", e.getMessage());
            throw new BlobUploadException("Blob uploaded but failed while setting metadata: " + e.getMessage(), e);
        }
    }
}
