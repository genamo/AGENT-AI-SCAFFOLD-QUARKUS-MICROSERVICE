package it.eng.snam.pmr.common.filter;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import it.eng.snam.pmr.common.annotation.AuthzRead;
import it.eng.snam.pmr.common.annotation.UserType;
import it.eng.snam.pmr.common.cache.AuthzAnnotationCache;
import it.eng.snam.pmr.common.service.AuthzService;
import it.eng.snam.pmr.common.service.RemiConeValidationService;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.UriInfo;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AuthzReadFilterTest {

    @Mock ContainerRequestContext req;
    @Mock ResourceInfo resourceInfo;
    @Mock AuthzService authzService;
    @Mock UriInfo uriInfo;

    AuthzReadFilter filter;

    @AuthzRead(userType = UserType.INTERNAL)
    @Path("/res")
    static class AnnotatedClass {
        public void doStuff() {}
    }

    static class NoAnnotationClass {
        public void doStuff() {}
    }

    static class MethodAnnotatedClass {
        @AuthzRead(userType = UserType.EXTERNAL)
        @Path("/method-res")
        public void annotatedMethod() {}
    }

    @BeforeEach
    void setUp() throws Exception {
        filter = new AuthzReadFilter();
        setField(filter, "resourceInfoRead", resourceInfo);
        setField(filter, "authzServiceRead", authzService);
        setField(filter, "securityEnabledRead", true);

        clearAuthzCache();

        when(req.getMethod()).thenReturn("GET");
        when(req.getUriInfo()).thenReturn(uriInfo);
        when(uriInfo.getRequestUri()).thenReturn(URI.create("http://test/api/res"));
        when(req.getHeaderString("Authorization")).thenReturn(null);
    }

    @Test
    void filter_securityDisabled_skipsAuthorization() throws Exception {
        setField(filter, "securityEnabledRead", false);
        filter.filter(req);
        verify(authzService, never()).assertAuthorized(anyString(), any(), any());
    }

    @Test
    void filter_resourceInfoNull_skipsAuthorization() throws Exception {
        setField(filter, "resourceInfoRead", null);
        filter.filter(req);
        verify(authzService, never()).assertAuthorized(anyString(), any(), any());
    }

    @Test
    void filter_resourceMethodNull_skipsAuthorization() throws Exception {
        when(resourceInfo.getResourceMethod()).thenReturn(null);
        filter.filter(req);
        verify(authzService, never()).assertAuthorized(anyString(), any(), any());
    }

    @Test
    void filter_noAnnotation_skipsAuthorization() throws Exception {
        Method m = NoAnnotationClass.class.getMethod("doStuff");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        when(resourceInfo.getResourceClass()).thenAnswer(i -> NoAnnotationClass.class);
        filter.filter(req);
        verify(authzService, never()).assertAuthorized(anyString(), any(), any());
    }

    @Test
    void filter_annotationOnClass_callsAssertAuthorized() throws Exception {
        Method m = AnnotatedClass.class.getMethod("doStuff");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        when(resourceInfo.getResourceClass()).thenAnswer(i -> AnnotatedClass.class);
        filter.filter(req);
        verify(authzService).assertAuthorized(anyString(), eq(AuthzService.Permit.READ), eq(UserType.INTERNAL));
    }

    @Test
    void filter_annotationOnMethod_callsAssertAuthorized() throws Exception {
        Method m = MethodAnnotatedClass.class.getMethod("annotatedMethod");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        when(resourceInfo.getResourceClass()).thenAnswer(i -> MethodAnnotatedClass.class);
        filter.filter(req);
        verify(authzService).assertAuthorized(anyString(), eq(AuthzService.Permit.READ), eq(UserType.EXTERNAL));
    }

    private static void setField(Object obj, String name, Object value) throws Exception {
        Field f = findField(obj.getClass(), name);
        f.setAccessible(true);
        f.set(obj, value);
    }

    private static Field findField(Class<?> clazz, String name) throws NoSuchFieldException {
        try { return clazz.getDeclaredField(name); }
        catch (NoSuchFieldException e) {
            if (clazz.getSuperclass() != null) return findField(clazz.getSuperclass(), name);
            throw e;
        }
    }

    @SuppressWarnings("unchecked")
    private static void clearAuthzCache() throws Exception {
        Field f = AuthzAnnotationCache.class.getDeclaredField("CACHE");
        f.setAccessible(true);
        ((Map<?, ?>) f.get(null)).clear();
    }
    
    @Test
    void filter_annotationOnMethod_propagatesUserTypeForDownstreamFilters() throws Exception {
        Method m = MethodAnnotatedClass.class.getMethod("annotatedMethod");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        when(resourceInfo.getResourceClass()).thenAnswer(i -> MethodAnnotatedClass.class);

        filter.filter(req);

        verify(req).setProperty(
                RemiConeValidationService.PMR_USER_TYPE_PROP,
                UserType.EXTERNAL.name()
        );
    }

}
