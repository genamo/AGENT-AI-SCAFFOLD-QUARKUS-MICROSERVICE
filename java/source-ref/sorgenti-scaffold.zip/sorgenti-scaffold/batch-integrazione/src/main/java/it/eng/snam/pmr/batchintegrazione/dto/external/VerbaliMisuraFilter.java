package it.eng.snam.pmr.batchintegrazione.dto.external;

import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.YearMonth;

@Data
@NoArgsConstructor
public class VerbaliMisuraFilter {

    @QueryParam("codiceCliente")
    private String codiceCliente;

    @QueryParam("codiceRemi")
    private String codiceRemi;

    @QueryParam("periodoRiferimentoDa")
    private YearMonth periodoRiferimentoDa;

    @QueryParam("periodoRiferimentoA")
    private YearMonth periodoRiferimentoA;

    @QueryParam("dataEmissioneDa")
    private LocalDate dataEmissioneDa;

    @QueryParam("dataEmissioneA")
    private LocalDate dataEmissioneA;

}