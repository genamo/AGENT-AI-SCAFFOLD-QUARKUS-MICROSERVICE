package it.eng.snam.pmr.batchintegrazione.service;

import java.util.List;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.IntegrazioneParametriSistemaDTO;
import it.eng.snam.pmr.batchintegrazione.dto.ParametriSistemaRequestSearch;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class ParametriService extends AbstractService {

    private static final Logger LOG =
            Logger.getLogger(ParametriService.class);

    @Inject
    @RestClient
    BatchIntegrazioneDgClient client;

    @Inject
    ObjectMapper objectMapper;

    /**
     * Chiamata remota POST /parametri-sistema/search
     *
     * Server ritorna:
     * - 200 OK + body(List<DTO>)
     * - 204 NO CONTENT (lista vuota)
     * - 400 BAD REQUEST
     */
    public List<IntegrazioneParametriSistemaDTO> searchParametri(
            ParametriSistemaRequestSearch request
    ) {

        try (Response resp = client.searchParametri(request)) {

            int status = resp.getStatus();

            if (status == Response.Status.NO_CONTENT.getStatusCode()) {
                return List.of();
            }

            if (status == Response.Status.OK.getStatusCode()) {
                String json = resp.readEntity(String.class);
                return readList(json);
            }

            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                String body = safeReadBody(resp);
                throw new IllegalArgumentException(
                        "ParametriSistema search 400: " +
                                (body.isBlank() ? "Bad Request" : body)
                );
            }

            throw remoteError(
                    "POST /parametri-sistema/search",
                    status,
                    resp
            );
        }
    }

    // =========================
    // Helpers
    // =========================

    private List<IntegrazioneParametriSistemaDTO> readList(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return objectMapper.readValue(
                    json,
                    new TypeReference<List<IntegrazioneParametriSistemaDTO>>() {}
            );
        } catch (Exception e) {
            throw new RemoteCallException(
                    "Impossibile deserializzare lista IntegrazioneParametriSistemaDTO",
                    e
            );
        }
    }
}