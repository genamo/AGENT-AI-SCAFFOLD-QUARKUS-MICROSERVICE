package it.eng.snam.pmr.common.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class GenericException extends RuntimeException {
    @Serial
    private static final long serialVersionUID = -5089332088896177974L;
}
