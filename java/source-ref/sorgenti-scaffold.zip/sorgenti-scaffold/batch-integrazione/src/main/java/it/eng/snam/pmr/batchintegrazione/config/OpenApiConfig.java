package it.eng.snam.pmr.batchintegrazione.config;

import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.enums.ParameterIn;
import org.eclipse.microprofile.openapi.annotations.enums.SecuritySchemeType;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;
import org.eclipse.microprofile.openapi.annotations.security.SecurityScheme;
import org.eclipse.microprofile.openapi.annotations.servers.Server;

import jakarta.ws.rs.ApplicationPath;

@ApplicationPath("/")   // ✅ FONDAMENTALE
@OpenAPIDefinition(
    info = @Info(
        title = "Batch Integrazione API",
        version = "1.0"
    ),

    servers = @Server(url = "/"),

    // ✅ security globale
    security = @SecurityRequirement(name = "bearerAuth"),

    components = @org.eclipse.microprofile.openapi.annotations.Components(
        parameters = {
            @Parameter(name = "keyLogic", in = ParameterIn.HEADER),
            @Parameter(name = "transactionId", in = ParameterIn.HEADER),
            @Parameter(name = "modAsync", in = ParameterIn.HEADER),
            @Parameter(name = "processType", in = ParameterIn.HEADER)
        }
    )
)

@SecurityScheme(
    securitySchemeName = "bearerAuth",
    type = SecuritySchemeType.HTTP,
    scheme = "bearer",
    bearerFormat = "JWT"
)
public class OpenApiConfig {
}
