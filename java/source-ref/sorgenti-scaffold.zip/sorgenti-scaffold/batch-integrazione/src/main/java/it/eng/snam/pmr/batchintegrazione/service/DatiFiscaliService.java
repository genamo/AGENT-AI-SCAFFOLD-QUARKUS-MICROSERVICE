package it.eng.snam.pmr.batchintegrazione.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.DatiFiscaliClient;
import it.eng.snam.pmr.batchintegrazione.dto.datifiscali.VerbaliMisuraDto;
import it.eng.snam.pmr.batchintegrazione.dto.datifiscali.VerbaliMisuraGiornDto;
import it.eng.snam.pmr.batchintegrazione.dto.datifiscali.VerbaliMisuraGiornSearchDto;
import it.eng.snam.pmr.batchintegrazione.dto.datifiscali.VerbaliMisuraSearchDto;
import it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration.DateRiepiloghiDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.B2BTokenUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class DatiFiscaliService extends AbstractService {

    private static final Logger LOG = Logger.getLogger(DatiFiscaliService.class);

    @Inject
    @RestClient
    DatiFiscaliClient datiFiscaliClient;

    @Inject
    ObjectMapper objectMapper;

    @Inject
    B2BTokenUtils tokenUtil;

    // ======================================================
    // MONITORING INTEGRATION
    // ======================================================

    public DateRiepiloghiDTO saveDateRiepiloghi(DateRiepiloghiDTO dto) {
        try (Response resp = datiFiscaliClient.saveDateRiepiloghi(dto)) {
            return handleSaveRespDatiFiscali(resp, DateRiepiloghiDTO.class);
        }
    }

    // ======================================================
    // VERBALI MISURA
    // ======================================================

    public List<VerbaliMisuraSearchDto> getAllVerbaliMisura() {
        try (Response resp = datiFiscaliClient.getAllVerbaliMisura()) {
            return handleListRespDatiFiscali(resp, new TypeReference<>() {});
        }
    }

    public Optional<VerbaliMisuraSearchDto> findVerbaleMisuraById(
            String remiAssoluto,
            LocalDateTime dataInitVerbale) {
        try (Response resp = datiFiscaliClient.findVerbaleMisuraById(remiAssoluto, dataInitVerbale)) {
            return handleOptionalRespDatiFiscali(resp, VerbaliMisuraSearchDto.class);
        }
    }

    public VerbaliMisuraDto saveVerbaleMisura(VerbaliMisuraDto dto) {
        try (Response resp = datiFiscaliClient.saveVerbaleMisura(dto)) {
            return handleSaveRespDatiFiscali(resp, VerbaliMisuraDto.class);
        }
    }

    public VerbaliMisuraDto deleteVerbaleMisura(
            String remiAssoluto,
            LocalDateTime dataInitVerbale) {
        try (Response resp = datiFiscaliClient.deleteVerbaleMisura(remiAssoluto, dataInitVerbale)) {
            return handleSaveRespDatiFiscali(resp, VerbaliMisuraDto.class);
        }
    }

    public VerbaliMisuraDto restoreVerbaleMisura(
            String remiAssoluto,
            LocalDateTime dataInitVerbale) {
        try (Response resp = datiFiscaliClient.restoreVerbaleMisura(remiAssoluto, dataInitVerbale)) {
            return handleSaveRespDatiFiscali(resp, VerbaliMisuraDto.class);
        }
    }

    // ======================================================
    // VERBALI MISURA GIORN
    // ======================================================

    public List<VerbaliMisuraGiornSearchDto> getAllVerbaliMisuraGiorn() {
        try (Response resp = datiFiscaliClient.getAllVerbaliMisuraGiorn()) {
            return handleListRespDatiFiscali(resp, new TypeReference<>() {});
        }
    }

    public Optional<VerbaliMisuraGiornSearchDto> findVerbaleMisuraGiornById(
            String remiAssoluto,
            LocalDateTime dataVolPunta,
            LocalDateTime dataIniVerb) {
        try (Response resp = datiFiscaliClient.findVerbaleMisuraGiornById(
                remiAssoluto,
                dataVolPunta,
                dataIniVerb)) {
            return handleOptionalRespDatiFiscali(resp, VerbaliMisuraGiornSearchDto.class);
        }
    }

    public VerbaliMisuraGiornDto saveVerbaleMisuraGiorn(VerbaliMisuraGiornDto dto) {
        try (Response resp = datiFiscaliClient.saveVerbaleMisuraGiorn(dto)) {
            return handleSaveRespDatiFiscali(resp, VerbaliMisuraGiornDto.class);
        }
    }

    public VerbaliMisuraGiornDto deleteVerbaleMisuraGiorn(
            String remiAssoluto,
            LocalDateTime dataVolPunta,
            LocalDateTime dataIniVerb) {
        try (Response resp = datiFiscaliClient.deleteVerbaleMisuraGiorn(
                remiAssoluto,
                dataVolPunta,
                dataIniVerb)) {
            return handleSaveRespDatiFiscali(resp, VerbaliMisuraGiornDto.class);
        }
    }

    public VerbaliMisuraGiornDto restoreVerbaleMisuraGiorn(
            String remiAssoluto,
            LocalDateTime dataVolPunta,
            LocalDateTime dataIniVerb) {
        try (Response resp = datiFiscaliClient.restoreVerbaleMisuraGiorn(
                remiAssoluto,
                dataVolPunta,
                dataIniVerb)) {
            return handleSaveRespDatiFiscali(resp, VerbaliMisuraGiornDto.class);
        }
    }

    // ======================================================
    // Helpers generici
    // ======================================================

    private <T> List<T> handleListRespDatiFiscali(Response respDatiFiscali, TypeReference<List<T>> refDatiFiscali) {
        int status = respDatiFiscali.getStatus();

        if (status == Response.Status.NO_CONTENT.getStatusCode()) {
            return List.of();
        }
        if (status == Response.Status.OK.getStatusCode()) {
            String json = respDatiFiscali.readEntity(String.class);
            if (json == null || json.isBlank()) {
                return List.of();
            }
            try {
                return objectMapper.readValue(json, refDatiFiscali);
            } catch (Exception e) {
                throw new RemoteCallException("Impossibile deserializzare la risposta", e);
            }
        }
        if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
            String body = safeReadBody(respDatiFiscali);
            throw new IllegalArgumentException("Richiesta non valida: " + extractErrorDetail(body));
        }
        throw remoteError("dati-fiscali", status, respDatiFiscali);
    }

    private <T> Optional<T> handleOptionalRespDatiFiscali(Response respDatiFiscali, Class<T> typeDatiFiscali) {
        int status = respDatiFiscali.getStatus();

        if (status == Response.Status.NOT_FOUND.getStatusCode()
                || status == Response.Status.NO_CONTENT.getStatusCode()) {
            return Optional.empty();
        }
        if (status == Response.Status.OK.getStatusCode()) {
            return Optional.ofNullable(respDatiFiscali.readEntity(typeDatiFiscali));
        }
        if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
            String body = safeReadBody(respDatiFiscali);
            throw new IllegalArgumentException("Richiesta non valida: " + extractErrorDetail(body));
        }
        throw remoteError("dati-fiscali", status, respDatiFiscali);
    }

    private <T> T handleSaveRespDatiFiscali(Response respDatiFiscali, Class<T> typeDatiFiscali) {
        int status = respDatiFiscali.getStatus();

        if (status == Response.Status.OK.getStatusCode()
                || status == Response.Status.CREATED.getStatusCode()) {
            return respDatiFiscali.readEntity(typeDatiFiscali);
        }
        if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
            String body = safeReadBody(respDatiFiscali);
            throw new IllegalArgumentException("Richiesta non valida: " + extractErrorDetail(body));
        }
        throw remoteError("dati-fiscali", status, respDatiFiscali);
    }
}
