package it.eng.snam.pmr.batchintegrazione.test.service.external;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.client.external.SummerPmrIntegrationClient;
import it.eng.snam.pmr.batchintegrazione.dto.external.AssoMailRemiDTO;
import it.eng.snam.pmr.batchintegrazione.dto.external.AssoMailRemiFilter;
import it.eng.snam.pmr.batchintegrazione.dto.external.MailMonitoraggioVerbaliMisuraDTO;
import it.eng.snam.pmr.batchintegrazione.dto.external.MailMonitoraggioVerbaliMisuraFilter;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.external.SummerPmrIntegrationService;
import it.eng.snam.pmr.common.util.JsonUtils;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class SummerPmrIntegrationServiceTest {

    @Mock
    private SummerPmrIntegrationClient client;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private RequestHeadersContext headersCtx;

    @InjectMocks
    private SummerPmrIntegrationService service;

    private AssoMailRemiFilter filter;

    @BeforeEach
    void setUp() {
        filter = new AssoMailRemiFilter();
    }

    @Test
    void findRemiByIdMail_shouldReturnList_whenClientReturnsOk() throws Exception {
        List<String> expected = List.of("TEST");
        String json = JsonUtils.writeAsJsonPrettyLogStringWithoutNull(expected);

        Response response = mock(Response.class);

        when(client.findRemiByIdMail(any())).thenReturn(response);
        when(response.getStatus()).thenReturn(Response.Status.OK.getStatusCode());
        when(response.hasEntity()).thenReturn(true);
        when(response.readEntity(String.class)).thenReturn(json);
        lenient().when(objectMapper.readValue(eq(json), any(TypeReference.class))).thenReturn(expected);

        List<String> actual = service.findRemiByIdMail(1L);

        assertEquals(expected.getFirst(), actual.getFirst());

        verify(client).findRemiByIdMail(any());
        verify(response).getStatus();
        verify(response).readEntity(String.class);
    }

    @Test
    void filteredSearch_shouldReturnList_whenClientReturnsOk() throws Exception {
        String json = "[{\"idMail\":1}]";

        Response response = mock(Response.class);
        List<AssoMailRemiDTO> expected = List.of(new AssoMailRemiDTO());

        when(client.filteredSearch(filter)).thenReturn(response);
        when(response.getStatus()).thenReturn(Response.Status.OK.getStatusCode());
        when(response.hasEntity()).thenReturn(true);
        when(response.readEntity(String.class)).thenReturn(json);
        lenient().when(objectMapper.readValue(eq(json), any(TypeReference.class))).thenReturn(expected);

        List<AssoMailRemiDTO> actual = service.filteredSearch(filter);

        verify(client).filteredSearch(filter);
        verify(response).getStatus();
        verify(response).readEntity(String.class);
    }

    @Test
    void filteredSearch_shouldThrowIllegalArgumentException_whenClientReturnsBadRequest() {
        Response response = mock(Response.class);

        when(client.filteredSearch(filter)).thenReturn(response);
        when(response.getStatus()).thenReturn(Response.Status.BAD_REQUEST.getStatusCode());
        when(response.hasEntity()).thenReturn(true);
        when(response.readEntity(String.class)).thenReturn("Filtro non valido");

        BadRequestException ex = assertThrows(BadRequestException.class, () -> service.filteredSearch(filter));

        assertTrue(ex.getMessage().contains("illegal request"));

        verify(client).filteredSearch(filter);
    }

    @Test
    void filteredSearch_shouldThrowInternalServerErrorException_whenClientReturnsServerError() {
        Response response = mock(Response.class);

        when(client.filteredSearch(filter)).thenReturn(response);
        when(response.getStatus()).thenReturn(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());
        when(response.hasEntity()).thenReturn(true);
        when(response.readEntity(String.class)).thenReturn("Errore remoto");

        InternalServerErrorException ex = assertThrows(InternalServerErrorException.class,
                                                       () -> service.filteredSearch(filter));

        assertTrue(ex.getMessage().contains("internal server error"));

        verify(client).filteredSearch(filter);
    }

    @Test
    void filteredSearch_withMailMonitoraggioVerbaliMisuraFilter_shouldReturnList_whenClientReturnsOk() throws Exception {
        String json = "[{\"identificativoMailVerble\":2}]";
        MailMonitoraggioVerbaliMisuraFilter mailMonitoraggioVerbaliMisuraFilter = new MailMonitoraggioVerbaliMisuraFilter();

        Response response = mock(Response.class);
        List<MailMonitoraggioVerbaliMisuraDTO> expected = List.of(new MailMonitoraggioVerbaliMisuraDTO());

        when(client.filteredSearch(mailMonitoraggioVerbaliMisuraFilter)).thenReturn(response);
        when(response.hasEntity()).thenReturn(true);
        when(response.getStatus()).thenReturn(Response.Status.OK.getStatusCode());
        when(response.readEntity(String.class)).thenReturn(json);
        lenient().when(objectMapper.readValue(eq(json), any(TypeReference.class))).thenReturn(expected);

        List<MailMonitoraggioVerbaliMisuraDTO> actual = service.filteredSearch(mailMonitoraggioVerbaliMisuraFilter);

        verify(client).filteredSearch(mailMonitoraggioVerbaliMisuraFilter);
        verify(response).getStatus();
        verify(response).readEntity(String.class);
    }
}