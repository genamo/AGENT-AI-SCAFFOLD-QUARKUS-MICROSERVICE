package it.eng.snam.pmr.common.filter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.common.annotation.RemiConeCheck;
import it.eng.snam.pmr.common.cache.AuthzAnnotationCache;
import it.eng.snam.pmr.common.dto.RemiConeDTO;
import it.eng.snam.pmr.common.service.RemiConeValidationService;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.UriInfo;

@ExtendWith(MockitoExtension.class)
class RemiConeCheckFilterTest {

    @Mock
    ContainerRequestContext req;

    @Mock
    ContainerResponseContext resp;

    @Mock
    ResourceInfo resourceInfo;

    @Mock
    UriInfo uriInfo;

    @Mock
    RemiConeValidationService coneValidationService;

    private RemiConeCheckFilter filter;
    private MultivaluedMap<String, String> queryParams;
    private final Map<String, Object> requestProperties = new HashMap<>();

    static class ResourceFixture {

        @RemiConeCheck
        public void requestDefault() {
        }

        @RemiConeCheck(
                mode = RemiConeCheck.Mode.REQUEST,
                singleField = "code",
                listField = "codes",
                queryParam = "code",
                queryListParam = "codes"
        )
        public void requestCustom() {
        }

        @RemiConeCheck(
                mode = RemiConeCheck.Mode.RESPONSE,
                responseField = "code",
                moduleCodes = {" pdm ", "ABC", " "}
        )
        public void responseWithModules() {
        }

        @RemiConeCheck(mode = RemiConeCheck.Mode.RESPONSE, responseField = "code")
        public void responseCustom() {
        }
    }

    @BeforeEach
    void setUp() throws Exception {
        filter = new RemiConeCheckFilter();
        setField(filter, "resourceInfo", resourceInfo);
        setField(filter, "coneValidationService", coneValidationService);
        setField(filter, "objectMapper", new ObjectMapper());

        clearAuthzCache();

        queryParams = new MultivaluedHashMap<>();
        requestProperties.clear();

        lenient().when(req.getProperty(anyString())).thenAnswer(inv -> requestProperties.get(inv.getArgument(0)));
        lenient().doAnswer(inv -> {
            requestProperties.put(inv.getArgument(0), inv.getArgument(1));
            return null;
        }).when(req).setProperty(anyString(), any());
    }

    @Test
    void requestFilter_allowsAuthorizedSingleQueryParam() throws Exception {
        Method method = ResourceFixture.class.getMethod("requestDefault");
        when(resourceInfo.getResourceMethod()).thenReturn(method);
        mockRequestQueryContext();

        queryParams.add("remiAssoluto", "remi01");
        when(coneValidationService.resolveAndCache(req)).thenReturn(new RemiConeDTO(false, List.of("REMI01")));

        assertThatCode(() -> filter.filter(req)).doesNotThrowAnyException();

        verify(coneValidationService).resolveAndCache(req);
    }

    @Test
    void requestFilter_deniesUnauthorizedSingleQueryParam() throws Exception {
        Method method = ResourceFixture.class.getMethod("requestDefault");
        when(resourceInfo.getResourceMethod()).thenReturn(method);
        mockRequestQueryContext();

        queryParams.add("remiAssoluto", "REMI99");
        when(coneValidationService.resolveAndCache(req)).thenReturn(new RemiConeDTO(false, List.of("REMI01")));

        assertThatThrownBy(() -> filter.filter(req))
                .isInstanceOf(ForbiddenException.class)
                .hasMessageContaining("REMI_NOT_AUTHORIZED");
    }

    @Test
    void requestFilter_deniesUnauthorizedQueryList() throws Exception {
        Method method = ResourceFixture.class.getMethod("requestCustom");
        when(resourceInfo.getResourceMethod()).thenReturn(method);
        mockRequestQueryContext();

        queryParams.add("codes", "REMI01");
        queryParams.add("codes", "REMI99");
        when(coneValidationService.resolveAndCache(req)).thenReturn(new RemiConeDTO(false, List.of("REMI01")));

        assertThatThrownBy(() -> filter.filter(req))
                .isInstanceOf(ForbiddenException.class)
                .hasMessageContaining("REMI_LIST_NOT_AUTHORIZED");
    }

    @Test
    void requestFilter_postBody_deniesUnauthorizedSingleField() throws Exception {
        Method method = ResourceFixture.class.getMethod("requestDefault");
        when(resourceInfo.getResourceMethod()).thenReturn(method);
        mockRequestQueryContext();

        when(req.getMethod()).thenReturn("POST");
        when(req.getEntityStream()).thenReturn(new ByteArrayInputStream(
                "{\"remiAssoluto\":\"REMI99\"}".getBytes()
        ));
        when(coneValidationService.resolveAndCache(req)).thenReturn(new RemiConeDTO(false, List.of("REMI01")));

        assertThatThrownBy(() -> filter.filter(req))
                .isInstanceOf(ForbiddenException.class)
                .hasMessageContaining("REMI_NOT_AUTHORIZED");

        verify(req).setEntityStream(any(InputStream.class));
    }

    @Test
    void requestFilter_invalidJsonBody_doesNotFailAndRestoresEntityStream() throws Exception {
        Method method = ResourceFixture.class.getMethod("requestDefault");
        when(resourceInfo.getResourceMethod()).thenReturn(method);
        mockRequestQueryContext();

        when(req.getMethod()).thenReturn("PUT");
        when(req.getEntityStream()).thenReturn(new ByteArrayInputStream("{invalid-json".getBytes()));
        when(coneValidationService.resolveAndCache(req)).thenReturn(new RemiConeDTO(false, List.of("REMI01")));

        assertThatCode(() -> filter.filter(req)).doesNotThrowAnyException();
        verify(req).setEntityStream(any(InputStream.class));
    }

    @Test
    void responseFilter_filtersArrayAndUpdatesNumberOfElements() throws Exception {
        Method method = ResourceFixture.class.getMethod("responseCustom");
        when(resourceInfo.getResourceMethod()).thenReturn(method);
        mockResponseMutationContext();

        requestProperties.put(
                RemiConeValidationService.PMR_REMI_CONE_PROP,
                new RemiConeDTO(false, List.of("REMI01"))
        );

        when(resp.getStatus()).thenReturn(200);

        Map<String, Object> entity = new LinkedHashMap<>();
        entity.put("data", List.of(
                Map.of("code", "REMI01"),
                Map.of("code", "REMI99"),
                Map.of("other", "safe-default-kept")
        ));
        entity.put("numberOfElements", 3);

        when(resp.getEntity()).thenReturn(entity);

        filter.filter(req, resp);

        ArgumentCaptor<Object> captor = ArgumentCaptor.forClass(Object.class);
        verify(resp).setEntity(captor.capture(), any(Annotation[].class), eq(MediaType.APPLICATION_JSON_TYPE));

        Map<?, ?> mapped = (Map<?, ?>) captor.getValue();
        assertThat((Integer) mapped.get("numberOfElements")).isEqualTo(2);

        List<?> data = (List<?>) mapped.get("data");
        assertThat(data).hasSize(2);
    }

    @Test
    void responseFilter_unauthorizedSingleObject_setsDataToNull() throws Exception {
        Method method = ResourceFixture.class.getMethod("responseCustom");
        when(resourceInfo.getResourceMethod()).thenReturn(method);
        mockResponseMutationContext();

        requestProperties.put(
                RemiConeValidationService.PMR_REMI_CONE_PROP,
                new RemiConeDTO(false, List.of("REMI01"))
        );

        when(resp.getStatus()).thenReturn(200);

        Map<String, Object> entity = new LinkedHashMap<>();
        entity.put("data", Map.of("code", "REMI99"));
        entity.put("numberOfElements", 1);

        when(resp.getEntity()).thenReturn(entity);

        filter.filter(req, resp);

        ArgumentCaptor<Object> captor = ArgumentCaptor.forClass(Object.class);
        verify(resp).setEntity(captor.capture(), any(Annotation[].class), eq(MediaType.APPLICATION_JSON_TYPE));

        Map<?, ?> mapped = (Map<?, ?>) captor.getValue();
        assertThat(mapped.get("data")).isNull();
        assertThat(mapped.get("numberOfElements")).isEqualTo(0);
    }

    @Test
    void responseFilter_whenConeNotCached_resolvesItFromService() throws Exception {
        Method method = ResourceFixture.class.getMethod("responseCustom");
        when(resourceInfo.getResourceMethod()).thenReturn(method);
        mockResponseMutationContext();

        when(resp.getStatus()).thenReturn(200);
        when(resp.getEntity()).thenReturn(Map.of(
                "data", Map.of("code", "REMI01"),
                "numberOfElements", 1
        ));

        when(coneValidationService.resolveAndCache(req)).thenReturn(new RemiConeDTO(false, List.of("REMI01")));

        filter.filter(req, resp);

        verify(coneValidationService).resolveAndCache(req);
    }

    @Test
    void responseFilter_non200Status_skipsMutation() throws Exception {
        Method method = ResourceFixture.class.getMethod("responseCustom");
        when(resourceInfo.getResourceMethod()).thenReturn(method);

        when(resp.getStatus()).thenReturn(500);
        
        filter.filter(req, resp);

        verify(resp, never()).setEntity(any(), any(Annotation[].class), any());
    }
    
    @Test
    void requestFilter_storesNormalizedModuleCodesInRequestProperty() throws Exception {
        Method method = ResourceFixture.class.getMethod("responseWithModules");
        when(resourceInfo.getResourceMethod()).thenReturn(method);

        when(coneValidationService.resolveAndCache(req)).thenReturn(new RemiConeDTO(true, List.of()));

        filter.filter(req);

        assertThat(requestProperties.get(RemiConeValidationService.PMR_REMI_MODULE_CODES_PROP))
                .isEqualTo(new java.util.LinkedHashSet<>(List.of("PDM", "ABC")));

        verify(coneValidationService).resolveAndCache(req);
    }

    
    

    private void mockRequestQueryContext() {
        when(req.getUriInfo()).thenReturn(uriInfo);
        when(uriInfo.getQueryParameters()).thenReturn(queryParams);
    }

    private void mockResponseMutationContext() {
        when(resp.getEntityAnnotations()).thenReturn(new Annotation[0]);
    }

    private static void setField(Object target, String name, Object value) throws Exception {
        Field field = findField(target.getClass(), name);
        field.setAccessible(true);
        field.set(target, value);
    }

    private static Field findField(Class<?> type, String name) throws NoSuchFieldException {
        try {
            return type.getDeclaredField(name);
        } catch (NoSuchFieldException e) {
            if (type.getSuperclass() != null) {
                return findField(type.getSuperclass(), name);
            }
            throw e;
        }
    }

    @SuppressWarnings("unchecked")
    private static void clearAuthzCache() throws Exception {
        Field f = AuthzAnnotationCache.class.getDeclaredField("CACHE");
        f.setAccessible(true);
        ((Map<?, ?>) f.get(null)).clear();
    }
}
