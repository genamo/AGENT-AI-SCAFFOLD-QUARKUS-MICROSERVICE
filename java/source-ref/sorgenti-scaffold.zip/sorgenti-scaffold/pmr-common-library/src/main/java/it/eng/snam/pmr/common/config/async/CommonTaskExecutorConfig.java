package it.eng.snam.pmr.common.config.async;

import java.util.concurrent.Executor;

import it.eng.snam.pmr.common.config.async.decorator.ContextCopyingDecorator;
import it.eng.snam.pmr.common.config.async.properties.AsyncProperties;
import it.eng.snam.pmr.common.util.async.ExecutorCreator;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class CommonTaskExecutorConfig {

    public static final String DEFAULT_EXECUTOR = "asyncTaskExecutor";

    private final AsyncProperties properties;

    @Produces
    @ApplicationScoped
    @TaskExecutorQualifier
    public Executor asyncTaskExecutor() {
        return ExecutorCreator.createExecutor(properties, "Async-", new ContextCopyingDecorator());
    }
}
