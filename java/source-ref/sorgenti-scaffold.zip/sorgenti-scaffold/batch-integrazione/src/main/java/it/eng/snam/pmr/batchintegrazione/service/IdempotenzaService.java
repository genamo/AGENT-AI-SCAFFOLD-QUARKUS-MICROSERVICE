package it.eng.snam.pmr.batchintegrazione.service;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.IdempotenzaRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.IdempotenzaResponseDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class IdempotenzaService extends AbstractService {

    private static final Logger LOG =
            Logger.getLogger(IdempotenzaService.class);

    @Inject
    @RestClient
    BatchIntegrazioneDgClient client;

    @Inject
    ObjectMapper objectMapper;

    // ======================================================
    // UPSERT (gate + update stato)
    // ======================================================

    
    public IdempotenzaResponseDTO insert(IdempotenzaRequestDTO request) {

        try (Response resp = client.insertIdempotenza(request)) {

            int status = resp.getStatus();

            if (status == Response.Status.OK.getStatusCode()) {
                String json = resp.readEntity(String.class);
                return readResponse(json);
            }

            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                String body = safeReadBody(resp);
                throw new IllegalArgumentException(
                        "Idempotenza insert 400: " +
                        (body.isBlank() ? "Bad Request" : body)
                );
            }

            throw remoteError(
                    "POST /idempotenza-flussi-insert",
                    status,
                    resp
            );
        }
    }
    
    public IdempotenzaResponseDTO update(IdempotenzaRequestDTO request) {

        try (Response resp = client.updateIdempotenza(request)) {

            int status = resp.getStatus();

            if (status == Response.Status.OK.getStatusCode()) {
                String json = resp.readEntity(String.class);
                return readResponse(json);
            }

            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                String body = safeReadBody(resp);
                throw new IllegalArgumentException(
                        "Idempotenza update 400: " +
                        (body.isBlank() ? "Bad Request" : body)
                );
            }

            throw remoteError(
                    "POST /idempotenza-flussi-update",
                    status,
                    resp
            );
        }
    }

    // ======================================================
    // HELPERS
    // ======================================================

    private IdempotenzaResponseDTO readResponse(String json) {
        if (json == null || json.isBlank()) {
            throw new RemoteCallException(
                    "Risposta vuota da idempotenza-flussi"
            );
        }

        try {
            return objectMapper.readValue(
                    json,
                    IdempotenzaResponseDTO.class
            );
        } catch (Exception e) {
            throw new RemoteCallException(
                    "Impossibile deserializzare IdempotenzaResponseDTO",
                    e
            );
        }
    }
}
