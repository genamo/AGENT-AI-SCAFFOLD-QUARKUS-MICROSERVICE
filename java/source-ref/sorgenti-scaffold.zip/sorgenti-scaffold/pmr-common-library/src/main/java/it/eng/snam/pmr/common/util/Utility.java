package it.eng.snam.pmr.common.util;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import it.eng.snam.pmr.common.filter.RequestHeadersContext;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.response.ResponseStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
public class Utility {

    @Inject
    RequestHeadersContext headersCtx;

    // =========================
    // Static helpers
    // =========================
    public static String defaultUuidIfBlank(String v) {
        return (v == null || v.isBlank()) ? UUID.randomUUID().toString() : v;
    }
    public static boolean parseBooleanOrDefault(String v, boolean defaultValue) {
        if (v == null || v.isBlank()) return defaultValue;
        String s = v.trim().toLowerCase();
        if ("true".equals(s)) return true;
        if ("false".equals(s)) return false;
        return defaultValue;
    }
    public static String defaultIfBlank(String v, String def) {
        return (v == null || v.trim().isEmpty()) ? def : v;
    }
    public static long elapsedMs(long s) { return (System.nanoTime() - s) / 1_000_000; }
    public static String safe(Object v) {
        if (v == null) return "null";
        String s = String.valueOf(v).trim();
        if (s.isEmpty()) return "blank";
        return s.length() > 120 ? s.substring(0, 120) + "..." : s;
    }

    // =========================
    // Context helpers
    // =========================
    private String currentPath() {
        String p = (headersCtx != null) ? headersCtx.getPath() : null;
        return (p == null || p.isBlank()) ? "N/A" : p;
    }

    private long startNanos() {
        long s = (headersCtx != null) ? headersCtx.getStartNanos() : 0L;
        return (s > 0L) ? s : System.nanoTime();
    }

    private String executionTime() {
        return Duration.ofNanos(System.nanoTime() - startNanos()).toMillis() + "ms";
    }

    // =========================
    // Common headers
    // =========================
    private Response.ResponseBuilder withCommonHeaders(Response.ResponseBuilder rb) {
        return rb
            .header(CommonConstants.Headers.KEYLOGIC, headersCtx.getKeyLogic())
            .header(CommonConstants.Headers.TRANSACTION_ID, headersCtx.getTransactionId())
            .header(CommonConstants.Headers.MOD_ASYNC, String.valueOf(headersCtx.isModAsync()))
            .header(CommonConstants.Headers.PROCESS_TYPE, headersCtx.getProcessType());
    }

    // =========================
    // Internal builder
    // =========================
    private static <T> GenericResponse<T> baseGeneric(String path) {
        GenericResponse<T> gr = new GenericResponse<>();
        gr.setTimestamp(OffsetDateTime.now().toString());
        gr.setPath(path);
        return gr;
    }

    // =========================
    // 200 OK
    // =========================
    public <T> Response ok(T data) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);
        gr.setExecutionTime(executionTime());
        if (data instanceof List<?> l) gr.setNumberOfElements(l.size());
        return withCommonHeaders(Response.ok(gr)).build();
    }

    public <T> Response inProgress(T data) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);
        gr.setExecutionTime(executionTime());
        gr.setStatus(ResponseStatus.IN_ELABORAZIONE.toString());
        if (data instanceof List<?> l) gr.setNumberOfElements(l.size());
        return withCommonHeaders(Response.ok(gr)).build();
    }

    public <T> Response inCarico(T data) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);
        gr.setExecutionTime(executionTime());
        gr.setStatus(ResponseStatus.PRESO_IN_CARICO.toString());
        if (data instanceof List<?> l) gr.setNumberOfElements(l.size());
        return withCommonHeaders(Response.ok(gr)).build();
    }

    public <T> Response okWithMessageCustom(T data, GenericResponse.Message msg) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);
        gr.setExecutionTime(executionTime());
        gr.setMessage(msg);
        if (data instanceof List<?> l) gr.setNumberOfElements(l.size());
        return withCommonHeaders(Response.ok(gr)).build();
    }

    public <T> Response okEmpty() {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setExecutionTime(executionTime());
        gr.setNumberOfElements(0);
        return withCommonHeaders(Response.ok(gr)).build();
    }

    // =========================
    // 201 CREATED
    // =========================
    public <T> Response created(T data) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);
        gr.setExecutionTime(executionTime());
        if (data instanceof List<?> l) gr.setNumberOfElements(l.size());
        return withCommonHeaders(Response.status(Response.Status.CREATED).entity(gr)).build();
    }

    // =========================
    // 4XX - 5XX ERROR
    // =========================
    public <T> Response errorResponse(String message, Response.Status status) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setExecutionTime(executionTime());
        gr.setStatus(ResponseStatus.IN_ERRORE.toString());
        GenericResponse.Message m = new GenericResponse.Message();
        m.setMessageType("ERROR");
        m.setMessageCode(status.name());
        m.setMessageDescription(message);
        gr.setMessage(m);
        return withCommonHeaders(Response.status(status).entity(gr)).build();
    }

    public <T> Response errorResponseWithCustomMessage(GenericResponse.Message message, Response.Status status) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setExecutionTime(executionTime());
        gr.setMessage(message);
        return withCommonHeaders(Response.status(status).entity(gr)).build();
    }

    // =========================
    // 204 NO CONTENT
    // =========================
    public Response noContentOnlyHeaders() {
        return withCommonHeaders(Response.noContent()).build();
    }

    // =========================
    // Helper: Optional & List
    // =========================
    public <T> Response okOrNotFound(Optional<T> opt, String notFoundMessage) {
        Objects.requireNonNull(opt, "opt must not be null");
        if (opt.isPresent()) {
            return ok(opt.get());
        }
        return errorResponse(notFoundMessage, Response.Status.NOT_FOUND);
    }

    public <T> Response okOrNotFoundWithCustomMessage(Optional<T> opt, GenericResponse.Message customMessage) {
        Objects.requireNonNull(opt, "opt must not be null");
        if (opt.isPresent()) {
            return okWithMessageCustom(opt.get(), customMessage);
        }
        return errorResponseWithCustomMessage(customMessage, Response.Status.NOT_FOUND);
    }



    public <T> Response okOrEmpty(List<T> list) {
        if (list == null || list.isEmpty()) return okEmpty();
        return ok(list);
    }

    public <T> Response okOrEmptyWithCustomMessage(List<T> list, GenericResponse.Message customMessage) {
        if (list == null || list.isEmpty()) return okEmpty();
        return okWithMessageCustom(list, customMessage);
    }
}
