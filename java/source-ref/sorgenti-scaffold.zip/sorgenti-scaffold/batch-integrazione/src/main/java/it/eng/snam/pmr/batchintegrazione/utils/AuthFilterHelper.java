package it.eng.snam.pmr.batchintegrazione.utils;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Strings;
import org.eclipse.microprofile.config.ConfigProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.core.HttpHeaders;
import lombok.experimental.UtilityClass;

@UtilityClass
public class AuthFilterHelper {

    private final String M2M = "M2M";
    private final String JWT = "JWT";
    private final String BEARER = "Bearer ";
    private final String AUTH_MODE = ".auth-mode";
    private final String INVOKED_METHOD = "org.eclipse.microprofile.rest.client.invokedMethod";

    public String resolveConfigKey(ClientRequestContext requestContext) {
        Method method = Optional.ofNullable(requestContext.getProperty(INVOKED_METHOD)).filter(Method.class::isInstance).map(Method.class::cast)
                                .orElseThrow(() -> new IllegalStateException("Unable to resolve invoked RestClient's method"));

        return Optional.ofNullable(method.getDeclaringClass().getAnnotation(RegisterRestClient.class))
                       .map(RegisterRestClient::configKey).filter(StringUtils::isNotBlank)
                       .orElseThrow(() -> new IllegalStateException("Unable to resolve RestClient's configKey from: " + method.getDeclaringClass().getName()));
    }

    public String resolveAuthMode(String configKey) {
        String authModeKey = StringUtils.join(configKey, AUTH_MODE);
        return ConfigProvider.getConfig().getOptionalValue(authModeKey, String.class)
                             .orElse(JWT);
    }

    public boolean isAuthModeM2M(String authMode) {
        return Strings.CI.equals(authMode, M2M);
    }

    public String normalizeBearer(String auth) {
        return Optional.ofNullable(auth).filter(StringUtils::isNotBlank).map(String::trim)
                       .map(value -> value.startsWith(BEARER) ? value : StringUtils.join(BEARER, value))
                       .orElseThrow(() -> new IllegalStateException("Authorization token is blank"));
    }

    public boolean hasAuthorization(ClientRequestContext requestContext) {
        List<Object> values = requestContext.getHeaders().get(HttpHeaders.AUTHORIZATION);
        return values != null && values.stream().filter(Objects::nonNull).map(Object::toString)
                                       .anyMatch(StringUtils::isNotBlank);
    }
}