package it.eng.snam.pmr.batchintegrazionedg.test.service;

import java.util.HashMap;
import java.util.Map;
import io.quarkus.test.junit.QuarkusTestProfile;

public class NoSecurityTestProfile implements QuarkusTestProfile {
    @Override
    public Map<String, String> getConfigOverrides() {
        Map<String, String> config = new HashMap<>();
        // Security
        config.put("quarkus.oidc.enabled", "false");
        config.put("quarkus.security.enabled", "false");
        // Redis
        config.put("quarkus.redis.hosts", "redis://localhost:16380");
        config.put("quarkus.redis.devservices.enabled", "false");
        // Scheduler
        config.put("quarkus.scheduler.enabled", "false");
        // Kafka - disable channels instead of using in-memory connector
        config.put("mp.messaging.incoming.monitor-flussi-in.enabled", "false");
        
        config.put("mp.messaging.outgoing.kafka-out.enabled", "false");
        config.put("kafka-prefix.topics", "test");
        config.put("kafka.bootstrap.servers", "localhost:19092");
        config.put("kafka.security.protocol", "PLAINTEXT");
        config.put("kafka.sasl.mechanism", "PLAIN");
        config.put("kafka.sasl.jaas.config",
                "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"\" password=\"\";");
        config.put("kafka.topics.auto-create", "false");
        return config;
    }
}
