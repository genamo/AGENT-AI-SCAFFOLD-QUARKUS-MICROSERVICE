package it.eng.snam.pmr.common.dto.acr.addressing;

import lombok.Builder;

@Builder
public record AcrVerticalDTO(
        Integer verticalId,
        String verticalCode,
        String verticalName,
        String verticalDescription
) {}
