package it.eng.snam.pmr.common.annotation;

import jakarta.ws.rs.NameBinding;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@NameBinding
@Retention(RUNTIME)
@Target({ TYPE, METHOD })
public @interface AuthzRead {

    UserType userType() default UserType.INTERNAL;
}