package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import it.eng.snam.pmr.batchintegrazione.dto.datiprimari.QualitaGasGiornDto;
import it.eng.snam.pmr.batchintegrazione.dto.flussi.QualitaGasGiornPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.DatiPrimariService;
import it.eng.snam.pmr.batchintegrazione.service.handler.QualitaGasGiornHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;

class QualitaGasGiornHandlerTest {

    private QualitaGasGiornHandler handler;
    private DatiPrimariService datiPrimariService;

    @BeforeEach
    void setUp() throws Exception {
        handler = new QualitaGasGiornHandler();
        datiPrimariService = Mockito.mock(DatiPrimariService.class);
        injectField(QualitaGasGiornHandler.class, handler, "datiPrimariService", datiPrimariService);
    }

    @Test
    void getFlowTypeReturnsExpectedValue() {
        assertEquals(Constants.Flussi.QUALITA_GASDAY_FLOW, handler.getFlowType());
    }

    @Test
    void getDtoClassReturnsExpectedType() throws Exception {
        Class<?> dtoClass = (Class<?>) invokeProtectedMethod(handler, "getDtoClass", new Class<?>[0]);
        assertEquals(QualitaGasGiornPayloadDto.class, dtoClass);
    }

    @Test
    void handleInsertCallsSaveWhenDataIsPresent() {
        QualitaGasGiornDto data = Mockito.mock(QualitaGasGiornDto.class);

        QualitaGasGiornPayloadDto dto = QualitaGasGiornPayloadDto.builder()
                .summerTransactionId("TX-001")
                .operation("INSERT")
                .data(List.of(data))
                .build();

        assertDoesNotThrow(() -> invokeProtectedMethod(handler, "handle", new Class<?>[] { QualitaGasGiornPayloadDto.class }, dto));

        verify(datiPrimariService).saveQualitaGasGiorn(data);
    }

    @Test
    void handleDeleteCallsDeleteWhenDataIsPresent() {
        QualitaGasGiornDto data = Mockito.mock(QualitaGasGiornDto.class);
        Integer codiceAop = 1001;
        LocalDateTime dataIniPre = LocalDateTime.of(2026, 7, 15, 0, 0);

        Mockito.when(data.codiceAop()).thenReturn(codiceAop);
        Mockito.when(data.dataIniPre()).thenReturn(dataIniPre);

        QualitaGasGiornPayloadDto dto = QualitaGasGiornPayloadDto.builder()
                .summerTransactionId("TX-002")
                .operation("DELETE")
                .data(List.of(data))
                .build();

        assertDoesNotThrow(() -> invokeProtectedMethod(handler, "handle", new Class<?>[] { QualitaGasGiornPayloadDto.class }, dto));

        verify(datiPrimariService).deleteQualitaGasGiorn(codiceAop, dataIniPre);
    }

    @Test
    void handleInsertDoesNothingWhenDataIsNull() {
        QualitaGasGiornPayloadDto dto = QualitaGasGiornPayloadDto.builder()
                .summerTransactionId("TX-003")
                .operation("INSERT")
                .data(null)
                .build();

        assertDoesNotThrow(() -> invokeProtectedMethod(handler, "handle", new Class<?>[] { QualitaGasGiornPayloadDto.class }, dto));

        verifyNoInteractions(datiPrimariService);
    }

    @Test
    void handleDeleteDoesNothingWhenDataIsEmpty() {
        QualitaGasGiornPayloadDto dto = QualitaGasGiornPayloadDto.builder()
                .summerTransactionId("TX-004")
                .operation("DELETE")
                .data(List.of())
                .build();

        assertDoesNotThrow(() -> invokeProtectedMethod(handler, "handle", new Class<?>[] { QualitaGasGiornPayloadDto.class }, dto));

        verifyNoInteractions(datiPrimariService);
    }

    @Test
    void handleThrowsExceptionWhenOperationIsNull() {
        QualitaGasGiornPayloadDto dto = QualitaGasGiornPayloadDto.builder()
                .summerTransactionId("TX-005")
                .operation(null)
                .data(List.of())
                .build();

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> invokeProtectedMethod(handler, "handle", new Class<?>[] { QualitaGasGiornPayloadDto.class }, dto)
        );

        assertEquals("Operation field is required", ex.getMessage());
        verifyNoInteractions(datiPrimariService);
    }

    @Test
    void handleThrowsExceptionWhenOperationIsEmpty() {
        QualitaGasGiornPayloadDto dto = QualitaGasGiornPayloadDto.builder()
                .summerTransactionId("TX-006")
                .operation("")
                .data(List.of())
                .build();

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> invokeProtectedMethod(handler, "handle", new Class<?>[] { QualitaGasGiornPayloadDto.class }, dto)
        );

        assertEquals("Operation field is required", ex.getMessage());
        verifyNoInteractions(datiPrimariService);
    }

    @Test
    void handleThrowsExceptionWhenOperationIsInvalid() {
        QualitaGasGiornPayloadDto dto = QualitaGasGiornPayloadDto.builder()
                .summerTransactionId("TX-007")
                .operation("UPDATE")
                .data(List.of())
                .build();

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> invokeProtectedMethod(handler, "handle", new Class<?>[] { QualitaGasGiornPayloadDto.class }, dto)
        );

        assertEquals("Invalid operation: UPDATE", ex.getMessage());
        verifyNoInteractions(datiPrimariService);
    }

    private static void injectField(Class<?> declaringClass, Object target, String fieldName, Object value) throws Exception {
        Field field = declaringClass.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private static Object invokeProtectedMethod(Object target, String methodName, Class<?>[] parameterTypes, Object... args) throws Exception {
        try {
            Method method = target.getClass().getDeclaredMethod(methodName, parameterTypes);
            method.setAccessible(true);
            return method.invoke(target, args);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof Exception ex) {
                throw ex;
            }
            throw e;
        }
    }
}
