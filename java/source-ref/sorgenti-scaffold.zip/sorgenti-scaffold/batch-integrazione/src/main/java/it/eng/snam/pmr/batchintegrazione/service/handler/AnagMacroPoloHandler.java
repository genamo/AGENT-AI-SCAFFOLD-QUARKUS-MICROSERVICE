package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AnagMacroPoloPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AnagMacroPoloHandler extends AbstractFlussoHandler<AnagMacroPoloPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AnagMacroPoloPayloadDto> getDtoClass() {
        return AnagMacroPoloPayloadDto.class;
    }

    @Override
    protected void handle(AnagMacroPoloPayloadDto dto) {
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAnagMacroPolo(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteAnagMacroPolo(dto.data().getFirst().codiceMacroPolo());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}
    	
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ANAG_MACRO_POLO_FLOW;
    }
}