package it.eng.snam.pmr.batchintegrazionedg.resource;

import it.eng.snam.pmr.batchintegrazionedg.utils.RequestCtx;
import jakarta.ws.rs.container.ContainerRequestContext;

/**
 * Base resource per eliminare duplicazioni Sonar
 */
public abstract class AbstractResource {

    protected record ReqContext(
            long start,
            String path,
            String kl,
            String tid,
            boolean modAsync,
            String processType
    ) {}

    /**
     * Inizializza contesto request standard
     */
    protected ReqContext init(ContainerRequestContext ctx, String path) {

        return new ReqContext(
                System.nanoTime(),
                path,
                RequestCtx.kl(ctx),
                RequestCtx.tid(ctx),
                RequestCtx.modAsync(ctx),
                RequestCtx.processType(ctx)
        );
    }
}
