package it.eng.snam.pmr.batchintegrazionedg.resource;

import java.util.List;
import java.util.Optional;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.dto.AnagFlussiDTO;
import it.eng.snam.pmr.batchintegrazionedg.service.AnagFlussiService;
import it.eng.snam.pmr.batchintegrazionedg.utils.Utility;
import it.eng.snam.pmr.common.annotation.LogPmr;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/anag-flussi")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@LogPmr
@RunOnVirtualThread
public class AnagFlussiResource extends AbstractResource {

    @Inject
    AnagFlussiService service;

    @Context
    ContainerRequestContext ctx;

    // =========================
    // GET ALL
    // =========================
    @GET
    @Path("/")
    public Response getAll() {

        ReqContext c = init(ctx, "/");

        List<AnagFlussiDTO> list = service.getAll();

        return Utility.okOrEmpty(
                list,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // =========================
    // SEARCH
    // =========================
    @GET
    @Path("/search")
    public Response findByFlowId(@QueryParam("flowId") String flowId) {

        ReqContext c = init(ctx, "/search");

        if (flowId == null || flowId.isBlank()) {
            return Utility.badRequest(
                    "Il parametro flowId è obbligatorio",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        AnagFlussiDTO dto = service.findByFlowId(flowId);

        return Utility.okOrNotFound(
                Optional.ofNullable(dto),
                "Nessun flusso trovato per flowId=" + flowId,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }
}
