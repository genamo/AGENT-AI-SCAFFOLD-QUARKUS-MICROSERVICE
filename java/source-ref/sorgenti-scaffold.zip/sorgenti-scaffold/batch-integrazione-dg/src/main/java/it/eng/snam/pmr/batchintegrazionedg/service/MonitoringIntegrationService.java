package it.eng.snam.pmr.batchintegrazionedg.service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

import org.apache.kafka.common.header.Headers;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration.MonitoringIntegrationOutcome;
import it.eng.snam.pmr.batchintegrazionedg.entity.MonitoringIntegrationRequest;
import it.eng.snam.pmr.batchintegrazionedg.kafka.KafkaTopic;
import it.eng.snam.pmr.batchintegrazionedg.kafka.producer.KafkaGenericProducer;
import it.eng.snam.pmr.batchintegrazionedg.repository.MonitoringIntegrationMetadataRepository;
import it.eng.snam.pmr.batchintegrazionedg.repository.MonitoringIntegrationRequestRepository;
import it.eng.snam.pmr.batchintegrazionedg.repository.MonitoringIntegrationStatusRepository;
import it.eng.snam.pmr.batchintegrazionedg.utils.monitoring.integration.MonitoringIntegrationExecutor;
import it.eng.snam.pmr.batchintegrazionedg.utils.monitoring.integration.RequestValidator;
import it.eng.snam.pmr.common.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RunOnVirtualThread
@RequiredArgsConstructor
public class MonitoringIntegrationService extends AbstractService {

    private final MonitoringIntegrationRequestRepository requestRepository;
    private final MonitoringIntegrationMetadataRepository metadataRepository;
    private final MonitoringIntegrationStatusRepository statusRepository;
    private final KafkaGenericProducer producer;

    @Transactional
    public Long sendRequestGenerateSend(MonitoringIntegration integrationRequest) {
        String userId = MdcManager.getHeader(AuthorizationUtils.USER_ID);
        String transactionId = MdcManager.getHeader(CommonConstants.LogParams.TN);
        RequestValidator.validate(integrationRequest);

        LocalDateTime now = LocalDateTime.now(ZoneOffset.UTC);
        String integrationType = integrationRequest.getIntegrationType();

        MonitoringIntegrationExecutor.persistRequest(integrationType, userId, transactionId, now, requestRepository::persist);
        Long id = MonitoringIntegrationExecutor.retrieveRequestId(transactionId, requestRepository::findIdByTransactionId);
        MonitoringIntegrationExecutor.persistMetadata(transactionId, integrationRequest.getRequestBody(), id, now, metadataRepository::persist);
        MonitoringIntegrationExecutor.persistStatus(transactionId, id, now, statusRepository::persist);

        producer.sendEventWithHeaders(KafkaTopic.MONITORING_INTEGRATION, integrationRequest, null);
        return id;
    }

    @Transactional
    public void persist(MonitoringIntegrationOutcome payload, Headers headers) {
        LocalDateTime now = LocalDateTime.now(ZoneOffset.UTC);
        String transactionId = MdcManager.getHeader(CommonConstants.LogParams.TN);
        String userId = MdcManager.getHeader(AuthorizationUtils.USER_ID);

        MonitoringIntegrationRequest request = requestRepository.findByTransactionIdAndUserId(transactionId, userId).orElseThrow();
        MonitoringIntegrationExecutor.updateRequest(request, payload, now, requestRepository::persist);
        MonitoringIntegrationExecutor.updateMetadata(request.getId(), payload, now, metadataRepository::findByIntegrationRequestId, metadataRepository::persist);
        MonitoringIntegrationExecutor.updateStatus(request.getId(), payload, now, statusRepository::findByUploadRequestId, statusRepository::persist);

        log.info("MonitoringIntegrationRequest persisted. transactionId={}, userId={}, status={} - {}", transactionId, userId, payload.getResponseStatusCode(), payload.getResponseStatus());
    }
}
