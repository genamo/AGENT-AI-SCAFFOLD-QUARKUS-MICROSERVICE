package it.eng.snam.pmr.common.response;

import it.eng.snam.pmr.common.util.MessageTypeEnum;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class GenericResponseTest {

    // -----------------------------------------------------------------------
    // Default constructor
    // -----------------------------------------------------------------------

    @Test
    void defaultConstructor_setsTimestampAndStatus() {
        GenericResponse<String> resp = new GenericResponse<>();
        assertThat(resp.getTimestamp()).isNotNull().isNotBlank();
        assertThat(resp.getStatus()).isEqualTo(ResponseStatus.ELABORATO.toString());
        assertThat(resp.getMessage()).isNull();
    }

    @Test
    void constructorWithData_setsDataAndTimestamp() {
        GenericResponse<String> resp = new GenericResponse<>("hello", "ok");
        assertThat(resp.getData()).isEqualTo("hello");
        assertThat(resp.getTimestamp()).isNotNull();
    }

    // -----------------------------------------------------------------------
    // Setters / Getters
    // -----------------------------------------------------------------------

    @Test
    void settersAndGetters_workCorrectly() {
        GenericResponse<Integer> resp = new GenericResponse<>();
        resp.setData(42);
        resp.setStatus("MY_STATUS");
        resp.setExecutionTime("100ms");
        resp.setNumberOfElements(5);
        resp.setNumberOfPages(2);
        resp.setPath("/test");

        assertThat(resp.getData()).isEqualTo(42);
        assertThat(resp.getStatus()).isEqualTo("MY_STATUS");
        assertThat(resp.getExecutionTime()).isEqualTo("100ms");
        assertThat(resp.getNumberOfElements()).isEqualTo(5);
        assertThat(resp.getNumberOfPages()).isEqualTo(2);
        assertThat(resp.getPath()).isEqualTo("/test");
    }

    // -----------------------------------------------------------------------
    // buildMessage(MessageTypeEnum)
    // -----------------------------------------------------------------------

    @Test
    void buildMessage_withEnum_setsTypeAndCode() {
        GenericResponse<Void> resp = new GenericResponse<>();
        resp.buildMessage(MessageTypeEnum.OK);

        assertThat(resp.getMessage()).isNotNull();
        assertThat(resp.getMessage().getMessageType()).isEqualTo("Info");
        assertThat(resp.getMessage().getMessageCode()).isEqualTo("1");
    }

    @Test
    void buildMessage_calledTwice_overwritesPrevious() {
        GenericResponse<Void> resp = new GenericResponse<>();
        resp.buildMessage(MessageTypeEnum.OK);
        resp.buildMessage(MessageTypeEnum.ERROR_GESTITO);
        assertThat(resp.getMessage().getMessageType()).isEqualTo("Error");
        assertThat(resp.getMessage().getMessageCode()).isEqualTo("2");
    }

    // -----------------------------------------------------------------------
    // buildMessage(MessageTypeEnum, String, List)
    // -----------------------------------------------------------------------

    @Test
    void buildMessage_withDescAndPlaceholders_setsAll() {
        GenericResponse<Void> resp = new GenericResponse<>();
        resp.buildMessage(MessageTypeEnum.ERROR_BUSINESS_LOGIC, "Something went wrong", List.of("p1", "p2"));

        assertThat(resp.getMessage().getMessageType()).isEqualTo("Error");
        assertThat(resp.getMessage().getMessageCode()).isEqualTo("7");
        assertThat(resp.getMessage().getMessageDescription()).isEqualTo("Something went wrong");
        assertThat(resp.getMessage().getMessagePlaceholder()).containsExactly("p1", "p2");
    }

    // -----------------------------------------------------------------------
    // Message inner class
    // -----------------------------------------------------------------------

    @Test
    void message_noArgsConstructor_allNull() {
        GenericResponse.Message m = new GenericResponse.Message();
        assertThat(m.getMessageType()).isNull();
        assertThat(m.getMessageCode()).isNull();
        assertThat(m.getMessageDescription()).isNull();
        assertThat(m.getMessagePlaceholder()).isNull();
    }

    @Test
    void message_allArgsConstructor_setsAll() {
        GenericResponse.Message m = new GenericResponse.Message("Error", "3", "desc", List.of("x"));
        assertThat(m.getMessageType()).isEqualTo("Error");
        assertThat(m.getMessageCode()).isEqualTo("3");
        assertThat(m.getMessageDescription()).isEqualTo("desc");
        assertThat(m.getMessagePlaceholder()).containsExactly("x");
    }

    @Test
    void message_typeCodePlaceholdersConstructor_setsThree() {
        GenericResponse.Message m = new GenericResponse.Message("Info", "1", List.of("a"));
        assertThat(m.getMessageType()).isEqualTo("Info");
        assertThat(m.getMessageCode()).isEqualTo("1");
        assertThat(m.getMessagePlaceholder()).containsExactly("a");
        assertThat(m.getMessageDescription()).isNull();
    }

    @Test
    void message_setters_workCorrectly() {
        GenericResponse.Message m = new GenericResponse.Message();
        m.setMessageType("t");
        m.setMessageCode("c");
        m.setMessageDescription("d");
        m.setMessagePlaceholder(List.of("ph"));

        assertThat(m.getMessageType()).isEqualTo("t");
        assertThat(m.getMessageCode()).isEqualTo("c");
        assertThat(m.getMessageDescription()).isEqualTo("d");
        assertThat(m.getMessagePlaceholder()).containsExactly("ph");
    }

    // -----------------------------------------------------------------------
    // equals / hashCode / toString (Lombok @Data)
    // -----------------------------------------------------------------------

    @Test
    void genericResponse_equals_sameContent() {
        GenericResponse<String> r1 = new GenericResponse<>();
        r1.setData("x");
        r1.setStatus("OK");
        r1.setExecutionTime("10ms");
        r1.setNumberOfElements(5);
        r1.setNumberOfPages(1);
        r1.setPath("/path");
        r1.setTimestamp("2024-01-01T00:00:00Z");

        GenericResponse<String> r2 = new GenericResponse<>();
        r2.setData("x");
        r2.setStatus("OK");
        r2.setExecutionTime("10ms");
        r2.setNumberOfElements(5);
        r2.setNumberOfPages(1);
        r2.setPath("/path");
        r2.setTimestamp("2024-01-01T00:00:00Z");

        assertThat(r1).isEqualTo(r2);
        assertThat(r1.hashCode()).isEqualTo(r2.hashCode());
    }

    @Test
    void genericResponse_notEquals_differentData() {
        GenericResponse<String> r1 = new GenericResponse<>();
        r1.setData("a");
        GenericResponse<String> r2 = new GenericResponse<>();
        r2.setData("b");
        assertThat(r1).isNotEqualTo(r2);
    }

    @Test
    void genericResponse_toString_containsFieldValues() {
        GenericResponse<String> r = new GenericResponse<>();
        r.setData("myData");
        r.setStatus("ELABORATO");
        String s = r.toString();
        assertThat(s).contains("myData").contains("ELABORATO");
    }

    @Test
    void message_equals_sameContent() {
        GenericResponse.Message m1 = new GenericResponse.Message("Error", "E1", "desc", List.of("p"));
        GenericResponse.Message m2 = new GenericResponse.Message("Error", "E1", "desc", List.of("p"));
        assertThat(m1).isEqualTo(m2);
        assertThat(m1.hashCode()).isEqualTo(m2.hashCode());
    }

    @Test
    void message_notEquals_differentType() {
        GenericResponse.Message m1 = new GenericResponse.Message("Error", "E1", null, null);
        GenericResponse.Message m2 = new GenericResponse.Message("Info", "E1", null, null);
        assertThat(m1).isNotEqualTo(m2);
    }

    @Test
    void message_toString_containsFields() {
        GenericResponse.Message m = new GenericResponse.Message("Error", "E99", "desc", null);
        assertThat(m.toString()).contains("Error").contains("E99");
    }

    @Test
    void genericResponse_setMessage_replacesMessage() {
        GenericResponse<String> r = new GenericResponse<>();
        GenericResponse.Message msg = new GenericResponse.Message("W", "W1", null, null);
        r.setMessage(msg);
        assertThat(r.getMessage()).isSameAs(msg);
    }
}
