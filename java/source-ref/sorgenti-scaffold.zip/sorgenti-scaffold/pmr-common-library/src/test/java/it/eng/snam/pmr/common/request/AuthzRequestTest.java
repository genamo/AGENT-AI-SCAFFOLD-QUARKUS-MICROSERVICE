package it.eng.snam.pmr.common.request;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Set;

import org.junit.jupiter.api.Test;

class AuthzRequestTest {

    @Test
    void constructor_setsAllFields() {
        AuthzRequest req = new AuthzRequest("PROFILE", "resource/path", "READ",
                Set.of("ROLE1", "ROLE2"), "INTERNAL");
        assertThat(req.profile()).isEqualTo("PROFILE");
        assertThat(req.resource()).isEqualTo("resource/path");
        assertThat(req.permit()).isEqualTo("READ");
        assertThat(req.roles()).containsExactlyInAnyOrder("ROLE1", "ROLE2");
        assertThat(req.userType()).isEqualTo("INTERNAL");
    }

    @Test
    void equalsAndHashCode_twoEqualRecords() {
        AuthzRequest r1 = new AuthzRequest("P", "res", "READ", Set.of("R"), "INT");
        AuthzRequest r2 = new AuthzRequest("P", "res", "READ", Set.of("R"), "INT");
        assertThat(r1).isEqualTo(r2);
        assertThat(r1.hashCode()).isEqualTo(r2.hashCode());
    }

    @Test
    void toString_containsFieldValues() {
        AuthzRequest req = new AuthzRequest("PROF", "res", "WRITE", Set.of("R"), "EXT");
        String s = req.toString();
        assertThat(s).contains("PROF").contains("res").contains("WRITE").contains("EXT");
    }

    @Test
    void nullFields_areAllowed() {
        AuthzRequest req = new AuthzRequest(null, null, null, null, null);
        assertThat(req.profile()).isNull();
        assertThat(req.resource()).isNull();
    }
}
