package it.eng.snam.pmr.batchintegrazione.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class BlobUploadException extends BatchIntegrazioneException {
    @Serial
    private static final long serialVersionUID = 5582171773310205188L;
}
