package it.eng.snam.pmr.batchintegrazionedg.response;

public enum ResponseStatus {
    ELABORATO("ELABORATO"),
    IN_ELABORAZIONE("IN ELABORAZIONE"),
    IN_ERRORE("IN ERRORE"),
	PRESO_IN_CARICO("PRESO IN CARICO");

    private String status;

    ResponseStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
