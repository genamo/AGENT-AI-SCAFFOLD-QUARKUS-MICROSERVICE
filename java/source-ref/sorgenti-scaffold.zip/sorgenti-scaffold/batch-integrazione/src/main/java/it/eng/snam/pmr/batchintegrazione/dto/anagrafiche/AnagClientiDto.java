package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AnagClientiDto(
        String codiceCliente,
        String descrizioneCliente,
        String ragioneSociale,
        String ragioneSociale2,
        String indirizzo,
        String comune,
        String provincia,
        String paese,
        String cap,
        String partitaIva,
        String telefono,
        String fax,
        String email1,
        String email2,
        String email3,
        String email4,
        String email5,
        String indirizzo2,
        String comune2,
        String provincia2,
        String paese2,
        String cap2,
        String telefono2,
        String fax2,
        String email12,
        String email22,
        String email32,
        String email42,
        String email52,
        LocalDateTime actionDate,
        String userAction,
        Integer isDeleted
) {}