package it.eng.snam.pmr.batchintegrazionedg.test.unit;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import it.eng.snam.pmr.batchintegrazionedg.utils.MessageTypeEnum;

class MessageTypeEnumTest {

    @Test
    void ok_hasCorrectValues() {
        assertEquals("Info", MessageTypeEnum.OK.getMessageType());
        assertEquals("1", MessageTypeEnum.OK.getMessageCode());
    }

    @Test
    void errorGestitoSearch_hasCorrectValues() {
        assertEquals("Info", MessageTypeEnum.ERROR_GESTITO_SEARCH.getMessageType());
        assertEquals("4", MessageTypeEnum.ERROR_GESTITO_SEARCH.getMessageCode());
    }

    @Test
    void errorGestito_hasCorrectValues() {
        assertEquals("Error", MessageTypeEnum.ERROR_GESTITO.getMessageType());
        assertEquals("2", MessageTypeEnum.ERROR_GESTITO.getMessageCode());
    }

    @Test
    void errorNonGestito_hasCorrectValues() {
        assertEquals("Error", MessageTypeEnum.ERROR_NON_GESTITO.getMessageType());
        assertEquals("3", MessageTypeEnum.ERROR_NON_GESTITO.getMessageCode());
    }

    @Test
    void errorBusinessLogic_hasCorrectValues() {
        assertEquals("Error", MessageTypeEnum.ERROR_BUSINESS_LOGIC.getMessageType());
        assertEquals("7", MessageTypeEnum.ERROR_BUSINESS_LOGIC.getMessageCode());
    }

    @Test
    void allValuesEnumerable() {
        assertEquals(5, MessageTypeEnum.values().length);
    }
}
