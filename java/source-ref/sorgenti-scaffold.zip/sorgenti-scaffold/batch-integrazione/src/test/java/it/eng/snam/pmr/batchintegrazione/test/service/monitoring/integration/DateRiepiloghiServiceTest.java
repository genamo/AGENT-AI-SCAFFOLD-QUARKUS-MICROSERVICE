package it.eng.snam.pmr.batchintegrazione.test.service.monitoring.integration;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Collections;

import org.apache.kafka.common.header.Headers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.client.DatiFiscaliClient;
import it.eng.snam.pmr.batchintegrazione.dto.flussi.DateRiepiloghiPayloadDTO;
import it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration.DateRiepiloghiDTO;
import it.eng.snam.pmr.batchintegrazione.service.monitoring.integration.DateRiepiloghiService;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.util.JsonUtils;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
public class DateRiepiloghiServiceTest {

    @Spy
    @InjectMocks
    private DateRiepiloghiService dateRiepiloghiService;

    @Mock
    private DatiFiscaliClient datiFiscaliClient;

    @Mock
    private Response response;

    @Mock
    private Headers headers;

    @Test
    void saveDateRiepiloghi_shouldBuildRequestCallClientAndReturn() {
        GenericResponse<String> expectedGenericResponse = new GenericResponse<>();
        expectedGenericResponse.setData("OK");

        when(datiFiscaliClient.saveDateRiepiloghi(any())).thenReturn(response);
        when(response.getStatus()).thenReturn(Response.Status.OK.getStatusCode());
        lenient().when(response.readEntity(String.class)).thenReturn(
                JsonUtils.writeAsJsonPrettyLogStringWithoutNull(expectedGenericResponse));

        when(datiFiscaliClient.saveDateRiepiloghi(any(DateRiepiloghiDTO.class))).thenReturn(response);

        DateRiepiloghiDTO dateRiepiloghiDTO = new DateRiepiloghiDTO("TEST", LocalDateTime.now(), LocalDateTime.now(), "TEST");
        DateRiepiloghiPayloadDTO dateRiepiloghiPayloadDTO = new DateRiepiloghiPayloadDTO("TEST", "TEST",Collections.singletonList(dateRiepiloghiDTO));
        dateRiepiloghiService.saveDateRiepiloghi(dateRiepiloghiPayloadDTO, headers);

        verify(datiFiscaliClient).saveDateRiepiloghi(argThat(request -> "TEST".equals(request.getTipoRiepilogo())
                                                                        && "TEST".equals(request.getUtenteUltimoAggiornamento())));
    }

    @Test
    void saveDateRiepiloghi_shouldFailOnNull() {
        assertThrows(IllegalArgumentException.class, () -> dateRiepiloghiService.saveDateRiepiloghi(null, headers));
    }

    @Test
    void saveDateRiepiloghi_shouldFailOnNullSummerTransactionId() {
        DateRiepiloghiDTO dateRiepiloghiDTO = new DateRiepiloghiDTO("TEST", LocalDateTime.now(), LocalDateTime.now(), "TEST");
        DateRiepiloghiPayloadDTO dateRiepiloghiPayloadDTO = new DateRiepiloghiPayloadDTO(null, "TEST", Collections.singletonList(dateRiepiloghiDTO));
        assertThrows(IllegalArgumentException.class, () -> dateRiepiloghiService.saveDateRiepiloghi(dateRiepiloghiPayloadDTO, headers));
    }

    @Test
    void saveDateRiepiloghi_shouldFailOnNullOperation() {
        DateRiepiloghiDTO dateRiepiloghiDTO = new DateRiepiloghiDTO("TEST", LocalDateTime.now(), LocalDateTime.now(), "TEST");
        DateRiepiloghiPayloadDTO dateRiepiloghiPayloadDTO = new DateRiepiloghiPayloadDTO("TEST", null, Collections.singletonList(dateRiepiloghiDTO));
        assertThrows(IllegalArgumentException.class, () -> dateRiepiloghiService.saveDateRiepiloghi(dateRiepiloghiPayloadDTO, headers));
    }

    @Test
    void saveDateRiepiloghi_shouldFailOnNullData() {
        DateRiepiloghiPayloadDTO dateRiepiloghiPayloadDTO = new DateRiepiloghiPayloadDTO("TEST", "TEST", null);
        assertThrows(IllegalArgumentException.class, () -> dateRiepiloghiService.saveDateRiepiloghi(dateRiepiloghiPayloadDTO, headers));
    }
}
