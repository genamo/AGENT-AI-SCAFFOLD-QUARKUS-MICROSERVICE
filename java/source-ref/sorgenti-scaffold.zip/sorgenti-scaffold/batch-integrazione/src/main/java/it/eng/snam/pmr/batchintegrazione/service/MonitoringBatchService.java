package it.eng.snam.pmr.batchintegrazione.service;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.faulttolerance.CircuitBreaker;
import org.eclipse.microprofile.faulttolerance.Retry;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;
import org.jboss.logging.MDC;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringBatchDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringBatchSearchDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.exception.RetryableRemoteException;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CacheUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class MonitoringBatchService extends AbstractService {

    private static final Logger LOG =
            Logger.getLogger(MonitoringBatchService.class);

    private static final TypeReference<List<MonitoringBatchDTO>> LIST_TYPE_BATCH =
            new TypeReference<>() {};

    @Inject
    @RestClient
    BatchIntegrazioneDgClient clientforBatch;

    @Inject
    ObjectMapper objectMapperForBatch;

    @Inject
    CacheUtils cacheUtilsForBatch;

    @ConfigProperty(
        name = "cache.monitoring-batch.last-executions.ttl-seconds",
        defaultValue = "300"
    )
    int lastExecutionsTtlSecondsForBatch;

    // =========================
    // API
    // =========================

    public List<MonitoringBatchDTO> getAll() {
        try (Response resp = clientforBatch.getAllMonitoringBatch()) {
            return handleListResponse(resp, "GET /monitoring-batch");
        }
    }

    public Optional<MonitoringBatchDTO> getById(Long id) {
        try (Response resp = clientforBatch.getByIdMonitoringBatch(id)) {

            int status = resp.getStatus();

            if (status == Response.Status.NOT_FOUND.getStatusCode()) {
                return Optional.empty();
            }
            if (status == Response.Status.OK.getStatusCode()) {
                return Optional.ofNullable(
                        resp.readEntity(MonitoringBatchDTO.class));
            }
            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                throw new IllegalArgumentException(
                        "getById: richiesta non valida. " + safeReadBody(resp));
            }

            throw remoteError("GET /monitoring-batch/{id}", status, resp);
        }
    }

    public Optional<MonitoringBatchDTO> getByTransactionId(String txId) {
        try (Response resp =
                     clientforBatch.getByTransactionIdMonitoringBatch(txId)) {

            int status = resp.getStatus();

            if (status == Response.Status.NOT_FOUND.getStatusCode()) {
                return Optional.empty();
            }
            if (status == Response.Status.OK.getStatusCode()) {
                return Optional.ofNullable(
                        resp.readEntity(MonitoringBatchDTO.class));
            }
            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                throw new IllegalArgumentException(
                        "getByTransactionId: richiesta non valida. " +
                                safeReadBody(resp));
            }

            throw remoteError(
                    "GET /monitoring-batch/transaction/{transactionId}",
                    status, resp
            );
        }
    }

    /**
     * CACHED (Redis distribuita)
     */
    public List<MonitoringBatchDTO> getLastExecutions(int limit) {

        String cacheKey = cacheUtilsForBatch.key(
                "monitoring-batch",
                "last-executions",
                "limit=" + limit,
                "processType=" + headersCtx.getProcessType()
        );

        return cacheUtilsForBatch.getOrCompute(
                cacheKey,
                LIST_TYPE_BATCH,
                lastExecutionsTtlSecondsForBatch,
                () -> {
                    try (Response resp =
                                 clientforBatch.getLastExecutionsMonitoringBatch(limit)) {

                        LOG.infof(
                                "Cache miss per key %s - recupero da remoto (PT=%s)",
                                cacheKey,
                                headersCtx.getProcessType()
                        );

                        return handleListResponse(
                                resp,
                                "GET /monitoring-batch/last-executions"
                        );
                    }
                }
        );
    }

    public List<MonitoringBatchDTO> getByPeriod(
            Integer month,
            Integer day
    ) {
        try (Response resp =
                     clientforBatch.getByPeriodMonitoringBatch(month, day)) {

            return handleListResponse(
                    resp,
                    "GET /monitoring-batch/period"
            );
        }
    }

    public MonitoringBatchDTO save(MonitoringBatchDTO dtoSaveBatch) {
        try (Response resp = clientforBatch.saveMonitoringBatch(dtoSaveBatch)) {

            int statusBatch = resp.getStatus();

            if (statusBatch == Response.Status.OK.getStatusCode()
                    || statusBatch == Response.Status.CREATED.getStatusCode()) {

                return resp.readEntity(MonitoringBatchDTO.class);
            }

            if (statusBatch == Response.Status.BAD_REQUEST.getStatusCode()) {
                throw new IllegalArgumentException(
                        "save: richiesta non valida. " +
                                safeReadBody(resp));
            }

            throw remoteError(
                    "POST /monitoring-batch/save",
                    statusBatch, resp
            );
        }
    }

    @Retry(
            maxRetries = 3,
            delay = 1000,
            delayUnit = ChronoUnit.MILLIS,
            jitter = 200,
            jitterDelayUnit = ChronoUnit.MILLIS,
            retryOn = { RetryableRemoteException.class },
            abortOn = { IllegalArgumentException.class }
        )
        @Timeout(5_000)
        @CircuitBreaker(
            requestVolumeThreshold = 10,
            failureRatio = 0.5,
            delay = 10,
            delayUnit = ChronoUnit.SECONDS
        )
        public List<MonitoringBatchDTO> findByCustomSearch(MonitoringBatchSearchDTO searchBatchDto) {
            try (Response resp = clientforBatch.findByCustomSearchMonitoringBatch(searchBatchDto)) {

                int statusBatch = resp.getStatus();

                if (statusBatch == Response.Status.NO_CONTENT.getStatusCode()) {
                    return List.of();
                }

                if (statusBatch == Response.Status.OK.getStatusCode()) {
                    return handleListResponse(resp, "POST /monitoring-batch/search");
                }

                if (statusBatch == Response.Status.BAD_REQUEST.getStatusCode()) {
                    throw new IllegalArgumentException(
                            "findByCustomSearchMonitoringBatch: richiesta non valida. " + safeReadBody(resp));
                }

                if (isRetryableStatus(statusBatch)) {
                    throw new RetryableRemoteException(
                            "Retryable HTTP " + statusBatch + " - " + safeReadBody(resp));
                }

                throw remoteError("POST /monitoring-batch/search", statusBatch, resp);
            }
        }

    private boolean isRetryableStatus(int status) {
        return status == 429
                || status == 500
                || status == 502
                || status == 503
                || status == 504;
    }
    
    
    // =========================
    // Helpers
    // =========================

    private List<MonitoringBatchDTO> handleListResponse(
            Response resp,
            String operation
    ) {
        int status = resp.getStatus();

        if (status == Response.Status.NO_CONTENT.getStatusCode()) {
            return List.of();
        }

        if (status == Response.Status.OK.getStatusCode()) {
            String json = resp.readEntity(String.class);
            return readList(json);
        }

        if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
            throw new IllegalArgumentException(
                    operation + ": richiesta non valida. " +
                            safeReadBody(resp));
        }

        throw remoteError(operation, status, resp);
    }

    private List<MonitoringBatchDTO> readList(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return objectMapperForBatch.readValue(json, LIST_TYPE_BATCH);
        } catch (Exception e) {
            throw new RemoteCallException(
                    "Impossibile deserializzare lista MonitoringBatchDTO",
                    e
            );
        }
    }
    
    
    public void saveBatchStatus(String transId,String flow,String sender, LocalDate day,  BatchStatus status) {
        saveBatchStatus(transId,flow,sender, day, status, null, null);
    }

    public void saveBatchStatus(String transId,String flow,String sender,  LocalDate day,
                                 BatchStatus status,
                                 String fileBatch,
                                 String fileOutput) {

        MonitoringBatchDTO dto = MonitoringBatchDTO.builder()
                .transactionId(transId)
                .correlationId(transId)
                .flowId(flow)
                .dayNumber(toDayNumber(day))
                .monthNumber(toMonthNumber(day))
                .granularita("G")
                .sender(sender)
                .isWorkaround(false)
                .fileBatch(encodeToBase64(fileBatch))
                .fileOutput(encodeToBase64(fileOutput))
                .status(status.code)
                .statusDescription(status.description)
                .actionDate(LocalDateTime.now())
                .userAction(
                        Optional.ofNullable(MDC.get(AuthorizationUtils.USER_ID))
                                .map(Object::toString)
                                .orElse("SYSTEM")
                )
                .isDeleted(0)
                .build();

        save(dto);
    }

   
	private int toDayNumber(LocalDate date) {
		return date.getYear() * 10000 + date.getMonthValue() * 100 + date.getDayOfMonth();
	}

    private int toMonthNumber(LocalDate date) {
        return date.getYear() * 100 + date.getMonthValue();
    }

    private String encodeToBase64(String jsonFile) {
        if (jsonFile == null) {
            return null;
        }
        return Base64.getEncoder().encodeToString(jsonFile.getBytes(StandardCharsets.UTF_8));
    }

    // =========================================================
    // STATUS ENUM
    // =========================================================

    public enum BatchStatus {
        INIT(0, "INIT"),
        BEGIN(100, "BEGIN"),
        PROGRESS(150, "PROGRESS"),
        COMPLETED(200, "COMPLETED"),
        ERROR(400, "ERROR");

        final int code;
        final String description;

        BatchStatus(int code, String description) {
            this.code = code;
            this.description = description;
        }
    }
    
    
    
}