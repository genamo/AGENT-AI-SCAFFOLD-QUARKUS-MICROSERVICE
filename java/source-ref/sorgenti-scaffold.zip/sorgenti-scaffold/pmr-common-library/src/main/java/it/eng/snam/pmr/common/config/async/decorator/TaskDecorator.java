package it.eng.snam.pmr.common.config.async.decorator;

@FunctionalInterface
public interface TaskDecorator {

    Runnable decorate(Runnable runnable);
}