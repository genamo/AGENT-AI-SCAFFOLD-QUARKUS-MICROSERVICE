package it.eng.snam.pmr.common.dto;

import java.time.Instant;

public record UserMeterModuleAuthorizationDTO(
        Long userMeterModuleAuthorizationId,
        String userCode,
        Long userId,
        String meterCode,
        String meterId,
        String moduleCode,
        Instant insertDate,
        Instant updateDate,
        String organizationCode,
        Long organizationId,
        String weakSapCode,
        Long flowId,
        Long entityId,
        Integer cancelledFlag,
        String pkSource,
        Integer denominatore,
        Integer penalita,
        String idErrore
) {}
