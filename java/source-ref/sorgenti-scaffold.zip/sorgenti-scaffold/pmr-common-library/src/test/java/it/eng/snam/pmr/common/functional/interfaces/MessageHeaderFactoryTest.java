package it.eng.snam.pmr.common.functional.interfaces;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import it.eng.snam.pmr.common.dto.kafka.produce.MessageHeaderContext;
import it.eng.snam.pmr.common.functional.interfaces.kafka.producer.MessageHeaderFactory;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.mdc.MdcManager;

class MessageHeaderFactoryTest {

    @Test
    void messageHeaderFactoryMdcShouldCreateContextFromMdc() {
        try (MockedStatic<MdcManager> mdcMock = mockStatic(MdcManager.class)) {

            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.TN)).thenReturn("TX-MDC");
            mdcMock.when(() -> MdcManager.getHeader(AuthorizationUtils.USER_ID)).thenReturn("USER-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.KL)).thenReturn("KL-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.PT)).thenReturn("PT-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.FT)).thenReturn("FT-MDC");

            MessageHeaderContext context = MessageHeaderFactory.mdc().create();

            assertEquals("TX-MDC", context.getTransactionId());
            assertEquals("USER-MDC", context.getUserId());
            assertEquals("KL-MDC", context.getKeyLogic());
            assertEquals("PT-MDC", context.getProcessType());
            assertEquals("FT-MDC", context.getFlowType());
        }
    }

    @Test
    void messageHeaderFactoryMergeShouldGivePriorityToOverrideThenMdc() {
        MessageHeaderContext override = MessageHeaderContext.builder().transactionId("TX-OVERRIDE").flowType(
                "FT-OVERRIDE").messageKey("KEY-OVERRIDE").build();

        try (MockedStatic<MdcManager> mdcMock = mockStatic(MdcManager.class)) {

            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.TN)).thenReturn("TX-MDC");
            mdcMock.when(() -> MdcManager.getHeader(AuthorizationUtils.USER_ID)).thenReturn("USER-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.KL)).thenReturn("KL-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.PT)).thenReturn("PT-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.FT)).thenReturn("FT-MDC");

            MessageHeaderContext context = MessageHeaderFactory.resolve(MessageHeaderFactory.merge(override));

            assertEquals("TX-OVERRIDE", context.getTransactionId());
            assertEquals("USER-MDC", context.getUserId());
            assertEquals("KL-MDC", context.getKeyLogic());
            assertEquals("PT-MDC", context.getProcessType());
            assertEquals("FT-OVERRIDE", context.getFlowType());
            assertEquals("KEY-OVERRIDE", context.getMessageKey());
        }
    }

    @Test
    void messageHeaderFactoryResolveShouldUseMdcWhenFactoryIsNull() {
        try (MockedStatic<MdcManager> mdcMock = mockStatic(MdcManager.class)) {

            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.TN)).thenReturn("TX-MDC");
            mdcMock.when(() -> MdcManager.getHeader(AuthorizationUtils.USER_ID)).thenReturn("USER-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.KL)).thenReturn("KL-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.PT)).thenReturn("PT-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.FT)).thenReturn("FT-MDC");

            MessageHeaderContext context = MessageHeaderFactory.resolve(null);

            assertEquals("TX-MDC", context.getTransactionId());
            assertEquals("USER-MDC", context.getUserId());
            assertEquals("KL-MDC", context.getKeyLogic());
            assertEquals("PT-MDC", context.getProcessType());
            assertEquals("FT-MDC", context.getFlowType());
            assertNotNull(context.getMessageKey());
        }
    }

    @Test
    void messageHeaderFactoryResolveShouldApplyDefaultsWhenValuesAreBlank() {
        MessageHeaderFactory factory = () -> MessageHeaderContext.builder().transactionId(null).userId("USER-MDC").keyLogic("")
                                                                 .processType(" ").flowType(" ").messageKey(" ")
                                                                 .build();

        MessageHeaderContext context = MessageHeaderFactory.resolve(factory);

        assertNull(context.getTransactionId());
        assertEquals("USER-MDC", context.getUserId());
        assertNull(context.getKeyLogic());
        assertEquals("N/A", context.getProcessType());
        assertEquals("UNKNOWN", context.getFlowType());
        assertNotNull(context.getMessageKey());
    }

    @Test
    void messageHeaderFactoryResolveShouldLowerCaseUserId() {
        MessageHeaderFactory factory = () -> MessageHeaderContext.builder().transactionId("TX").userId("USER.UPPER")
                                                                 .keyLogic("KL").processType("PT").flowType("FT")
                                                                 .messageKey("KEY").build();

        MessageHeaderContext context = MessageHeaderFactory.resolve(factory);

        assertEquals("USER.UPPER", context.getUserId());
    }

    @Test
    void messageHeaderFactoryMergeShouldHandleNullOverride() {
        try (MockedStatic<MdcManager> mdcMock = mockStatic(MdcManager.class)) {

            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.TN)).thenReturn("TX-MDC");
            mdcMock.when(() -> MdcManager.getHeader(AuthorizationUtils.USER_ID)).thenReturn("USER-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.KL)).thenReturn("KL-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.PT)).thenReturn("PT-MDC");
            mdcMock.when(() -> MdcManager.getHeader(CommonConstants.LogParams.FT)).thenReturn("FT-MDC");

            MessageHeaderContext context = MessageHeaderFactory.resolve(MessageHeaderFactory.merge(null));

            assertEquals("TX-MDC", context.getTransactionId());
            assertEquals("USER-MDC", context.getUserId());
            assertEquals("KL-MDC", context.getKeyLogic());
            assertEquals("PT-MDC", context.getProcessType());
            assertEquals("FT-MDC", context.getFlowType());
            assertNotNull(context.getMessageKey());
        }
    }
}
