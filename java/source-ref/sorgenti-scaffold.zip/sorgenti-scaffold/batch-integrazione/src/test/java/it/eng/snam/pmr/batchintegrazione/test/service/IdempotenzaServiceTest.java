package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.IdempotenzaRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.IdempotenzaResponseDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.IdempotenzaService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class IdempotenzaServiceTest {

    @Mock
    BatchIntegrazioneDgClient client;

    @Mock
    ObjectMapper objectMapper;

    @Mock
    RequestHeadersContext headersCtx;

    @InjectMocks
    IdempotenzaService service;

    @BeforeEach
    void injectHeadersCtxIntoAbstractService() throws Exception {
        Field field = AbstractService.class.getDeclaredField("headersCtx");
        field.setAccessible(true);
        field.set(service, headersCtx);
    }

    private Response mockResp(int status) {
        Response response = org.mockito.Mockito.mock(Response.class);
        when(response.getStatus()).thenReturn(status);
        return response;
    }

    private IdempotenzaRequestDTO buildRequest() {
        return new IdempotenzaRequestDTO("tx1", "FLOW", "KL", "IN_PROGRESS", null);
    }

    private void mockHeadersForRemoteError() {
        when(headersCtx.getKeyLogic()).thenReturn("kl");
        when(headersCtx.getTransactionId()).thenReturn("tx");
        when(headersCtx.getProcessType()).thenReturn("PT");
    }

    // ======================================================
    // INSERT
    // ======================================================

    @Test
    void insert_200_validJson_returnsDto() throws Exception {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(200);

        when(resp.readEntity(String.class)).thenReturn("{\"started\":true}");
        when(client.insertIdempotenza(request)).thenReturn(resp);

        IdempotenzaResponseDTO expected = new IdempotenzaResponseDTO(true, "tx1", "IN_PROGRESS");
        when(objectMapper.readValue("{\"started\":true}", IdempotenzaResponseDTO.class)).thenReturn(expected);

        IdempotenzaResponseDTO result = service.insert(request);

        assertEquals(expected, result);
    }

    @Test
    void insert_200_blankJson_throwsRemoteCallException() {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(200);

        when(resp.readEntity(String.class)).thenReturn(" ");
        when(client.insertIdempotenza(request)).thenReturn(resp);

        assertThrows(RemoteCallException.class, () -> service.insert(request));
    }

    @Test
    void insert_200_invalidJson_throwsRemoteCallException() throws Exception {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(200);

        when(resp.readEntity(String.class)).thenReturn("{invalid}");
        when(client.insertIdempotenza(request)).thenReturn(resp);
        when(objectMapper.readValue("{invalid}", IdempotenzaResponseDTO.class))
                .thenThrow(new RuntimeException("boom"));

        assertThrows(RemoteCallException.class, () -> service.insert(request));
    }

    @Test
    void insert_400_withBody_throwsIllegalArgumentException() {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(400);

        when(resp.hasEntity()).thenReturn(true);
        when(resp.readEntity(String.class)).thenReturn("bad request");
        when(client.insertIdempotenza(request)).thenReturn(resp);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> service.insert(request));
        assertEquals("Idempotenza insert 400: bad request", ex.getMessage());
    }

    @Test
    void insert_400_withoutBody_throwsIllegalArgumentExceptionWithDefaultMessage() {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(400);

        when(resp.hasEntity()).thenReturn(false);
        when(client.insertIdempotenza(request)).thenReturn(resp);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> service.insert(request));
        assertEquals("Idempotenza insert 400: Bad Request", ex.getMessage());
    }

    @Test
    void insert_500_throwsRemoteCallException() {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(500);

        when(resp.hasEntity()).thenReturn(false);
        when(client.insertIdempotenza(request)).thenReturn(resp);

        mockHeadersForRemoteError();

        RemoteCallException ex = assertThrows(RemoteCallException.class, () -> service.insert(request));
        assertEquals("POST /idempotenza-flussi-insert errore HTTP 500", ex.getMessage());
    }

    // ======================================================
    // UPDATE
    // ======================================================

    @Test
    void update_200_validJson_returnsDto() throws Exception {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(200);

        when(resp.readEntity(String.class)).thenReturn("{\"started\":false}");
        when(client.updateIdempotenza(request)).thenReturn(resp);

        IdempotenzaResponseDTO expected = new IdempotenzaResponseDTO(false, "tx1", "IN_PROGRESS");
        when(objectMapper.readValue("{\"started\":false}", IdempotenzaResponseDTO.class)).thenReturn(expected);

        IdempotenzaResponseDTO result = service.update(request);

        assertEquals(expected, result);
    }

    @Test
    void update_200_blankJson_throwsRemoteCallException() {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(200);

        when(resp.readEntity(String.class)).thenReturn(" ");
        when(client.updateIdempotenza(request)).thenReturn(resp);

        assertThrows(RemoteCallException.class, () -> service.update(request));
    }

    @Test
    void update_200_invalidJson_throwsRemoteCallException() throws Exception {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(200);

        when(resp.readEntity(String.class)).thenReturn("{invalid}");
        when(client.updateIdempotenza(request)).thenReturn(resp);
        when(objectMapper.readValue("{invalid}", IdempotenzaResponseDTO.class))
                .thenThrow(new RuntimeException("boom"));

        assertThrows(RemoteCallException.class, () -> service.update(request));
    }

    @Test
    void update_400_withBody_throwsIllegalArgumentException() {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(400);

        when(resp.hasEntity()).thenReturn(true);
        when(resp.readEntity(String.class)).thenReturn("bad request");
        when(client.updateIdempotenza(request)).thenReturn(resp);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> service.update(request));
        assertEquals("Idempotenza update 400: bad request", ex.getMessage());
    }

    @Test
    void update_400_withoutBody_throwsIllegalArgumentExceptionWithDefaultMessage() {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(400);

        when(resp.hasEntity()).thenReturn(false);
        when(client.updateIdempotenza(request)).thenReturn(resp);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> service.update(request));
        assertEquals("Idempotenza update 400: Bad Request", ex.getMessage());
    }

    @Test
    void update_500_throwsRemoteCallException() {
        IdempotenzaRequestDTO request = buildRequest();
        Response resp = mockResp(500);

        when(resp.hasEntity()).thenReturn(false);
        when(client.updateIdempotenza(request)).thenReturn(resp);

        mockHeadersForRemoteError();

        RemoteCallException ex = assertThrows(RemoteCallException.class, () -> service.update(request));
        assertEquals("POST /idempotenza-flussi-update errore HTTP 500", ex.getMessage());
    }
}
