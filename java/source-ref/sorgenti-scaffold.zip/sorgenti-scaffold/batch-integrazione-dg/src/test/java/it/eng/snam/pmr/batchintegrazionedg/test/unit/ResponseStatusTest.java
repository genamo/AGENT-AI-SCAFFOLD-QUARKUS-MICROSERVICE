package it.eng.snam.pmr.batchintegrazionedg.test.unit;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import it.eng.snam.pmr.batchintegrazionedg.response.ResponseStatus;

class ResponseStatusTest {

    @Test
    void elaborato_hasCorrectStatus() {
        assertEquals("ELABORATO", ResponseStatus.ELABORATO.getStatus());
    }

    @Test
    void inElaborazione_hasCorrectStatus() {
        assertEquals("IN ELABORAZIONE", ResponseStatus.IN_ELABORAZIONE.getStatus());
    }

    @Test
    void inErrore_hasCorrectStatus() {
        assertEquals("IN ERRORE", ResponseStatus.IN_ERRORE.getStatus());
    }

    @Test
    void presoInCarico_hasCorrectStatus() {
        assertEquals("PRESO IN CARICO", ResponseStatus.PRESO_IN_CARICO.getStatus());
    }

    @Test
    void allValues_exist() {
        assertEquals(4, ResponseStatus.values().length);
    }

    @Test
    void valueOf_works() {
        assertEquals(ResponseStatus.ELABORATO, ResponseStatus.valueOf("ELABORATO"));
    }
}
