package it.eng.snam.pmr.batchintegrazionedg.repository;

import java.util.Optional;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import it.eng.snam.pmr.batchintegrazionedg.domain.IdempotenzaFlussi;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class IdempotenzaFlussiRepository implements PanacheRepository<IdempotenzaFlussi> {

    public Optional<IdempotenzaFlussi> findByTransactionId(String transactionId) {
        return find("transactionId = ?1 AND isDeleted = 0", transactionId)
                .firstResultOptional();
    }
}
