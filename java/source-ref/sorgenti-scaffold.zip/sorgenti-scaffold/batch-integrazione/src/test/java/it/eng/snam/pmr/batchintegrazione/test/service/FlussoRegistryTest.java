package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.when;

import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.service.FlussoRegistry;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.FlussoHandler;
import jakarta.enterprise.inject.Instance;

@ExtendWith(MockitoExtension.class)
class FlussoRegistryTest {

    @Mock
    Instance<FlussoHandler> handlerInstance;

    @Mock
    FlussoHandler handler1;

    @Mock
    FlussoHandler handler2;

    private FlussoRegistry registry;

    @BeforeEach
    void setUp() {
        when(handler1.getFlowType()).thenReturn("FLOW_1");
        when(handler2.getFlowType()).thenReturn("FLOW_2");
        when(handlerInstance.stream()).thenReturn(Stream.of(handler1, handler2));

        registry = new FlussoRegistry(handlerInstance);
    }

    @Test
    void get_existingFlow_returnsMappedHandler() {
        assertSame(handler1, registry.get("FLOW_1"));
        assertSame(handler2, registry.get("FLOW_2"));
    }

    @Test
    void get_unknownFlow_returnsNull() {
        assertNull(registry.get("UNKNOWN_FLOW"));
    }
}
