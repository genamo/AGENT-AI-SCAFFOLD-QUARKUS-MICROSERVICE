package it.eng.snam.pmr.batchintegrazionedg.test.resource;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.TestProfile;
import io.restassured.http.ContentType;
import it.eng.snam.pmr.batchintegrazionedg.domain.IdempotenzaFlussi;
import it.eng.snam.pmr.batchintegrazionedg.domain.IdempotenzaStatus;
import it.eng.snam.pmr.batchintegrazionedg.dto.IdempotenzaResponseDTO;
import it.eng.snam.pmr.batchintegrazionedg.service.IdempotenzaFlussiService;
import it.eng.snam.pmr.batchintegrazionedg.test.service.NoSecurityTestProfile;

@QuarkusTest
@TestProfile(NoSecurityTestProfile.class)
class IdempotenzaFlussiResourceTest {

    @InjectMock
    IdempotenzaFlussiService service;

    private IdempotenzaFlussi buildEntity(String transactionId, IdempotenzaStatus status) {
        IdempotenzaFlussi entity = new IdempotenzaFlussi();
        entity.setTransactionId(transactionId);
        entity.setFlowId("FLOW-001");
        entity.setKeyLogic("KL-001");
        entity.setStatus(status);
        entity.setErrorMessage(status == IdempotenzaStatus.ERROR ? "Errore tecnico" : null);
        return entity;
    }

    // =========================================================
    // INSERT
    // =========================================================

    @Test
    void insert_newTransaction_returns200WithStartedTrue() {
        when(service.start(any()))
                .thenReturn(new IdempotenzaResponseDTO(true, "TXN-001", "IN_PROGRESS"));

        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "transactionId": "TXN-001",
                  "flowId": "FLOW-001",
                  "keyLogic": "KL-001"
                }
                """)
            .when()
                .post("/idempotenza-flussi/idempotenza-flussi-insert")
            .then()
                .statusCode(200)
                .body("started", equalTo(true))
                .body("transactionId", equalTo("TXN-001"))
                .body("status", equalTo("IN_PROGRESS"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).start(any());
    }

    @Test
    void insert_duplicateTransaction_returns200WithStartedFalse() {
        when(service.start(any()))
                .thenReturn(new IdempotenzaResponseDTO(false, "TXN-001", "COMPLETED"));

        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "transactionId": "TXN-001",
                  "flowId": "FLOW-001",
                  "keyLogic": "KL-001"
                }
                """)
            .when()
                .post("/idempotenza-flussi/idempotenza-flussi-insert")
            .then()
                .statusCode(200)
                .body("started", equalTo(false))
                .body("transactionId", equalTo("TXN-001"))
                .body("status", equalTo("COMPLETED"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).start(any());
    }

    @Test
    void insert_missingTransactionId_returns400AndHeaders() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "flowId": "FLOW-001",
                  "keyLogic": "KL-001"
                }
                """)
            .when()
                .post("/idempotenza-flussi/idempotenza-flussi-insert")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("transactionId obbligatorio"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).start(any());
    }

    @Test
    void insert_blankTransactionId_returns400AndHeaders() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "transactionId": "   ",
                  "flowId": "FLOW-001",
                  "keyLogic": "KL-001"
                }
                """)
            .when()
                .post("/idempotenza-flussi/idempotenza-flussi-insert")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("transactionId obbligatorio"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).start(any());
    }

    // =========================================================
    // UPDATE STATUS
    // =========================================================

    @Test
    void update_existingTransaction_returns200WithStartedFalse() {
        when(service.updateStatus(any()))
                .thenReturn(new IdempotenzaResponseDTO(false, "TXN-001", "COMPLETED"));

        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "transactionId": "TXN-001",
                  "flowId": "FLOW-001",
                  "keyLogic": "KL-001",
                  "status": "COMPLETED"
                }
                """)
            .when()
                .post("/idempotenza-flussi/idempotenza-flussi-update")
            .then()
                .statusCode(200)
                .body("started", equalTo(false))
                .body("transactionId", equalTo("TXN-001"))
                .body("status", equalTo("COMPLETED"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).updateStatus(any());
    }

    @Test
    void update_missingTransactionId_returns400AndHeaders() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "flowId": "FLOW-001",
                  "keyLogic": "KL-001",
                  "status": "COMPLETED"
                }
                """)
            .when()
                .post("/idempotenza-flussi/idempotenza-flussi-update")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("transactionId obbligatorio"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).updateStatus(any());
    }

    @Test
    void update_blankTransactionId_returns400AndHeaders() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "transactionId": "   ",
                  "flowId": "FLOW-001",
                  "keyLogic": "KL-001",
                  "status": "COMPLETED"
                }
                """)
            .when()
                .post("/idempotenza-flussi/idempotenza-flussi-update")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("transactionId obbligatorio"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).updateStatus(any());
    }

    // =========================================================
    // SEARCH
    // =========================================================

    @Test
    void search_found_returns200WithEntity() {
        when(service.findByTransactionId("TXN-001"))
                .thenReturn(Optional.of(buildEntity("TXN-001", IdempotenzaStatus.IN_PROGRESS)));

        given()
            .queryParam("transactionId", "TXN-001")
            .when()
                .get("/idempotenza-flussi/search")
            .then()
                .statusCode(200)
                .body("transactionId", equalTo("TXN-001"))
                .body("flowId", equalTo("FLOW-001"))
                .body("keyLogic", equalTo("KL-001"))
                .body("status", equalTo("IN_PROGRESS"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).findByTransactionId("TXN-001");
    }

    @Test
    void search_notFound_returns404AndHeaders() {
        when(service.findByTransactionId("UNKNOWN"))
                .thenReturn(Optional.empty());

        given()
            .queryParam("transactionId", "UNKNOWN")
            .when()
                .get("/idempotenza-flussi/search")
            .then()
                .statusCode(404)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("NOT_FOUND"))
                .body("messageDescription", equalTo("Record non trovato"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).findByTransactionId("UNKNOWN");
    }

    @Test
    void search_missingTransactionId_returns400AndHeaders() {
        given()
            .when()
                .get("/idempotenza-flussi/search")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("transactionId obbligatorio"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).findByTransactionId(any());
    }

    @Test
    void search_blankTransactionId_returns400AndHeaders() {
        given()
            .queryParam("transactionId", "   ")
            .when()
                .get("/idempotenza-flussi/search")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("transactionId obbligatorio"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).findByTransactionId(any());
    }
}
