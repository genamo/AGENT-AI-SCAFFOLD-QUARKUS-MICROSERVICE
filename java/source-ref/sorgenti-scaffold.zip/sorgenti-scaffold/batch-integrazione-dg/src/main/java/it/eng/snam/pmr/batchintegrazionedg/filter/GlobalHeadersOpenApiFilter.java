package it.eng.snam.pmr.batchintegrazionedg.filter;

import java.util.Collections;
import java.util.Map;

import org.eclipse.microprofile.openapi.OASFactory;
import org.eclipse.microprofile.openapi.OASFilter;
import org.eclipse.microprofile.openapi.models.OpenAPI;
import org.eclipse.microprofile.openapi.models.PathItem;
import org.eclipse.microprofile.openapi.models.media.Schema;
import org.eclipse.microprofile.openapi.models.parameters.Parameter;


public class GlobalHeadersOpenApiFilter implements OASFilter {

    @Override
    public void filterOpenAPI(OpenAPI openAPI) {

        if (openAPI.getPaths() == null || openAPI.getPaths().getPathItems() == null) {
            return;
        }

        for (Map.Entry<String, PathItem> entry
                : openAPI.getPaths().getPathItems().entrySet()) {

            addHeaders(entry.getValue());
        }
    }

    private void addHeaders(PathItem pathItem) {
        addIfPresent(pathItem.getGET());
        addIfPresent(pathItem.getPOST());
        addIfPresent(pathItem.getPUT());
        addIfPresent(pathItem.getDELETE());
        addIfPresent(pathItem.getPATCH());
        addIfPresent(pathItem.getOPTIONS());
        addIfPresent(pathItem.getHEAD());
    }

    private void addIfPresent(
            org.eclipse.microprofile.openapi.models.Operation operation) {

        if (operation == null) return;

        operation.addParameter(header("KEY-LOGIC", "Chiave di correlazione tecnica"));
		operation.addParameter(header("TRANSACTION-ID", "Transaction id tecnico"));
		operation.addParameter(header("MOD-ASYNC", "Modalità asincrona"));
		operation.addParameter(header("PROCESS-TYPE", "Tipo processo (GUI | FLUSSO | N/A)"));
    }

    private Parameter header(String name, String description) {

        Schema schema = OASFactory.createSchema();
        schema.setType(Collections.singletonList(Schema.SchemaType.STRING));

        Parameter p = OASFactory.createParameter();
        p.setName(name);
        p.setIn(Parameter.In.HEADER);   // ✅ FIX QUI
        p.setRequired(false);
        p.setDescription(description);
        p.setSchema(schema);

        return p;
    }
}
