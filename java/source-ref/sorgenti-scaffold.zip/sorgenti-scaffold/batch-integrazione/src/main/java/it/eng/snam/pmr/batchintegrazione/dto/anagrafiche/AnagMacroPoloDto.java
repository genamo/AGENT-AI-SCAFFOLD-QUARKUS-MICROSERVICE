package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AnagMacroPoloDto(
        String codiceMacroPolo,
        String descrizione,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {}