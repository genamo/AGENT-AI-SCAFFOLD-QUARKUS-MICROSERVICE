package it.eng.snam.pmr.batchintegrazione.test.resource.external;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.List;

import it.eng.snam.pmr.batchintegrazione.dto.external.MailMonitoraggioVerbaliMisuraDTO;
import it.eng.snam.pmr.batchintegrazione.dto.external.MailMonitoraggioVerbaliMisuraFilter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.dto.external.AssoMailRemiDTO;
import it.eng.snam.pmr.batchintegrazione.dto.external.AssoMailRemiFilter;
import it.eng.snam.pmr.batchintegrazione.resource.external.SummerPmrIntegrationResource;
import it.eng.snam.pmr.batchintegrazione.service.external.SummerPmrIntegrationService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class SummerPmrIntegrationResourceTest {

    @Mock
    private SummerPmrIntegrationService service;

    @Mock
    private Utility utility;

    @InjectMocks
    private SummerPmrIntegrationResource resource;

    private AssoMailRemiFilter filter;
    private MailMonitoraggioVerbaliMisuraFilter mailMonitoraggioVerbaliMisuraFilter;


    @BeforeEach
    void setUp() {
        filter = new AssoMailRemiFilter();
        mailMonitoraggioVerbaliMisuraFilter = new MailMonitoraggioVerbaliMisuraFilter();
    }

    @Test
    void filteredSearch_shouldReturnOkOrEmpty_whenServiceReturnsList() {
        List<AssoMailRemiDTO> result = List.of(new AssoMailRemiDTO());
        Response expectedResponse = Response.ok().build();

        when(service.filteredSearch(filter)).thenReturn(result);
        when(utility.okOrEmpty(result)).thenReturn(expectedResponse);

        Response actualResponse = resource.filteredSearch(filter);

        assertSame(expectedResponse, actualResponse);

        verify(service).filteredSearch(filter);
        verify(utility).okOrEmpty(result);
        verifyNoMoreInteractions(service, utility);
    }

    @Test
    void findRemiByIdMail_shouldReturnOkOrEmpty_whenServiceReturnsList() {
        List<String> result = List.of("TEST");
        Response expectedResponse = Response.ok().build();

        when(service.findRemiByIdMail(any())).thenReturn(result);
        when(utility.okOrEmpty(result)).thenReturn(expectedResponse);

        Response actualResponse = resource.findRemiByIdMail(1L);

        assertSame(expectedResponse, actualResponse);

        verify(service).findRemiByIdMail(any());
        verify(utility).okOrEmpty(result);
        verifyNoMoreInteractions(service, utility);
    }

    @Test
    void filteredSearch_withMailMonitoraggioVerbaliMisuraFilter_shouldReturnOkOrEmpty_whenServiceReturnsList() {
        // Sostituisci "MailMonitoraggioVerbaliMisuraDTO" con il nome esatto della tua classe DTO
        List<MailMonitoraggioVerbaliMisuraDTO> result = List.of(new MailMonitoraggioVerbaliMisuraDTO());
        Response expectedResponse = Response.ok().build();

        when(service.filteredSearch(mailMonitoraggioVerbaliMisuraFilter)).thenReturn(result);
        when(utility.okOrEmpty(result)).thenReturn(expectedResponse);

        Response actualResponse = resource.filteredSearch(mailMonitoraggioVerbaliMisuraFilter);

        assertSame(expectedResponse, actualResponse);

        verify(service).filteredSearch(mailMonitoraggioVerbaliMisuraFilter);
        verify(utility).okOrEmpty(result);
        verifyNoMoreInteractions(service, utility);
    }
}
