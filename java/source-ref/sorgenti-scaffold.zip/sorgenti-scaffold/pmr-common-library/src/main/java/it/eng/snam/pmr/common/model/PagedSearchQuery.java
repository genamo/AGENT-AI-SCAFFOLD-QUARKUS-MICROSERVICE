package it.eng.snam.pmr.common.model;

import java.util.Map;

import lombok.Value;

@Value(staticConstructor = "of")
public class PagedSearchQuery {

    String jpql;
    Map<String, Object> params;
    Integer page;
    Integer size;

    public Integer resolvePage() {
        return resolve(page, 0);
    }

    public Integer resolveSize() {
        return resolve(size, 20);
    }

    private Integer resolve(Integer value, Integer safe) {
        return value != null && value > 0 ? value : safe;
    }
}
