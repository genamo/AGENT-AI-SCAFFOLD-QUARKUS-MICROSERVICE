package it.eng.snam.pmr.common.util.exception.mapper;

import java.util.Set;

import jakarta.validation.ConstraintViolation;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ConstraintViolationNormalizer {

    public String normalize(Set<ConstraintViolation<?>> violations) {
        return violations.stream().map(ConstraintViolationNormalizer::normalize).toList().toString();
    }

    private String normalize(ConstraintViolation<?> violation) {
        return violation.getPropertyPath() + ": " + violation.getMessage() + ": invalidValue(" + violation.getInvalidValue() + ")";
    }
}
