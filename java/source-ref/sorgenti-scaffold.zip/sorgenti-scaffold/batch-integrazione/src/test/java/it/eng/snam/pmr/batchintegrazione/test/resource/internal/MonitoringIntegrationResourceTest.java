package it.eng.snam.pmr.batchintegrazione.test.resource.internal;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.batchintegrazione.resource.internal.MonitoringIntegrationResource;
import it.eng.snam.pmr.batchintegrazione.service.internal.MonitoringIntegrationService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class MonitoringIntegrationResourceTest {

    @Test
    void sendRequestMonitoringIntegration_shouldCallServiceAndReturnOkResponse() {
        MonitoringIntegrationService service = mock(MonitoringIntegrationService.class);
        Utility utility = mock(Utility.class);

        MonitoringIntegrationResource resource = new MonitoringIntegrationResource(service, utility);

        MonitoringIntegration request = mock(MonitoringIntegration.class);
        Response expectedResponse = mock(Response.class);

        when(service.sendRequestMonitoringIntegration(request)).thenReturn(10L);
        when(utility.ok(10L)).thenReturn(expectedResponse);

        Response result = resource.sendRequestMonitoringIntegration(request);

        assertSame(expectedResponse, result);

        verify(service).sendRequestMonitoringIntegration(request);
        verify(utility).ok(10L);
        verifyNoMoreInteractions(service, utility);
    }
}
