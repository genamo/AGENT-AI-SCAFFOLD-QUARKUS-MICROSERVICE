package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AnagPoloDto(
        String codicePolo,
        String descrizione,
        String valido,
        String codiceMacroPolo,
        LocalDateTime actionDate,
        String userAction,
        Integer isDeleted
) {}