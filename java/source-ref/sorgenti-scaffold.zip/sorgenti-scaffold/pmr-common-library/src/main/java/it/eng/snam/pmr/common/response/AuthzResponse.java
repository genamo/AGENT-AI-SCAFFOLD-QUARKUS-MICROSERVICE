package it.eng.snam.pmr.common.response;

public record AuthzResponse(boolean enabled, String reason) {
}
