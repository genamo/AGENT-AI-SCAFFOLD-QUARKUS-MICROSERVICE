package it.eng.snam.pmr.batchintegrazionedg.scheduler;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.jboss.logging.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringBatchDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.request.BiometanoFilter;
import it.eng.snam.pmr.batchintegrazionedg.kafka.KafkaTopic;
import it.eng.snam.pmr.batchintegrazionedg.kafka.producer.KafkaGenericProducer;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringBatchService;
import it.eng.snam.pmr.batchintegrazionedg.utils.Utility;
import it.eng.snam.pmr.batchintegrazionedg.utils.Utility.FlussiStatus;
import it.eng.snam.pmr.common.dto.kafka.produce.MessageHeaderContext;
import it.eng.snam.pmr.common.util.JsonUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class CronJobHandlers {

    private static final Logger LOG = Logger.getLogger(CronJobHandlers.class);

    private static final String PROCESS_TYPE = "FLUSSO";
    private static final String FLOW_TYPE = "BATCH";

	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");

    private final MonitoringBatchService monitoringBatchService;
    private final KafkaGenericProducer producer;

    @Inject
    public CronJobHandlers(
            MonitoringBatchService monitoringBatchService,
            KafkaGenericProducer producer,
            ObjectMapper objectMapper) {

        this.monitoringBatchService = monitoringBatchService;
        this.producer = producer;
    }

    public void startBatch001() {
    	LOG.info("START BIOMETANO BATCH......");
        executeBatch(BatchType.BATCH001);
    }

    public void startBatch002() {
    	LOG.info("START DELIBERA_96 BATCH......");
        executeBatch(BatchType.BATCH002);
    }

    private void executeBatch(BatchType batchType) {
        String transactionId = buildTransactionId(batchType);
		MonitoringBatchDTO batch = buildBatchDto(transactionId, batchType.name(), FlussiStatus.BEGIN, null, null);
        monitoringBatchService.save(batch);
        try {
        	MessageHeaderContext context = buildHeader(transactionId, batchType);
    		byte[] payload = buildPayload(batchType, batch.monthNumber());
            producer.sendEventWithHeaders(
                    KafkaTopic.DELIBERA_BIOMETANO_TOPIC,
                    context,
                    payload,
                    Map.of());

		} catch (Exception e) {
			LOG.errorf(e, "Errore durante l'invio del batch %s a Kafka", batchType.name());
			monitoringBatchService.save(buildBatchDto(transactionId, batchType.name(), FlussiStatus.ERROR, null, e.getMessage()));
		}
		
    }

    private String buildTransactionId(BatchType batchType) {
		return batchType.name() + "_" + LocalDateTime.now().format(FORMATTER);
    }

	private MessageHeaderContext buildHeader(String transactionId, BatchType batchType) {
        return MessageHeaderContext.builder()
                .transactionId(transactionId)
                .processType(PROCESS_TYPE)
                .flowType(FLOW_TYPE)
                .messageKey(UUID.randomUUID().toString())
                .keyLogic(batchType.keyLogic())
                .build();
    }

	private byte[] buildPayload(BatchType batchType, Integer annoMese) {

	    try {
			YearMonth competenza = YearMonth.of(annoMese / 100, annoMese % 100);
	        BiometanoFilter payload;
			switch (batchType) {
			case BATCH001:
				payload = BiometanoFilter.builder()
					.executioner("JOB_BIOMETANO")
					.documentType("BIOMETANO")
					.fileFormat("XML")
					.competenza(competenza)
					.remiAssolutoList(List.of())
					.build();
				break;
			case BATCH002:
				payload = BiometanoFilter.builder()
					.executioner("JOB_DELIBERA96")
					.documentType("DELIBERA96")
					.fileFormat("XML")
					.competenza(competenza)
					.remiAssolutoList(List.of())
					.build();
				break;

			default:
				throw new IllegalArgumentException("Tipo batch non supportato: " + batchType.name());
			}
	        return JsonUtils.writeAsJsonBytesWithoutNull(payload);
	    } catch (Exception e) {
	        throw new IllegalArgumentException(
	                "Payload non serializzabile", e);
	    }
	}

    private enum BatchType {
        BATCH001,
        BATCH002;
        public String keyLogic() {
            return UUID.randomUUID().toString();
        }
    }
    
    private MonitoringBatchDTO buildBatchDto(String transId, String flow, FlussiStatus status, String fileBatch, String fileOutput) {
    	
		return MonitoringBatchDTO.builder()
				.transactionId(transId)
				.correlationId(transId)
				.actionDate(LocalDateTime.now())
				.dayNumber(Utility.toDayNumber(LocalDate.now().minusMonths(1).withDayOfMonth(1)))
				.fileBatch(fileBatch!=null ? Utility.encodeToBase64(fileBatch) : null)
				.fileOutput(fileOutput!=null ? Utility.encodeToBase64(fileOutput) : null)
				.flowId(flow)
				.granularita("M")
				.isDeleted(0)
				.isWorkaround(false)
				.monthNumber(Utility.toMonthNumber(LocalDate.now().minusMonths(1)))
				.status(status.code)
                .statusDescription(status.description)
				.userAction("SYSTEM")
				.sender("PMR")
				.build();
	}
}