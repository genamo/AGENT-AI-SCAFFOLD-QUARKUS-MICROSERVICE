package it.eng.snam.pmr.common.filter;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import it.eng.snam.pmr.common.annotation.AuthzRead;
import it.eng.snam.pmr.common.annotation.UserType;
import it.eng.snam.pmr.common.cache.AuthzAnnotationCache;
import it.eng.snam.pmr.common.resolver.MinimalContextResolver;
import it.eng.snam.pmr.common.service.AuthzService;
import it.eng.snam.pmr.common.service.RemiConeValidationService;

import jakarta.annotation.Priority;
import jakarta.inject.Singleton;
import jakarta.inject.Inject;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.ext.Provider;

@Provider
@AuthzRead
@Singleton
@Priority(Priorities.AUTHORIZATION)
public class AuthzReadFilter implements ContainerRequestFilter {

    private static final Logger LOG = Logger.getLogger(AuthzReadFilter.class);

    @Context
    ResourceInfo resourceInfoRead;

    @Inject
    AuthzService authzServiceRead;

    @ConfigProperty(name = "security.enabled", defaultValue = "true")
    boolean securityEnabledRead;

    @Override
    public void filter(ContainerRequestContext reqRead) {

        LOG.infof("AuthzReadFilter HIT — method=%s path=%s auth=%s",
                reqRead.getMethod(),
                reqRead.getUriInfo().getRequestUri(),
                reqRead.getHeaderString("Authorization") != null ? "PRESENT" : "MISSING");

        // ✅ security off
        if (!securityEnabledRead) {
            LOG.debug("Security disabled -> skip AuthzReadFilter");
            return;
        }

        // ✅ safety check
        if (resourceInfoRead == null || resourceInfoRead.getResourceMethod() == null) {
            LOG.warn("ResourceInfo not available -> skip AuthzReadFilter");
            return;
        }

        // ✅ recupero annotation da cache (NO REFLECTION ogni volta)
        AuthzRead annotation = AuthzAnnotationCache.getAuthzRead(resourceInfoRead);

        if (annotation == null) {
            return; // nessuna annotation -> skip
        }

        // ✅ recupero parametro USER_TYPE
        UserType userType = annotation.userType();

        // ✅ costruzione context
        String context = MinimalContextResolver.build(
                resourceInfoRead.getResourceClass(),
                resourceInfoRead.getResourceMethod()
        );

        if (context == null || context.isBlank()) {
            LOG.warn("Context blank -> skip AuthzReadFilter");
            return;
        }

        LOG.debugf("AuthzReadFilter invoked -> %s#%s context=%s userType=%s",
                resourceInfoRead.getResourceClass().getSimpleName(),
                resourceInfoRead.getResourceMethod().getName(),
                context,
                userType
        );

        // ✅ chiamata service con userType
        authzServiceRead.assertAuthorized(
                context,
                AuthzService.Permit.READ,
                userType
        );

        // ✅ propaga UserType per RemiConeCheckFilter (e altri filtri downstream)
        reqRead.setProperty(RemiConeValidationService.PMR_USER_TYPE_PROP, userType.name());
    }
}