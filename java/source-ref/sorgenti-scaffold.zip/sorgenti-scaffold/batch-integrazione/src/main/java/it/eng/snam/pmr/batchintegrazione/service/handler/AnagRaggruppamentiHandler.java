package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AnagRaggruppamentiPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AnagRaggruppamentiHandler extends AbstractFlussoHandler<AnagRaggruppamentiPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AnagRaggruppamentiPayloadDto> getDtoClass() {
        return AnagRaggruppamentiPayloadDto.class;
    }

    @Override
    protected void handle(AnagRaggruppamentiPayloadDto dto) {
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAnagRaggruppamenti(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteAnagRaggruppamenti(dto.data().getFirst().codiceRaggrRemi());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}
    	
    	
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ANAG_RAGGRUPPAMENTI_FLOW;
    }
}