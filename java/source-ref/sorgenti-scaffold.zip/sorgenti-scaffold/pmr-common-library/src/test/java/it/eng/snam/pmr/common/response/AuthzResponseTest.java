package it.eng.snam.pmr.common.response;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class AuthzResponseTest {

    @Test
    void constructor_setsFields() {
        AuthzResponse r = new AuthzResponse(true, "AUTHORIZED");
        assertThat(r.enabled()).isTrue();
        assertThat(r.reason()).isEqualTo("AUTHORIZED");
    }

    @Test
    void constructor_disabledWithReason() {
        AuthzResponse r = new AuthzResponse(false, "NOT_AUTHORIZED");
        assertThat(r.enabled()).isFalse();
        assertThat(r.reason()).isEqualTo("NOT_AUTHORIZED");
    }

    @Test
    void equalsAndHashCode_twoEqualRecords() {
        AuthzResponse r1 = new AuthzResponse(true, "OK");
        AuthzResponse r2 = new AuthzResponse(true, "OK");
        assertThat(r1).isEqualTo(r2);
        assertThat(r1.hashCode()).isEqualTo(r2.hashCode());
    }

    @Test
    void toString_containsFieldValues() {
        AuthzResponse r = new AuthzResponse(true, "REASON");
        assertThat(r.toString()).contains("REASON");
    }
}
