package it.eng.snam.pmr.batchintegrazione.resource.internal;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileDataRequest;
import it.eng.snam.pmr.batchintegrazione.service.file.data.FileDataEngine;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import it.eng.snam.pmr.common.annotation.AuthzWrite;
import it.eng.snam.pmr.common.annotation.LogPmr;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;

@LogPmr
@Path("/")
@RunOnVirtualThread
@RequiredArgsConstructor
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class FileDataResource {

    private final FileDataEngine engine;
    private final Utility utility;

    @POST
    @AuthzWrite
    @Path("/bi_file-data-engine_power-up")
    public Response powerUp(FileDataRequest request) {
        return utility.ok(engine.powerUp(request));
    }
}
