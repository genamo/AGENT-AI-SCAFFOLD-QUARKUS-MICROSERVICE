package it.eng.snam.pmr.common.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class RestClientCallException extends RuntimeException {
    @Serial
    private static final long serialVersionUID = -3914840997439860965L;
}
