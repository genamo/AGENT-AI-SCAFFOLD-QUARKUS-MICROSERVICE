package it.eng.snam.pmr.batchintegrazionedg.test.resource;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;

import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.TestProfile;
import io.restassured.http.ContentType;
import it.eng.snam.pmr.batchintegrazionedg.dto.IntegrazioneParametriSistemaDTO;
import it.eng.snam.pmr.batchintegrazionedg.service.ParametriService;
import it.eng.snam.pmr.batchintegrazionedg.test.service.NoSecurityTestProfile;

@QuarkusTest
@TestProfile(NoSecurityTestProfile.class)
class ParametriSistemaResourceTest {

    @InjectMock
    ParametriService parametriService;

    private IntegrazioneParametriSistemaDTO buildDto() {
        return new IntegrazioneParametriSistemaDTO(
                1L,
                "PARAM_001",
                "valore",
                LocalDate.now().minusDays(10),
                LocalDate.now().plusDays(10),
                null,
                null,
                0
        );
    }

    @Test
    void searchParametri_withResults_returns200() {
        when(parametriService.search(any())).thenReturn(List.of(buildDto()));

        given()
            .contentType(ContentType.JSON)
            .body("{\"dataRiferimento\":\"2026-05-22\",\"codici\":[\"PARAM_001\"]}")
            .when().post("/parametri-sistema/search")
            .then()
            .statusCode(200);
    }

    @Test
    void searchParametri_emptyResult_returns200() {
        when(parametriService.search(any())).thenReturn(List.of());

        given()
            .contentType(ContentType.JSON)
            .body("{\"dataRiferimento\":\"2026-05-22\",\"codici\":[]}")
            .when().post("/parametri-sistema/search")
            .then()
            .statusCode(200);
    }

    @Test
    void searchParametri_nullBody_returns400() {
        given()
            .contentType(ContentType.JSON)
            .when().post("/parametri-sistema/search")
            .then()
            .statusCode(400);
    }

    @Test
    void searchParametri_withNullDate_returns200() {
        when(parametriService.search(any())).thenReturn(List.of(buildDto()));

        given()
            .contentType(ContentType.JSON)
            .body("{\"codici\":[\"PARAM_001\"]}")
            .when().post("/parametri-sistema/search")
            .then()
            .statusCode(200);
    }

    @Test
    void searchParametri_multipleResults_returns200() {
        when(parametriService.search(any()))
                .thenReturn(List.of(buildDto(), buildDto()));

        given()
            .contentType(ContentType.JSON)
            .body("{\"dataRiferimento\":\"2026-05-22\",\"codici\":[\"PARAM_001\",\"PARAM_002\"]}")
            .when().post("/parametri-sistema/search")
            .then()
            .statusCode(200);
    }

    // ====== HEADERS ======

    @Test
    void searchParametri_setsResponseHeaders() {
        when(parametriService.search(any())).thenReturn(List.of());

        given()
            .contentType(ContentType.JSON)
            .body("{\"dataRiferimento\":\"2026-05-22\"}")
            .when().post("/parametri-sistema/search")
            .then()
            .statusCode(200)

            // ✅ FIX COMPLETO
            .header("KEY-LOGIC", notNullValue())
            .header("TRANSACTION-ID", notNullValue())
            .header("MOD-ASYNC", notNullValue())
            .header("PROCESS-TYPE", notNullValue());
    }
}