package it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DateRiepiloghiDTO implements Serializable {

    @Serial
    private static final long serialVersionUID = -3546466853223053452L;

    private String tipoRiepilogo;
    private LocalDateTime dataInvio;
    private LocalDateTime dataUltimoAggiornamento;
    private String utenteUltimoAggiornamento;
}