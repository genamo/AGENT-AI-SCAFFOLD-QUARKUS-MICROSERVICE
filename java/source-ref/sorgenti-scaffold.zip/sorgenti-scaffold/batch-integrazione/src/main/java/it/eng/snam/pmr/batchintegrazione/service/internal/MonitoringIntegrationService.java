package it.eng.snam.pmr.batchintegrazione.service.internal;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.fasterxml.jackson.core.type.TypeReference;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.common.service.abstracts.AbstractService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RunOnVirtualThread
public class MonitoringIntegrationService extends AbstractService {

    @Inject
    @RestClient
    BatchIntegrazioneDgClient batchIntegrazioneDgClient;

    public Long sendRequestMonitoringIntegration(MonitoringIntegration integrationRequest) {
        return executeClientCall(() -> batchIntegrazioneDgClient.sendRequestMonitoringIntegration(integrationRequest), new TypeReference<>() {});
    }
}
