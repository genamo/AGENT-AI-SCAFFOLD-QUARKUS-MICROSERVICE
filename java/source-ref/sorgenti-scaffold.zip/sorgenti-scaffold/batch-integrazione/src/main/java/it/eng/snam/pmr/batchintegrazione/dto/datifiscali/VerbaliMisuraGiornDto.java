package it.eng.snam.pmr.batchintegrazione.dto.datifiscali;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record VerbaliMisuraGiornDto(
        String remiAssoluto,
        LocalDateTime dataVolPunta,
        LocalDateTime dataIniVerb,
        BigDecimal valoreVolGiorn,
        String codiceUmVolGiorn,
        BigDecimal valorePunta,
        BigDecimal valoreEnrgGiorn,
        String codiceUmEnrgGiorn,
        BigDecimal valorePcsGiorn,
        String codiceUmPcsGiorn,
        String aVol,
        LocalDateTime dataAgg,
        String codiceUserAgg,
        BigDecimal valoreEnrgGiornKwh,
        String codiceUmEnrgGiornKwh,
        BigDecimal valorePcsGiornKwh,
        String codiceUmPcsGiornKwh,
        BigDecimal invNlg,
        String provQual,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {}
