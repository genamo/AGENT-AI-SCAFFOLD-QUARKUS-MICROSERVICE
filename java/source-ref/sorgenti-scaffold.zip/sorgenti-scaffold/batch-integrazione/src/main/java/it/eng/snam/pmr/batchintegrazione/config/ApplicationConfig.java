package it.eng.snam.pmr.batchintegrazione.config;

import java.time.LocalDateTime;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;

@ApplicationScoped
public class ApplicationConfig {

    private static final Logger LOG = Logger.getLogger(ApplicationConfig.class);

    @ConfigProperty(name = "quarkus.application.name") String appName;
    @ConfigProperty(name = "quarkus.application.version") String appVersion;

    void onStart(@Observes io.quarkus.runtime.StartupEvent ev) {
        LOG.infof("════════════════════════════════════════");
        LOG.infof("  %s v%s started at %s", appName, appVersion, LocalDateTime.now());
        LOG.infof("════════════════════════════════════════");
    }

    void onStop(@Observes io.quarkus.runtime.ShutdownEvent ev) {
        LOG.infof("%s shutting down gracefully...", appName);
    }

}
