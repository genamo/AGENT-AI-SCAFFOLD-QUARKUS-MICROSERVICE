package it.eng.snam.pmr.batchintegrazione.kafka;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.eclipse.microprofile.reactive.messaging.Acknowledgment;
import org.eclipse.microprofile.reactive.messaging.Incoming;
import org.eclipse.microprofile.reactive.messaging.Message;
import org.jboss.logging.Logger;

import io.smallrye.common.annotation.RunOnVirtualThread;
import io.smallrye.reactive.messaging.kafka.api.IncomingKafkaRecordMetadata;
import it.eng.snam.pmr.batchintegrazione.config.kafka.KafkaConsumerRuntimeConfig;
import it.eng.snam.pmr.batchintegrazione.dto.DlqFlussoRequestDTO;
import it.eng.snam.pmr.batchintegrazione.service.DlqFlussoService;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class KafkaDlqConsumer {

    private static final Logger LOG = Logger.getLogger(KafkaDlqConsumer.class);
    private static final AtomicBoolean SKIP_LOGGED = new AtomicBoolean(false);
    private static final int MAX_DLQ_RECORDS_PER_TX = 3;

    @Inject
    DlqFlussoService dlqFlussoService;

    @Inject
    KafkaConsumerRuntimeConfig kafkaConsumerRuntimeConfig;

    @Incoming("global-dlq-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeDlq(Message<byte[]> message) {
        if (kafkaConsumerRuntimeConfig.isSkipMessage()) {
            logSkipOnce();
            return message.ack();
        }

        try {
            saveDlqRecord(message);
            return message.ack();
        } catch (Exception e) {
            LOG.error("Errore nel consumer DLQ", e);
            return message.nack(e);
        }
    }

    private void logSkipOnce() {
        if (SKIP_LOGGED.compareAndSet(false, true)) {
            LOG.warn("app.kafka.skip-message=true: i messaggi della DLQ verranno ACKati senza salvataggio.");
        }
    }

    private void saveDlqRecord(Message<byte[]> message) {
        IncomingKafkaRecordMetadata<?, ?> metadata =
                message.getMetadata(IncomingKafkaRecordMetadata.class).orElse(null);

        String topic = metadata != null ? metadata.getTopic() : "unknown";
        Headers headers = metadata != null ? metadata.getHeaders() : new RecordHeaders();
        int partition = metadata != null ? metadata.getPartition() : -1;
        long offset = metadata != null ? metadata.getOffset() : -1L;

        byte[] payloadBytes = message.getPayload();
        String payload = payloadBytes == null
                ? ""
                : Base64.getEncoder().encodeToString(payloadBytes);

        String flow = extractHeader(headers, Constants.KafkaHeaders.FLOW_TYPE);
        String transactionId = extractHeader(headers, Constants.KafkaHeaders.TRANSACTION_ID);
        String processType = extractHeader(headers, Constants.KafkaHeaders.PROCESS_TYPE);
        String messageKey = extractHeader(headers, Constants.KafkaHeaders.MESSAGE_KEY);

        // Dead-letter headers valorizzati da SmallRye/Kafka
        String deadLetterReason = extractHeader(headers, "dead-letter-reason");
        String deadLetterExceptionClass = extractHeader(headers, "dead-letter-exception-class-name");
        String deadLetterTopic = extractHeader(headers, "dead-letter-topic");
        String deadLetterPartition = extractHeader(headers, "dead-letter-partition");
        String deadLetterOffset = extractHeader(headers, "dead-letter-offset");

        String safeTransactionId = (transactionId == null || transactionId.isBlank())
                ? "DLQ_" + topic + "_" + partition + "_" + offset
                : transactionId;

        String safeFlow = (flow == null || flow.isBlank())
                ? "UNKNOWN_FLOW"
                : flow;

        String keyLogic = safeFlow + "_" + topic + "_" + partition + "_" + offset;

        String controlKey = buildControlKey(transactionId, safeFlow, processType, messageKey, payload);

        long count = dlqFlussoService.countByControlKey(controlKey);
        LOG.infof("DLQ controlKey=%s count=%d", controlKey, count);

        if (count >= MAX_DLQ_RECORDS_PER_TX) {
            LOG.warnf(
                    "Limite DLQ raggiunto per controlKey=%s (count=%d). Nessun nuovo record salvato.",
                    controlKey, count
            );
            return;
        }

        String errorType = (deadLetterExceptionClass == null || deadLetterExceptionClass.isBlank())
                ? "DLQ"
                : deadLetterExceptionClass;

        String errorMessage = (deadLetterReason == null || deadLetterReason.isBlank())
                ? "Messaggio ricevuto da globaldlq"
                : deadLetterReason;

        if (deadLetterTopic != null && !deadLetterTopic.isBlank()) {
            errorMessage = errorMessage
                    + " | sourceTopic=" + deadLetterTopic
                    + " partition=" + safe(deadLetterPartition)
                    + " offset=" + safe(deadLetterOffset);
        }

        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder()
                .transactionId(safeTransactionId)
                .flowId(safeFlow)
                .controlKey(controlKey)
                .keyLogic(keyLogic)
                .originalTopic(topic)
                .originalPartition(partition)
                .originalOffset(offset)
                .processType(processType)
                .messageKey(messageKey)
                .errorType(errorType)
                .errorMessage(errorMessage)
                .payload(payload)
                .status("RECEIVED")
                .build();

        dlqFlussoService.save(request);

        LOG.infof(
                "Record DLQ salvato: transactionId=%s controlKey=%s topic=%s partition=%d offset=%d",
                safeTransactionId, controlKey, topic, partition, offset
        );
    }

    private String buildControlKey(
            String transactionId,
            String flow,
            String processType,
            String messageKey,
            String payloadBase64) {

        if (transactionId != null && !transactionId.isBlank()) {
            return transactionId;
        }

        String base = safe(flow)
                + "|"
                + safe(processType)
                + "|"
                + safe(messageKey)
                + "|"
                + safe(payloadBase64);

        return sha256Hex(base);
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }

    private String sha256Hex(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(value.getBytes(StandardCharsets.UTF_8));

            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 non disponibile", e);
        }
    }

    private String extractHeader(Headers headers, String name) {
        if (headers == null) {
            return "";
        }
        Header header = headers.lastHeader(name);
        return header != null
                ? new String(header.value(), StandardCharsets.UTF_8)
                : "";
    }
}
