package it.eng.snam.pmr.batchintegrazionedg.repository;

import java.util.Optional;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import it.eng.snam.pmr.batchintegrazionedg.domain.AnagFlussi;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class AnagFlussiRepository implements PanacheRepository<AnagFlussi> {

    /**
     * Recupera un flusso tramite il suo identificativo FLOW_ID.
     * FLOW_ID è unico nel database.
     */
    public Optional<AnagFlussi> findByFlowId(String flowId) {
        return find("flowId = ?1 AND isDeleted = 0", flowId).firstResultOptional();
    }
    
    /**
     * Override del metodo di conteggio o lista per considerare solo i record non eliminati.
     */
    public long countActive() {
        return count("isDeleted = 0");
    }
}
