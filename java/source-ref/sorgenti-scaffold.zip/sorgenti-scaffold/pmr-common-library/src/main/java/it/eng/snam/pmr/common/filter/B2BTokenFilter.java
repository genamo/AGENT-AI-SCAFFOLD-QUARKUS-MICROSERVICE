package it.eng.snam.pmr.common.filter;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import it.eng.snam.pmr.common.util.B2BTokenUtils;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.ext.Provider;

@Provider
@Priority(Priorities.AUTHENTICATION - 10)
public class B2BTokenFilter implements ContainerRequestFilter {

    private static final Logger LOG = Logger.getLogger(B2BTokenFilter.class);
    public static final String B2B_SUPER_USER_KEY = "b2b.super_user";

    @Inject
    B2BTokenUtils b2bTokenUtils;

    @ConfigProperty(name = "security.enabled", defaultValue = "true")
    boolean securityEnabled;

    @Override
    public void filter(ContainerRequestContext req) {
        if (!securityEnabled) return;

        String authHeader = req.getHeaderString("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) return;

        if (b2bTokenUtils.isValid(authHeader)) {
            LOG.info("B2B SUPER_USER riconosciuto — bypass autorizzazione");
            req.setProperty(B2B_SUPER_USER_KEY, Boolean.TRUE);
        }
    }
}