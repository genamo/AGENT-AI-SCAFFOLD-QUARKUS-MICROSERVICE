package it.eng.snam.pmr.batchintegrazionedg.domain;

public enum IdempotenzaStatus {
    IN_PROGRESS,
    COMPLETED,
    ERROR
}