package it.eng.snam.pmr.common.config.async;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import it.eng.snam.pmr.common.config.async.decorator.ContextCopyingDecorator;
import it.eng.snam.pmr.common.config.async.decorator.TaskDecorator;

public class DecoratedThreadPoolExecutor extends ThreadPoolExecutor {

    private final TaskDecorator taskDecorator;

    public DecoratedThreadPoolExecutor(ThreadPoolContext context, TaskDecorator decorator) {
        super(context.getCorePoolSize(), context.getMaximumPoolSize(), context.getKeepAliveTime(), TimeUnit.SECONDS,
              new ArrayBlockingQueue<>(context.getQueueCapacity()), context.getThreadFactory(), new ThreadPoolExecutor.CallerRunsPolicy());
        this.taskDecorator = decorator != null ? decorator : new ContextCopyingDecorator();
    }

    @Override
    public void execute(Runnable command) {
        super.execute(taskDecorator.decorate(command));
    }
}
