package it.eng.snam.pmr.common.dto;

import java.util.List;

public record ProfileModuleDto(
        String moduleCode,
        List<String> meterList
) {}
