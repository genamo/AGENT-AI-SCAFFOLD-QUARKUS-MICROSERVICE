package it.eng.snam.pmr.common.resolver;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class JwtRolesResolverTest {

    @Test
    void resolveAllRoles_nullBearer_returnsEmpty() {
        assertThat(JwtRolesResolver.resolveAllRoles(null)).isEmpty();
    }

    @Test
    void resolveAllRoles_blankBearer_returnsEmpty() {
        assertThat(JwtRolesResolver.resolveAllRoles("  ")).isEmpty();
    }

    @Test
    void resolveAllRoles_tokenWithRolesArray_returnsAll() {
        String token = JWT.create()
                .withClaim("roles", List.of("ADMIN", "READ"))
                .sign(Algorithm.HMAC256("s"));
        Set<String> roles = JwtRolesResolver.resolveAllRoles("Bearer " + token);
        assertThat(roles).containsExactlyInAnyOrder("ADMIN", "READ");
    }

    @Test
    void resolveAllRoles_tokenWithSingleRole_returnsIt() {
        String token = JWT.create()
                .withClaim("role", "WRITER")
                .sign(Algorithm.HMAC256("s"));
        Set<String> roles = JwtRolesResolver.resolveAllRoles("Bearer " + token);
        assertThat(roles).containsExactly("WRITER");
    }

    @Test
    void resolveAllRoles_tokenWithBothRolesAndRole_mergesThem() {
        String token = JWT.create()
                .withClaim("roles", List.of("ADMIN"))
                .withClaim("role", "SUPER")
                .sign(Algorithm.HMAC256("s"));
        Set<String> roles = JwtRolesResolver.resolveAllRoles("Bearer " + token);
        assertThat(roles).containsExactlyInAnyOrder("ADMIN", "SUPER");
    }

    @Test
    void resolveAllRoles_tokenWithNoClaims_returnsEmpty() {
        String token = JWT.create().withClaim("x", "y").sign(Algorithm.HMAC256("s"));
        Set<String> roles = JwtRolesResolver.resolveAllRoles("Bearer " + token);
        assertThat(roles).isEmpty();
    }

    @Test
    void resolveAllRoles_tokenWithoutBearerPrefix_stillWorks() {
        String token = JWT.create()
                .withClaim("roles", List.of("ROLE_X"))
                .sign(Algorithm.HMAC256("s"));
        Set<String> roles = JwtRolesResolver.resolveAllRoles(token);
        assertThat(roles).containsExactly("ROLE_X");
    }
}
