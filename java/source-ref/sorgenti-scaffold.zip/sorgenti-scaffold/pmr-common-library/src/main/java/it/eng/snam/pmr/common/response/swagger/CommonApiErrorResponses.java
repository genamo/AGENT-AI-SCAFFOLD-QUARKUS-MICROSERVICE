package it.eng.snam.pmr.common.response.swagger;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;

import jakarta.ws.rs.core.MediaType;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@APIResponse(responseCode = "400", description = "Bad request",
        content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ErrorGenericResponse.class)))
@APIResponse(responseCode = "401", description = "Unauthorized",
        content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ErrorGenericResponse.class)))
@APIResponse(responseCode = "403", description = "Forbidden",
        content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ErrorGenericResponse.class)))
@APIResponse(responseCode = "404", description = "Not found",
        content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ErrorGenericResponse.class)))
@APIResponse(responseCode = "409", description = "Conflict",
        content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ErrorGenericResponse.class)))
@APIResponse(responseCode = "500", description = "Internal server error",
        content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ErrorGenericResponse.class)))
@APIResponse(responseCode = "502", description = "Bad gateway",
        content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ErrorGenericResponse.class)))
@APIResponse(responseCode = "503", description = "Service unavailable",
        content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ErrorGenericResponse.class)))
public @interface CommonApiErrorResponses {
}