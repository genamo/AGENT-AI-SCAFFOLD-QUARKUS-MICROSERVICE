package it.eng.snam.pmr.batchintegrazione.utils.file.data;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileDataRequest;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileReference;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class FileDataRequestValidator {

    public void validate(FileDataRequest request) {
        log.info("Validating request");

        if (request == null)
            throw new IllegalArgumentException("'request' must be valued properly.");

        String executioner = request.getExecutioner();
        if (StringUtils.isBlank(executioner))
            throw new IllegalArgumentException("'executioner' must be valued properly.");

        String activity = request.getActivity();
        if (StringUtils.isBlank(activity))
            throw new IllegalArgumentException("'activity' must be valued properly.");

        List<FileReference> fileReferences = request.getFileReferences();
        if (CollectionUtils.isEmpty(fileReferences))
            throw new IllegalArgumentException("'fileReferences' must be valued properly.");

        String sourceSystem = request.getSourceSystem();
        if (StringUtils.isBlank(sourceSystem))
            throw new IllegalArgumentException("'sourceSystem' must be valued properly.");

        log.info("Request validated: executioner={} - activity={} - sourceSystem={} - fileReferences={}",
                 executioner, activity, sourceSystem, fileReferences.stream().map(FileReference::getFileName).toList());
    }
}
