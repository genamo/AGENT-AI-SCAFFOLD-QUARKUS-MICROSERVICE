package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.ContattoPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class ContattoHandler extends AbstractFlussoHandler<ContattoPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<ContattoPayloadDto> getDtoClass() {
        return ContattoPayloadDto.class;
    }

    @Override
    protected void handle(ContattoPayloadDto dto) {
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveContatto(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteContatto(dto.data().getFirst().idContatto());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}	
        
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.CONTATTO_FLOW;
    }
}