package it.eng.snam.pmr.batchintegrazione.exception;

public class ControlledDlqException extends RuntimeException {

   
	private static final long serialVersionUID = 1L;
	private final String code;
    private final String transactionId;

    public ControlledDlqException(String code, String transactionId, String message) {
        super(message, null, false, false);
        this.code = code;
        this.transactionId = transactionId;
    }

    public String getCode() {
        return code;
    }

    public String getTransactionId() {
        return transactionId;
    }
}