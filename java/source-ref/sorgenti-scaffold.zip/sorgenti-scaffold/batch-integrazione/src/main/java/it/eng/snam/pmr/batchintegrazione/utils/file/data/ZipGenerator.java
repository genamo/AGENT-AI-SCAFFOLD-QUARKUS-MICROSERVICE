package it.eng.snam.pmr.batchintegrazione.utils.file.data;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileDataRequest;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileReference;
import it.eng.snam.pmr.batchintegrazione.exception.ZipGenerationException;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class ZipGenerator {

    public void generate(FileDataRequest request, OutputStream outputStream) {
        try (ZipOutputStream zipOutputStream = new ZipOutputStream(new BufferedOutputStream(outputStream))) {
            List<FileReference> deduplicated = FileReferenceDeduplicator.deduplicate(request.getFileReferences());
            int size = deduplicated.size();

            log.info("Generating ZIP");
            for (FileReference fileReference : deduplicated) {
                int entryIndex = deduplicated.indexOf(fileReference) + 1;
                log.info("Processing FileReference's entry {} of size {}", entryIndex, size);

                String fileName = fileReference.getFileName();
                log.info("Writing on ZIP: {}", fileName);

                zipOutputStream.putNextEntry(new ZipEntry(fileName));
                zipOutputStream.write(fileReference.getFileContent());
                zipOutputStream.closeEntry();
            }

            zipOutputStream.finish();
            log.info("ZIP generated successfully.");
        } catch (IOException e) {
            log.error("Error while generating ZIP: {}", e.getMessage());
            throw new ZipGenerationException("Error while generating ZIP: " + e.getMessage(), e);
        }
    }
}
