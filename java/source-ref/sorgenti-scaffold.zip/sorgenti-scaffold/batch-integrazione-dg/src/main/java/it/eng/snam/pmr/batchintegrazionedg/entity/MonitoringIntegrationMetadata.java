package it.eng.snam.pmr.batchintegrazionedg.entity;

import java.time.LocalDateTime;
import java.util.Objects;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity
@ToString
@Table(name = "monitoring_integration_metadata", schema = "dbo")
public class MonitoringIntegrationMetadata extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "integration_request_id", nullable = false)
    private Long integrationRequestId;

    @Column(name = "request", length = 4000)
    private String request;

    @Column(name = "response", length = 4000)
    private String response;

    @CreationTimestamp
    @Column(name = "created_at_utc", nullable = false)
    private LocalDateTime createdAtUtc;

    @UpdateTimestamp
    @Column(name = "updated_at_utc")
    private LocalDateTime updatedAtUtc;

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass())
            return false;
        MonitoringIntegrationMetadata that = (MonitoringIntegrationMetadata) o;
        return Objects.equals(getId(), that.getId()) && Objects.equals(getIntegrationRequestId(), that.getIntegrationRequestId())
               && Objects.equals(getRequest(), that.getRequest()) && Objects.equals(getResponse(), that.getResponse())
               && Objects.equals(getCreatedAtUtc(), that.getCreatedAtUtc()) && Objects.equals(getUpdatedAtUtc(), that.getUpdatedAtUtc());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getIntegrationRequestId(), getRequest(), getResponse(), getCreatedAtUtc(), getUpdatedAtUtc());
    }
}
