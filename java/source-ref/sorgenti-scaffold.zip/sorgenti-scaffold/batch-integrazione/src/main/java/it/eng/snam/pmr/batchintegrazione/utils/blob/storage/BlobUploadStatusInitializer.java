package it.eng.snam.pmr.batchintegrazione.utils.blob.storage;

import org.apache.commons.lang3.StringUtils;

import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.BlobUploadStatus;
import lombok.experimental.UtilityClass;

@UtilityClass
public class BlobUploadStatusInitializer {

    public final String SUCCESS = "READY_TO_DOWNLOAD";
    public final String SUCCESS_MESSAGE = "Upload terminated successfully";

    public final String FAILED = "UPLOAD_FAILED";
    public final String FAILED_MESSAGE = "Upload terminated with failure";

    public final String EXCEPTION = "EXCEPTION";

    public BlobUploadStatus initialize(Boolean exists, String blobPath, String containerName) {
        return Boolean.TRUE.equals(exists)
                ? BlobUploadStatus.of(containerName, blobPath, BlobUploadProperties.ZIP_CONTENT_TYPE, SUCCESS, SUCCESS_MESSAGE)
                : BlobUploadStatus.of(containerName, blobPath, BlobUploadProperties.ZIP_CONTENT_TYPE, FAILED, FAILED_MESSAGE);
    }

    public BlobUploadStatus initialize(Throwable cause) {
        return BlobUploadStatus.of(StringUtils.EMPTY, StringUtils.EMPTY, StringUtils.EMPTY, EXCEPTION, cause.getMessage());
    }
}
