package it.eng.snam.pmr.common.interceptor;

import org.jboss.logging.Logger;

import it.eng.snam.pmr.common.annotation.LogPmr;
import jakarta.annotation.Priority;
import jakarta.interceptor.AroundInvoke;
import jakarta.interceptor.Interceptor;
import jakarta.interceptor.InvocationContext;

@LogPmr
@Interceptor
@Priority(Interceptor.Priority.APPLICATION)
public class LogPmrInterceptor {

    private static final Logger LOG = Logger.getLogger(LogPmrInterceptor.class);

    @AroundInvoke
    public Object logMethodEntryExit(InvocationContext ctx) throws Exception {
        String methodName = ctx.getMethod().getName();
        LOG.infof("IN %s", methodName);
        long start = System.nanoTime();
        try {
            Object result = ctx.proceed();
            return result;
        } finally {
            long elapsedMs = (System.nanoTime() - start) / 1_000_000;
            LOG.infof("OUT %s elapsedMs=%d", methodName, elapsedMs);
        }
    }
}

