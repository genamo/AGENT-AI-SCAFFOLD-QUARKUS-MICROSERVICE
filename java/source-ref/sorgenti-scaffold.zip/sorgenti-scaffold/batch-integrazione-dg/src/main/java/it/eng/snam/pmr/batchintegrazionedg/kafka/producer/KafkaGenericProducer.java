package it.eng.snam.pmr.batchintegrazionedg.kafka.producer;

import java.util.Map;

import org.eclipse.microprofile.reactive.messaging.Channel;
import org.eclipse.microprofile.reactive.messaging.Emitter;

import it.eng.snam.pmr.batchintegrazionedg.kafka.KafkaTopic;
import it.eng.snam.pmr.batchintegrazionedg.service.abstracts.KafkaTopicResolver;
import it.eng.snam.pmr.batchintegrazionedg.utils.kafka.Channels;
import it.eng.snam.pmr.common.dto.kafka.produce.MessageHeaderContext;
import it.eng.snam.pmr.common.functional.interfaces.kafka.producer.MessageHeaderFactory;
import it.eng.snam.pmr.common.util.kafka.producer.MessagePublisher;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class KafkaGenericProducer {

    @Inject
    KafkaTopicResolver kafkaTopicResolver;

    @Inject
    @Channel(Channels.Outgoing.KAFKA_OUT)
    Emitter<byte[]> emitter;

    public void sendEventWithHeaders(KafkaTopic topic, Object payload, Map<String, String> additionalHeaders) {
        sendEventWithHeaders(topic, MessageHeaderFactory.mdc(), payload, additionalHeaders);
    }

    public void sendEventWithHeaders(KafkaTopic topic, MessageHeaderContext headerContext, Object payload, Map<String, String> additionalHeaders) {
        sendEventWithHeaders(topic, MessageHeaderFactory.merge(headerContext), payload, additionalHeaders);
    }

    public void sendEventWithHeaders(KafkaTopic topic, MessageHeaderFactory headerFactory, Object payload, Map<String, String> additionalHeaders) {
        String realTopic = kafkaTopicResolver.findRealTopic(topic);
        MessagePublisher.send(realTopic, headerFactory, payload, emitter::send, additionalHeaders);
    }
}