package it.eng.snam.pmr.batchintegrazione.utils.file.data;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileReference;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class FileReferenceDeduplicator {

    public List<FileReference> deduplicate(List<FileReference> fileReferences) {
        log.info("Deduplicating FileReferences");
        Map<String, FileReference> uniqueFilesByName = new LinkedHashMap<>();
        Map<String, Integer> occurrencesByFileName = new LinkedHashMap<>();
        for (FileReference fileReference : fileReferences) {
            String fileName = fileReference.getFileName();

            occurrencesByFileName.merge(fileName, 1, Integer::sum);
            uniqueFilesByName.putIfAbsent(fileName, fileReference);
        }

        List<FileReference> deduplicated = new LinkedList<>(uniqueFilesByName.values());
        int received = fileReferences.size();
        int unique = deduplicated.size();

        log.info("FileReferences received={}, unique={}, discarded={}", received, unique, (received - unique));
        occurrencesByFileName.forEach((fileName, occurrences) -> {
            if (occurrences > 1)
                log.warn("Duplicated fileName found. fileName={}, occurrences={}, discarded={}", fileName, occurrences, occurrences - 1);
        });

        return deduplicated;
    }
}
