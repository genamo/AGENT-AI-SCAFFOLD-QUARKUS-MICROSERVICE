package it.eng.snam.pmr.common.resolver;

import jakarta.ws.rs.Path;

import java.lang.reflect.Method;

public final class MinimalContextResolver {

    private MinimalContextResolver() {}

    /**
     * B1: context = path completo dell'endpoint (classe + metodo), senza HTTP method.
     *
     * Esempi:
     *  - Classe @Path("/anag-flussi"), Metodo @GET                 => "/anag-flussi"
     *  - Classe @Path("/monitoring-flussi"), Metodo @POST @Path("/save") => "/monitoring-flussi/save"
     */
    public static String build(Class<?> resourceClass, Method resourceMethod) {
        String classPath = extractPath(resourceClass.getAnnotation(Path.class));
        String methodPath = extractPath(resourceMethod != null ? resourceMethod.getAnnotation(Path.class) : null);

        return normalize(join(classPath, methodPath));
    }

    /**
     * Variante strict:
     * @Path sulla classe obbligatorio.
     */
    public static String buildStrict(Class<?> resourceClass, Method resourceMethod) {
        if (resourceClass.getAnnotation(Path.class) == null) {
            throw new IllegalStateException("Missing @Path on resource class: " + resourceClass.getName());
        }
        return build(resourceClass, resourceMethod);
    }

    private static String extractPath(Path p) {
        return (p == null) ? "" : p.value();
    }

    private static String join(String classPath, String methodPath) {
        String a = trimSlashes(classPath);
        String b = trimSlashes(methodPath);

        if (a.isEmpty() && b.isEmpty()) return "/";
        if (a.isEmpty()) return "/" + b;
        if (b.isEmpty()) return "/" + a;
        return "/" + a + "/" + b;
    }

    private static String trimSlashes(String s) {
        if (s == null) return "";
        s = s.trim();
        while (s.startsWith("/")) s = s.substring(1);
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    private static String normalize(String raw) {
        if (raw == null) return "/";
        String s = raw.trim();
        if (s.isEmpty()) return "/";

        if (!s.startsWith("/")) s = "/" + s;

        while (s.length() > 1 && s.endsWith("/")) {
            s = s.substring(0, s.length() - 1);
        }

        while (s.contains("//")) {
            s = s.replace("//", "/");
        }

        return s;
    }
}