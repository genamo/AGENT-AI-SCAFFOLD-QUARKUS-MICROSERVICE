package it.eng.snam.pmr.common.config.async.decorator;

import java.util.Map;

import org.slf4j.MDC;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ContextCopyingDecorator implements TaskDecorator {

    @Override
    public Runnable decorate(Runnable runnable) {
        Map<String, String> contextMap = MDC.getCopyOfContextMap();
        log.debug("{}", contextMap != null ? contextMap : "contextMap null");
        return () -> {
            try {
                if (contextMap != null)
                    MDC.setContextMap(contextMap);

                runnable.run();
            } finally {
                MDC.clear();
            }
        };
    }
}
