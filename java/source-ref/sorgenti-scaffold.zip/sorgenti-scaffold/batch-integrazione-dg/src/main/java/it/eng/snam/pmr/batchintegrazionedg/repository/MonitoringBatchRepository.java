package it.eng.snam.pmr.batchintegrazionedg.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import it.eng.snam.pmr.batchintegrazionedg.domain.MonitoringBatch;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringBatchSearchDTO;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@ApplicationScoped
public class MonitoringBatchRepository implements PanacheRepository<MonitoringBatch> {

    @Inject
    EntityManager em;

    // =========================================================
    // BASIC QUERIES
    // =========================================================

    public Optional<MonitoringBatch> findByTransactionId(String transactionId) {
        Map<String, Object> params = new HashMap<>();
        params.put("transactionId", transactionId);

        return find("transactionId = :transactionId AND isDeleted = 0", params)
                .firstResultOptional();
    }

    public List<MonitoringBatch> findByPeriod(Integer monthNumber, Integer dayNumber) {
        StringBuilder query = new StringBuilder("isDeleted = 0");
        Map<String, Object> params = new HashMap<>();

        if (monthNumber != null) {
            query.append(" AND monthNumber = :monthNumber");
            params.put("monthNumber", monthNumber);
        }

        if (dayNumber != null) {
            query.append(" AND dayNumber = :dayNumber");
            params.put("dayNumber", dayNumber);
        }

        return find(query.toString(), params).list();
    }

    // =========================================================
    // CUSTOM SEARCH (READ UNCOMMITTED)
    // =========================================================

    @Transactional
    public List<MonitoringBatch> findByCustomSearchReadUncommitted(MonitoringBatchSearchDTO search) {

        em.createNativeQuery("SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED")
                .executeUpdate();

        try {
            StringBuilder query = new StringBuilder("isDeleted = 0");
            Map<String, Object> params = new HashMap<>();

            if (search != null) {

                if (notBlank(search.transactionId())) {
                    query.append(" AND transactionId = :transactionId");
                    params.put("transactionId", search.transactionId());
                }

                if (notBlank(search.correlationId())) {
                    query.append(" AND correlationId = :correlationId");
                    params.put("correlationId", search.correlationId());
                }

                if (notBlank(search.flowId())) {
                    query.append(" AND flowId = :flowId");
                    params.put("flowId", search.flowId());
                }

                if (search.monthNumber() != null) {
                    query.append(" AND monthNumber = :monthNumber");
                    params.put("monthNumber", search.monthNumber());
                }

                if (search.dayNumber() != null) {
                    query.append(" AND dayNumber = :dayNumber");
                    params.put("dayNumber", search.dayNumber());
                }

                if (notBlank(search.granularita())) {
                    query.append(" AND granularita = :granularita");
                    params.put("granularita", search.granularita());
                }

                if (notBlank(search.sender())) {
                    query.append(" AND sender = :sender");
                    params.put("sender", search.sender());
                }

                if (search.isWorkaround() != null) {
                    query.append(" AND isWorkaround = :isWorkaround");
                    params.put("isWorkaround", search.isWorkaround());
                }

                if (search.status() != null) {
                    query.append(" AND status = :status");
                    params.put("status", search.status());
                }
            }

            return find(query.toString(), params).list();

        } finally {
            em.createNativeQuery("SET TRANSACTION ISOLATION LEVEL READ COMMITTED")
                    .executeUpdate();
        }
    }

    // =========================================================
    // LAST EXECUTIONS (SQL SERVER NOLOCK)
    // =========================================================

    @SuppressWarnings("unchecked")
    public List<MonitoringBatch> findLastExecutionsNoLock(int limit) {
        return em.createNativeQuery(
                        "SELECT * " +
                        "FROM MONITORING_BATCH WITH (NOLOCK) " +
                        "WHERE IS_DELETED = 0 " +
                        "ORDER BY ACTION_DATE DESC",
                        MonitoringBatch.class
                )
                .setMaxResults(limit)
                .getResultList();
    }

    // =========================================================
    // UTILS
    // =========================================================

    private boolean notBlank(String s) {
        return s != null && !s.isBlank();
    }
}
