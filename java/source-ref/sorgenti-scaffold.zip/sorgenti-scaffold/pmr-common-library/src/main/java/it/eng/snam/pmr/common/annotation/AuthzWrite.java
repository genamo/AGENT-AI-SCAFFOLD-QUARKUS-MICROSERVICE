package it.eng.snam.pmr.common.annotation;

import jakarta.ws.rs.NameBinding;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.*;

@NameBinding
@Retention(RUNTIME)
@Target({ TYPE, METHOD })
public @interface AuthzWrite {

    UserType userType() default UserType.INTERNAL;
}