package it.eng.snam.pmr.batchintegrazionedg.domain;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(
    name = "anag_flussi",
    uniqueConstraints = @UniqueConstraint(
        name = "uq_anag_flussi",
        columnNames = { "flow_id" }
    )
)
public class AnagFlussi extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @NotBlank
    @Column(name = "flow_id", nullable = false, length = 50)
    private String flowId;

    @NotBlank
    @Column(name = "desc_flow", nullable = false, length = 250)
    private String descFlow;

    @NotBlank
    @Column(name = "granularita", nullable = false, length = 2)
    private String granularita = "G";

    @NotBlank
    @Column(name = "verso", nullable = false, length = 5)
    private String verso = "IN";

    @NotBlank
    @Column(name = "process_type", nullable = false, length = 5)
    private String processType = "N/A";

    @Column(name = "sender", length = 50)
    private String sender;

    @Column(name = "receiver", length = 50)
    private String receiver;

    @CreationTimestamp
    @Column(name = "action_date", nullable = false)
    private LocalDateTime actionDate;

    @NotBlank
    @Column(name = "user_action", nullable = false, length = 50)
    private String userAction = "DATASETUP";

    @NotNull
    @Column(name = "is_deleted", nullable = false)
    private Integer isDeleted = 0;

    // getter/setter (come già li avevi)

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFlowId() { return flowId; }
    public void setFlowId(String flowId) { this.flowId = flowId; }

    public String getDescFlow() { return descFlow; }
    public void setDescFlow(String descFlow) { this.descFlow = descFlow; }

    public String getGranularita() { return granularita; }
    public void setGranularita(String granularita) { this.granularita = granularita; }

    public String getVerso() { return verso; }
    public void setVerso(String verso) { this.verso = verso; }

    public String getProcessType() { return processType; }
    public void setProcessType(String processType) { this.processType = processType; }

    public String getSender() { return sender; }
    public void setSender(String sender) { this.sender = sender; }

    public String getReceiver() { return receiver; }
    public void setReceiver(String receiver) { this.receiver = receiver; }

    public LocalDateTime getActionDate() { return actionDate; }
    public void setActionDate(LocalDateTime actionDate) { this.actionDate = actionDate; }

    public String getUserAction() { return userAction; }
    public void setUserAction(String userAction) { this.userAction = userAction; }

    public Integer getIsDeleted() { return isDeleted; }
    public void setIsDeleted(Integer isDeleted) { this.isDeleted = isDeleted; }
}