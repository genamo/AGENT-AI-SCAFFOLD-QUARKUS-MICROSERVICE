package it.eng.snam.pmr.batchintegrazione.service.monitoring.integration;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import java.io.Serial;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Riferimento ad una mail di Riepilogo Tabellare da inviare")
public class StatoInvioMailRequest implements Serializable {

    @Serial
    private static final long serialVersionUID = 1395551282882269014L;

    @Schema(description = "Identificativo mail", required = true)
    private Long idMail;

    @Schema(description = "Stato invio mail", required = true)
    private String statoInvio;
}
