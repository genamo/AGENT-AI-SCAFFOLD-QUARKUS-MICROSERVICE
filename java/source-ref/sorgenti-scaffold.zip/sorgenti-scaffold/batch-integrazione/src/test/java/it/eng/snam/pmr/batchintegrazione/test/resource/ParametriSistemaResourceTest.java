package it.eng.snam.pmr.batchintegrazione.test.resource;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.dto.IntegrazioneParametriSistemaDTO;
import it.eng.snam.pmr.batchintegrazione.dto.ParametriSistemaRequestSearch;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.resource.ParametriSistemaResource;
import it.eng.snam.pmr.batchintegrazione.service.ParametriService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class ParametriSistemaResourceTest {

    @Mock ParametriService remoteService;
    @Mock Utility utility;
    @InjectMocks ParametriSistemaResource resource;

    private ParametriSistemaRequestSearch buildReq() {
        return ParametriSistemaRequestSearch.builder().build();
    }

    @Test
    void searchParametri_null_badRequest() {
        Response resp = mock(Response.class);
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.searchParametri(null));
        verify(remoteService, never()).searchParametri(any());
    }

    @Test
    void searchParametri_emptyResult() {
        ParametriSistemaRequestSearch req = buildReq();
        when(remoteService.searchParametri(req)).thenReturn(List.of());
        Response resp = mock(Response.class);
        when(utility.okOrEmpty(List.of())).thenReturn(resp);
        assertSame(resp, resource.searchParametri(req));
    }

    @Test
    void searchParametri_withResult() {
        ParametriSistemaRequestSearch req = buildReq();
        List<IntegrazioneParametriSistemaDTO> result = List.of(
                new IntegrazioneParametriSistemaDTO(1L, "COD", "VAL", null, null, null, null, null));
        when(remoteService.searchParametri(req)).thenReturn(result);
        Response resp = mock(Response.class);
        when(utility.okOrEmpty(result)).thenReturn(resp);
        assertSame(resp, resource.searchParametri(req));
    }

    @Test
    void searchParametri_illegalArgument_badRequest() {
        ParametriSistemaRequestSearch req = buildReq();
        when(remoteService.searchParametri(req)).thenThrow(new IllegalArgumentException("bad param"));
        Response resp = mock(Response.class);
        when(utility.badRequest("bad param")).thenReturn(resp);
        assertSame(resp, resource.searchParametri(req));
    }

    @Test
    void searchParametri_remoteCallException_badGateway() {
        ParametriSistemaRequestSearch req = buildReq();
        RemoteCallException ex = new RemoteCallException("remote error");
        when(remoteService.searchParametri(req)).thenThrow(ex);
        Response resp = mock(Response.class);
        when(utility.badGateway(ex)).thenReturn(resp);
        assertSame(resp, resource.searchParametri(req));
    }
}
