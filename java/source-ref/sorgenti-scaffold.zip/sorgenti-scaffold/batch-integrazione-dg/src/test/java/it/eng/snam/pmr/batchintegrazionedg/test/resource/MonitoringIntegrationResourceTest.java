package it.eng.snam.pmr.batchintegrazionedg.test.resource;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.batchintegrazionedg.resource.MonitoringIntegrationResource;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringIntegrationService;
import it.eng.snam.pmr.common.util.Utility;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class MonitoringIntegrationResourceTest {

    @Test
    void sendRequestGenerateSend_shouldCallServiceAndReturnOkResponse() {
        MonitoringIntegrationService service = mock(MonitoringIntegrationService.class);
        Utility utility = mock(Utility.class);

        MonitoringIntegrationResource resource = new MonitoringIntegrationResource(service, utility);

        MonitoringIntegration request = mock(MonitoringIntegration.class);
        Response expectedResponse = mock(Response.class);

        when(service.sendRequestGenerateSend(request)).thenReturn(10L);
        when(utility.ok(10L)).thenReturn(expectedResponse);

        Response result = resource.sendRequestGenerateSend(request);

        assertSame(expectedResponse, result);

        verify(service).sendRequestGenerateSend(request);
        verify(utility).ok(10L);
        verifyNoMoreInteractions(service, utility);
    }
}
