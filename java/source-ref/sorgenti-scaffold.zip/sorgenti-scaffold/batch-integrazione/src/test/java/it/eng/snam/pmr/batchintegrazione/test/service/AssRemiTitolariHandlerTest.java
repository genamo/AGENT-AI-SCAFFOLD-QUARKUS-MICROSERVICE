package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.verify;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiTitolariDto;
import it.eng.snam.pmr.batchintegrazione.dto.flussi.AssRemiTitolariPayloadDto;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringFlussiService;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringFlussiService.FlussiStatus;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.service.handler.AssRemiTitolariHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;

@ExtendWith(MockitoExtension.class)
class AssRemiTitolariHandlerTest {

	private static final String PAYLOAD =
	        "{\"summer_transaction_id\":\"RIDPACC_22f2e2e1-4a00-4088-51a5-ce7fc09a1ab7\",\"operation\":\"INSERT\",\"data\":[{\"remiAssoluto\":\"REMI001\",\"codiceCliente\":\"CLI001\"}]}";

    @Mock
    AnagraficheService anagraficheService;

    @Mock
    MonitoringFlussiService monitoring;

    @Mock
    RequestHeadersContext headersCtx;

    private AssRemiTitolariHandler handler;

    @BeforeEach
    void setUp() throws Exception {
        handler = new AssRemiTitolariHandler();
        injectField(AssRemiTitolariHandler.class, handler, "anagraficheService", anagraficheService);
        injectField(AbstractFlussoHandler.class, handler, "monitoring", monitoring);
        injectField(AbstractFlussoHandler.class, handler, "headersCtx", headersCtx);
    }

    @Test
    void getFlowType_returnsAssRemiTitolariFlow() {
        assertEquals(Constants.Flussi.ASS_REMI_TITOLARI_FLOW, handler.getFlowType());
    }

    @Test
    void getDtoClass_returnsAssRemiTitolariPayloadDtoClass() throws Exception {
        Class<?> dtoClass = (Class<?>) invokeProtectedMethod(handler, "getDtoClass", new Class<?>[0]);
        assertEquals(AssRemiTitolariPayloadDto.class, dtoClass);
    }

    @Test
    void handle_delegatesToAnagraficheService() throws Exception {
        AssRemiTitolariDto dto = new AssRemiTitolariDto("REMI001", null, null, "CLI001", null, null, null, null, null);

        AssRemiTitolariPayloadDto payloadDto = AssRemiTitolariPayloadDto.builder()
                .summerTransactionId("tr01")
                .operation("INSERT")
                .data(List.of(dto))
                .build();


        invokeProtectedMethod(handler, "handle", new Class<?>[] { AssRemiTitolariPayloadDto.class }, payloadDto);

        verify(anagraficheService).saveAssRemiTitolari(dto);
    }

    @Test
    void process_validPayload_savesStatusesAndDelegatesToService() {
        handler.process(PAYLOAD);

        InOrder inOrder = inOrder(monitoring, headersCtx, anagraficheService);

        inOrder.verify(monitoring).saveFlussoStatus(
                eq(Constants.Flussi.ASS_REMI_TITOLARI_FLOW),
                eq("SUMMER"),
                any(LocalDate.class),
                eq(FlussiStatus.INIT));

        inOrder.verify(headersCtx).setCorrelationId("RIDPACC_22f2e2e1-4a00-4088-51a5-ce7fc09a1ab7");

        inOrder.verify(monitoring).saveFlussoStatus(
                eq(Constants.Flussi.ASS_REMI_TITOLARI_FLOW),
                eq("SUMMER"),
                any(LocalDate.class),
                eq(FlussiStatus.BEGIN));

        inOrder.verify(monitoring).saveFlussoStatus(
                eq(Constants.Flussi.ASS_REMI_TITOLARI_FLOW),
                eq("SUMMER"),
                any(LocalDate.class),
                eq(FlussiStatus.PROGRESS), eq(PAYLOAD), isNull());

        inOrder.verify(anagraficheService).saveAssRemiTitolari(any(AssRemiTitolariDto.class));

        inOrder.verify(monitoring).saveFlussoStatus(
                eq(Constants.Flussi.ASS_REMI_TITOLARI_FLOW),
                eq("SUMMER"),
                any(LocalDate.class),
                eq(FlussiStatus.COMPLETED),
                eq(PAYLOAD),
                isNull());
    }

    private static void injectField(Class<?> declaringClass, Object target, String fieldName, Object value)
            throws Exception {
        Field field = declaringClass.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private static Object invokeProtectedMethod(Object target, String methodName, Class<?>[] parameterTypes,
            Object... args) throws Exception {
        Method method = target.getClass().getDeclaredMethod(methodName, parameterTypes);
        method.setAccessible(true);
        return method.invoke(target, args);
    }
}
