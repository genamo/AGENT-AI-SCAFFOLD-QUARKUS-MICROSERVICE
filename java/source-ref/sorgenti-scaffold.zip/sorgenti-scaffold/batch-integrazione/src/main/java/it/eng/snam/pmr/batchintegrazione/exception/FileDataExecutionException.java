package it.eng.snam.pmr.batchintegrazione.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class FileDataExecutionException extends BatchIntegrazioneException {
    @Serial
    private static final long serialVersionUID = -1750482368735624528L;
}
