package it.eng.snam.pmr.common.dto.acr.addressing;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;

@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public record AcrRecipientRequestDTO(
        Boolean includeTerritory,
        Boolean excludeChief,
        List<String> profiles,
        List<String> territories,
        List<Integer> widgets,
        List<Integer> verticals,
        List<Integer> administrationLists,
        List<String> subProfiles
) {}
