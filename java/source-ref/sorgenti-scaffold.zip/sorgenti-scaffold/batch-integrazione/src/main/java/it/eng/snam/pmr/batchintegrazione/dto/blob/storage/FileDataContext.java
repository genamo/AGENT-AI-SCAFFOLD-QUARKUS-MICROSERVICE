package it.eng.snam.pmr.batchintegrazione.dto.blob.storage;

import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FileDataContext {

    private String executioner;
    private String activity;
    private String fileName;
    private String contentType;
    private InputStream inputStream;
    private Map<String, String> metadata;
    private CompletableFuture<Void> writerFuture;
}
