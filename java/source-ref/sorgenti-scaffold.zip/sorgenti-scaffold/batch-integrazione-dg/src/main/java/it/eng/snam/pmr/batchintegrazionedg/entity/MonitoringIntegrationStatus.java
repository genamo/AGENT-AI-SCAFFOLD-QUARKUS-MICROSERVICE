package it.eng.snam.pmr.batchintegrazionedg.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity
@ToString
@Table(name = "monitoring_integration_status", schema = "dbo")
public class MonitoringIntegrationStatus extends PanacheEntityBase {

    @Id
    @Column(name = "integration_request_id")
    private Long integrationRequestId;

    @Column(name = "status")
    private Integer status;

    @Column(name = "status_message", length = 2000)
    private String statusMessage;

    @Column(name = "content_type", length = 100)
    private String contentType;

    @CreationTimestamp
    @Column(name = "created_at_utc", nullable = false)
    private LocalDateTime createdAtUtc;

    @UpdateTimestamp
    @Column(name = "updated_at_utc")
    private LocalDateTime updatedAtUtc;
}
