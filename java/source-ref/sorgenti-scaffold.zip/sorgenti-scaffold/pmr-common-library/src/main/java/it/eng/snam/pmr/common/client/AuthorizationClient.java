package it.eng.snam.pmr.common.client;

import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import it.eng.snam.pmr.common.dto.acr.addressing.AcrRecipientRequestDTO;
import it.eng.snam.pmr.common.request.AuthzRequest;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/")
@RegisterRestClient(configKey = "authorization-client")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface AuthorizationClient {

    @POST
    @Path("/auth_check")
    Response check(@HeaderParam("Authorization") String bearer, AuthzRequest request);

    // ======================================================
    // ACR ROLES
    // ======================================================
    @GET
    @Path("/acr/data-access/roles_with_user")
    Response getRolesWithUser(@HeaderParam("JwtUserId") String jwtUserId);

    @GET
    @Path("/acr/data-access/roles")
    Response getRoles(@HeaderParam("Authorization") String bearer);

    // ======================================================
    // ACR ADDRESSING
    // ======================================================
    @POST
    @Path("/acr/addressing/recipient")
    Response getRecipients(AcrRecipientRequestDTO request);

    @GET
    @Path("/acr/addressing/administration-list")
    Response getAdministrationLists();

    @GET
    @Path("/acr/addressing/profile")
    Response getProfiles();

    @GET
    @Path("/acr/addressing/territory")
    Response getTerritories();

    @GET
    @Path("/acr/addressing/widget")
    Response getWidgets();

    @GET
    @Path("/acr/addressing/vertical")
    Response getVerticals();

    @GET
    @Path("/acr/addressing/subprofile")
    Response getSubProfiles();
    
 // ======================================================
 // AUTH ADMINISTRATION LIST
 // ======================================================
	 @GET
	 @Path("/auth_administration-list_all")
	 Response getAllAdministrationLists();

}
