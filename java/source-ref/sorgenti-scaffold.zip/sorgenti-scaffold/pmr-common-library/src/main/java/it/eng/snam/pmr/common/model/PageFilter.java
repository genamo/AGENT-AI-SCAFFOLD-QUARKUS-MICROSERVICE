package it.eng.snam.pmr.common.model;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import jakarta.ws.rs.QueryParam;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Parametri di paginazione")
public class PageFilter {

    @QueryParam("page")
    @Schema(description = "Numero pagina, indice da 0", examples = "0", defaultValue = "0")
    private Integer page;

    @QueryParam("size")
    @Schema(description = "Numero elementi per pagina", examples = "20", defaultValue = "20")
    private Integer size;

    public Integer resolvePage() {
        return resolve(page, 0);
    }

    public Integer resolveSize() {
        return resolve(size, 20);
    }

    private Integer resolve(Integer value, Integer safe) {
        return value != null && value > 0 ? value : safe;
    }
}