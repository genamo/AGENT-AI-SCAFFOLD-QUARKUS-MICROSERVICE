package it.eng.snam.pmr.batchintegrazionedg.repository;

import java.util.Optional;

import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import it.eng.snam.pmr.batchintegrazionedg.entity.MonitoringIntegrationRequest;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MonitoringIntegrationRequestRepository implements PanacheRepositoryBase<MonitoringIntegrationRequest, Long> {

    public Optional<Long> findIdByTransactionId(String transactionId) {
        return find("select id from MonitoringIntegrationRequest where transactionId = ?1", transactionId)
                .project(Long.class)
                .firstResultOptional();
    }

    public Optional<MonitoringIntegrationRequest> findByTransactionIdAndUserId(String transactionId, String userId) {
        return find("transactionId = ?1 and userId = ?2", transactionId, userId).firstResultOptional();
    }
}
