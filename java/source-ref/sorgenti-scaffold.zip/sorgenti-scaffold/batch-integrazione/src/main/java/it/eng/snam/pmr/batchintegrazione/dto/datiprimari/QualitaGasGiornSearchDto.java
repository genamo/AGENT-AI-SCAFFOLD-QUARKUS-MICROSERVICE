package it.eng.snam.pmr.batchintegrazione.dto.datiprimari;

import java.time.LocalDateTime;

public record QualitaGasGiornSearchDto(
        Integer codiceAop,
        LocalDateTime dataIniPre
) {}