package it.eng.snam.pmr.common.config.async.decorator;

import java.util.Map;

import org.slf4j.MDC;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class SubContextCopyingDecorator implements TaskDecorator {

    private final String suffix;

    @Override
    public Runnable decorate(Runnable runnable) {
        Map<String, String> contextMap = MDC.getCopyOfContextMap();
        log.debug("{}", contextMap != null ? contextMap : "contextMap null");
        String callerThreadName = Thread.currentThread().getName();
        return () -> {
            Thread currentThread = Thread.currentThread();
            String originalThreadName = currentThread.getName();
            try {
                if (contextMap != null)
                    MDC.setContextMap(contextMap);

                if (callerThreadName != null) {
                    String indexOriginalThreadName = callerThreadName.substring(callerThreadName.lastIndexOf("-") + 1);
                    currentThread.setName(callerThreadName + suffix + indexOriginalThreadName);
                }

                runnable.run();
            } finally {
                currentThread.setName(originalThreadName);
                MDC.clear();
            }
        };
    }
}
