package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.jboss.logging.MDC;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringBatchDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringBatchSearchDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.exception.RetryableRemoteException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringBatchService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CacheUtils;
import jakarta.ws.rs.core.Response;


@ExtendWith(MockitoExtension.class)
class MonitoringBatchServiceTest {

    @Mock BatchIntegrazioneDgClient client;
    @Mock ObjectMapper objectMapper;
    @Mock RequestHeadersContext headersCtx;
    @Mock CacheUtils cacheUtils;

    @InjectMocks MonitoringBatchService service;

    @BeforeEach
    void injectHeadersCtxIntoAbstractService() throws Exception {
        // headersCtx è nel parent AbstractService: lo settiamo esplicitamente per evitare injection mancata
        Field f = AbstractService.class.getDeclaredField("headersCtx");
        f.setAccessible(true);
        f.set(service, headersCtx);
    }

    private Response mockResp(int status) {
        Response r = mock(Response.class);
        when(r.getStatus()).thenReturn(status);
        return r;
    }

    private void mockHeadersForRemoteError() {
        when(headersCtx.getKeyLogic()).thenReturn("kl");
        when(headersCtx.getTransactionId()).thenReturn("tx");
        when(headersCtx.getProcessType()).thenReturn("PT");
    }

    // ---- getAll ----

    @Test
    void getAll_204_returnsEmpty() {
        Response r204 = mockResp(204);
        when(client.getAllMonitoringBatch()).thenReturn(r204);

        assertTrue(service.getAll().isEmpty());
    }

    @Test
    void getAll_200_emptyJson_returnsEmpty() {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("");
        when(client.getAllMonitoringBatch()).thenReturn(resp);

        assertTrue(service.getAll().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAll_200_validJson_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(client.getAllMonitoringBatch()).thenReturn(resp);

        MonitoringBatchDTO dto = MonitoringBatchDTO.builder().transactionId("tx1").build();
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(dto));

        List<MonitoringBatchDTO> result = service.getAll();
        assertEquals(1, result.size());
        assertEquals("tx1", result.get(0).transactionId());
    }

    @Test
    void getAll_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.getAllMonitoringBatch()).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.getAll());
    }

    @Test
    void getAll_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.getAllMonitoringBatch()).thenReturn(resp);

        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.getAll());
    }

    // ---- getById ----

    @Test
    void getById_404_returnsEmpty() {
        Response r404 = mockResp(404);
        when(client.getByIdMonitoringBatch(1L)).thenReturn(r404);

        assertTrue(service.getById(1L).isEmpty());
    }

    @Test
    void getById_200_returnsOptionalEmpty_whenBodyNull() {
        Response resp = mockResp(200);
        when(resp.readEntity(MonitoringBatchDTO.class)).thenReturn(null);
        when(client.getByIdMonitoringBatch(1L)).thenReturn(resp);

        Optional<MonitoringBatchDTO> result = service.getById(1L);
        assertTrue(result.isEmpty());
    }

    @Test
    void getById_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.getByIdMonitoringBatch(1L)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.getById(1L));
    }

    @Test
    void getById_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.getByIdMonitoringBatch(1L)).thenReturn(resp);

        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.getById(1L));
    }

    // ---- getByTransactionId ----

    @Test
    void getByTransactionId_404_returnsEmpty() {
        Response r404 = mockResp(404);
        when(client.getByTransactionIdMonitoringBatch("tx1")).thenReturn(r404);

        assertTrue(service.getByTransactionId("tx1").isEmpty());
    }

    @Test
    void getByTransactionId_200_returnsOptionalEmpty_whenBodyNull() {
        Response resp = mockResp(200);
        when(resp.readEntity(MonitoringBatchDTO.class)).thenReturn(null);
        when(client.getByTransactionIdMonitoringBatch("tx1")).thenReturn(resp);

        assertTrue(service.getByTransactionId("tx1").isEmpty());
    }

    @Test
    void getByTransactionId_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.getByTransactionIdMonitoringBatch("tx1")).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.getByTransactionId("tx1"));
    }

    @Test
    void getByTransactionId_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.getByTransactionIdMonitoringBatch("tx1")).thenReturn(resp);

        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.getByTransactionId("tx1"));
    }

    // ---- save ----

    @Test
    void save_200_returnsDto() {
        MonitoringBatchDTO dto = MonitoringBatchDTO.builder().transactionId("tx1").build();

        Response resp = mockResp(200);
        when(resp.readEntity(MonitoringBatchDTO.class)).thenReturn(dto);
        when(client.saveMonitoringBatch(dto)).thenReturn(resp);

        MonitoringBatchDTO result = service.save(dto);
        assertEquals("tx1", result.transactionId());
    }

    @Test
    void save_201_returnsDto() {
        MonitoringBatchDTO dto = MonitoringBatchDTO.builder().transactionId("tx2").build();

        Response resp = mockResp(201);
        when(resp.readEntity(MonitoringBatchDTO.class)).thenReturn(dto);
        when(client.saveMonitoringBatch(dto)).thenReturn(resp);

        MonitoringBatchDTO result = service.save(dto);
        assertEquals("tx2", result.transactionId());
    }

    @Test
    void save_400_throwsIllegalArgument() {
        MonitoringBatchDTO dto = MonitoringBatchDTO.builder().build();

        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.saveMonitoringBatch(dto)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.save(dto));
    }

    @Test
    void save_500_throwsRemoteCallException() {
        MonitoringBatchDTO dto = MonitoringBatchDTO.builder().build();

        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.saveMonitoringBatch(dto)).thenReturn(resp);

        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.save(dto));
    }

    // ---- findByCustomSearch ----

    @Test
    void findByCustomSearch_204_returnsEmpty() {
        MonitoringBatchSearchDTO search = MonitoringBatchSearchDTO.builder().build();

        Response r204 = mockResp(204);
        when(client.findByCustomSearchMonitoringBatch(search)).thenReturn(r204);

        assertTrue(service.findByCustomSearch(search).isEmpty());
    }

    @Test
    void findByCustomSearch_200_emptyJson_returnsEmpty() {
        MonitoringBatchSearchDTO search = MonitoringBatchSearchDTO.builder().build();

        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("");
        when(client.findByCustomSearchMonitoringBatch(search)).thenReturn(resp);

        assertTrue(service.findByCustomSearch(search).isEmpty());
    }

    @Test
    void findByCustomSearch_400_throwsIllegalArgument() {
        MonitoringBatchSearchDTO search = MonitoringBatchSearchDTO.builder().build();

        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findByCustomSearchMonitoringBatch(search)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.findByCustomSearch(search));
    }

    @Test
    void findByCustomSearch_429_throwsRetryable() {
        MonitoringBatchSearchDTO search = MonitoringBatchSearchDTO.builder().build();

        Response resp = mockResp(429);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findByCustomSearchMonitoringBatch(search)).thenReturn(resp);

        assertThrows(RetryableRemoteException.class, () -> service.findByCustomSearch(search));
    }

    @Test
    void findByCustomSearch_500_throwsRetryable() {
        MonitoringBatchSearchDTO search = MonitoringBatchSearchDTO.builder().build();

        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findByCustomSearchMonitoringBatch(search)).thenReturn(resp);

        assertThrows(RetryableRemoteException.class, () -> service.findByCustomSearch(search));
    }

    @Test
    void findByCustomSearch_503_throwsRetryable() {
        MonitoringBatchSearchDTO search = MonitoringBatchSearchDTO.builder().build();

        Response resp = mockResp(503);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findByCustomSearchMonitoringBatch(search)).thenReturn(resp);

        assertThrows(RetryableRemoteException.class, () -> service.findByCustomSearch(search));
    }

    @Test
    void findByCustomSearch_403_throwsRemoteCallException() {
        MonitoringBatchSearchDTO search = MonitoringBatchSearchDTO.builder().build();

        Response resp = mockResp(403);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findByCustomSearchMonitoringBatch(search)).thenReturn(resp);

        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.findByCustomSearch(search));
    }

    // ---- getLastExecutions (CacheUtils mock) ----

    @Test
    @SuppressWarnings("unchecked")
    void getLastExecutions_cacheUsesCacheUtils() {
        when(headersCtx.getProcessType()).thenReturn("BATCH");

        List<MonitoringBatchDTO> expected =
                List.of(MonitoringBatchDTO.builder().transactionId("tx").build());

        when(cacheUtils.key(any(), any(), any(), any())).thenReturn("cache-key");
        when(cacheUtils.getOrCompute(anyString(), any(), anyInt(), any())).thenReturn(expected);

        List<MonitoringBatchDTO> result = service.getLastExecutions(5);
        assertEquals(expected, result);
    }

    // ---- getByPeriod ----

    @Test
    void getByPeriod_204_returnsEmpty() {
        Response r204 = mockResp(204);
        when(client.getByPeriodMonitoringBatch(1, 15)).thenReturn(r204);

        assertTrue(service.getByPeriod(1, 15).isEmpty());
    }

    @Test
    void getByPeriod_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.getByPeriodMonitoringBatch(1, 15)).thenReturn(resp);

        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.getByPeriod(1, 15));
    }
    
    @Test
    void getById_200_returnsDto() {
        MonitoringBatchDTO dto = MonitoringBatchDTO.builder().transactionId("tx1").build();

        Response resp = mockResp(200);
        when(resp.readEntity(MonitoringBatchDTO.class)).thenReturn(dto);
        when(client.getByIdMonitoringBatch(1L)).thenReturn(resp);

        Optional<MonitoringBatchDTO> result = service.getById(1L);

        assertTrue(result.isPresent());
        assertEquals("tx1", result.get().transactionId());
    }

    @Test
    void getByTransactionId_200_returnsDto() {
        MonitoringBatchDTO dto = MonitoringBatchDTO.builder().transactionId("tx1").build();

        Response resp = mockResp(200);
        when(resp.readEntity(MonitoringBatchDTO.class)).thenReturn(dto);
        when(client.getByTransactionIdMonitoringBatch("tx1")).thenReturn(resp);

        Optional<MonitoringBatchDTO> result = service.getByTransactionId("tx1");

        assertTrue(result.isPresent());
        assertEquals("tx1", result.get().transactionId());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getByPeriod_200_validJson_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(client.getByPeriodMonitoringBatch(1, 15)).thenReturn(resp);

        MonitoringBatchDTO dto = MonitoringBatchDTO.builder().transactionId("txP").build();
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(dto));

        List<MonitoringBatchDTO> result = service.getByPeriod(1, 15);

        assertEquals(1, result.size());
        assertEquals("txP", result.get(0).transactionId());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAll_200_invalidJson_throwsRemoteCallException() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(client.getAllMonitoringBatch()).thenReturn(resp);

        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class)))
            .thenThrow(new RuntimeException("boom"));

        assertThrows(RemoteCallException.class, () -> service.getAll());
    }

    @Test
    void findByCustomSearch_502_throwsRetryable() {
        MonitoringBatchSearchDTO search = MonitoringBatchSearchDTO.builder().build();

        Response resp = mockResp(502);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findByCustomSearchMonitoringBatch(search)).thenReturn(resp);

        assertThrows(RetryableRemoteException.class, () -> service.findByCustomSearch(search));
    }

    @Test
    void findByCustomSearch_504_throwsRetryable() {
        MonitoringBatchSearchDTO search = MonitoringBatchSearchDTO.builder().build();

        Response resp = mockResp(504);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findByCustomSearchMonitoringBatch(search)).thenReturn(resp);

        assertThrows(RetryableRemoteException.class, () -> service.findByCustomSearch(search));
    }

    @Test
    void saveBatchStatus_shortOverload_buildsDtoWithDefaults() {
        Response resp = mockResp(200);
        when(resp.readEntity(MonitoringBatchDTO.class)).thenReturn(MonitoringBatchDTO.builder().build());

        ArgumentCaptor<MonitoringBatchDTO> captor = ArgumentCaptor.forClass(MonitoringBatchDTO.class);
        when(client.saveMonitoringBatch(captor.capture())).thenReturn(resp);

        service.saveBatchStatus(
            "tx-batch",
            "PMR001A",
            "BATCH-SENDER",
            LocalDate.of(2026, 6, 12),
            MonitoringBatchService.BatchStatus.BEGIN
        );

        MonitoringBatchDTO dto = captor.getValue();
        assertEquals("tx-batch", dto.transactionId());
        assertEquals("tx-batch", dto.correlationId());
        assertEquals("PMR001A", dto.flowId());
        assertEquals(20260612, dto.dayNumber());
        assertEquals(202606, dto.monthNumber());
        assertEquals("G", dto.granularita());
        assertEquals("BATCH-SENDER", dto.sender());
        assertEquals(false, dto.isWorkaround());
        assertNull(dto.fileBatch());
        assertNull(dto.fileOutput());
        assertEquals(100, dto.status());
        assertEquals("BEGIN", dto.statusDescription());
        assertEquals("SYSTEM", dto.userAction());
        assertEquals(0, dto.isDeleted());
        assertNotNull(dto.actionDate());
    }

    @Test
    void saveBatchStatus_fullOverload_encodesFilesAndUsesMdcUser() {
        try {
            MDC.put(AuthorizationUtils.USER_ID, "batch-user");

            Response resp = mockResp(200);
            when(resp.readEntity(MonitoringBatchDTO.class)).thenReturn(MonitoringBatchDTO.builder().build());

            ArgumentCaptor<MonitoringBatchDTO> captor = ArgumentCaptor.forClass(MonitoringBatchDTO.class);
            when(client.saveMonitoringBatch(captor.capture())).thenReturn(resp);

            service.saveBatchStatus(
                "tx-batch",
                "PMR001B",
                "GUI-SENDER",
                LocalDate.of(2026, 1, 31),
                MonitoringBatchService.BatchStatus.ERROR,
                "{\"a\":1}",
                "{\"b\":2}"
            );

            MonitoringBatchDTO dto = captor.getValue();
            assertEquals(
                Base64.getEncoder().encodeToString("{\"a\":1}".getBytes(StandardCharsets.UTF_8)),
                dto.fileBatch()
            );
            assertEquals(
                Base64.getEncoder().encodeToString("{\"b\":2}".getBytes(StandardCharsets.UTF_8)),
                dto.fileOutput()
            );
            assertEquals(400, dto.status());
            assertEquals("ERROR", dto.statusDescription());
            assertEquals("batch-user", dto.userAction());
        } finally {
            MDC.clear();
        }
    }

}