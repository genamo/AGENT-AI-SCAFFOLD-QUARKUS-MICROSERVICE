package it.eng.snam.pmr.batchintegrazionedg.service;

import java.time.LocalDate;
import java.util.List;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.domain.IntegrazioneParametriSistema;
import it.eng.snam.pmr.batchintegrazionedg.dto.IntegrazioneParametriSistemaDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.ParametriSistemaRequestSearch;
import it.eng.snam.pmr.batchintegrazionedg.mapper.IntegrazioneParametriSistemaMapper;
import it.eng.snam.pmr.batchintegrazionedg.repository.ParametriSistemaRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
@RunOnVirtualThread
public class ParametriService {
    @Inject
    IntegrazioneParametriSistemaMapper mapper;
    @Inject
    ParametriSistemaRepository repository;

    public List<IntegrazioneParametriSistemaDTO> getAll() {
        return mapper.toDtoList(IntegrazioneParametriSistema.listAll());
    }
    
    public List<IntegrazioneParametriSistemaDTO> search(ParametriSistemaRequestSearch request) {
        // Gestione dei default se i campi sono null
        LocalDate dataInput = (request.dataRiferimento() != null) 
                ? request.dataRiferimento() 
                : LocalDate.now();
                
        List<IntegrazioneParametriSistema> entities = repository.findParametriSistema(dataInput, request.codici());
        return mapper.toDtoList(entities);
    }
}
