package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AnagPoloPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AnagPoloHandler extends AbstractFlussoHandler<AnagPoloPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AnagPoloPayloadDto> getDtoClass() {
        return AnagPoloPayloadDto.class;
    }

    @Override
    protected void handle(AnagPoloPayloadDto dto) {
    	
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAnagPolo(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteAnagPolo(dto.data().getFirst().codicePolo());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ANAG_POLO_FLOW;
    }
}