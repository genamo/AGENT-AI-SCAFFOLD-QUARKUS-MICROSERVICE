package it.eng.snam.pmr.batchintegrazionedg.resource;

import java.util.List;
import java.util.Optional;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringFlussiDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringFlussiSearchDTO;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringFlussiService;
import it.eng.snam.pmr.batchintegrazionedg.utils.Utility;
import it.eng.snam.pmr.common.annotation.LogPmr;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/monitoring-flussi")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RunOnVirtualThread
@LogPmr
public class MonitoringFlussiResource extends AbstractResource {

    @Inject
    MonitoringFlussiService service;

    @Context
    ContainerRequestContext ctx;

    // ======================================================
    // GET ALL
    // ======================================================
    @GET
    public Response getAll() {

        ReqContext c = init(ctx, "/monitoring-flussi");

        List<MonitoringFlussiDTO> list = service.getAll();

        return Utility.okOrEmpty(
                list,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // ======================================================
    // GET BY ID
    // ======================================================
    @GET
    @Path("/{id}")
    public Response getById(@PathParam("id") Long id) {

        ReqContext c = init(ctx, "/monitoring-flussi/{id}");

        if (id == null || id <= 0) {
            return Utility.badRequest(
                    "Path param 'id' non valido",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        MonitoringFlussiDTO dto = service.getById(id);

        return Utility.okOrNotFound(
                Optional.ofNullable(dto),
                "Nessun flusso trovato per id=" + id,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // ======================================================
    // GET BY TRANSACTION ID
    // ======================================================
    @GET
    @Path("/transaction/{transactionId}")
    public Response getByTransactionId(@PathParam("transactionId") String txId) {

        ReqContext c = init(ctx, "/monitoring-flussi/transaction/{transactionId}");

        if (txId == null || txId.isBlank()) {
            return Utility.badRequest(
                    "Path param 'transactionId' non valido",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        MonitoringFlussiDTO dto = service.getByTransactionId(txId);

        return Utility.okOrNotFound(
                Optional.ofNullable(dto),
                "Nessun flusso trovato per transactionId=" + txId,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // ======================================================
    // GET LAST EXECUTIONS
    // ======================================================
    @GET
    @Path("/last-executions")
    public Response getLastExecutions(
            @QueryParam("limit") @DefaultValue("10") int limit) {

        ReqContext c = init(ctx, "/monitoring-flussi/last-executions");

        if (limit <= 0) {
            return Utility.badRequest(
                    "Query param 'limit' deve essere > 0",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        List<MonitoringFlussiDTO> list = service.getLastExecutions(limit);

        return Utility.okOrEmpty(
                list,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // ======================================================
    // GET BY PERIOD
    // ======================================================
    @GET
    @Path("/period")
    public Response getByPeriod(
            @QueryParam("monthNumber") Integer month,
            @QueryParam("dayNumber") Integer day) {

        ReqContext c = init(ctx, "/monitoring-flussi/period");

        List<MonitoringFlussiDTO> list =
                service.getByPeriod(month, day);

        return Utility.okOrEmpty(
                list,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // ======================================================
    // SAVE
    // ======================================================
    @POST
    @Path("/save")
    public Response save(MonitoringFlussiDTO dto) {

        ReqContext c = init(ctx, "/monitoring-flussi/save");

        if (dto == null) {
            return Utility.badRequest(
                    "Body mancante o non valido",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        boolean exists =
                dto.transactionId() != null
                && !dto.transactionId().isBlank()
                && service.getByTransactionId(dto.transactionId()) != null;

        MonitoringFlussiDTO saved = service.save(dto);

        return exists
                ? Utility.ok(saved, c.path(), c.kl(), c.tid(), c.modAsync(), c.processType(), c.start())
                : Utility.created(saved, c.path(), c.kl(), c.tid(), c.modAsync(), c.processType(), c.start());
    }

    // ======================================================
    // CUSTOM SEARCH
    // ======================================================
    @POST
    @Path("/search")
    public Response findByCustomSearch(MonitoringFlussiSearchDTO searchDto) {

        ReqContext c = init(ctx, "/monitoring-flussi/search");

        if (searchDto == null) {
            return Utility.badRequest(
                    "Body di ricerca mancante o non valido",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        List<MonitoringFlussiDTO> list =
                service.findByCustomSearch(searchDto);

        return Utility.okOrEmpty(
                list,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }
}