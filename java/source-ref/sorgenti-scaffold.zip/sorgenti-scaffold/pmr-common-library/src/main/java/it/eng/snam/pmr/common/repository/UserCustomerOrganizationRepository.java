package it.eng.snam.pmr.common.repository;

import it.eng.snam.pmr.common.databricks.DatabricksDS;
import it.eng.snam.pmr.common.databricks.DatabricksRetry;
import it.eng.snam.pmr.common.dto.UserCustomerOrganizationDTO;
import it.eng.snam.pmr.common.mapper.UserCustomerOrganizationJdbcMapper;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class UserCustomerOrganizationRepository {

    @Inject
    @ConfigProperty(name = "databricks.schema")
    String schema;

    @Inject
    @DatabricksDS
    DataSource dataSource;

    @Inject
    DatabricksRetry retry;

    private String table() {
        if (schema == null || schema.isBlank()) {
            throw new IllegalStateException("databricks.schema NOT configured");
        }
        return schema + ".usercustomerorganization";
    }

    private String baseSelectUsercustomerorganization() {
        return """
            SELECT
              OrganizationId,
              OrganizationCode,
              RoleDescription,
              FlowId,
              EntityId,
              Datastamp,
              CustomerOrganizationCode,
              TelephoneNumber,
              UserCode,
              UserCustomerOrganizationId,
              PositionDescription,
              UserTypeDescription,
              PkSource,
              Denominatore,
              Penalita,
              IdErrore,
              UserTypeCode,
              UserDescription,
              CancelledFlag
            FROM %s
            """.formatted(table());
    }

    public Optional<UserCustomerOrganizationDTO> findById(long userCustomerOrganizationId) {
        String sql = baseSelectUsercustomerorganization() + " WHERE UserCustomerOrganizationId = ?";
        return singleResult(sql, ps -> ps.setLong(1, userCustomerOrganizationId));
    }

    public List<UserCustomerOrganizationDTO> findByUserCode(String userCode) {
        String sql = baseSelectUsercustomerorganization() + " WHERE UserCode = ?";
        return listResult(sql, ps -> ps.setString(1, userCode));
    }

    public List<UserCustomerOrganizationDTO> findActiveByUserCode(String userCode) {
        String sql = baseSelectUsercustomerorganization() + """
            WHERE UserCode = ?
              AND (CancelledFlag IS NULL OR CancelledFlag = 0)
            """;
        return listResult(sql, ps -> ps.setString(1, userCode));
    }
    
    public List<UserCustomerOrganizationDTO> findAllActive() {
        String sql = baseSelectUsercustomerorganization() + """
            WHERE (CancelledFlag IS NULL OR CancelledFlag = 0)
            """;
        return listResult(sql, ps -> {});
    }

    public List<UserCustomerOrganizationDTO> findByFlowId(long flowId) {
        String sql = baseSelectUsercustomerorganization() + " WHERE FlowId = ?";
        return listResult(sql, ps -> ps.setLong(1, flowId));
    }

    public List<UserCustomerOrganizationDTO> findByOrganizationCode(Long organizationCode) {
        String sql = baseSelectUsercustomerorganization() + " WHERE OrganizationCode = ?";
        return listResult(sql, ps -> ps.setLong(1, organizationCode));
    }

    public List<UserCustomerOrganizationDTO> findActiveByOrganizationCode(Long organizationCode) {
        String sql = baseSelectUsercustomerorganization() + """
            WHERE OrganizationCode = ?
              AND (CancelledFlag IS NULL OR CancelledFlag = 0)
            """;
        return listResult(sql, ps -> ps.setLong(1, organizationCode));
    }

    public List<UserCustomerOrganizationDTO> findByKeys(String userCode, String customerOrganizationCode) {
        String sql = baseSelectUsercustomerorganization() + """
            WHERE UserCode = ?
              AND CustomerOrganizationCode = ?
            """;
        return listResult(sql, ps -> {
            ps.setString(1, userCode);
            ps.setString(2, customerOrganizationCode);
        });
    }

    public List<UserCustomerOrganizationDTO> findActiveByKeys(String userCode, String customerOrganizationCode) {
        String sql = baseSelectUsercustomerorganization() + """
            WHERE UserCode = ?
              AND CustomerOrganizationCode = ?
              AND (CancelledFlag IS NULL OR CancelledFlag = 0)
            """;
        return listResult(sql, ps -> {
            ps.setString(1, userCode);
            ps.setString(2, customerOrganizationCode);
        });
    }

    public List<UserCustomerOrganizationDTO> findByUserCodePaged(String userCode, int limit, int offset) {
        String sql = baseSelectUsercustomerorganization() + """
            WHERE UserCode = ?
            LIMIT ? OFFSET ?
            """;
        return listResult(sql, ps -> {
            ps.setString(1, userCode);
            ps.setInt(2, limit);
            ps.setInt(3, offset);
        });
    }

    private Optional<UserCustomerOrganizationDTO> singleResult(
            String sql, SqlConsumer<PreparedStatement> binder) {

        return retry.execute(() -> {
            try (Connection c = dataSource.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {

                binder.accept(ps);

                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) return Optional.empty();
                    return Optional.of(UserCustomerOrganizationJdbcMapper.map(rs));
                }
            }
        });
    }

    private List<UserCustomerOrganizationDTO> listResult(
            String sql, SqlConsumer<PreparedStatement> binder) {

        return retry.execute(() -> {
            try (Connection c = dataSource.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {

                binder.accept(ps);

                try (ResultSet rs = ps.executeQuery()) {
                    return mapAll(rs);
                }
            }
        });
    }
    
    public List<UserCustomerOrganizationDTO> findActiveByCustomerOrganizationCodes(List<String> customerOrganizationCodes) {
        if (customerOrganizationCodes == null || customerOrganizationCodes.isEmpty()) {
            return List.of();
        }

        String placeholders = String.join(", ", java.util.Collections.nCopies(customerOrganizationCodes.size(), "?"));

        String sql = baseSelectUsercustomerorganization() + """
            WHERE CustomerOrganizationCode IN (%s)
              AND (CancelledFlag IS NULL OR CancelledFlag = 0)
            """.formatted(placeholders);

        return listResult(sql, ps -> {
            for (int i = 0; i < customerOrganizationCodes.size(); i++) {
                ps.setString(i + 1, customerOrganizationCodes.get(i));
            }
        });
    }


    private static List<UserCustomerOrganizationDTO> mapAll(ResultSet rs) throws SQLException {
        List<UserCustomerOrganizationDTO> out = new ArrayList<>();
        while (rs.next()) {
            out.add(UserCustomerOrganizationJdbcMapper.map(rs));
        }
        return out;
    }

    @FunctionalInterface
    interface SqlConsumer<T> {
        void accept(T t) throws SQLException;
    }
}