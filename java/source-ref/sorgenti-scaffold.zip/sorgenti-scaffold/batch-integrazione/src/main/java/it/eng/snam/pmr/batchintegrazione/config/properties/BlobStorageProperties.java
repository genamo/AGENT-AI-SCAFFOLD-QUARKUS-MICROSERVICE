package it.eng.snam.pmr.batchintegrazione.config.properties;

import io.smallrye.config.ConfigMapping;

@ConfigMapping(prefix = "azure.blob")
public interface BlobStorageProperties {

    String accountName();

    String accountKey();
}