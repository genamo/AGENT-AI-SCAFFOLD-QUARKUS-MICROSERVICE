package it.eng.snam.pmr.batchintegrazione.service;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.faulttolerance.CircuitBreaker;
import org.eclipse.microprofile.faulttolerance.Retry;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;
import org.jboss.logging.MDC;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringFlussiDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringFlussiSearchDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.exception.RetryableRemoteException;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CacheUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class MonitoringFlussiService extends AbstractService {

    private static final Logger LOG = Logger.getLogger(MonitoringFlussiService.class);

    private static final TypeReference<List<MonitoringFlussiDTO>> LIST_TYPE =
            new TypeReference<>() {};

    @Inject
    @RestClient
    BatchIntegrazioneDgClient client;

    @Inject
    ObjectMapper objectMapper;

    @Inject
    CacheUtils cacheUtils;

    @ConfigProperty(
        name = "cache.monitoring-flussi.last-executions.ttl-seconds",
        defaultValue = "300"
    )
    int lastExecutionsTtlSeconds;

    // =========================
    // API tipizzate (NO HEADER PARAM)
    // =========================

    public List<MonitoringFlussiDTO> getAll() {
        try (Response resp = client.getAllMonitoringFlussi()) {
            return handleListResponse(resp, "GET /monitoring-flussi");
        }
    }

    public Optional<MonitoringFlussiDTO> getById(Long id) {
        try (Response resp = client.getByIdMonitoringFlussi(id)) {

            int status = resp.getStatus();

            if (status == Response.Status.NOT_FOUND.getStatusCode()) {
                return Optional.empty();
            }
            if (status == Response.Status.OK.getStatusCode()) {
                return Optional.ofNullable(resp.readEntity(MonitoringFlussiDTO.class));
            }
            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                throw new IllegalArgumentException(
                        "getById: richiesta non valida. " + safeReadBody(resp));
            }

            throw remoteError("GET /monitoring-flussi/{id}", status, resp);
        }
    }

    public Optional<MonitoringFlussiDTO> getByTransactionId(String txId) {
        try (Response resp = client.getByTransactionIdMonitoringFlussi(txId)) {

            int status = resp.getStatus();

            if (status == Response.Status.NOT_FOUND.getStatusCode()) {
                return Optional.empty();
            }
            if (status == Response.Status.OK.getStatusCode()) {
                return Optional.ofNullable(resp.readEntity(MonitoringFlussiDTO.class));
            }
            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                throw new IllegalArgumentException(
                        "getByTransactionId: richiesta non valida. " + safeReadBody(resp));
            }

            throw remoteError("GET /monitoring-flussi/transaction/{transactionId}", status, resp);
        }
    }

    /**
     * CACHED (Redis distribuita)
     */
    public List<MonitoringFlussiDTO> getLastExecutions(int limit) {

        String cacheKey = cacheUtils.key(
                "monitoring-flussi",
                "last-executions",
                "limit=" + limit,
                "processType=" + headersCtx.getProcessType()
        );

        return cacheUtils.getOrCompute(
                cacheKey,
                LIST_TYPE,
                lastExecutionsTtlSeconds,
                () -> {
                    try (Response resp = client.getLastExecutionsMonitoringFlussi(limit)) {

                        LOG.infof(
                                "Cache miss per key %s - recupero da remoto (PT=%s)",
                                cacheKey,
                                headersCtx.getProcessType()
                        );

                        return handleListResponse(resp, "GET /monitoring-flussi/last-executions");
                    }
                }
        );
    }

    public List<MonitoringFlussiDTO> getByPeriod(Integer month, Integer day) {
        try (Response resp = client.getByPeriodMonitoringFlussi(month, day)) {
            return handleListResponse(resp, "GET /monitoring-flussi/period");
        }
    }

    public MonitoringFlussiDTO save(MonitoringFlussiDTO dto) {
        try (Response resp = client.saveMonitoringFlussi(dto)) {

            int status = resp.getStatus();

            if (status == Response.Status.OK.getStatusCode()
                    || status == Response.Status.CREATED.getStatusCode()) {
                return resp.readEntity(MonitoringFlussiDTO.class);
            }

            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                throw new IllegalArgumentException(
                        "save: richiesta non valida. " + safeReadBody(resp));
            }

            throw remoteError("POST /monitoring-flussi/save", status, resp);
        }
    }

    @Retry(
        maxRetries = 3,
        delay = 1000,
        delayUnit = ChronoUnit.MILLIS,
        jitter = 200,
        jitterDelayUnit = ChronoUnit.MILLIS,
        retryOn = { RetryableRemoteException.class },
        abortOn = { IllegalArgumentException.class }
    )
    @Timeout(5_000)
    @CircuitBreaker(
        requestVolumeThreshold = 10,
        failureRatio = 0.5,
        delay = 10,
        delayUnit = ChronoUnit.SECONDS
    )
    public List<MonitoringFlussiDTO> findByCustomSearch(MonitoringFlussiSearchDTO searchDto) {
        try (Response resp = client.findByCustomSearchMonitoringFlussi(searchDto)) {

            int status = resp.getStatus();

            if (status == Response.Status.NO_CONTENT.getStatusCode()) {
                return List.of();
            }

            if (status == Response.Status.OK.getStatusCode()) {
                return handleListResponse(resp, "POST /monitoring-flussi/search");
            }

            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                throw new IllegalArgumentException(
                        "findByCustomSearch: richiesta non valida. " + safeReadBody(resp));
            }

            if (isRetryableStatus(status)) {
                throw new RetryableRemoteException(
                        "Retryable HTTP " + status + " - " + safeReadBody(resp));
            }

            throw remoteError("POST /monitoring-flussi/search", status, resp);
        }
    }

    private boolean isRetryableStatus(int status) {
        return status == 429
                || status == 500
                || status == 502
                || status == 503
                || status == 504;
    }

    // =========================
    // Helpers
    // =========================

    private List<MonitoringFlussiDTO> handleListResponse(Response resp, String operation) {

        int status = resp.getStatus();

        if (status == Response.Status.NO_CONTENT.getStatusCode()) {
            return List.of();
        }

        if (status == Response.Status.OK.getStatusCode()) {
            String json = resp.readEntity(String.class);
            return readList(json);
        }

        if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
            throw new IllegalArgumentException(
                    operation + ": richiesta non valida. " + safeReadBody(resp));
        }

        throw remoteError(operation, status, resp);
    }

    private List<MonitoringFlussiDTO> readList(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return objectMapper.readValue(json, LIST_TYPE);
        } catch (Exception e) {
            throw new RemoteCallException("Impossibile deserializzare lista MonitoringFlussiDTO", e);
        }
    }
    
    
    public void saveFlussoStatus(String flow,String sender, LocalDate day, FlussiStatus status) {
        saveFlussoStatus(flow,sender, day, status, null, null);
    }

    public void saveFlussoStatus(String flow,
                                String sender,
                                LocalDate day,
                                FlussiStatus status,
                                String fileBatch,
                                String fileOutput) {
    	
        MonitoringFlussiDTO dto = MonitoringFlussiDTO.builder()
                .transactionId(headersCtx.getTransactionId())
                .correlationId(headersCtx.getCorrelationId()!=null?headersCtx.getCorrelationId().toString():"N/A")
                .flowId(flow)
                .dayNumber(toDayNumber(day))
                .monthNumber(toMonthNumber(day))
                .granularita("G")
                .sender(sender)
                .isWorkaround(resolveIsWorkaround())
                .fileFlusso(encodeToBase64(fileBatch))
                .fileOutput(encodeToBase64(fileOutput))
                .status(status.code)
                .statusDescription(status.description)
                .actionDate(LocalDateTime.now())
                .userAction(
                        Optional.ofNullable(MDC.get(AuthorizationUtils.USER_ID))
                                .map(Object::toString)
                                .orElse("SYSTEM")
                )
                .isDeleted(0)
                .build();

        save(dto);
    }

    private int toDayNumber(LocalDate date) {
        return date.getYear() * 10000 + date.getMonthValue() * 100 + date.getDayOfMonth();
    }

    private int toMonthNumber(LocalDate date) {
        return date.getYear() * 100 + date.getMonthValue();
    }

    private String encodeToBase64(String jsonFile) {
        if (jsonFile == null) {
            return null;
        }
        return Base64.getEncoder().encodeToString(jsonFile.getBytes(StandardCharsets.UTF_8));
    }

    private boolean resolveIsWorkaround() {
        return headersCtx != null && "GUI".equalsIgnoreCase(headersCtx.getProcessType());
    }


    // =========================================================
    // STATUS ENUM
    // =========================================================
    public enum FlussiStatus {
        INIT(0, "INIT"),
        BEGIN(100, "BEGIN"),
        PROGRESS(120, "IN ELABORAZIONE"),
        COMPLETED(220, "ACQUISITO"),
        ERROR(400, "ERROR");

        final int code;
        final String description;

        FlussiStatus(int code, String description) {
            this.code = code;
            this.description = description;
        }
    }

}