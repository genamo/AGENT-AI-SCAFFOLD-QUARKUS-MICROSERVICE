package it.eng.snam.pmr.common.filter;
import jakarta.enterprise.context.RequestScoped;
import lombok.Data;

@Data
@RequestScoped
public class RequestHeadersContext {

    private String keyLogic;
    private String transactionId;
    private boolean modAsync;
    private String processType;
    private String path;
    private long startNanos;
}
