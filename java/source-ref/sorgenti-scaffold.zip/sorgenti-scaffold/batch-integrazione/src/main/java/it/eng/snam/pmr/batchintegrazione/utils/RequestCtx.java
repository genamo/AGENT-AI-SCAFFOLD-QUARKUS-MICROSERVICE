package it.eng.snam.pmr.batchintegrazione.utils;

import it.eng.snam.pmr.batchintegrazione.filter.MdcHeadersFilter;
import jakarta.ws.rs.container.ContainerRequestContext;

public final class RequestCtx {
    private RequestCtx() {}

    public static String kl(ContainerRequestContext ctx) {
        return (String) ctx.getProperty(MdcHeadersFilter.PROP_KL);
    }

    public static String tid(ContainerRequestContext ctx) {
        return (String) ctx.getProperty(MdcHeadersFilter.PROP_TID);
    }

    public static boolean modAsync(ContainerRequestContext ctx) {
        Object v = ctx.getProperty(MdcHeadersFilter.PROP_MOD_ASYNC);
        return (v instanceof Boolean b) && b;
    }
    
    public static String processType(ContainerRequestContext ctx) {
        Object o = ctx.getProperty("CTX_PROCESS_TYPE");
        return o != null ? o.toString() : "N/A";
    }
}