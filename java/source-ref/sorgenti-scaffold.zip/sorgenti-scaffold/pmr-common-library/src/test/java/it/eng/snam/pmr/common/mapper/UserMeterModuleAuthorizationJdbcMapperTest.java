package it.eng.snam.pmr.common.mapper;

import it.eng.snam.pmr.common.dto.UserMeterModuleAuthorizationDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserMeterModuleAuthorizationJdbcMapperTest {

    @Mock
    ResultSet rs;

    @Test
    void map_allFieldsSet_mapsCorrectly() throws SQLException {
        Instant now = Instant.parse("2024-07-01T08:30:00Z");
        Timestamp ts = Timestamp.from(now);

        when(rs.getObject("UserMeterModuleAuthorizationId")).thenReturn(1L);
        when(rs.getString("UserCode")).thenReturn("USR42");
        when(rs.getObject("UserId")).thenReturn(100L);
        when(rs.getString("MeterCode")).thenReturn("MTR001");
        when(rs.getString("MeterId")).thenReturn("MID001");
        when(rs.getString("ModuleCode")).thenReturn("MOD01");
        when(rs.getTimestamp("InsertDate")).thenReturn(ts);
        when(rs.getTimestamp("UpdateDate")).thenReturn(ts);
        when(rs.getString("OrganizationCode")).thenReturn("ORG01");
        when(rs.getObject("OrganizationId")).thenReturn(200L);
        when(rs.getString("WeakSapCode")).thenReturn("SAP01");
        when(rs.getObject("FlowId")).thenReturn(3L);
        when(rs.getObject("EntityId")).thenReturn(4L);
        when(rs.getObject("CancelledFlag")).thenReturn(0);
        when(rs.getString("PkSource")).thenReturn("SRC");
        when(rs.getObject("Denominatore")).thenReturn(2);
        when(rs.getObject("Penalita")).thenReturn(1);
        when(rs.getString("IdErrore")).thenReturn(null);

        UserMeterModuleAuthorizationDTO dto = UserMeterModuleAuthorizationJdbcMapper.map(rs);

        assertThat(dto.userMeterModuleAuthorizationId()).isEqualTo(1L);
        assertThat(dto.userCode()).isEqualTo("USR42");
        assertThat(dto.userId()).isEqualTo(100L);
        assertThat(dto.meterCode()).isEqualTo("MTR001");
        assertThat(dto.meterId()).isEqualTo("MID001");
        assertThat(dto.moduleCode()).isEqualTo("MOD01");
        assertThat(dto.insertDate()).isEqualTo(now);
        assertThat(dto.updateDate()).isEqualTo(now);
        assertThat(dto.organizationCode()).isEqualTo("ORG01");
        assertThat(dto.organizationId()).isEqualTo(200L);
        assertThat(dto.weakSapCode()).isEqualTo("SAP01");
        assertThat(dto.flowId()).isEqualTo(3L);
        assertThat(dto.entityId()).isEqualTo(4L);
        assertThat(dto.cancelledFlag()).isEqualTo(0);
        assertThat(dto.pkSource()).isEqualTo("SRC");
        assertThat(dto.denominatore()).isEqualTo(2);
        assertThat(dto.penalita()).isEqualTo(1);
        assertThat(dto.idErrore()).isNull();
    }

    @Test
    void map_nullTimestampsAndLongs_setsThemNull() throws SQLException {
        when(rs.getObject("UserMeterModuleAuthorizationId")).thenReturn(null);
        when(rs.getString("UserCode")).thenReturn(null);
        when(rs.getObject("UserId")).thenReturn(null);
        when(rs.getString("MeterCode")).thenReturn(null);
        when(rs.getString("MeterId")).thenReturn(null);
        when(rs.getString("ModuleCode")).thenReturn(null);
        when(rs.getTimestamp("InsertDate")).thenReturn(null);
        when(rs.getTimestamp("UpdateDate")).thenReturn(null);
        when(rs.getString("OrganizationCode")).thenReturn(null);
        when(rs.getObject("OrganizationId")).thenReturn(null);
        when(rs.getString("WeakSapCode")).thenReturn(null);
        when(rs.getObject("FlowId")).thenReturn(null);
        when(rs.getObject("EntityId")).thenReturn(null);
        when(rs.getObject("CancelledFlag")).thenReturn(null);
        when(rs.getString("PkSource")).thenReturn(null);
        when(rs.getObject("Denominatore")).thenReturn(null);
        when(rs.getObject("Penalita")).thenReturn(null);
        when(rs.getString("IdErrore")).thenReturn(null);

        UserMeterModuleAuthorizationDTO dto = UserMeterModuleAuthorizationJdbcMapper.map(rs);

        assertThat(dto.userMeterModuleAuthorizationId()).isNull();
        assertThat(dto.insertDate()).isNull();
        assertThat(dto.updateDate()).isNull();
        assertThat(dto.organizationId()).isNull();
        assertThat(dto.cancelledFlag()).isNull();
    }
}
