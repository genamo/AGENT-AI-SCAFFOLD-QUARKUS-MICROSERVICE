package it.eng.snam.pmr.common.dto.kafka;

import org.apache.kafka.common.header.internals.RecordHeaders;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

import it.eng.snam.pmr.common.dto.kafka.consume.IncomingMessageContext;

class MessageContextTest {

    @Test
    void staticFactory_setsAllFields() {
        byte[] payload = "abc".getBytes();
        RecordHeaders headers = new RecordHeaders();

        IncomingMessageContext ctx = IncomingMessageContext.of("topic-a", headers, payload, 3, null);

        assertThat(ctx.getTopic()).isEqualTo("topic-a");
        assertThat(ctx.getHeaders()).isSameAs(headers);
        assertThat(ctx.getPayload()).containsExactly(payload);
        assertThat(ctx.getSize()).isEqualTo(3);
        assertThat(ctx.getMetadata()).isNull();
    }
}
