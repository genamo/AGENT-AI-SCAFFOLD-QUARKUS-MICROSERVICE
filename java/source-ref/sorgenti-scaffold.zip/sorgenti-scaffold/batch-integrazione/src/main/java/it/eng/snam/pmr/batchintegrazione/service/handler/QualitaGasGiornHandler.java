package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.QualitaGasGiornPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.DatiPrimariService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class QualitaGasGiornHandler extends AbstractFlussoHandler<QualitaGasGiornPayloadDto> {

    @Inject
    DatiPrimariService datiPrimariService;

    @Override
    protected Class<QualitaGasGiornPayloadDto> getDtoClass() {
        return QualitaGasGiornPayloadDto.class;
    }

    @Override
    protected void handle(QualitaGasGiornPayloadDto dto) {
        if (dto.operation() != null && !dto.operation().isEmpty()) {
            switch (dto.operation()) {
                case "INSERT":
                    if (dto.data() != null && !dto.data().isEmpty()) {
                        datiPrimariService.saveQualitaGasGiorn(dto.data().getFirst());
                    }
                    break;

                case "DELETE":
                    if (dto.data() != null && !dto.data().isEmpty()) {
                        datiPrimariService.deleteQualitaGasGiorn(
                                dto.data().getFirst().codiceAop(),
                                dto.data().getFirst().dataIniPre()
                        );
                    }
                    break;

                default:
                    throw new IllegalArgumentException("Invalid operation: " + dto.operation());
            }
        } else {
            throw new IllegalArgumentException("Operation field is required");
        }
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.QUALITA_GASDAY_FLOW;
    }
}
