package it.eng.snam.pmr.common.util;

import java.time.Duration;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class ThreadSleeper {

    public void attempt(Integer attempt, Duration retryDelay) {
        try {
            long sleepTime = retryDelay.multipliedBy(attempt).toMillis();
            log.info("Attempting to sleep for: {}ms", sleepTime);

            Thread.sleep(sleepTime);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Retryable process interrupted", ex);
        }
    }
}
