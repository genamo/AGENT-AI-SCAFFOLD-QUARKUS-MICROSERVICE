package it.eng.snam.pmr.batchintegrazione.dto.blob.storage;

import lombok.Value;

@Value(staticConstructor = "of")
public class BlobUploadStatus {

    String containerName;
    String blobPath;
    String blobContentType;
    String status;
    String statusMessage;
}
