package it.eng.snam.pmr.batchintegrazione.service.abstracts;

import java.io.IOException;
import java.time.LocalDate;

import org.jboss.logging.Logger;

import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringFlussiService;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringFlussiService.FlussiStatus;
import it.eng.snam.pmr.common.util.JsonUtils;
import jakarta.inject.Inject;

public abstract class AbstractFlussoHandler<T> implements FlussoHandler {

    private static final Logger LOG = Logger.getLogger(AbstractFlussoHandler.class);

    private static final int DEFAULT_MAX_RETRIES = 3;
    private static final long DEFAULT_BASE_DELAY_MS = 3000L;
    private static final String DEFAULT_SENDER = "SUMMER";

    @Inject
    MonitoringFlussiService monitoring;


    @Inject
    protected RequestHeadersContext headersCtx;

    
    private final int maxRetries;
    private final long baseDelayMs;

    protected AbstractFlussoHandler() {
        this(DEFAULT_MAX_RETRIES, DEFAULT_BASE_DELAY_MS);
    }

    protected AbstractFlussoHandler(int maxRetries, long baseDelayMs) {
        this.maxRetries = maxRetries;
        this.baseDelayMs = baseDelayMs;
    }

    protected abstract Class<T> getDtoClass();
    protected abstract void handle(T dto);
    protected abstract String flowType();

    @Override
    public String getFlowType() {
        return flowType();
    }

    @Override
    public void process(String payload) {
        try {
        	saveStatus(FlussiStatus.INIT);
        	T dto = deserialize(payload);
        	if(dto!=null) {
        		setCorrelationIdIfPresent(dto);
        		saveStatus(FlussiStatus.BEGIN);
        		checkData(dto);
        		saveStatus(FlussiStatus.PROGRESS, payload, null);
                executeHandleWithRetry(dto);
                saveStatus(FlussiStatus.COMPLETED, payload, null);
        	}else {
        		 saveStatus(FlussiStatus.ERROR, payload, JsonUtils.writeAsJsonStringWithoutNull("Input non valido o deserializzazione fallita"));
        	}
            
        } catch (Exception e) {
            LOG.errorf(e, "Errore durante l'elaborazione del flusso %s: %s", flowType(), e.getMessage());
            saveStatus(FlussiStatus.ERROR, payload, e.getMessage());
        }
    }

    protected T deserialize(String payload) throws IOException {
    	try {
    		return JsonUtils.getObject(payload, getDtoClass());	
    	}catch (Exception e) {
    		return null;
    	}
        
    }

    protected void executeHandleWithRetry(T dto) {
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                handle(dto);
                return;
            } catch (Exception e) {
                LOG.warnf(e, "Tentativo handle %d/%d fallito per flow=%s", attempt, maxRetries, flowType());

                if (attempt == maxRetries) {
                    LOG.error("Handle fallito definitivamente", e);
                    throw e;
                }

                try {
                    sleep(computeDelayMs(attempt));
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new IllegalStateException("Retry interrotto", ie);
                }
            }
        }
    }

    protected long computeDelayMs(int attempt) {
        return baseDelayMs * attempt;
    }

    protected void sleep(long millis) throws InterruptedException {
        Thread.sleep(millis);
    }

    protected LocalDate currentDate() {
        return LocalDate.now();
    }

    protected String sender() {
        return DEFAULT_SENDER;
    }

    private void saveStatus(FlussiStatus status) {
        monitoring.saveFlussoStatus(flowType(), sender(), currentDate(), status);
    }

    private void saveStatus(FlussiStatus status, String payload, String message) {
        monitoring.saveFlussoStatus(flowType(), sender(), currentDate(), status, payload, message);
    }
    

	protected void setCorrelationIdIfPresent(T dto) {
	    if (dto instanceof ValidationInterface c && c.getCorrelationId() != null) {
	        headersCtx.setCorrelationId(c.getCorrelationId());
	    }else {
	    	throw new IllegalStateException("DTO non contiene correlationId oppure il valore è null");
	    }
	}
	protected void checkData(T dto) {
	    if (!(dto instanceof ValidationInterface c && c.getElementNumber() > 0)) {
	        throw new IllegalStateException("DTO non contiene elementi da processare");
	    }
	}
}
