package it.eng.snam.pmr.batchintegrazione.test.service.internal;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.batchintegrazione.service.internal.MonitoringIntegrationService;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.util.JsonUtils;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class MonitoringIntegrationServiceTest {

    @Mock
    private BatchIntegrazioneDgClient batchIntegrazioneClient;

    private Response response;

    @BeforeEach
    void setUp() {
        response = mock(Response.class);
    }

    @Test
    void sendRequestGenerateSend_shouldBuildRequestCallClientAndReturnId() throws Exception {
        GenericResponse<Long> expectedGenericResponse = new GenericResponse<>();
        expectedGenericResponse.setData(99L);

        when(batchIntegrazioneClient.sendRequestMonitoringIntegration(any())).thenReturn(response);
        when(response.getStatus()).thenReturn(Response.Status.OK.getStatusCode());
        lenient().when(response.readEntity(String.class)).thenReturn(
                JsonUtils.writeAsJsonPrettyLogStringWithoutNull(expectedGenericResponse));

        MonitoringIntegrationService service = spy(new MonitoringIntegrationService());
        injectClient(service);

        when(batchIntegrazioneClient.sendRequestMonitoringIntegration(any(MonitoringIntegration.class))).thenReturn(
                response);

        MonitoringIntegration integration = new MonitoringIntegration();
        integration.setIntegrationType("TEST_TYPE");
        integration.setRequestBody("{}");
        service.sendRequestMonitoringIntegration(integration);

        verify(batchIntegrazioneClient).sendRequestMonitoringIntegration(
                argThat(request -> "TEST_TYPE".equals(request.getIntegrationType()) &&
                                   request.getRequestBody() != null));
    }

    private void injectClient(MonitoringIntegrationService service) throws Exception {
        Field fieldBatchIntegrazione = MonitoringIntegrationService.class.getDeclaredField("batchIntegrazioneDgClient");
        fieldBatchIntegrazione.setAccessible(true);
        fieldBatchIntegrazione.set(service, batchIntegrazioneClient);
    }
}
