package it.eng.snam.pmr.common.response.swagger;

import java.io.Serial;
import java.util.List;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import it.eng.snam.pmr.common.response.GenericResponse;

@Schema(name = "StringListResponse")
public class StringListResponse extends GenericResponse<List<String>> {
    @Serial
    private static final long serialVersionUID = -7075101192396912704L;
}
