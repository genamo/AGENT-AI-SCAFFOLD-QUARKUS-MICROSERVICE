package it.eng.snam.pmr.batchintegrazionedg.service;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.apache.kafka.common.header.Headers;
import org.jboss.logging.Logger;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.domain.MonitoringBatch;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringBatchDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringBatchSearchDTO;
import it.eng.snam.pmr.batchintegrazionedg.mapper.MonitoringBatchMapper;
import it.eng.snam.pmr.batchintegrazionedg.repository.MonitoringBatchRepository;
import it.eng.snam.pmr.batchintegrazionedg.service.abstracts.AbstractMonitoringCrudService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.transaction.Transactional.TxType;

@ApplicationScoped
@RunOnVirtualThread
public class MonitoringBatchService
        extends AbstractMonitoringCrudService<MonitoringBatchDTO, MonitoringBatch, MonitoringBatchSearchDTO> {

    private static final Logger LOG = Logger.getLogger(MonitoringBatchService.class);
    
    

    @Inject
    MonitoringBatchRepository repository;

    @Inject
    MonitoringBatchMapper mapper;

    @Override
    protected List<MonitoringBatch> listAllEntities() {
        return repository.listAll();
    }

    @Override
    protected MonitoringBatch findEntityById(Long id) {
        return repository.findById(id);
    }

    @Override
    protected Optional<MonitoringBatch> findEntityByTransactionId(String transactionId) {
        return repository.findByTransactionId(transactionId);
    }

    @Override
    protected List<MonitoringBatch> findLastExecutionsEntities(int limit) {
        return repository.findLastExecutionsNoLock(limit);
    }

    @Override
    protected List<MonitoringBatch> findByPeriodEntities(Integer monthNumber, Integer dayNumber) {
        return repository.findByPeriod(monthNumber, dayNumber);
    }

    @Override
    protected List<MonitoringBatch> findByCustomSearchEntities(MonitoringBatchSearchDTO search) {
        return repository.findByCustomSearchReadUncommitted(search);
    }

    @Override
    protected List<MonitoringBatchDTO> toDtoList(List<MonitoringBatch> entities) {
        return mapper.toDtoList(entities);
    }

    @Override
    protected MonitoringBatchDTO toDto(MonitoringBatch entity) {
        return mapper.toDto(entity);
    }

    @Transactional(TxType.REQUIRES_NEW)
    @Override
    protected MonitoringBatchDTO saveAttempt(MonitoringBatchDTO dto) {
        Optional<MonitoringBatch> existing = repository.findByTransactionId(dto.transactionId());

        MonitoringBatch entityToSave;

        if (existing.isPresent()) {
            entityToSave = existing.get();
            mapper.updateEntityFromDto(dto, entityToSave);
            repository.flush();
        } else {
            entityToSave = mapper.toEntity(dto);
            repository.persistAndFlush(entityToSave);
        }

        return mapper.toDto(entityToSave);
    }

    public void processBatch(String payload, Headers headers) {
        processPayload(payload, MonitoringBatchDTO.class, "Error processing batch message");
    }

    public void processSaveMonitoringBatch(String payload) {
        processPayload(payload, MonitoringBatchDTO.class, "Error processing batch message");
    }

    @Override
    protected Logger logger() {
        return LOG;
    }

    @Override
    protected String transactionIdOf(MonitoringBatchDTO request) {
        return request == null ? null : request.transactionId();
    }

    @Override
    protected MonitoringBatchDTO fallbackError(MonitoringBatchDTO request, String reason) {
        if (request == null) {
            return MonitoringBatchDTO.builder()
                    .statusDescription("ERROR_" + reason)
                    .isDeleted(0)
                    .build();
        }

        return request.toBuilder()
                .statusDescription("ERROR_" + reason)
                .isDeleted(request.isDeleted() == null ? 0 : request.isDeleted())
                .build();
    }

    @Override
    protected String interruptedRetryLogMessage() {
        return "Retry DB MonitoringBatch interrotto";
    }
    
 
    
    public enum FlussiStatus {
        INIT(0, "INIT"),
        BEGIN(100, "BEGIN"),
        PROGRESS(120, "IN ELABORAZIONE"),
        COMPLETED(220, "ACQUISITO"),
        ERROR(400, "ERROR");

        final int code;
        final String description;

        FlussiStatus(int code, String description) {
            this.code = code;
            this.description = description;
        }
    }
    
}
