package it.eng.snam.pmr.batchintegrazionedg.test.domain;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import it.eng.snam.pmr.batchintegrazionedg.domain.AnagFlussi;
import java.time.LocalDateTime;

class AnagFlussiEntityTest {

    @Test
    void gettersAndSetters_workCorrectly() {
        AnagFlussi e = new AnagFlussi();
        LocalDateTime now = LocalDateTime.now();

        e.setId(1L);
        e.setFlowId("FLOW-001");
        e.setDescFlow("Descrizione flusso");
        e.setGranularita("G");
        e.setVerso("IN");
        e.setProcessType("N/A");
        e.setSender("SENDER");
        e.setReceiver("RECEIVER");
        e.setActionDate(now);
        e.setUserAction("SYSTEM");
        e.setIsDeleted(0);

        assertEquals(1L, e.getId());
        assertEquals("FLOW-001", e.getFlowId());
        assertEquals("Descrizione flusso", e.getDescFlow());
        assertEquals("G", e.getGranularita());
        assertEquals("IN", e.getVerso());
        assertEquals("N/A", e.getProcessType());
        assertEquals("SENDER", e.getSender());
        assertEquals("RECEIVER", e.getReceiver());
        assertEquals(now, e.getActionDate());
        assertEquals("SYSTEM", e.getUserAction());
        assertEquals(0, e.getIsDeleted());
    }

    @Test
    void defaultValues_areSet() {
        AnagFlussi e = new AnagFlussi();
        assertEquals("G", e.getGranularita());
        assertEquals("IN", e.getVerso());
        assertEquals("N/A", e.getProcessType());
        assertEquals("DATASETUP", e.getUserAction());
        assertEquals(0, e.getIsDeleted());
    }
}
