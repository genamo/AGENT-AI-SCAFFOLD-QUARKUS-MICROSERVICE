package it.eng.snam.pmr.batchintegrazione.kafka;

import java.util.Map;

import org.eclipse.microprofile.reactive.messaging.Channel;
import org.eclipse.microprofile.reactive.messaging.Emitter;

import it.eng.snam.pmr.batchintegrazione.service.abstracts.TopicService;
import it.eng.snam.pmr.common.dto.kafka.produce.MessageHeaderContext;
import it.eng.snam.pmr.common.functional.interfaces.kafka.producer.MessageHeaderFactory;
import it.eng.snam.pmr.common.util.kafka.producer.MessagePublisher;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class KafkaGenericProducer {

    @Inject
    TopicService topicService;

    @Inject
    @Channel("kafka-out")
    Emitter<byte[]> emitter;

    public void sendEventWithHeaders(String topic, Object payload, Map<String, String> additionalHeaders) {
        sendEventWithHeaders(topic, MessageHeaderFactory.mdc(), payload, additionalHeaders);
    }

    public void sendEventWithHeaders(String topic, MessageHeaderContext headerContext, Object payload, Map<String, String> additionalHeaders) {
        sendEventWithHeaders(topic, MessageHeaderFactory.merge(headerContext), payload, additionalHeaders);
    }

    public void sendEventWithHeaders(String topic, MessageHeaderFactory headerFactory, Object payload, Map<String, String> additionalHeaders) {
        String realTopic = topicService.getRealTopic(topic);
        MessagePublisher.send(realTopic, headerFactory, payload, emitter::send, additionalHeaders);
    }
}