package it.eng.snam.pmr.batchintegrazionedg.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazionedg.domain.IdempotenzaFlussi;
import it.eng.snam.pmr.batchintegrazionedg.domain.IdempotenzaStatus;
import it.eng.snam.pmr.batchintegrazionedg.dto.IdempotenzaRequestDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.IdempotenzaResponseDTO;
import it.eng.snam.pmr.batchintegrazionedg.repository.IdempotenzaFlussiRepository;
import it.eng.snam.pmr.batchintegrazionedg.service.IdempotenzaFlussiService;
import jakarta.persistence.PersistenceException;

@ExtendWith(MockitoExtension.class)
class IdempotenzaFlussiServiceTest {

    @Mock
    IdempotenzaFlussiRepository repository;

    @InjectMocks
    IdempotenzaFlussiService service;

    private IdempotenzaRequestDTO request(
            String transactionId,
            String flowId,
            String keyLogic,
            String status,
            String errorMessage) {
        return new IdempotenzaRequestDTO(
                transactionId,
                flowId,
                keyLogic,
                status,
                errorMessage
        );
    }

    private IdempotenzaFlussi entity(String transactionId, IdempotenzaStatus status) {
        IdempotenzaFlussi entity = new IdempotenzaFlussi();
        entity.setTransactionId(transactionId);
        entity.setFlowId("FLOW-" + transactionId);
        entity.setKeyLogic("KL-" + transactionId);
        entity.setStatus(status);
        return entity;
    }

    @Test
    void start_newTransaction_persistsEntityAndReturnsStartedTrue() {
        IdempotenzaRequestDTO request = request("TXN-001", "FLOW-001", "KL-001", null, null);

        IdempotenzaResponseDTO response = service.start(request);

        ArgumentCaptor<IdempotenzaFlussi> captor =
                ArgumentCaptor.forClass(IdempotenzaFlussi.class);

        verify(repository).persistAndFlush(captor.capture());

        IdempotenzaFlussi persisted = captor.getValue();
        assertEquals("TXN-001", persisted.getTransactionId());
        assertEquals("FLOW-001", persisted.getFlowId());
        assertEquals("KL-001", persisted.getKeyLogic());
        assertEquals(IdempotenzaStatus.IN_PROGRESS, persisted.getStatus());

        assertTrue(response.started());
        assertEquals("TXN-001", response.transactionId());
        assertEquals("IN_PROGRESS", response.status());
    }

    @Test
    void start_duplicateKey_returnsExistingStatus() {
        IdempotenzaRequestDTO request = request("TXN-002", "FLOW-002", "KL-002", null, null);
        IdempotenzaFlussi existing = entity("TXN-002", IdempotenzaStatus.COMPLETED);

        doThrow(new PersistenceException("duplicate key"))
                .when(repository).persistAndFlush(any(IdempotenzaFlussi.class));
        when(repository.findByTransactionId("TXN-002"))
                .thenReturn(Optional.of(existing));

        IdempotenzaResponseDTO response = service.start(request);

        verify(repository).persistAndFlush(any(IdempotenzaFlussi.class));
        verify(repository).findByTransactionId("TXN-002");

        assertFalse(response.started());
        assertEquals("TXN-002", response.transactionId());
        assertEquals("COMPLETED", response.status());
    }

    @Test
    void start_duplicateKey_whenRecordNotFound_returnsFallbackError() {
        IdempotenzaRequestDTO request = request("TXN-003", "FLOW-003", "KL-003", null, null);

        doThrow(new PersistenceException("2627 duplicate"))
                .when(repository).persistAndFlush(any(IdempotenzaFlussi.class));
        when(repository.findByTransactionId("TXN-003"))
                .thenReturn(Optional.empty());

        IdempotenzaResponseDTO response = service.start(request);

        verify(repository).persistAndFlush(any(IdempotenzaFlussi.class));
        verify(repository).findByTransactionId("TXN-003");

        assertFalse(response.started());
        assertEquals("TXN-003", response.transactionId());
        assertEquals("ERROR_DUPLICATE_BUT_NOT_FOUND", response.status());
    }

    @Test
    void start_duplicateKey_whenReadFails_returnsFallbackError() {
        IdempotenzaRequestDTO request = request("TXN-003B", "FLOW-003B", "KL-003B", null, null);

        doThrow(new PersistenceException("2627 duplicate"))
                .when(repository).persistAndFlush(any(IdempotenzaFlussi.class));
        when(repository.findByTransactionId("TXN-003B"))
                .thenThrow(new RuntimeException("read error"));

        IdempotenzaResponseDTO response = service.start(request);

        verify(repository).persistAndFlush(any(IdempotenzaFlussi.class));
        verify(repository).findByTransactionId("TXN-003B");

        assertFalse(response.started());
        assertEquals("TXN-003B", response.transactionId());
        assertEquals("ERROR_ERROR_READ_AFTER_DUPLICATE", response.status());
    }

    @Test
    void start_retryablePersistenceError_retriesAndEventuallySucceeds() {
        IdempotenzaRequestDTO request = request("TXN-004", "FLOW-004", "KL-004", null, null);
        AtomicInteger persistCalls = new AtomicInteger();

        doAnswer(invocation -> {
            if (persistCalls.getAndIncrement() == 0) {
                throw new PersistenceException("1205");
            }
            return null;
        }).when(repository).persistAndFlush(any(IdempotenzaFlussi.class));

        IdempotenzaResponseDTO response = service.start(request);

        verify(repository, times(2)).persistAndFlush(any(IdempotenzaFlussi.class));

        assertTrue(response.started());
        assertEquals("TXN-004", response.transactionId());
        assertEquals("IN_PROGRESS", response.status());
    }

    @Test
    void start_retryablePersistenceError_exhausted_returnsFallbackError() {
        IdempotenzaRequestDTO request = request("TXN-004B", "FLOW-004B", "KL-004B", null, null);

        doThrow(new PersistenceException("1205"))
                .when(repository).persistAndFlush(any(IdempotenzaFlussi.class));

        IdempotenzaResponseDTO response = service.start(request);

        verify(repository, times(5)).persistAndFlush(any(IdempotenzaFlussi.class));

        assertFalse(response.started());
        assertEquals("TXN-004B", response.transactionId());
        assertEquals("ERROR_DB_RETRY_EXHAUSTED_START", response.status());
    }

    @Test
    void start_nonTransientPersistenceError_returnsFallbackError() {
        IdempotenzaRequestDTO request = request("TXN-005", "FLOW-005", "KL-005", null, null);

        doThrow(new PersistenceException("generic db error"))
                .when(repository).persistAndFlush(any(IdempotenzaFlussi.class));

        IdempotenzaResponseDTO response = service.start(request);

        verify(repository).persistAndFlush(any(IdempotenzaFlussi.class));

        assertFalse(response.started());
        assertEquals("TXN-005", response.transactionId());
        assertEquals("ERROR_DB_ERROR_START", response.status());
    }

    @Test
    void updateStatus_missingStatus_returnsFallbackErrorWithoutCallingRepository() {
        IdempotenzaRequestDTO request = request("TXN-006", "FLOW-006", "KL-006", null, null);

        IdempotenzaResponseDTO response = service.updateStatus(request);

        verifyNoInteractions(repository);
        assertFalse(response.started());
        assertEquals("TXN-006", response.transactionId());
        assertEquals("ERROR_MISSING_STATUS", response.status());
    }

    @Test
    void updateStatus_existingTransaction_updatesStatusAndErrorMessage() {
        IdempotenzaRequestDTO request = request(
                "TXN-007",
                "FLOW-007",
                "KL-007",
                "ERROR",
                "Errore tecnico"
        );

        when(repository.update(
                "status = ?1, errorMessage = ?2 where transactionId = ?3",
                IdempotenzaStatus.ERROR,
                "Errore tecnico",
                "TXN-007"))
                .thenReturn(1);

        IdempotenzaResponseDTO response = service.updateStatus(request);

        verify(repository).update(
                "status = ?1, errorMessage = ?2 where transactionId = ?3",
                IdempotenzaStatus.ERROR,
                "Errore tecnico",
                "TXN-007");

        assertFalse(response.started());
        assertEquals("TXN-007", response.transactionId());
        assertEquals("ERROR", response.status());
    }

    @Test
    void updateStatus_notFound_returnsFallbackError() {
        IdempotenzaRequestDTO request = request(
                "TXN-008",
                "FLOW-008",
                "KL-008",
                "COMPLETED",
                null
        );

        when(repository.update(
                "status = ?1, errorMessage = ?2 where transactionId = ?3",
                IdempotenzaStatus.COMPLETED,
                null,
                "TXN-008"))
                .thenReturn(0);

        IdempotenzaResponseDTO response = service.updateStatus(request);

        verify(repository).update(
                "status = ?1, errorMessage = ?2 where transactionId = ?3",
                IdempotenzaStatus.COMPLETED,
                null,
                "TXN-008");

        assertFalse(response.started());
        assertEquals("TXN-008", response.transactionId());
        assertEquals("ERROR_NOT_FOUND_FOR_UPDATE", response.status());
    }

    @Test
    void updateStatus_retryablePersistenceError_retriesAndEventuallySucceeds() {
        IdempotenzaRequestDTO request = request(
                "TXN-009",
                "FLOW-009",
                "KL-009",
                "COMPLETED",
                null
        );
        AtomicInteger updateCalls = new AtomicInteger();

        when(repository.update(anyString(), any(), any(), any()))
                .thenAnswer(invocation -> {
                    if (updateCalls.getAndIncrement() == 0) {
                        throw new PersistenceException("lock request time out period exceeded");
                    }
                    return 1;
                });

        IdempotenzaResponseDTO response = service.updateStatus(request);

        verify(repository, times(2)).update(anyString(), any(), any(), any());

        assertFalse(response.started());
        assertEquals("TXN-009", response.transactionId());
        assertEquals("COMPLETED", response.status());
    }

    @Test
    void updateStatus_retryablePersistenceError_exhausted_returnsFallbackError() {
        IdempotenzaRequestDTO request = request(
                "TXN-009B",
                "FLOW-009B",
                "KL-009B",
                "COMPLETED",
                null
        );

        when(repository.update(anyString(), any(), any(), any()))
                .thenThrow(new PersistenceException("lock request time out period exceeded"));

        IdempotenzaResponseDTO response = service.updateStatus(request);

        verify(repository, times(5)).update(anyString(), any(), any(), any());

        assertFalse(response.started());
        assertEquals("TXN-009B", response.transactionId());
        assertEquals("ERROR_DB_RETRY_EXHAUSTED_UPDATE", response.status());
    }

    @Test
    void updateStatus_invalidEnum_returnsUnexpectedError() {
        IdempotenzaRequestDTO request = request(
                "TXN-010",
                "FLOW-010",
                "KL-010",
                "NOT_A_VALID_STATUS",
                null
        );

        IdempotenzaResponseDTO response = service.updateStatus(request);

        verifyNoInteractions(repository);
        assertFalse(response.started());
        assertEquals("TXN-010", response.transactionId());
        assertEquals("ERROR_UNEXPECTED_UPDATE", response.status());
    }

    @Test
    void findByTransactionId_delegatesToRepository() {
        IdempotenzaFlussi existing = entity("TXN-011", IdempotenzaStatus.IN_PROGRESS);

        when(repository.findByTransactionId("TXN-011"))
                .thenReturn(Optional.of(existing));

        Optional<IdempotenzaFlussi> result = service.findByTransactionId("TXN-011");

        verify(repository).findByTransactionId("TXN-011");
        assertTrue(result.isPresent());
        assertSame(existing, result.orElseThrow());
    }
}
