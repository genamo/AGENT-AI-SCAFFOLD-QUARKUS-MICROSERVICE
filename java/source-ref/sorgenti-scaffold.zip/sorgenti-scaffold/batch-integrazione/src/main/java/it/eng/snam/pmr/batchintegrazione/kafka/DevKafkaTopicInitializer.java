package it.eng.snam.pmr.batchintegrazione.kafka;

import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.CreateTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.errors.TopicExistsException;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import io.quarkus.runtime.StartupEvent;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.TopicService;
import it.eng.snam.pmr.batchintegrazione.utils.Constants.Topic;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;

@ApplicationScoped
public class DevKafkaTopicInitializer {

    private static final Logger LOG = Logger.getLogger(DevKafkaTopicInitializer.class);
    private static final long ADMIN_TIMEOUT_SECONDS = 10;

    @Inject TopicService topicService;
    @ConfigProperty(name = "kafka.bootstrap.servers")              String bootstrapServers;
    @ConfigProperty(name = "kafka.topics.auto-create", defaultValue = "false") boolean autoCreateTopics;
    @ConfigProperty(name = "kafka.topics.partitions",   defaultValue = "1")    int partitions;
    @ConfigProperty(name = "kafka.topics.replication-factor", defaultValue = "1") short replicationFactor;

    void onStart(@Observes StartupEvent event) {
        if (!autoCreateTopics) { LOG.debug("Kafka DEV topic auto-creation disabled"); return; }
        LOG.info("DEV profile -> Kafka topic auto-creation enabled");

        List<String> topicsToEnsure = List.of(
                topicService.getRealTopic(Topic.PMR001A_SUMMER_IN_TOPIC),
                topicService.getRealTopic(Topic.PMR001H_SUMMER_IN_TOPIC),
                topicService.getRealTopic(Topic.GLOBAL_DLQ_TOPIC)
                
        ).stream().filter(t -> t != null && !t.isBlank()).distinct().toList();

        if (topicsToEnsure.isEmpty()) { LOG.warn("No DEV Kafka topics to ensure"); return; }

        Properties props = new Properties();
        props.put("bootstrap.servers", bootstrapServers);

        try (AdminClient admin = AdminClient.create(props)) {
            Set<String> existing = admin.listTopics().names().get(ADMIN_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            List<NewTopic> toCreate = topicsToEnsure.stream()
                    .filter(t -> !existing.contains(t))
                    .map(t -> new NewTopic(t, partitions, replicationFactor))
                    .toList();
            if (toCreate.isEmpty()) { LOG.info("All DEV Kafka topics already exist"); return; }
            CreateTopicsResult result = admin.createTopics(toCreate);
            for (NewTopic nt : toCreate) {
                waitForTopicCreation(result, nt);
            }
        } catch (Exception e) { LOG.error("Error creating Kafka topics in DEV", e); }
    }

    private void waitForTopicCreation(CreateTopicsResult result, NewTopic nt)
            throws java.util.concurrent.TimeoutException {
        try {
            result.values().get(nt.name()).get(ADMIN_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            LOG.infof("Kafka DEV topic created: %s", nt.name());
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            LOG.warnf("Interrupted while waiting for Kafka DEV topic creation: %s", nt.name());
        } catch (ExecutionException ee) {
            if (ee.getCause() instanceof TopicExistsException)
                LOG.infof("Kafka DEV topic already exists (race): %s", nt.name());
            else
                LOG.errorf(ee.getCause(), "Error creating Kafka DEV topic: %s", nt.name());
        }
    }
}
