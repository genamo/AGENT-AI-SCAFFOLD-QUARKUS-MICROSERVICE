package it.eng.snam.pmr.common.filter;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class RequestHeadersContextTest {

    @Test
    void newInstance_hasExpectedDefaultValues() {
        RequestHeadersContext ctx = new RequestHeadersContext();

        assertThat(ctx.getKeyLogic()).isNull();
        assertThat(ctx.getTransactionId()).isNull();
        assertThat(ctx.isModAsync()).isFalse();
        assertThat(ctx.getProcessType()).isNull();
        assertThat(ctx.getPath()).isNull();
        assertThat(ctx.getStartNanos()).isZero();
    }

    @Test
    void gettersAndSetters_work() {
        RequestHeadersContext ctx = new RequestHeadersContext();
        ctx.setKeyLogic("KL");
        ctx.setTransactionId("TX");
        ctx.setModAsync(true);
        ctx.setProcessType("PT");
        ctx.setPath("/api/test");
        ctx.setStartNanos(123L);

        assertThat(ctx.getKeyLogic()).isEqualTo("KL");
        assertThat(ctx.getTransactionId()).isEqualTo("TX");
        assertThat(ctx.isModAsync()).isTrue();
        assertThat(ctx.getProcessType()).isEqualTo("PT");
        assertThat(ctx.getPath()).isEqualTo("/api/test");
        assertThat(ctx.getStartNanos()).isEqualTo(123L);
    }

    @Test
    void equalsHashCodeAndToString_workForSameValues() {
        RequestHeadersContext left = new RequestHeadersContext();
        left.setKeyLogic("KL");
        left.setTransactionId("TX");
        left.setModAsync(true);
        left.setProcessType("PT");
        left.setPath("/api/test");
        left.setStartNanos(123L);

        RequestHeadersContext right = new RequestHeadersContext();
        right.setKeyLogic("KL");
        right.setTransactionId("TX");
        right.setModAsync(true);
        right.setProcessType("PT");
        right.setPath("/api/test");
        right.setStartNanos(123L);

        assertThat(left).isEqualTo(right);
        assertThat(left.hashCode()).isEqualTo(right.hashCode());
        assertThat(left.toString())
                .contains("keyLogic=KL")
                .contains("transactionId=TX")
                .contains("modAsync=true")
                .contains("processType=PT")
                .contains("path=/api/test")
                .contains("startNanos=123");
    }

    @Test
    void equals_returnsFalseWhenAFieldDiffers() {
        RequestHeadersContext left = new RequestHeadersContext();
        left.setKeyLogic("KL");
        left.setTransactionId("TX");
        left.setModAsync(true);
        left.setProcessType("PT");
        left.setPath("/api/test");
        left.setStartNanos(123L);

        RequestHeadersContext right = new RequestHeadersContext();
        right.setKeyLogic("KL");
        right.setTransactionId("OTHER");

        assertThat(left).isNotEqualTo(right);
    }
}
