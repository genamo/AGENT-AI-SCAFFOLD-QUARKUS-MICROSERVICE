package it.eng.snam.pmr.batchintegrazione.test.resource.internal;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.BlobUploadStatus;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileDataRequest;
import it.eng.snam.pmr.batchintegrazione.resource.internal.FileDataResource;
import it.eng.snam.pmr.batchintegrazione.service.file.data.FileDataEngine;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class FileDataResourceTest {

    @Mock
    FileDataEngine engine;

    @Mock
    Utility utility;

    @Test
    void powerUp_returnsUtilityOkResponse() {
        FileDataResource resource = new FileDataResource(engine, utility);
        FileDataRequest request = new FileDataRequest();
        BlobUploadStatus status = BlobUploadStatus.of("container", "activity/file.zip", "application/zip", "READY_TO_DOWNLOAD",
                                                      "Upload terminated successfully");
        Response expected = mock(Response.class);

        when(engine.powerUp(request)).thenReturn(status);
        when(utility.ok(status)).thenReturn(expected);

        Response actual = resource.powerUp(request);

        assertSame(expected, actual);
        verify(engine).powerUp(request);
        verify(utility).ok(status);
    }
}
