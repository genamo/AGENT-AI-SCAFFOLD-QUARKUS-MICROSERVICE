package it.eng.snam.pmr.batchintegrazionedg.service;

import java.util.Optional;

import org.jboss.logging.Logger;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.domain.IdempotenzaFlussi;
import it.eng.snam.pmr.batchintegrazionedg.domain.IdempotenzaStatus;
import it.eng.snam.pmr.batchintegrazionedg.dto.IdempotenzaRequestDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.IdempotenzaResponseDTO;
import it.eng.snam.pmr.batchintegrazionedg.repository.IdempotenzaFlussiRepository;
import it.eng.snam.pmr.batchintegrazionedg.service.abstracts.AbstractPersistenceRetryService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.PersistenceException;
import jakarta.transaction.Transactional;
import jakarta.transaction.Transactional.TxType;

@ApplicationScoped
@RunOnVirtualThread
public class IdempotenzaFlussiService
        extends AbstractPersistenceRetryService<IdempotenzaRequestDTO, IdempotenzaResponseDTO> {

    private static final Logger LOG = Logger.getLogger(IdempotenzaFlussiService.class);

    @Inject
    IdempotenzaFlussiRepository repository;

    public IdempotenzaResponseDTO start(IdempotenzaRequestDTO request) {
        return executeWithRetry(request, this::startAttempt, "START");
    }

    public IdempotenzaResponseDTO updateStatus(IdempotenzaRequestDTO request) {
        if (request.status() == null || request.status().isBlank()) {
            LOG.errorf("updateStatus chiamato senza status, transactionId=%s", request.transactionId());
            return fallbackError(request, "MISSING_STATUS");
        }
        return executeWithRetry(request, this::updateStatusAttempt, "UPDATE");
    }

    public Optional<IdempotenzaFlussi> findByTransactionId(String transactionId) {
        return repository.findByTransactionId(transactionId);
    }

    @Transactional(TxType.REQUIRES_NEW)
    protected IdempotenzaResponseDTO startAttempt(IdempotenzaRequestDTO request) {
        IdempotenzaFlussi entity = new IdempotenzaFlussi();
        entity.setTransactionId(request.transactionId());
        entity.setFlowId(request.flowId());
        entity.setKeyLogic(request.keyLogic());
        entity.setStatus(IdempotenzaStatus.IN_PROGRESS);

        repository.persistAndFlush(entity);

        return new IdempotenzaResponseDTO(
                true,
                request.transactionId(),
                IdempotenzaStatus.IN_PROGRESS.name());
    }

    @Transactional(TxType.REQUIRES_NEW)
    protected IdempotenzaResponseDTO updateStatusAttempt(IdempotenzaRequestDTO request) {
        IdempotenzaStatus newStatus = IdempotenzaStatus.valueOf(request.status());

        int updated = repository.update(
                "status = ?1, errorMessage = ?2 where transactionId = ?3",
                newStatus,
                request.errorMessage(),
                request.transactionId()
        );

        if (updated == 0) {
            LOG.errorf("Idempotenza record non trovato per updateStatus, transactionId=%s",
                    request.transactionId());
            return fallbackError(request, "NOT_FOUND_FOR_UPDATE");
        }

        return new IdempotenzaResponseDTO(false, request.transactionId(), newStatus.name());
    }

    private IdempotenzaResponseDTO handleDuplicate(IdempotenzaRequestDTO request, PersistenceException e) {
        try {
            return repository.findByTransactionId(request.transactionId())
                    .map(existing -> new IdempotenzaResponseDTO(
                            false,
                            request.transactionId(),
                            existing.getStatus().name()))
                    .orElseGet(() -> {
                        LOG.warnf(e,
                                "Duplicate rilevato ma record non trovato subito dopo, transactionId=%s",
                                request.transactionId());
                        return fallbackError(request, "DUPLICATE_BUT_NOT_FOUND");
                    });

        } catch (Exception readEx) {
            LOG.errorf(readEx, "Errore in lettura dopo duplicate, transactionId=%s",
                    request.transactionId());
            return fallbackError(request, "ERROR_READ_AFTER_DUPLICATE");
        }
    }

    @Override
    protected Logger logger() {
        return LOG;
    }

    @Override
    protected String transactionIdOf(IdempotenzaRequestDTO request) {
        return request == null ? null : request.transactionId();
    }

    @Override
    protected IdempotenzaResponseDTO fallbackError(IdempotenzaRequestDTO request, String reason) {
        return new IdempotenzaResponseDTO(
                false,
                request == null ? null : request.transactionId(),
                "ERROR_" + reason
        );
    }

    @Override
    protected Optional<IdempotenzaResponseDTO> handlePersistenceException(
            IdempotenzaRequestDTO request,
            PersistenceException e) {

        if (!isDuplicateKey(e)) {
            return Optional.empty();
        }

        return Optional.of(handleDuplicate(request, e));
    }
}
