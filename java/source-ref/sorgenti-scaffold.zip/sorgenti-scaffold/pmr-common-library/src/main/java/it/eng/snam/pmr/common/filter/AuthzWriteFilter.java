package it.eng.snam.pmr.common.filter;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import it.eng.snam.pmr.common.annotation.AuthzWrite;
import it.eng.snam.pmr.common.annotation.UserType;
import it.eng.snam.pmr.common.cache.AuthzAnnotationCache;
import it.eng.snam.pmr.common.resolver.MinimalContextResolver;
import it.eng.snam.pmr.common.service.AuthzService;
import it.eng.snam.pmr.common.service.RemiConeValidationService;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.ext.Provider;

@Provider
@AuthzWrite
@Singleton
@Priority(Priorities.AUTHORIZATION)
public class AuthzWriteFilter implements ContainerRequestFilter {

    private static final Logger LOG = Logger.getLogger(AuthzWriteFilter.class);

    @Context
    ResourceInfo resourceInfo;

    @Inject
    AuthzService authzService;

    @ConfigProperty(name = "security.enabled", defaultValue = "true")
    boolean securityEnabled;

    @Override
    public void filter(ContainerRequestContext req) {

        LOG.infof("AuthzWriteFilter HIT — method=%s path=%s auth=%s",
                req.getMethod(),
                req.getUriInfo().getRequestUri(),
                req.getHeaderString("Authorization") != null ? "PRESENT" : "MISSING");

        // ✅ security off
        if (!securityEnabled) {
            LOG.debug("Security disabled -> skip AuthzWriteFilter");
            return;
        }

        // ✅ safety check
        if (resourceInfo == null || resourceInfo.getResourceMethod() == null) {
            LOG.warn("ResourceInfo not available -> skip AuthzWriteFilter");
            return;
        }

        // ✅ recupero annotation da cache
        AuthzWrite annotation = AuthzAnnotationCache.getAuthzWrite(resourceInfo);

        if (annotation == null) {
            return; // nessuna annotation -> skip
        }

        // ✅ recupero USER_TYPE
        UserType userType = annotation.userType();

        // ✅ costruzione context
        String context = MinimalContextResolver.build(
                resourceInfo.getResourceClass(),
                resourceInfo.getResourceMethod()
        );

        if (context == null || context.isBlank()) {
            LOG.warn("Context blank -> skip AuthzWriteFilter");
            return;
        }

        LOG.debugf("AuthzWriteFilter invoked -> %s#%s context=%s userType=%s",
                resourceInfo.getResourceClass().getSimpleName(),
                resourceInfo.getResourceMethod().getName(),
                context,
                userType
        );

        // ✅ chiamata service
        authzService.assertAuthorized(
                context,
                AuthzService.Permit.WRITE,
                userType
        );

        // ✅ propaga UserType per RemiConeCheckFilter (e altri filtri downstream)
        req.setProperty(RemiConeValidationService.PMR_USER_TYPE_PROP, userType.name());
    }
}