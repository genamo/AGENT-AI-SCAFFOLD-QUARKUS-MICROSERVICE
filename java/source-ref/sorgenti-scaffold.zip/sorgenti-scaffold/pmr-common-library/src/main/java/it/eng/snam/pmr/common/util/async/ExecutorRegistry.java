package it.eng.snam.pmr.common.util.async;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class ExecutorRegistry {

    private final String EMPTY_REGISTRY_MESSAGE = "ExecutorRegistry is empty";
    private final Set<Executor> REGISTERED_EXECUTORS = ConcurrentHashMap.newKeySet();

    public List<Executor> getExecutorRegistry() {
        if (REGISTERED_EXECUTORS.isEmpty())
            log.warn(EMPTY_REGISTRY_MESSAGE);

        return List.copyOf(REGISTERED_EXECUTORS);
    }

    public void register(Executor executor) {
        if (!REGISTERED_EXECUTORS.add(requireExecutor(executor)))
            log.warn("Executor already registered: {}", executor);
    }

    public void unregister(Executor executor) {
        if (!REGISTERED_EXECUTORS.remove(requireExecutor(executor)))
            log.warn("Executor not registered: {}", executor);
    }

    public boolean exists(Executor executor) {
        return REGISTERED_EXECUTORS.contains(requireExecutor(executor));
    }

    private Executor requireExecutor(Executor executor) {
        return Objects.requireNonNull(executor, "'executor' must be valued properly.");
    }
}