package it.eng.snam.pmr.batchintegrazionedg.service.abstracts;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import it.eng.snam.pmr.batchintegrazionedg.kafka.KafkaTopic;
import it.eng.snam.pmr.batchintegrazionedg.utils.kafka.KafkaTopicCacheInitializer;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
public class KafkaTopicResolver {

    @ConfigProperty(name = "kafka-prefix.topics")
    String kafkaTopicPrefix;

    private Map<KafkaTopic, String> topicCache;

    @PostConstruct
    public void init() {
        topicCache = KafkaTopicCacheInitializer.initialize(kafkaTopicPrefix);
    }

    public String findRealTopic(KafkaTopic topic) {
        if (topic == null)
            throw new IllegalArgumentException("Invalid topic");

        String resolvedTopicName = topicCache.get(topic);
        if (StringUtils.isBlank(resolvedTopicName))
            throw new IllegalArgumentException("Unknown topic: " + topic);

        return resolvedTopicName;
    }
}
