package it.eng.snam.pmr.common.mapper;

import it.eng.snam.pmr.common.dto.UserCustomerOrganizationDTO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;

public final class UserCustomerOrganizationJdbcMapper {

    private UserCustomerOrganizationJdbcMapper() {}

    public static UserCustomerOrganizationDTO map(ResultSet rs) throws SQLException {
        return new UserCustomerOrganizationDTO(
                getLong(rs, "OrganizationId"),
                getLong(rs, "OrganizationCode"),
                rs.getString("RoleDescription"),
                getLong(rs, "FlowId"),
                getLong(rs, "EntityId"),
                toInstant(rs.getTimestamp("Datastamp")),
                rs.getString("CustomerOrganizationCode"),
                rs.getString("TelephoneNumber"),
                rs.getString("UserCode"),
                getLong(rs, "UserCustomerOrganizationId"),
                rs.getString("PositionDescription"),
                rs.getString("UserTypeDescription"),
                rs.getString("PkSource"),
                getInteger(rs, "Denominatore"),
                getInteger(rs, "Penalita"),
                rs.getString("IdErrore"),
                rs.getString("UserTypeCode"),
                rs.getString("UserDescription"),
                getInteger(rs, "CancelledFlag")
        );
    }

    private static Instant toInstant(Timestamp ts) {
        return ts == null ? null : ts.toInstant();
    }

    private static Long getLong(ResultSet rs, String col) throws SQLException {
        Object v = rs.getObject(col);
        return v == null ? null : ((Number) v).longValue();
    }

    private static Integer getInteger(ResultSet rs, String col) throws SQLException {
        Object v = rs.getObject(col);
        return v == null ? null : ((Number) v).intValue();
    }
}