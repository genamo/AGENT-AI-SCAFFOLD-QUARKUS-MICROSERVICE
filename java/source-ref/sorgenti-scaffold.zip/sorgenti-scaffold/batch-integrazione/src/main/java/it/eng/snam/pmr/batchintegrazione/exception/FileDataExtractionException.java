package it.eng.snam.pmr.batchintegrazione.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class FileDataExtractionException extends BatchIntegrazioneException {
    @Serial
    private static final long serialVersionUID = 3522327152063603001L;
}
