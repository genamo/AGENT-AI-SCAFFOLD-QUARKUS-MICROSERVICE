package it.eng.snam.pmr.common.dto.acr.addressing;

import lombok.Builder;

@Builder
public record AcrSubProfileDTO(
        String subProfileId,
        String subProfileDescription
) {}
