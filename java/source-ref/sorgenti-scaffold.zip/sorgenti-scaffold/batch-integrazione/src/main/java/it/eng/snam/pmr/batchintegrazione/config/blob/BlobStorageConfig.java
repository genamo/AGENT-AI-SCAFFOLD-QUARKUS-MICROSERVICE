package it.eng.snam.pmr.batchintegrazione.config.blob;

import com.azure.storage.blob.BlobServiceClient;

import it.eng.snam.pmr.batchintegrazione.config.properties.BlobStorageProperties;
import it.eng.snam.pmr.batchintegrazione.utils.blob.storage.BlobConnectionBuilder;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import lombok.RequiredArgsConstructor;

@ApplicationScoped
@RequiredArgsConstructor
public class BlobStorageConfig {

    private final BlobStorageProperties blobStorageProperties;

    @Produces
    @ApplicationScoped
    public BlobServiceClient blobServiceClient() {
        return BlobConnectionBuilder.init(blobStorageProperties);
    }
}
