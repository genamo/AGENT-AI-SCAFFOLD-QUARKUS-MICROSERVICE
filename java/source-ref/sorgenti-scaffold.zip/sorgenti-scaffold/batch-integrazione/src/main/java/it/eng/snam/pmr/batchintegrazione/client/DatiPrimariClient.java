package it.eng.snam.pmr.batchintegrazione.client;

import java.time.LocalDateTime;

import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.annotation.RegisterProviders;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import it.eng.snam.pmr.batchintegrazione.filter.RestClientHeadersFilter;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@RegisterRestClient(configKey = "dati-primari-client")
@RegisterProviders(value = {@RegisterProvider(RestClientHeadersFilter.class)})
public interface DatiPrimariClient {

    // ======================================================
    // QUALITA GAS GIORN
    // ======================================================

    @GET
    @Path("/dp_qualita-gas-giorn_getall")
    Response getAllQualitaGasGiorn();

    @GET
    @Path("/dp_qualita-gas-giorn_find")
    Response findQualitaGasGiornById(
            @QueryParam("codiceAop") Integer codiceAop,
            @QueryParam("dataIniPre") LocalDateTime dataIniPre);

    @POST
    @Path("/dp_qualita-gas-giorn_save")
    Response saveQualitaGasGiorn(Object dto);

    @DELETE
    @Path("/dp_qualita-gas-giorn_delete")
    Response deleteQualitaGasGiorn(
            @QueryParam("codiceAop") Integer codiceAop,
            @QueryParam("dataIniPre") LocalDateTime dataIniPre);

    @PUT
    @Path("/dp_qualita-gas-giorn_restore")
    Response restoreQualitaGasGiorn(
            @QueryParam("codiceAop") Integer codiceAop,
            @QueryParam("dataIniPre") LocalDateTime dataIniPre);

    // ======================================================
    // ANALISI QUALITA GAS GIORN
    // ======================================================

    @GET
    @Path("/dp_analisi-qualita-gas-giorn_getall")
    Response getAllAnalisiQualitaGasGiorn();

    @GET
    @Path("/dp_analisi-qualita-gas-giorn_find")
    Response findAnalisiQualitaGasGiornById(
            @QueryParam("remiAssoluto") String remiAssoluto,
            @QueryParam("dataIniAnalisi") LocalDateTime dataIniAnalisi);

    @POST
    @Path("/dp_analisi-qualita-gas-giorn_save")
    Response saveAnalisiQualitaGasGiorn(Object dto);

    @DELETE
    @Path("/dp_analisi-qualita-gas-giorn_delete")
    Response deleteAnalisiQualitaGasGiorn(
            @QueryParam("remiAssoluto") String remiAssoluto,
            @QueryParam("dataIniAnalisi") LocalDateTime dataIniAnalisi);

    @PUT
    @Path("/dp_analisi-qualita-gas-giorn_restore")
    Response restoreAnalisiQualitaGasGiorn(
            @QueryParam("remiAssoluto") String remiAssoluto,
            @QueryParam("dataIniAnalisi") LocalDateTime dataIniAnalisi);
}