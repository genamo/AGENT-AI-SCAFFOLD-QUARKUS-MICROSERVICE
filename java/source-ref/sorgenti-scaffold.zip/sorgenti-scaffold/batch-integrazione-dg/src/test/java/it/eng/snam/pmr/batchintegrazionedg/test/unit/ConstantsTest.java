package it.eng.snam.pmr.batchintegrazionedg.test.unit;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import it.eng.snam.pmr.batchintegrazionedg.utils.Constants;
import java.util.List;

class ConstantsTest {

    @Test
    void headersConstants_defined() {
        assertNotNull(Constants.Headers.TRANSACTION_ID);
        assertNotNull(Constants.Headers.KEYLOGIC);
        assertNotNull(Constants.Headers.MOD_ASYNC);
        assertNotNull(Constants.Headers.PROCESS_TYPE);
        assertNotNull(Constants.Headers.JWT);
        assertNotNull(Constants.Headers.AUTHORIZATION);
    }

    @Test
    void logParamsConstants_defined() {
        assertNotNull(Constants.LogParams.TN);
        assertNotNull(Constants.LogParams.KL);
        assertNotNull(Constants.LogParams.API);
        assertNotNull(Constants.LogParams.MK);
        assertNotNull(Constants.LogParams.PT);
    }

    @Test
    void topicConstants_defined() {
        assertNotNull(Constants.Topic.INTEGRAZIONE_FLUSSI_TOPIC);
        assertEquals("integrazioneflussi", Constants.Topic.INTEGRAZIONE_FLUSSI_TOPIC);
        
    }

    @Test
    void getAllTopicsValue_returnsBothTopics() throws Exception {
        List<String> topics = Constants.Topic.getAllTopicsValue();
        assertNotNull(topics);
        assertEquals(2, topics.size());
        assertTrue(topics.contains("integrazioneflussi"));
        
    }

    @Test
    void timestampFormat_defined() {
        assertNotNull(Constants.TIMESTAMP_FORMAT);
        assertEquals("yyyyMMddHHmmssSSS", Constants.TIMESTAMP_FORMAT);
    }

    @Test
    void msgError_defined() {
        assertNotNull(Constants.MSG_ERROR);
        assertEquals("Error", Constants.MSG_ERROR);
    }
}
