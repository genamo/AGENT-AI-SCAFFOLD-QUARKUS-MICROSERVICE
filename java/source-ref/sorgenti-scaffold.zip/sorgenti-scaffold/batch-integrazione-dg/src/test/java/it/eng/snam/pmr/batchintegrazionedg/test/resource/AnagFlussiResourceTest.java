package it.eng.snam.pmr.batchintegrazionedg.test.resource;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;

import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.TestProfile;
import it.eng.snam.pmr.batchintegrazionedg.dto.AnagFlussiDTO;
import it.eng.snam.pmr.batchintegrazionedg.service.AnagFlussiService;
import it.eng.snam.pmr.batchintegrazionedg.test.service.NoSecurityTestProfile;

@QuarkusTest
@TestProfile(NoSecurityTestProfile.class)
class AnagFlussiResourceTest {

    @InjectMock
    AnagFlussiService service;

    private AnagFlussiDTO buildDto(String flowId) {
        return new AnagFlussiDTO(
                1L,
                flowId,
                "Desc",
                "G",
                "IN",
                "N/A",
                null,
                null,
                LocalDateTime.now(),
                "SYSTEM",
                0
        );
    }

    // ====== GET ALL ======

    @Test
    void getAll_withData_returns200WithListAndHeaders() {
        when(service.getAll()).thenReturn(List.of(buildDto("FLOW-001")));

        given()
        .when()
            .get("/anag-flussi/")
        .then()
            .statusCode(200)
            .body(notNullValue())
            .header("KEY-LOGIC", notNullValue())
            .header("TRANSACTION-ID", notNullValue())
            .header("MOD-ASYNC", notNullValue())
            .header("PROCESS-TYPE", notNullValue());
    }

    @Test
    void getAll_emptyList_returns200AndHeaders() {
        when(service.getAll()).thenReturn(List.of());

        given()
        .when()
            .get("/anag-flussi/")
        .then()
            .statusCode(200)
            .header("KEY-LOGIC", notNullValue())
            .header("TRANSACTION-ID", notNullValue())
            .header("MOD-ASYNC", notNullValue())
            .header("PROCESS-TYPE", notNullValue());
    }

    // ====== SEARCH ======

    @Test
    void findByFlowId_found_returns200AndHeaders() {
        when(service.findByFlowId("FLOW-001"))
            .thenReturn(buildDto("FLOW-001"));

        given()
        .queryParam("flowId", "FLOW-001")
        .when()
            .get("/anag-flussi/search")
        .then()
            .statusCode(200)
            .header("KEY-LOGIC", notNullValue())
            .header("TRANSACTION-ID", notNullValue())
            .header("MOD-ASYNC", notNullValue())
            .header("PROCESS-TYPE", notNullValue());
    }

    @Test
    void findByFlowId_notFound_returns404AndHeaders() {
        when(service.findByFlowId("UNKNOWN")).thenReturn(null);

        given()
        .queryParam("flowId", "UNKNOWN")
        .when()
            .get("/anag-flussi/search")
        .then()
            .statusCode(404)
            .header("KEY-LOGIC", notNullValue())
            .header("TRANSACTION-ID", notNullValue())
            .header("MOD-ASYNC", notNullValue())
            .header("PROCESS-TYPE", notNullValue());
    }

    @Test
    void findByFlowId_missingParam_returns400AndHeaders() {
        given()
        .when()
            .get("/anag-flussi/search")
        .then()
            .statusCode(400)
            .header("KEY-LOGIC", notNullValue())
            .header("TRANSACTION-ID", notNullValue())
            .header("MOD-ASYNC", notNullValue())
            .header("PROCESS-TYPE", notNullValue());
    }

    @Test
    void findByFlowId_blankParam_returns400AndHeaders() {
        given()
        .queryParam("flowId", "   ")
        .when()
            .get("/anag-flussi/search")
        .then()
            .statusCode(400)
            .header("KEY-LOGIC", notNullValue())
            .header("TRANSACTION-ID", notNullValue())
            .header("MOD-ASYNC", notNullValue())
            .header("PROCESS-TYPE", notNullValue());
    }
}
