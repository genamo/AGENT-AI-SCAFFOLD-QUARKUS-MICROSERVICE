package it.eng.snam.pmr.common.annotation;

import jakarta.ws.rs.NameBinding;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@NameBinding
@Retention(RUNTIME)
@Target({TYPE, METHOD})
public @interface RemiConeCheck {

    Mode mode() default Mode.REQUEST;

    String singleField() default "remiAssoluto";

    String listField() default "remiAssoluti";

    String queryParam() default "remiAssoluto";

    String queryListParam() default "remiAssoluti";

    String responseField() default "remiAssoluto";

    String[] moduleCodes() default {};

    enum Mode {
        REQUEST,
        RESPONSE
    }
}
