package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AnagRaggruppamentiDto(
        String codiceRaggrRemi,
        String descrizioneRaggrRemi,
        String biometano,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {}