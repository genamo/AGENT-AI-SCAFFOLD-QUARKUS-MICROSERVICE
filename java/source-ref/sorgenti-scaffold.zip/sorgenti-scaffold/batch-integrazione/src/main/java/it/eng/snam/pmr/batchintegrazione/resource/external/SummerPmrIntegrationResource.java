package it.eng.snam.pmr.batchintegrazione.resource.external;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.dto.external.AssoMailRemiFilter;
import it.eng.snam.pmr.batchintegrazione.dto.external.MailMonitoraggioVerbaliMisuraFilter;
import it.eng.snam.pmr.batchintegrazione.dto.external.VerbaliMisuraFilter;
import it.eng.snam.pmr.batchintegrazione.service.external.SummerPmrIntegrationService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import it.eng.snam.pmr.common.annotation.AuthzRead;
import it.eng.snam.pmr.common.annotation.LogPmr;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;

@LogPmr
@Path("/")
@RunOnVirtualThread
@RequiredArgsConstructor
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SummerPmrIntegrationResource {

    private final SummerPmrIntegrationService service;
    private final Utility utility;

    @GET
    @AuthzRead
    @Path("/bi_monitoraggio-riepilogo-tabellari_cerca")
    public Response filteredSearch(@BeanParam AssoMailRemiFilter filter) {
        return utility.okOrEmpty(service.filteredSearch(filter));
    }

    @GET
    @AuthzRead
    @Path("/bi_monitoraggio-riepilogo-tabellari_cerca-remi-associati")
    public Response findRemiByIdMail(@QueryParam("idMail") Long idMail) {
        return utility.okOrEmpty(service.findRemiByIdMail(idMail));
    }

    @GET
    @AuthzRead
    @Path("/bi_monitoraggio-verbali-misura_cerca")
    public Response filteredSearch(@BeanParam MailMonitoraggioVerbaliMisuraFilter filter) {
        return utility.okOrEmpty(service.filteredSearch(filter));
    }

    @GET
    @AuthzRead
    @Path("/bi_verbali-misura_cerca")
    public Response filteredSearch(@BeanParam VerbaliMisuraFilter filter) {
        return utility.okOrEmpty(service.filteredSearch(filter));
    }
}
