package it.eng.snam.pmr.batchintegrazionedg.dto;

import java.time.LocalDateTime;

public record AnagFlussiDTO(
    Long id,
    String flowId,
    String descFlow,
    String granularita,
    String verso,
    String processType,
    String sender,
    String receiver,
    LocalDateTime actionDate,
    String userAction,
    Integer isDeleted
) {}
