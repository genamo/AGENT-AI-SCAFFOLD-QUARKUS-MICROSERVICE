package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.client.DatiFiscaliClient;
import it.eng.snam.pmr.batchintegrazione.dto.datifiscali.VerbaliMisuraDto;
import it.eng.snam.pmr.batchintegrazione.dto.datifiscali.VerbaliMisuraGiornDto;
import it.eng.snam.pmr.batchintegrazione.dto.datifiscali.VerbaliMisuraGiornSearchDto;
import it.eng.snam.pmr.batchintegrazione.dto.datifiscali.VerbaliMisuraSearchDto;
import it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration.DateRiepiloghiDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.DatiFiscaliService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.B2BTokenUtils;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class DatiFiscaliServiceTest {

    @Mock
    DatiFiscaliClient datiFiscaliClient;

    @Mock
    ObjectMapper objectMapper;

    @Mock
    RequestHeadersContext headersCtx;

    @Mock
    B2BTokenUtils tokenUtil;

    @InjectMocks
    DatiFiscaliService service;

    private void injectAbstractField(String fieldName, Object value) throws Exception {
        Field field = AbstractService.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(service, value);
    }

    private Response mockResp(int status) {
        Response r = mock(Response.class);
        when(r.getStatus()).thenReturn(status);
        return r;
    }

    private void mockHeadersForRemoteError() {
        when(headersCtx.getKeyLogic()).thenReturn("kl");
        when(headersCtx.getTransactionId()).thenReturn("tx");
        when(headersCtx.getProcessType()).thenReturn("PT");
    }

    private static final LocalDateTime TS1 = LocalDateTime.of(2024, 1, 1, 0, 0);
    private static final LocalDateTime TS2 = LocalDateTime.of(2024, 1, 2, 0, 0);

    private static VerbaliMisuraSearchDto verbaleSearchDto() {
        return new VerbaliMisuraSearchDto("REMI001", TS1);
    }

    private static VerbaliMisuraDto verbaleDto() {
        return new VerbaliMisuraDto(
                "REMI001",
                TS1,
                1L,
                "A",
                "V",
                BigDecimal.ONE,
                BigDecimal.TEN,
                "SMC",
                BigDecimal.valueOf(2),
                TS1,
                TS2,
                BigDecimal.valueOf(3),
                TS2,
                TS2,
                20240101,
                BigDecimal.valueOf(4),
                BigDecimal.valueOf(5),
                (short) 1,
                "A",
                BigDecimal.valueOf(6),
                BigDecimal.valueOf(7),
                "KJ",
                BigDecimal.valueOf(8),
                "PCS",
                TS2,
                "user",
                BigDecimal.valueOf(9),
                "N",
                BigDecimal.valueOf(10),
                "KWH",
                BigDecimal.valueOf(11),
                "PCSKWH",
                "Y",
                "INSERT",
                TS2,
                0);
    }

    private static VerbaliMisuraGiornSearchDto verbaleGiornSearchDto() {
        return new VerbaliMisuraGiornSearchDto("REMI001", TS1, TS2);
    }

    private static VerbaliMisuraGiornDto verbaleGiornDto() {
        return new VerbaliMisuraGiornDto(
                "REMI001",
                TS1,
                TS2,
                BigDecimal.ONE,
                "SMC",
                BigDecimal.TEN,
                BigDecimal.valueOf(20),
                "KWH",
                BigDecimal.valueOf(30),
                "PCS",
                "A",
                TS2,
                "user",
                BigDecimal.valueOf(40),
                "KWH",
                BigDecimal.valueOf(50),
                "PCS",
                BigDecimal.valueOf(60),
                "Q",
                "INSERT",
                TS2,
                0);
    }

    private static DateRiepiloghiDTO dateRiepiloghiDto() {
        return new DateRiepiloghiDTO();
    }

    @org.junit.jupiter.api.BeforeEach
    void setUp() throws Exception {
        injectAbstractField("headersCtx", headersCtx);
        injectAbstractField("objectMapper", objectMapper);
    }

    // =========================================================================
    // MONITORING INTEGRATION
    // =========================================================================

    @Test
    void saveDateRiepiloghi_200_returnsDto() {
        DateRiepiloghiDTO dto = dateRiepiloghiDto();
        Response resp = mockResp(200);

        when(resp.readEntity(DateRiepiloghiDTO.class)).thenReturn(dto);
        when(datiFiscaliClient.saveDateRiepiloghi(dto)).thenReturn(resp);

        assertSame(dto, service.saveDateRiepiloghi(dto));
    }

    @Test
    void saveDateRiepiloghi_201_returnsDto() {
        DateRiepiloghiDTO dto = dateRiepiloghiDto();
        Response resp = mockResp(201);

        when(resp.readEntity(DateRiepiloghiDTO.class)).thenReturn(dto);
        when(datiFiscaliClient.saveDateRiepiloghi(dto)).thenReturn(resp);

        assertSame(dto, service.saveDateRiepiloghi(dto));
    }

    @Test
    void saveDateRiepiloghi_400_throwsIllegalArgument() {
        DateRiepiloghiDTO dto = dateRiepiloghiDto();
        Response resp = mockResp(400);

        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.saveDateRiepiloghi(dto)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.saveDateRiepiloghi(dto));
    }

    @Test
    void saveDateRiepiloghi_500_throwsRemoteCallException() {
        DateRiepiloghiDTO dto = dateRiepiloghiDto();
        Response resp = mockResp(500);

        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.saveDateRiepiloghi(dto)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.saveDateRiepiloghi(dto));
    }

    // =========================================================================
    // VERBALI MISURA
    // =========================================================================

    @Test
    void getAllVerbaliMisura_204_returnsEmpty() {
        Response resp = mockResp(204);
        when(datiFiscaliClient.getAllVerbaliMisura()).thenReturn(resp);

        assertTrue(service.getAllVerbaliMisura().isEmpty());
    }

    @Test
    void getAllVerbaliMisura_200_emptyJson_returnsEmpty() {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("");
        when(datiFiscaliClient.getAllVerbaliMisura()).thenReturn(resp);

        assertTrue(service.getAllVerbaliMisura().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAllVerbaliMisura_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(datiFiscaliClient.getAllVerbaliMisura()).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class)))
                .thenReturn(List.of(verbaleSearchDto()));

        List<VerbaliMisuraSearchDto> result = service.getAllVerbaliMisura();

        assertEquals(1, result.size());
        assertEquals("REMI001", result.get(0).remiAssoluto());
    }

    @Test
    void getAllVerbaliMisura_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.getAllVerbaliMisura()).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.getAllVerbaliMisura());
    }

    @Test
    void getAllVerbaliMisura_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.getAllVerbaliMisura()).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.getAllVerbaliMisura());
    }

    @Test
    void findVerbaleMisuraById_404_returnsEmpty() {
        Response resp = mockResp(404);
        when(datiFiscaliClient.findVerbaleMisuraById("REMI001", TS1)).thenReturn(resp);

        assertTrue(service.findVerbaleMisuraById("REMI001", TS1).isEmpty());
    }

    @Test
    void findVerbaleMisuraById_204_returnsEmpty() {
        Response resp = mockResp(204);
        when(datiFiscaliClient.findVerbaleMisuraById("REMI001", TS1)).thenReturn(resp);

        assertTrue(service.findVerbaleMisuraById("REMI001", TS1).isEmpty());
    }

    @Test
    void findVerbaleMisuraById_200_returnsDto() {
        VerbaliMisuraSearchDto dto = verbaleSearchDto();
        Response resp = mockResp(200);

        when(resp.readEntity(VerbaliMisuraSearchDto.class)).thenReturn(dto);
        when(datiFiscaliClient.findVerbaleMisuraById("REMI001", TS1)).thenReturn(resp);

        Optional<VerbaliMisuraSearchDto> result = service.findVerbaleMisuraById("REMI001", TS1);

        assertTrue(result.isPresent());
        assertEquals("REMI001", result.get().remiAssoluto());
    }

    @Test
    void findVerbaleMisuraById_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.findVerbaleMisuraById("REMI001", TS1)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.findVerbaleMisuraById("REMI001", TS1));
    }

    @Test
    void findVerbaleMisuraById_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.findVerbaleMisuraById("REMI001", TS1)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.findVerbaleMisuraById("REMI001", TS1));
    }

    @Test
    void saveVerbaleMisura_200_returnsDto() {
        VerbaliMisuraDto dto = verbaleDto();
        Response resp = mockResp(200);

        when(resp.readEntity(VerbaliMisuraDto.class)).thenReturn(dto);
        when(datiFiscaliClient.saveVerbaleMisura(dto)).thenReturn(resp);

        assertSame(dto, service.saveVerbaleMisura(dto));
    }

    @Test
    void saveVerbaleMisura_201_returnsDto() {
        VerbaliMisuraDto dto = verbaleDto();
        Response resp = mockResp(201);

        when(resp.readEntity(VerbaliMisuraDto.class)).thenReturn(dto);
        when(datiFiscaliClient.saveVerbaleMisura(dto)).thenReturn(resp);

        assertSame(dto, service.saveVerbaleMisura(dto));
    }

    @Test
    void saveVerbaleMisura_400_throwsIllegalArgument() {
        VerbaliMisuraDto dto = verbaleDto();
        Response resp = mockResp(400);

        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.saveVerbaleMisura(dto)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.saveVerbaleMisura(dto));
    }

    @Test
    void saveVerbaleMisura_500_throwsRemoteCallException() {
        VerbaliMisuraDto dto = verbaleDto();
        Response resp = mockResp(500);

        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.saveVerbaleMisura(dto)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.saveVerbaleMisura(dto));
    }

    @Test
    void deleteVerbaleMisura_200_returnsDto() {
        VerbaliMisuraDto dto = verbaleDto();
        Response resp = mockResp(200);

        when(resp.readEntity(VerbaliMisuraDto.class)).thenReturn(dto);
        when(datiFiscaliClient.deleteVerbaleMisura("REMI001", TS1)).thenReturn(resp);

        assertSame(dto, service.deleteVerbaleMisura("REMI001", TS1));
    }

    @Test
    void deleteVerbaleMisura_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.deleteVerbaleMisura("REMI001", TS1)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.deleteVerbaleMisura("REMI001", TS1));
    }

    @Test
    void deleteVerbaleMisura_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.deleteVerbaleMisura("REMI001", TS1)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.deleteVerbaleMisura("REMI001", TS1));
    }

    @Test
    void restoreVerbaleMisura_200_returnsDto() {
        VerbaliMisuraDto dto = verbaleDto();
        Response resp = mockResp(200);

        when(resp.readEntity(VerbaliMisuraDto.class)).thenReturn(dto);
        when(datiFiscaliClient.restoreVerbaleMisura("REMI001", TS1)).thenReturn(resp);

        assertSame(dto, service.restoreVerbaleMisura("REMI001", TS1));
    }

    @Test
    void restoreVerbaleMisura_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.restoreVerbaleMisura("REMI001", TS1)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.restoreVerbaleMisura("REMI001", TS1));
    }

    // =========================================================================
    // VERBALI MISURA GIORN
    // =========================================================================

    @Test
    void getAllVerbaliMisuraGiorn_204_returnsEmpty() {
        Response resp = mockResp(204);
        when(datiFiscaliClient.getAllVerbaliMisuraGiorn()).thenReturn(resp);

        assertTrue(service.getAllVerbaliMisuraGiorn().isEmpty());
    }

    @Test
    void getAllVerbaliMisuraGiorn_200_emptyJson_returnsEmpty() {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("");
        when(datiFiscaliClient.getAllVerbaliMisuraGiorn()).thenReturn(resp);

        assertTrue(service.getAllVerbaliMisuraGiorn().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAllVerbaliMisuraGiorn_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(datiFiscaliClient.getAllVerbaliMisuraGiorn()).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class)))
                .thenReturn(List.of(verbaleGiornSearchDto()));

        List<VerbaliMisuraGiornSearchDto> result = service.getAllVerbaliMisuraGiorn();

        assertEquals(1, result.size());
        assertEquals("REMI001", result.get(0).remiAssoluto());
    }

    @Test
    void getAllVerbaliMisuraGiorn_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.getAllVerbaliMisuraGiorn()).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.getAllVerbaliMisuraGiorn());
    }

    @Test
    void getAllVerbaliMisuraGiorn_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.getAllVerbaliMisuraGiorn()).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.getAllVerbaliMisuraGiorn());
    }

    @Test
    void findVerbaleMisuraGiornById_404_returnsEmpty() {
        Response resp = mockResp(404);
        when(datiFiscaliClient.findVerbaleMisuraGiornById("REMI001", TS1, TS2)).thenReturn(resp);

        assertTrue(service.findVerbaleMisuraGiornById("REMI001", TS1, TS2).isEmpty());
    }

    @Test
    void findVerbaleMisuraGiornById_204_returnsEmpty() {
        Response resp = mockResp(204);
        when(datiFiscaliClient.findVerbaleMisuraGiornById("REMI001", TS1, TS2)).thenReturn(resp);

        assertTrue(service.findVerbaleMisuraGiornById("REMI001", TS1, TS2).isEmpty());
    }

    @Test
    void findVerbaleMisuraGiornById_200_returnsDto() {
        VerbaliMisuraGiornSearchDto dto = verbaleGiornSearchDto();
        Response resp = mockResp(200);

        when(resp.readEntity(VerbaliMisuraGiornSearchDto.class)).thenReturn(dto);
        when(datiFiscaliClient.findVerbaleMisuraGiornById("REMI001", TS1, TS2)).thenReturn(resp);

        Optional<VerbaliMisuraGiornSearchDto> result =
                service.findVerbaleMisuraGiornById("REMI001", TS1, TS2);

        assertTrue(result.isPresent());
        assertEquals("REMI001", result.get().remiAssoluto());
    }

    @Test
    void findVerbaleMisuraGiornById_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.findVerbaleMisuraGiornById("REMI001", TS1, TS2)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class,
                () -> service.findVerbaleMisuraGiornById("REMI001", TS1, TS2));
    }

    @Test
    void findVerbaleMisuraGiornById_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.findVerbaleMisuraGiornById("REMI001", TS1, TS2)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class,
                () -> service.findVerbaleMisuraGiornById("REMI001", TS1, TS2));
    }

    @Test
    void saveVerbaleMisuraGiorn_200_returnsDto() {
        VerbaliMisuraGiornDto dto = verbaleGiornDto();
        Response resp = mockResp(200);

        when(resp.readEntity(VerbaliMisuraGiornDto.class)).thenReturn(dto);
        when(datiFiscaliClient.saveVerbaleMisuraGiorn(dto)).thenReturn(resp);

        assertSame(dto, service.saveVerbaleMisuraGiorn(dto));
    }

    @Test
    void saveVerbaleMisuraGiorn_201_returnsDto() {
        VerbaliMisuraGiornDto dto = verbaleGiornDto();
        Response resp = mockResp(201);

        when(resp.readEntity(VerbaliMisuraGiornDto.class)).thenReturn(dto);
        when(datiFiscaliClient.saveVerbaleMisuraGiorn(dto)).thenReturn(resp);

        assertSame(dto, service.saveVerbaleMisuraGiorn(dto));
    }

    @Test
    void saveVerbaleMisuraGiorn_400_throwsIllegalArgument() {
        VerbaliMisuraGiornDto dto = verbaleGiornDto();
        Response resp = mockResp(400);

        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.saveVerbaleMisuraGiorn(dto)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.saveVerbaleMisuraGiorn(dto));
    }

    @Test
    void saveVerbaleMisuraGiorn_500_throwsRemoteCallException() {
        VerbaliMisuraGiornDto dto = verbaleGiornDto();
        Response resp = mockResp(500);

        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.saveVerbaleMisuraGiorn(dto)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.saveVerbaleMisuraGiorn(dto));
    }

    @Test
    void deleteVerbaleMisuraGiorn_200_returnsDto() {
        VerbaliMisuraGiornDto dto = verbaleGiornDto();
        Response resp = mockResp(200);

        when(resp.readEntity(VerbaliMisuraGiornDto.class)).thenReturn(dto);
        when(datiFiscaliClient.deleteVerbaleMisuraGiorn("REMI001", TS1, TS2)).thenReturn(resp);

        assertSame(dto, service.deleteVerbaleMisuraGiorn("REMI001", TS1, TS2));
    }

    @Test
    void deleteVerbaleMisuraGiorn_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.deleteVerbaleMisuraGiorn("REMI001", TS1, TS2)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class,
                () -> service.deleteVerbaleMisuraGiorn("REMI001", TS1, TS2));
    }

    @Test
    void deleteVerbaleMisuraGiorn_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.deleteVerbaleMisuraGiorn("REMI001", TS1, TS2)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class,
                () -> service.deleteVerbaleMisuraGiorn("REMI001", TS1, TS2));
    }

    @Test
    void restoreVerbaleMisuraGiorn_200_returnsDto() {
        VerbaliMisuraGiornDto dto = verbaleGiornDto();
        Response resp = mockResp(200);

        when(resp.readEntity(VerbaliMisuraGiornDto.class)).thenReturn(dto);
        when(datiFiscaliClient.restoreVerbaleMisuraGiorn("REMI001", TS1, TS2)).thenReturn(resp);

        assertSame(dto, service.restoreVerbaleMisuraGiorn("REMI001", TS1, TS2));
    }

    @Test
    void restoreVerbaleMisuraGiorn_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiFiscaliClient.restoreVerbaleMisuraGiorn("REMI001", TS1, TS2)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class,
                () -> service.restoreVerbaleMisuraGiorn("REMI001", TS1, TS2));
    }
}
