package it.eng.snam.pmr.batchintegrazione.test.service.file.data;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.Executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.BlobUploadStatus;
import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.FileDataContext;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileDataRequest;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileReference;
import it.eng.snam.pmr.batchintegrazione.service.blob.storage.BlobStorageUploader;
import it.eng.snam.pmr.batchintegrazione.service.file.data.FileDataEngine;
import it.eng.snam.pmr.batchintegrazione.service.file.data.FileDataTransformer;

@ExtendWith(MockitoExtension.class)
class FileDataEngineTest {

    @Mock
    FileDataTransformer transformer;
    @Mock
    BlobStorageUploader uploader;

    private final Executor executor = Runnable::run;

    private FileDataEngine engine;

    @BeforeEach
    void setUp() {
        engine = new FileDataEngine(executor, transformer, uploader);
    }

    @Test
    void powerUp_validRequest_transformsUploadsAndReturnsUploaderStatus() {
        FileDataRequest request = validRequest();
        FileDataContext context = new FileDataContext("executioner", "activity", "file.zip", "application/zip", null,
                                                      null, null);
        BlobUploadStatus expected = BlobUploadStatus.of("container", "activity/file.zip", "application/zip", "READY_TO_DOWNLOAD",
                                                        "Upload terminated successfully");

        when(transformer.transform(request)).thenReturn(context);
        when(uploader.uploadAndVerify(context)).thenReturn(expected);

        BlobUploadStatus actual = engine.powerUp(request);

        assertSame(expected, actual);
        verify(transformer).transform(request);
        verify(uploader).uploadAndVerify(context);
    }

    @Test
    void powerUp_uploaderFails_returnsExceptionStatusUsingUnwrappedCause() {
        FileDataRequest request = validRequest();
        FileDataContext context = new FileDataContext("executioner", "activity", "file.zip", "application/zip", null,
                                                      null, null);

        when(transformer.transform(request)).thenReturn(context);
        when(uploader.uploadAndVerify(context)).thenThrow(new IllegalStateException("azure ko"));

        BlobUploadStatus actual = engine.powerUp(request);

        assertEquals("", actual.getBlobPath());
        assertEquals("", actual.getBlobContentType());
        assertEquals("EXCEPTION", actual.getStatus());
        assertTrue(actual.getStatusMessage().contains("azure ko"));
    }

    @Test
    void powerUp_blankExecutioner_returnsExceptionStatusAndDoesNotCallTransformer() {
        FileDataRequest request = validRequest();
        request.setExecutioner("  ");

        BlobUploadStatus actual = engine.powerUp(request);

        assertEquals("EXCEPTION", actual.getStatus());
        assertTrue(actual.getStatusMessage().contains("executioner"));
        verify(transformer, never()).transform(any());
        verify(uploader, never()).uploadAndVerify(any());
    }

    @Test
    void powerUp_blankActivity_returnsExceptionStatusAndDoesNotCallTransformer() {
        FileDataRequest request = validRequest();
        request.setActivity(" ");

        BlobUploadStatus actual = engine.powerUp(request);

        assertEquals("EXCEPTION", actual.getStatus());
        assertTrue(actual.getStatusMessage().contains("activity"));
        verify(transformer, never()).transform(any());
    }

    @Test
    void powerUp_emptyFileReferences_returnsExceptionStatusAndDoesNotCallTransformer() {
        FileDataRequest request = validRequest();
        request.setFileReferences(List.of());

        BlobUploadStatus actual = engine.powerUp(request);

        assertEquals("EXCEPTION", actual.getStatus());
        assertTrue(actual.getStatusMessage().contains("fileReferences"));
        verify(transformer, never()).transform(any());
    }

    @Test
    void powerUp_blankSourceSystem_returnsExceptionStatusAndDoesNotCallTransformer() {
        FileDataRequest request = validRequest();
        request.setSourceSystem("\t");

        BlobUploadStatus actual = engine.powerUp(request);

        assertEquals("EXCEPTION", actual.getStatus());
        assertTrue(actual.getStatusMessage().contains("sourceSystem"));
        verify(transformer, never()).transform(any());
    }

    @Test
    void constructorInjectionHasDirectExecutor() {
        assertNotNull(engine);
    }

    private static FileDataRequest validRequest() {
        FileDataRequest request = new FileDataRequest();
        request.setExecutioner("Executioner 01");
        request.setActivity("Monthly Closure");
        request.setSourceSystem("PMR");
        request.setFileReferences(List.of(new FileReference("a.txt", "alpha".getBytes(StandardCharsets.UTF_8)),
                                          new FileReference("b.txt", "beta".getBytes(StandardCharsets.UTF_8))));
        return request;
    }
}
