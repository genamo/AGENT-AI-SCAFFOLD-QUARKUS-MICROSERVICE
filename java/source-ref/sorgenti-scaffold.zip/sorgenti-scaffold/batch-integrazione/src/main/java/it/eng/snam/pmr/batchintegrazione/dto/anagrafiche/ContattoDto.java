package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record ContattoDto(
        Integer idContatto,
        Boolean attivo,
        String centro,
        String cognome,
        String denominazione,
        String idAssoRuolo,
        String nome,
        String note,
        String proprietario,
        String ruolo,
        String userId,
        Boolean modificabile,
        String ruoloDms,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {}