package it.eng.snam.pmr.common.util;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class B2BTokenUtils {

    private static final Logger LOG = Logger.getLogger(B2BTokenUtils.class);
    private static final String HMAC_ALGO = "HmacSHA256";

    @ConfigProperty(name = "security.b2b.secret")
    String secret;

    @ConfigProperty(name = "security.b2b.token-ttl-seconds", defaultValue = "300")
    long ttlSeconds;

    // =========================================================
    // GENERAZIONE
    // =========================================================
    public String generateToken() {
        long expiresAt = Instant.now().getEpochSecond() + ttlSeconds;

        String payload = String.valueOf(expiresAt);
        String signature = sign(payload);

        String token = payload + "." + signature;

        // encode finale
        String encoded = Base64.getUrlEncoder()
                .withoutPadding()
                .encodeToString(token.getBytes(StandardCharsets.UTF_8));

        LOG.infof("Token B2B generato (exp=%d)", expiresAt);

        return encoded;
    }

    public String generateSuperUserToken() {
        return "Bearer " + generateToken();
    }

    // =========================================================
    // VALIDAZIONE
    // =========================================================
    public boolean isValid(String authorizationHeader) {

        try { 
        	
            String token = authorizationHeader.substring(7);

            String decoded = new String(
                    Base64.getUrlDecoder().decode(token),
                    StandardCharsets.UTF_8
            );

            String[] parts = decoded.split("\\.", 2);
            if (parts.length != 2) return false;

            String payload = parts[0];
            String signature = parts[1];

            long expiresAt = Long.parseLong(payload);
            long now = Instant.now().getEpochSecond();

            if (now > expiresAt) {
                LOG.warnf("Token B2B scaduto exp=%d now=%d", expiresAt, now);
                return false;
            }

            String expectedSignature = sign(payload);

            boolean valid = constantTimeEquals(expectedSignature, signature);

            if (!valid) {
                LOG.warn("Firma token B2B NON valida");
            }

            return valid;

        } catch (Exception e) {
            LOG.warnf("Token B2B non valido: %s", e.getMessage());
            return false;
        }
    }

    // =========================================================
    // SIGNATURE
    // =========================================================
    private String sign(String payload) {
        try {
            Mac mac = Mac.getInstance(HMAC_ALGO);
            mac.init(new SecretKeySpec(
                    secret.getBytes(StandardCharsets.UTF_8),
                    HMAC_ALGO
            ));

            byte[] raw = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));

            return Base64.getUrlEncoder()
                    .withoutPadding()
                    .encodeToString(raw);

        } catch (Exception e) {
            throw new IllegalStateException("Errore firma token B2B", e);
        }
    }

    // =========================================================
    // SICUREZZA
    // =========================================================
    private boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null || a.length() != b.length()) return false;

        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }
}
