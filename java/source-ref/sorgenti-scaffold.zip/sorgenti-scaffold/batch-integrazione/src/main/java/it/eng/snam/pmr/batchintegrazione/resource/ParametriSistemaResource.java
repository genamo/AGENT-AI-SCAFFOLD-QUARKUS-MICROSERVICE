package it.eng.snam.pmr.batchintegrazione.resource;

import java.util.List;
import java.util.function.Supplier;

import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.dto.IntegrazioneParametriSistemaDTO;
import it.eng.snam.pmr.batchintegrazione.dto.ParametriSistemaRequestSearch;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.service.ParametriService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import it.eng.snam.pmr.common.annotation.AuthzRead;
import it.eng.snam.pmr.common.annotation.LogPmr;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.response.swagger.CommonApiErrorResponses;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;

@Path("/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RunOnVirtualThread
@LogPmr
@SecurityRequirement(name = "bearerAuth")
@RequiredArgsConstructor(onConstructor_ = @Inject)
@Tag(name = "ParametriSistemaResource", description = "API per la ricerca dei parametri di sistema")
public class ParametriSistemaResource {

	private final ParametriService remoteService;
	private final Utility utility;

	@POST
	@Path("/bi_parametri-sistema_search")
	@AuthzRead
	@Operation(summary = "Ricerca parametri di sistema")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Parametri di sistema recuperati correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ParametriSistemaListGenericResponse.class)))
	public Response searchParametri(

			@RequestBody(description = "Criteri di ricerca dei parametri di sistema", required = true, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ParametriSistemaRequestSearch.class))) ParametriSistemaRequestSearch request

	) {

		if (request == null) {
			return utility.badRequest("Request body mancante o non valido");
		}

		return handle(() -> utility.okOrEmpty(remoteService.searchParametri(request)));
	}

	private Response handle(Supplier<Response> action) {
		try {
			return action.get();
		} catch (IllegalArgumentException e) {
			return utility.badRequest(e.getMessage());
		} catch (RemoteCallException e) {
			return utility.badGateway(e);
		}
	}

	@Schema(name = "ParametriSistemaListGenericResponse")
	public static class ParametriSistemaListGenericResponse extends GenericResponse<List<IntegrazioneParametriSistemaDTO>> {

		private static final long serialVersionUID = 1L;
	}
}
