package it.eng.snam.pmr.common.util.kafka.consumer;

import java.nio.charset.StandardCharsets;

import org.apache.kafka.common.header.Headers;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class UnknownMessageHandler {

    public void handle(String topic, byte[] payload, Headers headers) {
        log.warn("No specific handler found for topic: {}", topic);
        log.debug("Headers: {}", headers);
        log.debug("Payload: {}", new String(payload, StandardCharsets.UTF_8));
    }
}
