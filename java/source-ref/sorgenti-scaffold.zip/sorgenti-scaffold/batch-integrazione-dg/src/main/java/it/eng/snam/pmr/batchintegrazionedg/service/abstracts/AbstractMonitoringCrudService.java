package it.eng.snam.pmr.batchintegrazionedg.service.abstracts;

import java.util.List;
import java.util.Optional;

import org.jboss.logging.Logger;

import it.eng.snam.pmr.common.util.JsonUtils;
import jakarta.persistence.PersistenceException;

public abstract class AbstractMonitoringCrudService<DTO, ENTITY, SEARCH>
        extends AbstractPersistenceRetryService<DTO, DTO> {

    public List<DTO> getAll() {
        return toDtoList(listAllEntities());
    }

    public DTO getById(Long id) {
        return toDto(findEntityById(id));
    }

    public DTO getByTransactionId(String transactionId) {
        return findEntityByTransactionId(transactionId)
                .map(this::toDto)
                .orElse(null);
    }

    public List<DTO> getLastExecutions(int limit) {
        return toDtoList(findLastExecutionsEntities(limit));
    }

    public List<DTO> getByPeriod(Integer monthNumber, Integer dayNumber) {
        return toDtoList(findByPeriodEntities(monthNumber, dayNumber));
    }

    public List<DTO> findByCustomSearch(SEARCH search) {
        return toDtoList(findByCustomSearchEntities(search));
    }

    public DTO save(DTO dto) {
        if (dto == null) {
            logger().error("save chiamato con dto nullo");
            return fallbackError(null, "NULL_REQUEST");
        }
        return executeWithRetry(dto, this::saveAttempt, "SAVE");
    }

    protected abstract DTO saveAttempt(DTO dto);

    protected void processPayload(String payload, Class<DTO> dtoClass, String errorMessage) {
        try {
            DTO dto = JsonUtils.getObject(payload, dtoClass);
            save(dto);
        } catch (Exception ex) {
            logger().error(errorMessage + ": " + ex.getMessage(), ex);
        }
    }

    @Override
    protected Optional<DTO> handlePersistenceException(DTO request, PersistenceException e) {
        if (!isDuplicateKey(e)) {
            return Optional.empty();
        }

        String transactionId = transactionIdOf(request);

        try {
            return Optional.of(
                    findEntityByTransactionId(transactionId)
                            .map(this::toDto)
                            .orElseGet(() -> {
                                logger().warnf(
                                        e,
                                        "Duplicate rilevato ma record non trovato subito dopo, transactionId=%s",
                                        transactionId);
                                return fallbackError(request, "DUPLICATE_BUT_NOT_FOUND");
                            })
            );
        } catch (Exception readEx) {
            logger().errorf(
                    readEx,
                    "Errore in lettura dopo duplicate, transactionId=%s",
                    transactionId);
            return Optional.of(fallbackError(request, "ERROR_READ_AFTER_DUPLICATE"));
        }
    }

    protected abstract Logger logger();

    protected abstract List<ENTITY> listAllEntities();

    protected abstract ENTITY findEntityById(Long id);

    protected abstract Optional<ENTITY> findEntityByTransactionId(String transactionId);

    protected abstract List<ENTITY> findLastExecutionsEntities(int limit);

    protected abstract List<ENTITY> findByPeriodEntities(Integer monthNumber, Integer dayNumber);

    protected abstract List<ENTITY> findByCustomSearchEntities(SEARCH search);

    protected abstract List<DTO> toDtoList(List<ENTITY> entities);

    protected abstract DTO toDto(ENTITY entity);
}
