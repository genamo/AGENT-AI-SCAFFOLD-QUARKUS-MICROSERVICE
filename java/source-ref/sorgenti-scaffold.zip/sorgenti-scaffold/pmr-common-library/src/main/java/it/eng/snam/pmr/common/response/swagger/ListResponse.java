package it.eng.snam.pmr.common.response.swagger;

import java.io.Serial;
import java.util.List;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import it.eng.snam.pmr.common.response.GenericResponse;

@Schema(name = "ListResponse")
public class ListResponse<T> extends GenericResponse<List<T>> {
    @Serial
    private static final long serialVersionUID = -5729611078080810739L;
}
