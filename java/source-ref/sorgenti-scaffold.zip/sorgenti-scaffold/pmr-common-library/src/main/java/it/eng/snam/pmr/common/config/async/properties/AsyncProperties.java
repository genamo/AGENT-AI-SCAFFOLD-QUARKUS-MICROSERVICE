package it.eng.snam.pmr.common.config.async.properties;

import io.smallrye.config.ConfigMapping;

@ConfigMapping(prefix = "async.properties")
public interface AsyncProperties {

    int corePoolSize();

    int maxPoolSize();

    int queueCapacity();

    int keepAliveSeconds();

    int awaitTerminationSeconds();
}
