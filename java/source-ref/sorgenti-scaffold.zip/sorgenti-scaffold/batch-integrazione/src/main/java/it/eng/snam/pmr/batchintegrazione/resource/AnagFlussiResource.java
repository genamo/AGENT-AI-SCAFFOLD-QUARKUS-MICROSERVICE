package it.eng.snam.pmr.batchintegrazione.resource;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.dto.AnagFlussiDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.response.CustomResponse;
import it.eng.snam.pmr.batchintegrazione.service.AnagFlussiService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import it.eng.snam.pmr.common.annotation.AuthzRead;
import it.eng.snam.pmr.common.annotation.LogPmr;
import it.eng.snam.pmr.common.annotation.UserType;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.response.swagger.CommonApiErrorResponses;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;

@Path("/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RunOnVirtualThread
@LogPmr
@RequiredArgsConstructor(onConstructor_ = @Inject)
@Tag(name = "AnagFlussiResource", description = "API per la consultazione dell'anagrafica flussi")
public class AnagFlussiResource {

	private final AnagFlussiService service;
	private final Utility utility;

	@GET
	@AuthzRead(userType = UserType.INTERNAL)
	@Path("/bi_anag-flussi_getall")
	@Operation(summary = "Recupera tutti i flussi censiti")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Lista flussi recuperata correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = AnagFlussiListGenericResponse.class)))
	public Response getAll() {
		return handle(() -> utility.okOrEmpty(service.getAll()));
	}

	@GET
	@Path("/bi_anag-flussi_search")
	@AuthzRead
	@Operation(summary = "Ricerca un flusso tramite FlowId")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Flusso recuperato correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = AnagFlussiGenericResponse.class)))
	public Response findByFlowId(

			@QueryParam("flowId") @Parameter(description = "Identificativo del flusso", required = true, example = "FLOW_001", schema = @Schema(type = SchemaType.STRING)) String flowId

	) {

		Response validationError = validateFlowId(flowId);
		if (validationError != null) {
			return validationError;
		}

		return handle(() -> {
			CustomResponse<Optional<AnagFlussiDTO>> cr = service.findByFlowId(flowId);
			return utility.okOrNotFoundWithCustomMessage(cr.getResponseData(), cr.getMessage());
		});
	}

	private Response handle(Supplier<Response> action) {
		try {
			return action.get();
		} catch (IllegalArgumentException e) {
			return utility.badRequest(e.getMessage());
		} catch (RemoteCallException e) {
			return utility.badGateway(e);
		}
	}

	private Response validateFlowId(String flowId) {
		if (flowId == null || flowId.isBlank()) {
			return utility.badRequest("Il parametro flowId è obbligatorio");
		}
		return null;
	}

	@Schema(name = "AnagFlussiListGenericResponse")
	public static class AnagFlussiListGenericResponse extends GenericResponse<List<AnagFlussiDTO>> {

		private static final long serialVersionUID = 1L;
	}

	@Schema(name = "AnagFlussiGenericResponse")
	public static class AnagFlussiGenericResponse extends GenericResponse<AnagFlussiDTO> {

		private static final long serialVersionUID = 1L;
	}
}
