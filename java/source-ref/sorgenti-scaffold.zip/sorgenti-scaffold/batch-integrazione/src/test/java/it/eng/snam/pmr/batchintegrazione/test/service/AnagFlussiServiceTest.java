package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.jboss.resteasy.reactive.ClientWebApplicationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.AnagFlussiDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.response.CustomResponse;
import it.eng.snam.pmr.batchintegrazione.service.AnagFlussiService;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class AnagFlussiServiceTest {

    @Mock BatchIntegrazioneDgClient client;
    @Mock ObjectMapper objectMapper;
    @Mock RequestHeadersContext headersCtx;
    @InjectMocks AnagFlussiService service;

    // ---- getAll ----

    @Test
    void getAll_204_returnsEmptyList() {
        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(204);
        when(client.getAll()).thenReturn(resp);

        List<AnagFlussiDTO> result = service.getAll();
        assertTrue(result.isEmpty());
    }

    @Test
    void getAll_200_emptyBody_returnsEmptyList() {
        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(200);
        when(resp.readEntity(String.class)).thenReturn("");
        when(client.getAll()).thenReturn(resp);

        List<AnagFlussiDTO> result = service.getAll();
        assertTrue(result.isEmpty());
    }

    @Test
    void getAll_200_nullBody_returnsEmptyList() {
        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(200);
        when(resp.readEntity(String.class)).thenReturn(null);
        when(client.getAll()).thenReturn(resp);

        List<AnagFlussiDTO> result = service.getAll();
        assertTrue(result.isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAll_200_validJson_returnsList() throws Exception {
        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(client.getAll()).thenReturn(resp);

        AnagFlussiDTO dto = new AnagFlussiDTO(null, "f1", null, null, null, null, null, null, null, null, null);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(dto));

        List<AnagFlussiDTO> result = service.getAll();
        assertEquals(1, result.size());
        assertEquals("f1", result.get(0).flowId());
    }

    @Test
    void getAll_500_throwsRemoteCallException() {
        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.getAll()).thenReturn(resp);
        when(headersCtx.getProcessType()).thenReturn("BATCH");

        assertThrows(RemoteCallException.class, () -> service.getAll());
    }

    @Test
    void getAll_503_throwsRemoteCallException() {
        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(503);
        when(resp.hasEntity()).thenReturn(true);
        when(resp.readEntity(String.class)).thenReturn("Service unavailable");
        when(client.getAll()).thenReturn(resp);
        when(headersCtx.getProcessType()).thenReturn("BATCH");

        RemoteCallException ex = assertThrows(RemoteCallException.class, () -> service.getAll());
        assertTrue(ex.getMessage().contains("HTTP 503"));
    }

    // ---- findByFlowId ----

    @Test
    void findByFlowId_200_returnsDto() {
        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(200);
        when(resp.readEntity(AnagFlussiDTO.class)).thenReturn(null);
        when(client.findByFlowId("flow1")).thenReturn(resp);

        CustomResponse<Optional<AnagFlussiDTO>> result = service.findByFlowId("flow1");
        assertNotNull(result);
        assertNotNull(result.getResponseData());
        assertTrue(result.getResponseData().isEmpty()); // null dto -> Optional.empty
    }

    @Test
    void findByFlowId_404_viaException_returnsEmpty() {
        Response notFoundResp = mock(Response.class);
        when(notFoundResp.getStatus()).thenReturn(404);

        ClientWebApplicationException ex = mock(ClientWebApplicationException.class);
        when(ex.getResponse()).thenReturn(notFoundResp);
        when(client.findByFlowId("flow1")).thenThrow(ex);

        CustomResponse<Optional<AnagFlussiDTO>> result = service.findByFlowId("flow1");
        assertNotNull(result);
        assertTrue(result.getResponseData().isEmpty());
        assertNotNull(result.getMessage());
        assertEquals("NOT_FOUND", result.getMessage().getMessageType());
    }

    @Test
    void findByFlowId_otherClientException_rethrows() {
        ClientWebApplicationException ex = mock(ClientWebApplicationException.class);
        Response otherResp = mock(Response.class);
        when(otherResp.getStatus()).thenReturn(500);
        when(ex.getResponse()).thenReturn(otherResp);
        when(client.findByFlowId("flow1")).thenThrow(ex);

        assertThrows(ClientWebApplicationException.class, () -> service.findByFlowId("flow1"));
    }

    @Test
    void findByFlowId_serverError_throwsRemoteCallException() {
        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.findByFlowId("flow1")).thenReturn(resp);
        when(headersCtx.getProcessType()).thenReturn("N/A");

        assertThrows(RemoteCallException.class, () -> service.findByFlowId("flow1"));
    }
}
