package it.eng.snam.pmr.common.dto;

import java.util.List;

public record ProfileScenarioDto(
        String profile,
        List<ProfileOrganizationDto> organizations
) {}

