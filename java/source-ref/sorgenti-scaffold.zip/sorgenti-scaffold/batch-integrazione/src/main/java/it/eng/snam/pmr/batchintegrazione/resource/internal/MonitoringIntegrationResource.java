package it.eng.snam.pmr.batchintegrazione.resource.internal;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.batchintegrazione.service.internal.MonitoringIntegrationService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import it.eng.snam.pmr.common.annotation.AuthzWrite;
import it.eng.snam.pmr.common.annotation.LogPmr;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;

@LogPmr
@Path("/")
@RunOnVirtualThread
@RequiredArgsConstructor
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MonitoringIntegrationResource {

    private final MonitoringIntegrationService monitoringIntegrationService;
    private final Utility utility;

    @POST
    @AuthzWrite
    @Path("/bi_monitoring-integration")
    public Response sendRequestMonitoringIntegration(MonitoringIntegration integrationRequest) {
        return utility.ok(monitoringIntegrationService.sendRequestMonitoringIntegration(integrationRequest));
    }
}
