package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.VerbaliMisuraPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.DatiFiscaliService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class VerbaliMisuraHandler extends AbstractFlussoHandler<VerbaliMisuraPayloadDto> {

    @Inject
    DatiFiscaliService datiFiscaliService;

    @Override
    protected Class<VerbaliMisuraPayloadDto> getDtoClass() {
        return VerbaliMisuraPayloadDto.class;
    }

    @Override
    protected void handle(VerbaliMisuraPayloadDto dto) {

        if (dto.operation() != null && !dto.operation().isEmpty()) {
            switch (dto.operation()) {
                case "INSERT":
                    if (dto.data() != null && !dto.data().isEmpty()) {
                        datiFiscaliService.saveVerbaleMisura(dto.data().getFirst());
                    }
                    break;

                case "DELETE":
                    if (dto.data() != null && !dto.data().isEmpty()) {
                        datiFiscaliService.deleteVerbaleMisura(
                                dto.data().getFirst().remiAssoluto(),
                                dto.data().getFirst().dataInitVerbale()
                        );
                    }
                    break;

                default:
                    throw new IllegalArgumentException("Invalid operation: " + dto.operation());
            }
        } else {
            throw new IllegalArgumentException("Operation field is required");
        }
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.VERBALI_MISURA_FLOW;
    }
}
