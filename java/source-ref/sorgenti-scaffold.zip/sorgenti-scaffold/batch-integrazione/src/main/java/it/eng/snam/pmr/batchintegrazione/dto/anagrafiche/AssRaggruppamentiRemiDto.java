package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AssRaggruppamentiRemiDto(
        String remiAssoluto,
        String codiceRaggrRemi,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {}