package it.eng.snam.pmr.batchintegrazionedg.test.unit;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import it.eng.snam.pmr.batchintegrazionedg.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazionedg.exception.RetryableRemoteException;

class ExceptionsTest {

    @Test
    void remoteCallException_messageOnly() {
        RemoteCallException ex = new RemoteCallException("Remote error");
        assertEquals("Remote error", ex.getMessage());
        assertNull(ex.getCause());
    }

    @Test
    void remoteCallException_messageAndCause() {
        RuntimeException cause = new RuntimeException("underlying");
        RemoteCallException ex = new RemoteCallException("Remote error", cause);
        assertEquals("Remote error", ex.getMessage());
        assertEquals(cause, ex.getCause());
    }

    @Test
    void remoteCallException_isRuntimeException() {
        assertInstanceOf(RuntimeException.class, new RemoteCallException("test"));
    }

    @Test
    void retryableRemoteException_messageOnly() {
        RetryableRemoteException ex = new RetryableRemoteException("Retry error");
        assertEquals("Retry error", ex.getMessage());
        assertNull(ex.getCause());
    }

    @Test
    void retryableRemoteException_messageAndCause() {
        RuntimeException cause = new RuntimeException("underlying");
        RetryableRemoteException ex = new RetryableRemoteException("Retry error", cause);
        assertEquals("Retry error", ex.getMessage());
        assertEquals(cause, ex.getCause());
    }

    @Test
    void retryableRemoteException_isRuntimeException() {
        assertInstanceOf(RuntimeException.class, new RetryableRemoteException("test"));
    }
}
