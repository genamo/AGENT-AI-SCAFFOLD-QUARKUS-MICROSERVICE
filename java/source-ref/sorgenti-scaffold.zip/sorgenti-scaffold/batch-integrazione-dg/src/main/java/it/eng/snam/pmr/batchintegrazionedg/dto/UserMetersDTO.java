package it.eng.snam.pmr.batchintegrazionedg.dto;

import java.util.List;

public record UserMetersDTO(
	    String userCode,
	    List<String> meters
	) {}
