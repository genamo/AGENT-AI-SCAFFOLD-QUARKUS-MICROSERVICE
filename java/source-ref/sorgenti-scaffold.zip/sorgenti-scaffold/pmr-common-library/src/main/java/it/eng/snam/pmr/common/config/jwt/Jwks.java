package it.eng.snam.pmr.common.config.jwt;

import io.smallrye.config.WithDefault;

public interface Jwks {

    @WithDefault("20")
    int cacheSize();

    @WithDefault("24")
    long cacheDurationHours();

    @WithDefault("10")
    int rateLimitSize();

    @WithDefault("1")
    long rateLimitDurationMinutes();
}