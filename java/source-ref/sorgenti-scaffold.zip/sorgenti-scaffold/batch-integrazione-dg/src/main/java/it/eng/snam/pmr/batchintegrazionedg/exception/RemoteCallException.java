package it.eng.snam.pmr.batchintegrazionedg.exception;


public class RemoteCallException extends RuntimeException {
    
	private static final long serialVersionUID = 1L;

	public RemoteCallException(String message) {
        super(message);
    }

    public RemoteCallException(String message, Throwable cause) {
        super(message, cause);
    }
}
