USE [pmrintegrazione]
GO
/****** Object:  Table [dbo].[anag_flussi]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[anag_flussi]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[anag_flussi](
    	[id] [bigint] IDENTITY(1,1) NOT NULL,
    	[flow_id] [varchar](50) NOT NULL,
    	[desc_flow] [varchar](250) NOT NULL,
    	[granularita] [varchar](2) NOT NULL,
    	[verso] [varchar](5) NOT NULL,
    	[process_type] [varchar](30) NOT NULL,
    	[sender] [varchar](50) NOT NULL,
    	[receiver] [varchar](50) NOT NULL,
    	[action_date] [datetime] NOT NULL,
    	[user_action] [varchar](50) NOT NULL,
    	[is_deleted] [int] NOT NULL,
     CONSTRAINT [pk_anag_flussi] PRIMARY KEY CLUSTERED 
    (
    	[id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
     CONSTRAINT [uq_anag_flussi] UNIQUE NONCLUSTERED 
    (
    	[flow_id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[cron_jobs_configuration]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[cron_jobs_configuration]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[cron_jobs_configuration](
    	[id] [bigint] IDENTITY(1,1) NOT NULL,
    	[job_name] [varchar](100) NOT NULL,
    	[cron_expression] [varchar](50) NOT NULL,
     CONSTRAINT [PK_cron_jobs_configuration] PRIMARY KEY CLUSTERED 
    (
    	[id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dlq_flussi]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[dlq_flussi]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[dlq_flussi](
    	[id] [bigint] IDENTITY(1,1) NOT NULL,
    	[transaction_id] [varchar](50) NULL,
    	[flow_id] [varchar](50) NULL,
    	[key_logic] [varchar](255) NULL,
    	[original_topic] [varchar](255) NULL,
    	[original_partition] [int] NULL,
    	[original_offset] [bigint] NULL,
    	[process_type] [varchar](100) NULL,
    	[message_key] [varchar](255) NULL,
    	[error_type] [varchar](100) NULL,
    	[error_message] [varchar](2000) NULL,
    	[payload] [varchar](max) NULL,
    	[status] [varchar](20) NOT NULL,
    	[created_at] [datetime] NOT NULL,
    	[updated_at] [datetime] NULL,
    	[user_action] [varchar](50) NOT NULL,
    	[is_deleted] [int] NOT NULL,
    	[control_key] [varchar](64) NULL,
     CONSTRAINT [pk_dlq_flussi] PRIMARY KEY CLUSTERED 
    (
    	[id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[idempotenza_flussi]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[idempotenza_flussi]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[idempotenza_flussi](
    	[id] [bigint] IDENTITY(1,1) NOT NULL,
    	[transaction_id] [varchar](50) NOT NULL,
    	[flow_id] [varchar](50) NOT NULL,
    	[key_logic] [varchar](255) NULL,
    	[status] [varchar](20) NOT NULL,
    	[error_message] [varchar](1000) NULL,
    	[created_at] [datetime] NOT NULL,
    	[updated_at] [datetime] NULL,
    	[user_action] [varchar](50) NOT NULL,
    	[is_deleted] [int] NOT NULL,
     CONSTRAINT [pk_idempotenza_flussi] PRIMARY KEY CLUSTERED 
    (
    	[id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
     CONSTRAINT [uq_idempotenza_flussi_transaction_id] UNIQUE NONCLUSTERED 
    (
    	[transaction_id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[integrazione_parametri_sistema]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[integrazione_parametri_sistema]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[integrazione_parametri_sistema](
    	[id] [bigint] IDENTITY(1,1) NOT NULL,
    	[codice] [varchar](32) NOT NULL,
    	[valore] [varchar](4000) NOT NULL,
    	[data_inizio] [date] NOT NULL,
    	[data_fine] [date] NOT NULL,
    	[action_date] [datetime] NULL,
    	[user_action] [varchar](50) NULL,
    	[is_deleted] [int] NOT NULL,
     CONSTRAINT [pk_integrazione_parametri_sistema] PRIMARY KEY CLUSTERED 
    (
    	[id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[monitoring_batch]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[monitoring_batch]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[monitoring_batch](
    	[id] [bigint] IDENTITY(1,1) NOT NULL,
    	[transaction_id] [varchar](100) NOT NULL,
    	[correlation_id] [varchar](100) NOT NULL,
    	[flow_id] [varchar](50) NOT NULL,
    	[day_number] [int] NOT NULL,
    	[month_number] [int] NOT NULL,
    	[granularita] [varchar](2) NOT NULL,
    	[sender] [varchar](50) NOT NULL,
    	[isworkaround] [bit] NOT NULL,
    	[status] [int] NOT NULL,
    	[status_desc] [varchar](50) NOT NULL,
    	[file_batch] [varchar](max) NULL,
    	[file_output] [varchar](max) NULL,
    	[action_date] [datetime] NOT NULL,
    	[user_action] [varchar](50) NOT NULL,
    	[is_deleted] [int] NOT NULL,
     CONSTRAINT [pk_monitoring_batch] PRIMARY KEY CLUSTERED 
    (
    	[id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[monitoring_batch_aud]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[monitoring_batch_aud]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[monitoring_batch_aud](
    	[id] [bigint] NOT NULL,
    	[rev] [int] NOT NULL,
    	[revtype] [tinyint] NOT NULL,
    	[transaction_id] [varchar](100) NOT NULL,
    	[correlation_id] [varchar](100) NOT NULL,
    	[flow_id] [varchar](50) NOT NULL,
    	[day_number] [int] NOT NULL,
    	[month_number] [int] NOT NULL,
    	[granularita] [varchar](2) NOT NULL,
    	[sender] [varchar](50) NOT NULL,
    	[isworkaround] [bit] NOT NULL,
    	[status] [int] NOT NULL,
    	[status_desc] [varchar](50) NOT NULL,
    	[file_batch] [nvarchar](max) NULL,
    	[file_output] [nvarchar](max) NULL,
    	[action_date] [datetime] NOT NULL,
    	[user_action] [varchar](50) NOT NULL,
    	[is_deleted] [int] NULL,
     CONSTRAINT [pk_monitoring_batch_aud] PRIMARY KEY CLUSTERED 
    (
    	[id] ASC,
    	[rev] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[monitoring_flussi]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[monitoring_flussi]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[monitoring_flussi](
    	[id] [bigint] IDENTITY(1,1) NOT NULL,
    	[transaction_id] [varchar](100) NOT NULL,
    	[correlation_id] [varchar](100) NOT NULL,
    	[flow_id] [varchar](50) NOT NULL,
    	[day_number] [int] NOT NULL,
    	[month_number] [int] NOT NULL,
    	[granularita] [varchar](2) NOT NULL,
    	[sender] [varchar](50) NOT NULL,
    	[isworkaround] [bit] NOT NULL,
    	[status] [int] NOT NULL,
    	[status_desc] [varchar](50) NOT NULL,
    	[file_flusso] [varchar](max) NULL,
    	[file_output] [varchar](max) NULL,
    	[action_date] [datetime] NOT NULL,
    	[user_action] [varchar](50) NOT NULL,
    	[is_deleted] [int] NOT NULL,
     CONSTRAINT [pk_monitoring_flussi] PRIMARY KEY CLUSTERED 
    (
    	[id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[monitoring_flussi_aud]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[monitoring_flussi_aud]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[monitoring_flussi_aud](
    	[id] [bigint] NOT NULL,
    	[rev] [int] NOT NULL,
    	[revtype] [tinyint] NOT NULL,
    	[transaction_id] [varchar](100) NOT NULL,
    	[correlation_id] [varchar](100) NOT NULL,
    	[flow_id] [varchar](50) NOT NULL,
    	[day_number] [int] NOT NULL,
    	[month_number] [int] NOT NULL,
    	[granularita] [varchar](2) NOT NULL,
    	[sender] [varchar](50) NOT NULL,
    	[isworkaround] [bit] NOT NULL,
    	[status] [int] NOT NULL,
    	[status_desc] [varchar](50) NOT NULL,
    	[file_flusso] [nvarchar](max) NULL,
    	[file_output] [nvarchar](max) NULL,
    	[action_date] [datetime] NOT NULL,
    	[user_action] [varchar](50) NOT NULL,
    	[is_deleted] [int] NULL,
     CONSTRAINT [pk_monitoring_flussi_aud] PRIMARY KEY CLUSTERED 
    (
    	[id] ASC,
    	[rev] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[revinfo]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[revinfo]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[revinfo](
    	[rev] [int] IDENTITY(1,1) NOT NULL,
    	[revtstmp] [bigint] NULL,
     CONSTRAINT [pk_revinfo] PRIMARY KEY CLUSTERED 
    (
    	[rev] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[shedlock]    Script Date: 10/06/2026 15:15:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'[dbo].[shedlock]') AND type = 'U')
BEGIN
    CREATE TABLE [dbo].[shedlock](
    	[name] [varchar](50) NOT NULL,
    	[lock_until] [datetime] NULL,
    	[locked_at] [datetime] NULL,
    	[locked_by] [varchar](250) NOT NULL,
     CONSTRAINT [PK_shedlock] PRIMARY KEY CLUSTERED 
    (
    	[name] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [uk_cron_jobs_configuration]    Script Date: 10/06/2026 15:15:15 ******/
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'uk_cron_jobs_configuration' AND object_id = OBJECT_ID(N'[dbo].[cron_jobs_configuration]'))
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX [uk_cron_jobs_configuration] ON [dbo].[cron_jobs_configuration]
    (
    	[job_name] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ix_dlq_flussi_control_key_is_deleted]    Script Date: 10/06/2026 15:15:15 ******/
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_dlq_flussi_control_key_is_deleted' AND object_id = OBJECT_ID(N'[dbo].[dlq_flussi]'))
BEGIN
    CREATE NONCLUSTERED INDEX [ix_dlq_flussi_control_key_is_deleted] ON [dbo].[dlq_flussi]
    (
    	[control_key] ASC,
    	[is_deleted] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END
GO
/****** Object:  Index [ix_dlq_flussi_created_at]    Script Date: 10/06/2026 15:15:15 ******/
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_dlq_flussi_created_at' AND object_id = OBJECT_ID(N'[dbo].[dlq_flussi]'))
BEGIN
    CREATE NONCLUSTERED INDEX [ix_dlq_flussi_created_at] ON [dbo].[dlq_flussi]
    (
    	[created_at] DESC
    )WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ix_dlq_flussi_flow_id]    Script Date: 10/06/2026 15:15:15 ******/
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_dlq_flussi_flow_id' AND object_id = OBJECT_ID(N'[dbo].[dlq_flussi]'))
BEGIN
    CREATE NONCLUSTERED INDEX [ix_dlq_flussi_flow_id] ON [dbo].[dlq_flussi]
    (
    	[flow_id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ix_dlq_flussi_status]    Script Date: 10/06/2026 15:15:15 ******/
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_dlq_flussi_status' AND object_id = OBJECT_ID(N'[dbo].[dlq_flussi]'))
BEGIN
    CREATE NONCLUSTERED INDEX [ix_dlq_flussi_status] ON [dbo].[dlq_flussi]
    (
    	[status] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ix_dlq_flussi_transaction_id]    Script Date: 10/06/2026 15:15:15 ******/
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'ix_dlq_flussi_transaction_id' AND object_id = OBJECT_ID(N'[dbo].[dlq_flussi]'))
BEGIN
    CREATE NONCLUSTERED INDEX [ix_dlq_flussi_transaction_id] ON [dbo].[dlq_flussi]
    (
    	[transaction_id] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [uk_monitoring_batch]    Script Date: 10/06/2026 15:15:15 ******/
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'uk_monitoring_batch' AND object_id = OBJECT_ID(N'[dbo].[monitoring_batch]'))
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX [uk_monitoring_batch] ON [dbo].[monitoring_batch]
    (
    	[transaction_id] ASC,
    	[is_deleted] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [uk_monitoring_flussi]    Script Date: 10/06/2026 15:15:15 ******/
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'uk_monitoring_flussi' AND object_id = OBJECT_ID(N'[dbo].[monitoring_flussi]'))
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX [uk_monitoring_flussi] ON [dbo].[monitoring_flussi]
    (
    	[transaction_id] ASC,
    	[is_deleted] ASC
    )WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END
GO
IF NOT EXISTS (
    SELECT 1 FROM sys.default_constraints dc
    JOIN sys.columns c ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'[dbo].[anag_flussi]') AND c.name = N'granularita'
)
BEGIN
    ALTER TABLE [dbo].[anag_flussi] ADD DEFAULT ('G') FOR [granularita]
END
GO
IF NOT EXISTS (
    SELECT 1 FROM sys.default_constraints dc
    JOIN sys.columns c ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'[dbo].[anag_flussi]') AND c.name = N'verso'
)
BEGIN
    ALTER TABLE [dbo].[anag_flussi] ADD DEFAULT ('IN') FOR [verso]
END
GO
IF NOT EXISTS (
    SELECT 1 FROM sys.default_constraints dc
    JOIN sys.columns c ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'[dbo].[anag_flussi]') AND c.name = N'process_type'
)
BEGIN
    ALTER TABLE [dbo].[anag_flussi] ADD DEFAULT ('N/A') FOR [process_type]
END
GO
IF NOT EXISTS (
    SELECT 1 FROM sys.default_constraints dc
    JOIN sys.columns c ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'[dbo].[anag_flussi]') AND c.name = N'action_date'
)
BEGIN
    ALTER TABLE [dbo].[anag_flussi] ADD DEFAULT (getdate()) FOR [action_date]
END
GO
IF NOT EXISTS (
    SELECT 1 FROM sys.default_constraints dc
    JOIN sys.columns c ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'[dbo].[anag_flussi]') AND c.name = N'user_action'
)
BEGIN
    ALTER TABLE [dbo].[anag_flussi] ADD DEFAULT ('DATASETUP') FOR [user_action]
END
GO
IF NOT EXISTS (
    SELECT 1 FROM sys.default_constraints dc
    JOIN sys.columns c ON dc.parent_object_id = c.object_id AND dc.parent_column_id = c.column_id
    WHERE dc.parent_object_id = OBJECT_ID(N'[dbo].[anag_flussi]') AND c.name = N'is_deleted'
)
BEGIN
    ALTER TABLE [dbo].[anag_flussi] ADD DEFAULT ((0)) FOR [is_deleted]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'df_dlq_flussi_status')
BEGIN
    ALTER TABLE [dbo].[dlq_flussi] ADD CONSTRAINT [df_dlq_flussi_status] DEFAULT ('RECEIVED') FOR [status]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'df_dlq_flussi_created_at')
BEGIN
    ALTER TABLE [dbo].[dlq_flussi] ADD CONSTRAINT [df_dlq_flussi_created_at] DEFAULT (getdate()) FOR [created_at]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'df_dlq_flussi_user_action')
BEGIN
    ALTER TABLE [dbo].[dlq_flussi] ADD CONSTRAINT [df_dlq_flussi_user_action] DEFAULT ('SYSTEM') FOR [user_action]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'df_dlq_flussi_is_deleted')
BEGIN
    ALTER TABLE [dbo].[dlq_flussi] ADD CONSTRAINT [df_dlq_flussi_is_deleted] DEFAULT ((0)) FOR [is_deleted]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'df_idempotenza_flussi_created_at')
BEGIN
    ALTER TABLE [dbo].[idempotenza_flussi] ADD CONSTRAINT [df_idempotenza_flussi_created_at] DEFAULT (getdate()) FOR [created_at]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'df_idempotenza_flussi_user_action')
BEGIN
    ALTER TABLE [dbo].[idempotenza_flussi] ADD CONSTRAINT [df_idempotenza_flussi_user_action] DEFAULT ('SYSTEM') FOR [user_action]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'df_idempotenza_flussi_is_deleted')
BEGIN
    ALTER TABLE [dbo].[idempotenza_flussi] ADD CONSTRAINT [df_idempotenza_flussi_is_deleted] DEFAULT ((0)) FOR [is_deleted]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'actiondate_constraint_default')
BEGIN
    ALTER TABLE [dbo].[integrazione_parametri_sistema] ADD CONSTRAINT [actiondate_constraint_default] DEFAULT (getdate()) FOR [action_date]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'fk_monitoring_batch_aud_revinfo')
BEGIN
    ALTER TABLE [dbo].[monitoring_batch_aud] WITH CHECK ADD CONSTRAINT [fk_monitoring_batch_aud_revinfo] FOREIGN KEY([rev])
    REFERENCES [dbo].[revinfo] ([rev])

    ALTER TABLE [dbo].[monitoring_batch_aud] CHECK CONSTRAINT [fk_monitoring_batch_aud_revinfo]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'fk_monitoring_flussi_aud_revinfo')
BEGIN
    ALTER TABLE [dbo].[monitoring_flussi_aud] WITH CHECK ADD CONSTRAINT [fk_monitoring_flussi_aud_revinfo] FOREIGN KEY([rev])
    REFERENCES [dbo].[revinfo] ([rev])

    ALTER TABLE [dbo].[monitoring_flussi_aud] CHECK CONSTRAINT [fk_monitoring_flussi_aud_revinfo]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'ck_dlq_flussi_status')
BEGIN
    ALTER TABLE [dbo].[dlq_flussi] WITH CHECK ADD CONSTRAINT [ck_dlq_flussi_status] CHECK (([status]='DISCARDED' OR [status]='PROCESSED' OR [status]='RECEIVED'))

    ALTER TABLE [dbo].[dlq_flussi] CHECK CONSTRAINT [ck_dlq_flussi_status]
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'ck_idempotenza_flussi_status')
BEGIN
    ALTER TABLE [dbo].[idempotenza_flussi] WITH CHECK ADD CONSTRAINT [ck_idempotenza_flussi_status] CHECK (([status]='ERROR' OR [status]='COMPLETED' OR [status]='IN_PROGRESS'))

    ALTER TABLE [dbo].[idempotenza_flussi] CHECK CONSTRAINT [ck_idempotenza_flussi_status]
END
GO

/****** DATASETUP ******/
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001A')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001A', N'ANAGRAFICA REMI', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001B')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001B', N'ANAGRAFICA CLIENTI', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001C')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001C', N'ASSOCIAZIONE REMI CLIENTI', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001D')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001D', N'ASSOCIAZIONE REMI TITOLARI', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001E')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001E', N'ASSOCIAZIONE REMI AOP', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001F')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001F', N'ASSOCIAZIONE STATO REMI', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001G')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001G', N'ASSOCIAZIONE REMI TIPO BILANCIO TECNICO', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001H')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001H', N'ANAGRAFICA AREA TECNICA', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001I')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001I', N'ANAGRAFICA POLO', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001L')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001L', N'ANAGRAFICA MACRO POLO', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001M')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001M', N'CONTATTO', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001N')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001N', N'ANAGRAFICA RAGGRUPPAMENTI', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
IF NOT EXISTS (SELECT 1 FROM [dbo].[anag_flussi] WHERE [flow_id] = N'PMR001O')
BEGIN
    INSERT [dbo].[anag_flussi] ([flow_id], [desc_flow], [granularita], [verso], [process_type], [sender], [receiver], [action_date], [user_action], [is_deleted]) VALUES (N'PMR001O', N'ANAGRAFICA RAGGRUPPAMENTI REMI', N'G', N'IN', N'ANAGRAFICHE', N'SUMMER', N'PMR', CAST(N'2026-06-12T00:00:00.000' AS DateTime), N'DATASETUP', 0);
END
GO