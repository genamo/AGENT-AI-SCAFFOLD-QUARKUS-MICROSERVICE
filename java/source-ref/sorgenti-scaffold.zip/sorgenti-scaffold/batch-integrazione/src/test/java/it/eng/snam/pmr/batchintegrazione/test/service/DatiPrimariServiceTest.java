package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.client.DatiPrimariClient;
import it.eng.snam.pmr.batchintegrazione.dto.datiprimari.AnalisiQualitaGasGiornDto;
import it.eng.snam.pmr.batchintegrazione.dto.datiprimari.AnalisiQualitaGasGiornSearchDto;
import it.eng.snam.pmr.batchintegrazione.dto.datiprimari.QualitaGasGiornDto;
import it.eng.snam.pmr.batchintegrazione.dto.datiprimari.QualitaGasGiornSearchDto;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.DatiPrimariService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.B2BTokenUtils;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class DatiPrimariServiceTest {

    @Mock
    DatiPrimariClient datiPrimariClient;

    @Mock
    ObjectMapper objectMapper;

    @Mock
    RequestHeadersContext headersCtx;

    @Mock
    B2BTokenUtils tokenUtil;

    @InjectMocks
    DatiPrimariService service;

    private void injectAbstractField(String fieldName, Object value) throws Exception {
        Field field = AbstractService.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(service, value);
    }

    private Response mockResp(int status) {
        Response r = mock(Response.class);
        when(r.getStatus()).thenReturn(status);
        return r;
    }

    private void mockHeadersForRemoteError() {
        when(headersCtx.getKeyLogic()).thenReturn("kl");
        when(headersCtx.getTransactionId()).thenReturn("tx");
        when(headersCtx.getProcessType()).thenReturn("PT");
    }

    private static final LocalDateTime TS1 = LocalDateTime.of(2024, 1, 1, 0, 0);
    private static final LocalDateTime TS2 = LocalDateTime.of(2024, 1, 2, 0, 0);

    private static QualitaGasGiornSearchDto qualitaSearchDto() {
        return new QualitaGasGiornSearchDto(100, TS1);
    }

    private static QualitaGasGiornDto qualitaDto() {
        return new QualitaGasGiornDto(
                100,
                TS1,
                "CRI",
                (short) 1,
                TS2,
                (short) 24,
                20240101,
                java.math.BigDecimal.ONE,
                "KG",
                java.math.BigDecimal.valueOf(2),
                "KGN",
                java.math.BigDecimal.valueOf(3),
                java.math.BigDecimal.valueOf(4),
                java.math.BigDecimal.valueOf(5),
                "KJ",
                java.math.BigDecimal.valueOf(6),
                java.math.BigDecimal.valueOf(7),
                "KWH",
                java.math.BigDecimal.valueOf(8),
                "PCS",
                java.math.BigDecimal.valueOf(9),
                java.math.BigDecimal.valueOf(10),
                java.math.BigDecimal.valueOf(11),
                java.math.BigDecimal.valueOf(12),
                java.math.BigDecimal.valueOf(13),
                java.math.BigDecimal.valueOf(14),
                java.math.BigDecimal.valueOf(15),
                java.math.BigDecimal.valueOf(16),
                java.math.BigDecimal.valueOf(17),
                java.math.BigDecimal.valueOf(18),
                java.math.BigDecimal.valueOf(19),
                java.math.BigDecimal.valueOf(20),
                java.math.BigDecimal.valueOf(21),
                java.math.BigDecimal.valueOf(22),
                java.math.BigDecimal.valueOf(23),
                java.math.BigDecimal.valueOf(24),
                java.math.BigDecimal.valueOf(25),
                "S",
                java.math.BigDecimal.valueOf(26),
                "Y",
                1L,
                TS2,
                "M",
                TS2,
                "user",
                "P",
                java.math.BigDecimal.valueOf(27),
                java.math.BigDecimal.valueOf(28),
                "UM",
                java.math.BigDecimal.valueOf(29),
                java.math.BigDecimal.valueOf(30),
                "UM2",
                java.math.BigDecimal.valueOf(31),
                java.math.BigDecimal.valueOf(32),
                java.math.BigDecimal.valueOf(33),
                java.math.BigDecimal.valueOf(34),
                java.math.BigDecimal.valueOf(35),
                java.math.BigDecimal.valueOf(36),
                java.math.BigDecimal.valueOf(37),
                (short) 1,
                (short) 2,
                (short) 3,
                (short) 4,
                (short) 5,
                (short) 6,
                (short) 7,
                (short) 8,
                (short) 9,
                "INSERT",
                TS2,
                0);
    }

    private static AnalisiQualitaGasGiornDto analisiDto() {
        return new AnalisiQualitaGasGiornDto(
                "REMI001",
                TS1,
                (short) 1,
                TS2,
                (short) 24,
                (short) 1,
                "AQ",
                java.math.BigDecimal.ONE,
                java.math.BigDecimal.valueOf(2),
                java.math.BigDecimal.valueOf(3),
                java.math.BigDecimal.valueOf(4),
                java.math.BigDecimal.valueOf(5),
                java.math.BigDecimal.valueOf(6),
                java.math.BigDecimal.valueOf(7),
                java.math.BigDecimal.valueOf(8),
                java.math.BigDecimal.valueOf(9),
                java.math.BigDecimal.valueOf(10),
                java.math.BigDecimal.valueOf(11),
                java.math.BigDecimal.valueOf(12),
                java.math.BigDecimal.valueOf(13),
                java.math.BigDecimal.valueOf(14),
                java.math.BigDecimal.valueOf(15),
                java.math.BigDecimal.valueOf(16),
                java.math.BigDecimal.valueOf(17),
                java.math.BigDecimal.valueOf(18),
                java.math.BigDecimal.valueOf(19),
                java.math.BigDecimal.valueOf(20),
                java.math.BigDecimal.valueOf(21),
                java.math.BigDecimal.valueOf(22),
                java.math.BigDecimal.valueOf(23),
                (short) 1,
                TS2,
                (short) 1,
                (short) 0,
                "UM1",
                "UM2",
                "UM3",
                "MV1",
                "MV2",
                "MV3",
                TS2,
                "user",
                java.math.BigDecimal.valueOf(24),
                "INSERT",
                TS2,
                0);
    }


    private static AnalisiQualitaGasGiornSearchDto analisiSearchDto() {
        return new AnalisiQualitaGasGiornSearchDto("REMI001", TS1);
    }

    
    @BeforeEach
    void setUp() throws Exception {
        injectAbstractField("headersCtx", headersCtx);
        injectAbstractField("objectMapper", objectMapper);
    }

    // =========================================================================
    // QUALITA GAS GIORN
    // =========================================================================

    @Test
    void getAllQualitaGasGiorn_204_returnsEmpty() {
        Response resp = mockResp(204);
        when(datiPrimariClient.getAllQualitaGasGiorn()).thenReturn(resp);

        assertTrue(service.getAllQualitaGasGiorn().isEmpty());
    }

    @Test
    void getAllQualitaGasGiorn_200_emptyJson_returnsEmpty() {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("");
        when(datiPrimariClient.getAllQualitaGasGiorn()).thenReturn(resp);

        assertTrue(service.getAllQualitaGasGiorn().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAllQualitaGasGiorn_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(datiPrimariClient.getAllQualitaGasGiorn()).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class)))
                .thenReturn(List.of(qualitaSearchDto()));

        List<QualitaGasGiornSearchDto> result = service.getAllQualitaGasGiorn();

        assertEquals(1, result.size());
        assertEquals(100, result.get(0).codiceAop());
    }

    @Test
    void getAllQualitaGasGiorn_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.getAllQualitaGasGiorn()).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.getAllQualitaGasGiorn());
    }

    @Test
    void getAllQualitaGasGiorn_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.getAllQualitaGasGiorn()).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.getAllQualitaGasGiorn());
    }

    @Test
    void findQualitaGasGiornById_404_returnsEmpty() {
        Response resp = mockResp(404);
        when(datiPrimariClient.findQualitaGasGiornById(100, TS1)).thenReturn(resp);

        assertTrue(service.findQualitaGasGiornById(100, TS1).isEmpty());
    }

    @Test
    void findQualitaGasGiornById_204_returnsEmpty() {
        Response resp = mockResp(204);
        when(datiPrimariClient.findQualitaGasGiornById(100, TS1)).thenReturn(resp);

        assertTrue(service.findQualitaGasGiornById(100, TS1).isEmpty());
    }

    @Test
    void findQualitaGasGiornById_200_returnsDto() {
        QualitaGasGiornSearchDto dto = qualitaSearchDto();
        Response resp = mockResp(200);

        when(resp.readEntity(QualitaGasGiornSearchDto.class)).thenReturn(dto);
        when(datiPrimariClient.findQualitaGasGiornById(100, TS1)).thenReturn(resp);

        Optional<QualitaGasGiornSearchDto> result = service.findQualitaGasGiornById(100, TS1);

        assertTrue(result.isPresent());
        assertEquals(100, result.get().codiceAop());
    }

    @Test
    void findQualitaGasGiornById_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.findQualitaGasGiornById(100, TS1)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.findQualitaGasGiornById(100, TS1));
    }

    @Test
    void findQualitaGasGiornById_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.findQualitaGasGiornById(100, TS1)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.findQualitaGasGiornById(100, TS1));
    }

    @Test
    void saveQualitaGasGiorn_200_returnsDto() {
        QualitaGasGiornDto dto = qualitaDto();
        Response resp = mockResp(200);

        when(resp.readEntity(QualitaGasGiornDto.class)).thenReturn(dto);
        when(datiPrimariClient.saveQualitaGasGiorn(dto)).thenReturn(resp);

        assertSame(dto, service.saveQualitaGasGiorn(dto));
    }

    @Test
    void saveQualitaGasGiorn_201_returnsDto() {
        QualitaGasGiornDto dto = qualitaDto();
        Response resp = mockResp(201);

        when(resp.readEntity(QualitaGasGiornDto.class)).thenReturn(dto);
        when(datiPrimariClient.saveQualitaGasGiorn(dto)).thenReturn(resp);

        assertSame(dto, service.saveQualitaGasGiorn(dto));
    }

    @Test
    void saveQualitaGasGiorn_400_throwsIllegalArgument() {
        QualitaGasGiornDto dto = qualitaDto();
        Response resp = mockResp(400);

        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.saveQualitaGasGiorn(dto)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.saveQualitaGasGiorn(dto));
    }

    @Test
    void saveQualitaGasGiorn_500_throwsRemoteCallException() {
        QualitaGasGiornDto dto = qualitaDto();
        Response resp = mockResp(500);

        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.saveQualitaGasGiorn(dto)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.saveQualitaGasGiorn(dto));
    }

    @Test
    void deleteQualitaGasGiorn_200_returnsDto() {
        QualitaGasGiornDto dto = qualitaDto();
        Response resp = mockResp(200);

        when(resp.readEntity(QualitaGasGiornDto.class)).thenReturn(dto);
        when(datiPrimariClient.deleteQualitaGasGiorn(100, TS1)).thenReturn(resp);

        assertSame(dto, service.deleteQualitaGasGiorn(100, TS1));
    }

    @Test
    void deleteQualitaGasGiorn_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.deleteQualitaGasGiorn(100, TS1)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.deleteQualitaGasGiorn(100, TS1));
    }

    @Test
    void deleteQualitaGasGiorn_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.deleteQualitaGasGiorn(100, TS1)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.deleteQualitaGasGiorn(100, TS1));
    }

    @Test
    void restoreQualitaGasGiorn_200_returnsDto() {
        QualitaGasGiornDto dto = qualitaDto();
        Response resp = mockResp(200);

        when(resp.readEntity(QualitaGasGiornDto.class)).thenReturn(dto);
        when(datiPrimariClient.restoreQualitaGasGiorn(100, TS1)).thenReturn(resp);

        assertSame(dto, service.restoreQualitaGasGiorn(100, TS1));
    }

    @Test
    void restoreQualitaGasGiorn_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.restoreQualitaGasGiorn(100, TS1)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.restoreQualitaGasGiorn(100, TS1));
    }

    // =========================================================================
    // ANALISI QUALITA GAS GIORN
    // =========================================================================

    @Test
    void getAllAnalisiQualitaGasGiorn_204_returnsEmpty() {
        Response resp = mockResp(204);
        when(datiPrimariClient.getAllAnalisiQualitaGasGiorn()).thenReturn(resp);

        assertTrue(service.getAllAnalisiQualitaGasGiorn().isEmpty());
    }

    @Test
    void getAllAnalisiQualitaGasGiorn_200_emptyJson_returnsEmpty() {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("");
        when(datiPrimariClient.getAllAnalisiQualitaGasGiorn()).thenReturn(resp);

        assertTrue(service.getAllAnalisiQualitaGasGiorn().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAllAnalisiQualitaGasGiorn_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(datiPrimariClient.getAllAnalisiQualitaGasGiorn()).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class)))
                .thenReturn(List.of(analisiSearchDto()));

        List<AnalisiQualitaGasGiornSearchDto> result = service.getAllAnalisiQualitaGasGiorn();

        assertEquals(1, result.size());
        assertEquals("REMI001", result.get(0).remiAssoluto());
    }

    @Test
    void getAllAnalisiQualitaGasGiorn_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.getAllAnalisiQualitaGasGiorn()).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.getAllAnalisiQualitaGasGiorn());
    }

    @Test
    void getAllAnalisiQualitaGasGiorn_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.getAllAnalisiQualitaGasGiorn()).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.getAllAnalisiQualitaGasGiorn());
    }

    @Test
    void findAnalisiQualitaGasGiornById_404_returnsEmpty() {
        Response resp = mockResp(404);
        when(datiPrimariClient.findAnalisiQualitaGasGiornById("REMI001", TS1)).thenReturn(resp);

        assertTrue(service.findAnalisiQualitaGasGiornById("REMI001", TS1).isEmpty());
    }

    @Test
    void findAnalisiQualitaGasGiornById_204_returnsEmpty() {
        Response resp = mockResp(204);
        when(datiPrimariClient.findAnalisiQualitaGasGiornById("REMI001", TS1)).thenReturn(resp);

        assertTrue(service.findAnalisiQualitaGasGiornById("REMI001", TS1).isEmpty());
    }

    @Test
    void findAnalisiQualitaGasGiornById_200_returnsDto() {
        AnalisiQualitaGasGiornSearchDto dto = analisiSearchDto();
        Response resp = mockResp(200);

        when(resp.readEntity(AnalisiQualitaGasGiornSearchDto.class)).thenReturn(dto);
        when(datiPrimariClient.findAnalisiQualitaGasGiornById("REMI001", TS1)).thenReturn(resp);

        Optional<AnalisiQualitaGasGiornSearchDto> result =
                service.findAnalisiQualitaGasGiornById("REMI001", TS1);

        assertTrue(result.isPresent());
        assertEquals("REMI001", result.get().remiAssoluto());
    }

    @Test
    void findAnalisiQualitaGasGiornById_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.findAnalisiQualitaGasGiornById("REMI001", TS1)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class,
                () -> service.findAnalisiQualitaGasGiornById("REMI001", TS1));
    }

    @Test
    void findAnalisiQualitaGasGiornById_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.findAnalisiQualitaGasGiornById("REMI001", TS1)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class,
                () -> service.findAnalisiQualitaGasGiornById("REMI001", TS1));
    }

    @Test
    void saveAnalisiQualitaGasGiorn_200_returnsDto() {
        AnalisiQualitaGasGiornDto dto = analisiDto();
        Response resp = mockResp(200);

        when(resp.readEntity(AnalisiQualitaGasGiornDto.class)).thenReturn(dto);
        when(datiPrimariClient.saveAnalisiQualitaGasGiorn(dto)).thenReturn(resp);

        assertSame(dto, service.saveAnalisiQualitaGasGiorn(dto));
    }

    @Test
    void saveAnalisiQualitaGasGiorn_201_returnsDto() {
        AnalisiQualitaGasGiornDto dto = analisiDto();
        Response resp = mockResp(201);

        when(resp.readEntity(AnalisiQualitaGasGiornDto.class)).thenReturn(dto);
        when(datiPrimariClient.saveAnalisiQualitaGasGiorn(dto)).thenReturn(resp);

        assertSame(dto, service.saveAnalisiQualitaGasGiorn(dto));
    }

    @Test
    void saveAnalisiQualitaGasGiorn_400_throwsIllegalArgument() {
        AnalisiQualitaGasGiornDto dto = analisiDto();
        Response resp = mockResp(400);

        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.saveAnalisiQualitaGasGiorn(dto)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class, () -> service.saveAnalisiQualitaGasGiorn(dto));
    }

    @Test
    void saveAnalisiQualitaGasGiorn_500_throwsRemoteCallException() {
        AnalisiQualitaGasGiornDto dto = analisiDto();
        Response resp = mockResp(500);

        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.saveAnalisiQualitaGasGiorn(dto)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class, () -> service.saveAnalisiQualitaGasGiorn(dto));
    }

    @Test
    void deleteAnalisiQualitaGasGiorn_200_returnsDto() {
        AnalisiQualitaGasGiornDto dto = analisiDto();
        Response resp = mockResp(200);

        when(resp.readEntity(AnalisiQualitaGasGiornDto.class)).thenReturn(dto);
        when(datiPrimariClient.deleteAnalisiQualitaGasGiorn("REMI001", TS1)).thenReturn(resp);

        assertSame(dto, service.deleteAnalisiQualitaGasGiorn("REMI001", TS1));
    }

    @Test
    void deleteAnalisiQualitaGasGiorn_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.deleteAnalisiQualitaGasGiorn("REMI001", TS1)).thenReturn(resp);

        assertThrows(IllegalArgumentException.class,
                () -> service.deleteAnalisiQualitaGasGiorn("REMI001", TS1));
    }

    @Test
    void deleteAnalisiQualitaGasGiorn_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.deleteAnalisiQualitaGasGiorn("REMI001", TS1)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class,
                () -> service.deleteAnalisiQualitaGasGiorn("REMI001", TS1));
    }

    @Test
    void restoreAnalisiQualitaGasGiorn_200_returnsDto() {
        AnalisiQualitaGasGiornDto dto = analisiDto();
        Response resp = mockResp(200);

        when(resp.readEntity(AnalisiQualitaGasGiornDto.class)).thenReturn(dto);
        when(datiPrimariClient.restoreAnalisiQualitaGasGiorn("REMI001", TS1)).thenReturn(resp);

        assertSame(dto, service.restoreAnalisiQualitaGasGiorn("REMI001", TS1));
    }

    @Test
    void restoreAnalisiQualitaGasGiorn_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(datiPrimariClient.restoreAnalisiQualitaGasGiorn("REMI001", TS1)).thenReturn(resp);
        mockHeadersForRemoteError();

        assertThrows(RemoteCallException.class,
                () -> service.restoreAnalisiQualitaGasGiorn("REMI001", TS1));
    }
}
