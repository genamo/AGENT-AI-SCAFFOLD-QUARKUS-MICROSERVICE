package it.eng.snam.pmr.batchintegrazione.utils.blob.storage;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class BlobUploadProperties {

    public final String ZIP_CONTENT_TYPE = "application/zip";

    public final Integer BUFFER_SIZE = 512 * 1024;
    public final byte[] BUFFER = new byte[BUFFER_SIZE];
}
