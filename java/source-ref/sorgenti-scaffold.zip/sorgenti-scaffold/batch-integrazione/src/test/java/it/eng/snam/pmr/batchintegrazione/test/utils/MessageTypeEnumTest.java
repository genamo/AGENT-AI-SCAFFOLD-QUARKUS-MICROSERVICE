package it.eng.snam.pmr.batchintegrazione.test.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.Test;

import it.eng.snam.pmr.batchintegrazione.utils.MessageTypeEnum;

class MessageTypeEnumTest {

    @Test
    void ok_values() {
        assertEquals("Info", MessageTypeEnum.OK.getMessageType());
        assertEquals("1", MessageTypeEnum.OK.getMessageCode());
    }

    @Test
    void errorGestitoSearch_values() {
        assertEquals("Info", MessageTypeEnum.ERROR_GESTITO_SEARCH.getMessageType());
        assertEquals("4", MessageTypeEnum.ERROR_GESTITO_SEARCH.getMessageCode());
    }

    @Test
    void errorGestito_values() {
        assertEquals("Error", MessageTypeEnum.ERROR_GESTITO.getMessageType());
        assertEquals("2", MessageTypeEnum.ERROR_GESTITO.getMessageCode());
    }

    @Test
    void errorNonGestito_values() {
        assertEquals("Error", MessageTypeEnum.ERROR_NON_GESTITO.getMessageType());
        assertEquals("3", MessageTypeEnum.ERROR_NON_GESTITO.getMessageCode());
    }

    @Test
    void errorBusinessLogic_values() {
        assertEquals("Error", MessageTypeEnum.ERROR_BUSINESS_LOGIC.getMessageType());
        assertEquals("7", MessageTypeEnum.ERROR_BUSINESS_LOGIC.getMessageCode());
    }

    @Test
    void allValuesCount() {
        assertEquals(5, MessageTypeEnum.values().length);
    }

    @Test
    void valueOf_ok() {
        assertSame(MessageTypeEnum.OK, MessageTypeEnum.valueOf("OK"));
    }

    @Test
    void valueOf_errorGestito() {
        assertSame(MessageTypeEnum.ERROR_GESTITO, MessageTypeEnum.valueOf("ERROR_GESTITO"));
    }
}
