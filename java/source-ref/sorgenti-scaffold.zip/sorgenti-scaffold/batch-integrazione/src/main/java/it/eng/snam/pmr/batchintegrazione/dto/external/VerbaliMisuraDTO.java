package it.eng.snam.pmr.batchintegrazione.dto.external;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VerbaliMisuraDTO {
    private Long identificativoMailVerble;
    private String codiceCliente;
    private String listaRemi;
    private String annoMeseRiferimento;
    private Date dataEmissione;
    private String statoInvio;
    private String elencoDestinatari;
}