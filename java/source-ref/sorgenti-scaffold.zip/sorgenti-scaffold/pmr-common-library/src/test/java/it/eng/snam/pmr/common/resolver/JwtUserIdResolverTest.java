package it.eng.snam.pmr.common.resolver;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

import it.eng.snam.pmr.common.util.AuthorizationUtils;

class JwtUserIdResolverTest {

    @Test
    void resolve_nullBearer_returnsNull() {
        assertThat(JwtUserIdResolver.resolve(null)).isNull();
    }

    @Test
    void resolve_blankBearer_returnsNull() {
        assertThat(JwtUserIdResolver.resolve("  ")).isNull();
    }

    @Test
    void resolve_tokenWithSub_returnsSub() {
        String token = JWT.create().withSubject("subuser").sign(Algorithm.HMAC256("s"));
        assertThat(JwtUserIdResolver.resolve("Bearer " + token)).isEqualTo("subuser");
    }

    @Test
    void resolve_tokenWithUserId_returnsIt() {
        String token = JWT.create().withClaim(AuthorizationUtils.CLAIM_USER_ID, "uid001").sign(Algorithm.HMAC256("s"));
        assertThat(JwtUserIdResolver.resolve("Bearer " + token)).isEqualTo("uid001");
    }

    @Test
    void resolve_tokenWithPreferredUsername_returnsIt() {
        String token = JWT.create().withClaim(AuthorizationUtils.CLAIM_USER_ID, "pref_user").sign(Algorithm.HMAC256("s"));
        assertThat(JwtUserIdResolver.resolve("Bearer " + token)).isEqualTo("pref_user");
    }

    @Test
    void resolve_tokenWithUsername_returnsIt() {
        String token = JWT.create().withClaim(AuthorizationUtils.CLAIM_USER_ID, "usr42").sign(Algorithm.HMAC256("s"));
        assertThat(JwtUserIdResolver.resolve("Bearer " + token)).isEqualTo("usr42");
    }

    @Test
    void resolve_tokenWithName_returnsIt() {
        String token = JWT.create().withClaim("name", "Mario Rossi").sign(Algorithm.HMAC256("s"));
        assertThat(JwtUserIdResolver.resolve("Bearer " + token)).isEqualTo("Mario Rossi");
    }

    @Test
    void resolve_tokenWithNoUserClaim_returnsNull() {
        String token = JWT.create().withClaim("other", "x").sign(Algorithm.HMAC256("s"));
        assertThat(JwtUserIdResolver.resolve("Bearer " + token)).isNull();
    }

    @Test
    void resolve_tokenWithoutBearerPrefix_stillWorks() {
        String token = JWT.create().withSubject("sub123").sign(Algorithm.HMAC256("s"));
        assertThat(JwtUserIdResolver.resolve(token)).isEqualTo("sub123");
    }
}
