package it.eng.snam.pmr.batchintegrazionedg.dto;

import java.time.LocalDateTime;

import lombok.Builder;

@Builder(toBuilder = true)
public record MonitoringFlussiDTO(
	String transactionId,
    String correlationId,
    String flowId,
    Integer dayNumber,
    Integer monthNumber,
    String granularita,
    String sender,
    Boolean isWorkaround,
    String statusDescription,
    String fileFlusso,  // Contenuto del file nvarchar(max)
    String fileOutput, // Contenuto del file nvarchar(max)
    Integer status,
    LocalDateTime actionDate,
    String userAction,
    Integer isDeleted
) {}
