package it.eng.snam.pmr.batchintegrazionedg.dto.request;

import java.time.YearMonth;
import java.util.List;

import lombok.Builder;

@Builder(toBuilder = true)
public record BiometanoFilter(
		String executioner,// "JOB_BIOMETANO", "JOB_DELIBERA96"
	    String documentType, //"BIOMETANO" (002) // "DELIBERA96" (001)
	    String fileFormat, //"XML"
	    YearMonth competenza, 
	    List<String> remiAssolutoList //lista vuota
	) {}
