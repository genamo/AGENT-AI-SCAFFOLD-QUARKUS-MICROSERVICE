package it.eng.snam.pmr.common.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;
import java.sql.*;
import java.util.List;
import java.util.Optional;

import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import it.eng.snam.pmr.common.databricks.DatabricksRetry;
import it.eng.snam.pmr.common.dto.UserCustomerOrganizationDTO;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserCustomerOrganizationRepositoryTest {

    @Mock DataSource dataSource;
    @Mock DatabricksRetry retry;
    @Mock Connection connection;
    @Mock PreparedStatement preparedStatement;
    @Mock ResultSet resultSet;

    UserCustomerOrganizationRepository repo;

    @BeforeEach
    @SuppressWarnings("unchecked")
    void setUp() throws Exception {
        repo = new UserCustomerOrganizationRepository();
        setField(repo, "schema", "testschema");
        setField(repo, "dataSource", dataSource);
        setField(repo, "retry", retry);

        // Make retry.execute() actually execute the SqlSupplier
        doAnswer(inv -> ((DatabricksRetry.SqlSupplier<?>) inv.getArgument(0)).get())
                .when(retry).execute(any(DatabricksRetry.SqlSupplier.class));

        // JDBC mock chain
        when(dataSource.getConnection()).thenReturn(connection);
        when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
        when(preparedStatement.executeQuery()).thenReturn(resultSet);

        // Default ResultSet: no results
        when(resultSet.next()).thenReturn(false);
    }

    private void stubSingleRow() throws SQLException {
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getObject("OrganizationId")).thenReturn(10L);
        when(resultSet.getObject("OrganizationCode")).thenReturn(20L);
        when(resultSet.getString("RoleDescription")).thenReturn("ROLE");
        when(resultSet.getObject("FlowId")).thenReturn(30L);
        when(resultSet.getObject("EntityId")).thenReturn(40L);
        when(resultSet.getTimestamp("Datastamp")).thenReturn(null);
        when(resultSet.getString("CustomerOrganizationCode")).thenReturn("CUST");
        when(resultSet.getString("TelephoneNumber")).thenReturn("123");
        when(resultSet.getString("UserCode")).thenReturn("user01");
        when(resultSet.getObject("UserCustomerOrganizationId")).thenReturn(99L);
        when(resultSet.getString("PositionDescription")).thenReturn("POS");
        when(resultSet.getString("UserTypeDescription")).thenReturn("INTERNAL");
        when(resultSet.getString("PkSource")).thenReturn("SRC");
        when(resultSet.getObject("Denominatore")).thenReturn(null);
        when(resultSet.getObject("Penalita")).thenReturn(null);
        when(resultSet.getString("IdErrore")).thenReturn(null);
        when(resultSet.getString("UserTypeCode")).thenReturn("INT");
        when(resultSet.getString("UserDescription")).thenReturn("User Description");
        when(resultSet.getObject("CancelledFlag")).thenReturn(0);
    }

    @Test
    void findById_found_returnsPresent() throws Exception {
        stubSingleRow();
        Optional<UserCustomerOrganizationDTO> result = repo.findById(99L);
        assertThat(result).isPresent();
        assertThat(result.get().userCode()).isEqualTo("user01");
        verify(preparedStatement).setLong(1, 99L);
    }

    @Test
    void findById_notFound_returnsEmpty() throws Exception {
        Optional<UserCustomerOrganizationDTO> result = repo.findById(999L);
        assertThat(result).isEmpty();
    }

    @Test
    void findByUserCode_returnsListOfResults() throws Exception {
        stubSingleRow();
        List<UserCustomerOrganizationDTO> list = repo.findByUserCode("user01");
        assertThat(list).hasSize(1);
        assertThat(list.get(0).userCode()).isEqualTo("user01");
        verify(preparedStatement).setString(1, "user01");
    }

    @Test
    void findByUserCode_noResults_returnsEmptyList() throws Exception {
        List<UserCustomerOrganizationDTO> list = repo.findByUserCode("nobody");
        assertThat(list).isEmpty();
    }

    @Test
    void findActiveByUserCode_setsCorrectParameters() throws Exception {
        repo.findActiveByUserCode("user01");
        verify(preparedStatement).setString(1, "user01");
    }

    @Test
    void findByFlowId_setsCorrectParameters() throws Exception {
        repo.findByFlowId(55L);
        verify(preparedStatement).setLong(1, 55L);
    }

    @Test
    void findByOrganizationCode_setsCorrectParameters() throws Exception {
        repo.findByOrganizationCode(77L);
        verify(preparedStatement).setLong(1, 77L);
    }

    @Test
    void findActiveByOrganizationCode_setsCorrectParameters() throws Exception {
        repo.findActiveByOrganizationCode(88L);
        verify(preparedStatement).setLong(1, 88L);
    }

    @Test
    void findByKeys_setsCorrectParameters() throws Exception {
        repo.findByKeys("user01", "CUST01");
        verify(preparedStatement).setString(1, "user01");
        verify(preparedStatement).setString(2, "CUST01");
    }

    @Test
    void findActiveByKeys_setsCorrectParameters() throws Exception {
        repo.findActiveByKeys("user01", "CUST01");
        verify(preparedStatement).setString(1, "user01");
        verify(preparedStatement).setString(2, "CUST01");
    }

    @Test
    void findByUserCodePaged_setsCorrectParameters() throws Exception {
        repo.findByUserCodePaged("user01", 10, 20);
        verify(preparedStatement).setString(1, "user01");
        verify(preparedStatement).setInt(2, 10);
        verify(preparedStatement).setInt(3, 20);
    }

    @Test
    void schema_blank_throwsIllegalState() throws Exception {
        setField(repo, "schema", "");
        assertThatThrownBy(() -> repo.findById(1L))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("databricks.schema");
    }

    private static void setField(Object obj, String name, Object value) throws Exception {
        Field f = findField(obj.getClass(), name);
        f.setAccessible(true);
        f.set(obj, value);
    }

    private static Field findField(Class<?> clazz, String name) throws NoSuchFieldException {
        try { return clazz.getDeclaredField(name); }
        catch (NoSuchFieldException e) {
            if (clazz.getSuperclass() != null) return findField(clazz.getSuperclass(), name);
            throw e;
        }
    }
}
