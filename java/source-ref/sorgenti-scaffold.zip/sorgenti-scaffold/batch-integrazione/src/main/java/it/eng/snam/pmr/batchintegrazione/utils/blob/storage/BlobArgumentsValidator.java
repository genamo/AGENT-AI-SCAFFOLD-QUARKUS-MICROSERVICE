package it.eng.snam.pmr.batchintegrazione.utils.blob.storage;

import org.apache.commons.lang3.StringUtils;

import it.eng.snam.pmr.batchintegrazione.config.properties.BlobStorageProperties;
import lombok.experimental.UtilityClass;

@UtilityClass
public class BlobArgumentsValidator {

    public void validateConnection(BlobStorageProperties properties) {
        if (StringUtils.isBlank(properties.accountName()))
            throw new IllegalArgumentException("'accountName' must be valued properly.");

        if (StringUtils.isBlank(properties.accountKey()))
            throw new IllegalArgumentException("'accountKey' must be valued properly.");
    }
}
