package it.eng.snam.pmr.batchintegrazionedg.test.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.TestProfile;
import it.eng.snam.pmr.batchintegrazionedg.service.TopicService;
import it.eng.snam.pmr.batchintegrazionedg.utils.Constants.Topic;
import jakarta.inject.Inject;

@QuarkusTest
@TestProfile(NoSecurityTestProfile.class)
class TopicServiceTest {

    @Inject
    TopicService topicService;

    @Test
    void getRealTopic_integrazioneFlussi_returnsPrefixedTopic() {
        String real = topicService.getRealTopic(Topic.INTEGRAZIONE_FLUSSI_TOPIC);
        assertNotNull(real);
        assertTrue(real.contains("integrazioneflussi"));
        assertTrue(real.startsWith("test-"));
    }

   

    @Test
    void getRealTopic_cacheWorks_returnsSameResult() {
        String first = topicService.getRealTopic(Topic.INTEGRAZIONE_FLUSSI_TOPIC);
        String second = topicService.getRealTopic(Topic.INTEGRAZIONE_FLUSSI_TOPIC);
        assertEquals(first, second);
    }

    @Test
    void getRealTopic_nullTopicName_throwsIllegalArgument() {
        assertThrows(IllegalArgumentException.class,
                () -> topicService.getRealTopic(null));
    }

    @Test
    void getRealTopic_blankTopicName_throwsIllegalArgument() {
        assertThrows(IllegalArgumentException.class,
                () -> topicService.getRealTopic("  "));
    }

    @Test
    void getRealTopic_unknownTopic_throwsIllegalArgument() {
        assertThrows(IllegalArgumentException.class,
                () -> topicService.getRealTopic("non-esiste"));
    }
}
