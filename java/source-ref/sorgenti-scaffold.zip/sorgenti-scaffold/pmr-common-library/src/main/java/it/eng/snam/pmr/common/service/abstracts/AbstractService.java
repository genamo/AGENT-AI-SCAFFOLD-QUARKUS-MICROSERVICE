package it.eng.snam.pmr.common.service.abstracts;

import java.util.Optional;
import java.util.function.Supplier;

import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

import com.fasterxml.jackson.core.type.TypeReference;

import it.eng.snam.pmr.common.dto.ResponseContext;
import it.eng.snam.pmr.common.exception.GenericException;
import it.eng.snam.pmr.common.exception.RemoteCallException;
import it.eng.snam.pmr.common.filter.RequestHeadersContext;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.JsonUtils;
import it.eng.snam.pmr.common.util.dto.ResponseContextInitializer;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import it.eng.snam.pmr.common.util.retry.RetryableProcessDomain;
import it.eng.snam.pmr.common.util.retry.RetryableProcessExecutor;
import jakarta.inject.Inject;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.ServiceUnavailableException;
import jakarta.ws.rs.core.Response;

public abstract class AbstractService {

    @Inject
    protected RequestHeadersContext headersCtx;

    protected <T> T executeClientCall(Supplier<Response> clientCall, TypeReference<GenericResponse<T>> typeReference) {
        Response response = executeRetryableClientCall(clientCall);
        return handleGenericResponse(response, typeReference);
    }

    protected <T> T executeRawClientCall(Supplier<Response> clientCall, TypeReference<T> typeReference) {
        Response response = executeRetryableClientCall(clientCall);
        return handleRawResponse(response, typeReference);
    }

    private Response executeRetryableClientCall(Supplier<Response> clientCall) {
        return RetryableProcessExecutor.execute(RetryableProcessDomain.REST_CLIENT, clientCall::get);
    }

    private <T> T handleGenericResponse(Response response, TypeReference<GenericResponse<T>> typeReference) {
        ResponseContext context = ResponseContextInitializer.init(response);
        if (context.emptyBody())
            return null;

        GenericResponse<T> genericResponse = JsonUtils.readValue(context.getOperation(), context.getBody(), typeReference);
        if (context.isOk())
            return genericResponse.getData();

        GenericResponse.Message message = genericResponse.getMessage();
        String errorDescription = message != null ? message.getMessageDescription() : "";
        logError(context, message);
        throwMapped(context.getOperation(), context.getStatus(), errorDescription);

        return null;
    }

    private <T> T handleRawResponse(Response response, TypeReference<T> typeReference) {
        ResponseContext context = ResponseContextInitializer.init(response);
        if (context.emptyBody())
            return null;

        if (context.isOk())
            return JsonUtils.readValue(context.getOperation(), context.getBody(), typeReference);

        logError(context, context.getBody());
        throwMapped(context.getOperation(), context.getStatus(), context.getBody());

        return null;
    }

    private void logError(ResponseContext context, Object body) {
        String keyLogic = contextOrMdc(() -> headersCtx.getKeyLogic(), CommonConstants.LogParams.KL);
        String transactionId = contextOrMdc(() -> headersCtx.getTransactionId(), CommonConstants.LogParams.TN);
        String processType = contextOrMdc(() -> headersCtx.getProcessType(), CommonConstants.LogParams.PT);

        Logger.getLogger(getClass())
              .errorf("%s failed. KL=%s TID=%s PT=%s HTTP=%d body=%s",
                      context.getOperation(), keyLogic, transactionId, processType, context.getStatus(), body);
    }

    private String contextOrMdc(Supplier<String> contextSupplier, String mdcKey) {
        Supplier<String> mdcSupplier = () -> StringUtils.defaultString(MdcManager.getHeader(mdcKey));
        try {
            return Optional.ofNullable(contextSupplier.get()).filter(StringUtils::isNotBlank)
                           .orElse(mdcSupplier.get());
        } catch (Exception ignored) {
            // RequestScoped non attivo: fallback su MDC
            return mdcSupplier.get();
        }
    }

    private void throwMapped(String operation, int status, String errorDescription) {
        if (status == Response.Status.BAD_REQUEST.getStatusCode())
            throw new BadRequestException(operation + ": illegal request. " + errorDescription);

        if (status == Response.Status.UNAUTHORIZED.getStatusCode())
            throw new NotAuthorizedException(operation + ": unauthorized request. " + errorDescription);

        if (status == Response.Status.FORBIDDEN.getStatusCode())
            throw new ForbiddenException(operation + ": unauthorized request. " + errorDescription);

        if (status == Response.Status.NOT_FOUND.getStatusCode())
            throw new NotFoundException(operation + ": resource not found. " + errorDescription);

        if (status == Response.Status.INTERNAL_SERVER_ERROR.getStatusCode())
            throw new InternalServerErrorException(operation + ": internal server error. " + errorDescription);

        if (status == Response.Status.SERVICE_UNAVAILABLE.getStatusCode())
            throw new ServiceUnavailableException(operation + ": service unavailable. " + errorDescription);

        if (status == Response.Status.BAD_GATEWAY.getStatusCode())
            throw new RemoteCallException(operation + ": bad gateway. " + errorDescription);

        throw new GenericException(operation + ": generic error. " + errorDescription);
    }
}