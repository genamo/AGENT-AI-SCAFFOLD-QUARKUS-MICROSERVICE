package it.eng.snam.pmr.batchintegrazione.resource;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringFlussiDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringFlussiSearchDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringFlussiService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import it.eng.snam.pmr.common.annotation.AuthzRead;
import it.eng.snam.pmr.common.annotation.AuthzWrite;
import it.eng.snam.pmr.common.annotation.LogPmr;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.response.swagger.CommonApiErrorResponses;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;

@Path("/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RunOnVirtualThread
@LogPmr
@RequiredArgsConstructor(onConstructor_ = @Inject)
@Tag(name = "MonitoringFlussiResource", description = "API per il monitoraggio e la consultazione dei flussi")
public class MonitoringFlussiResource {

	private final MonitoringFlussiService service;
	private final Utility utility;

	@GET
	@AuthzRead
	@Path("/bi_monitoring-flussi_getall")
	@Operation(summary = "Recupera tutti i monitoring flussi")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Lista monitoring flussi recuperata correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringFlussiListGenericResponse.class)))
	public Response getAll() {
		return handle(() -> utility.okOrEmpty(service.getAll()));
	}

	@GET
	@Path("/bi_monitoring-flussi_id/{id}")
	@AuthzRead
	@Operation(summary = "Recupera un monitoring flusso tramite identificativo")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Monitoring flusso recuperato correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringFlussiGenericResponse.class)))
	public Response getById(

			@PathParam("id") @Parameter(description = "Identificativo del monitoring flusso", required = true, example = "1", schema = @Schema(type = SchemaType.INTEGER)) Long id

	) {

		Response validationError = validateId(id);
		if (validationError != null) {
			return validationError;
		}

		return handle(() -> {
			Optional<MonitoringFlussiDTO> opt = service.getById(id);
			return utility.okOrNotFound(opt, buildIdNotFoundMessage(id));
		});
	}

	@GET
	@Path("/bi_monitoring-flussi_transaction/{transactionId}")
	@AuthzRead
	@Operation(summary = "Recupera un monitoring flusso tramite transactionId")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Monitoring flusso recuperato correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringFlussiGenericResponse.class)))
	public Response getByTransactionId(

			@PathParam("transactionId") @Parameter(description = "Transaction identifier", required = true, example = "TX123456", schema = @Schema(type = SchemaType.STRING)) String txId

	) {

		Response validationError = validateTransactionId(txId);
		if (validationError != null) {
			return validationError;
		}

		return handle(() -> {
			Optional<MonitoringFlussiDTO> opt = service.getByTransactionId(txId);
			return utility.okOrNotFound(opt, buildTransactionNotFoundMessage(txId));
		});
	}

	@GET
	@Path("/bi_monitoring-flussi_last-executions")
	@AuthzRead
	@Operation(summary = "Recupera le ultime esecuzioni dei flussi")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Ultime esecuzioni recuperate correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringFlussiListGenericResponse.class)))
	public Response getLastExecutions(

			@QueryParam("limit") @Parameter(description = "Numero massimo risultati", required = false, example = "10", schema = @Schema(type = SchemaType.INTEGER)) Integer limit

	) {

		Integer validatedLimit = normalizeLimit(limit);
		if (validatedLimit == null) {
			return utility.badRequest("Query param 'limit' deve essere > 0");
		}

		return handle(() -> utility.okOrEmpty(service.getLastExecutions(validatedLimit)));
	}

	@GET
	@Path("/bi_monitoring-flussi_period")
	@AuthzRead
	@Operation(summary = "Recupera i monitoring flussi filtrati per periodo")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Monitoring flussi recuperati correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringFlussiListGenericResponse.class)))
	public Response getByPeriod(

			@QueryParam("monthNumber") @Parameter(description = "Numero del mese", required = false, example = "7") Integer month,

			@QueryParam("dayNumber") @Parameter(description = "Numero del giorno", required = false, example = "15") Integer day

	) {
		return handle(() -> utility.okOrEmpty(service.getByPeriod(month, day)));
	}

	@POST
	@Path("/bi_monitoring-flussi_save")
	@AuthzWrite
	@Operation(summary = "Salva un nuovo monitoring flusso")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Monitoring flusso salvato correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringFlussiGenericResponse.class)))
	public Response save(

			@RequestBody(description = "Payload monitoring flusso", required = true, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringFlussiDTO.class))) MonitoringFlussiDTO dto

	) {

		if (dto == null) {
			return utility.badRequest("Body mancante o non valido");
		}

		return handle(() -> utility.ok(service.save(dto)));
	}

	@POST
	@Path("/bi_monitoring-flussi_search")
	@AuthzRead
	@Operation(summary = "Ricerca monitoring flussi tramite criteri avanzati")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "Ricerca completata correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringFlussiListGenericResponse.class)))
	public Response findByCustomSearch(

			@RequestBody(description = "Criteri di ricerca", required = true, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MonitoringFlussiSearchDTO.class))) MonitoringFlussiSearchDTO searchDto

	) {

		if (searchDto == null) {
			return utility.badRequest("Body di ricerca mancante o non valido");
		}

		return handle(() -> utility.okOrEmpty(service.findByCustomSearch(searchDto)));
	}

	private Response handle(Supplier<Response> action) {
		try {
			return action.get();
		} catch (IllegalArgumentException e) {
			return utility.badRequest(e.getMessage());
		} catch (RemoteCallException e) {
			return utility.badGateway(e);
		}
	}

	private Response validateId(Long id) {
		if (id == null || id <= 0) {
			return utility.badRequest("Path param 'id' non valido");
		}
		return null;
	}

	private Response validateTransactionId(String transactionId) {
		if (transactionId == null || transactionId.isBlank()) {
			return utility.badRequest("Path param 'transactionId' non valido");
		}
		return null;
	}

	private Integer normalizeLimit(Integer limit) {
		int lim = (limit == null) ? 10 : limit;
		return lim > 0 ? lim : null;
	}

	private String buildIdNotFoundMessage(Long id) {
		return "Nessun monitoring flusso trovato per id=" + id;
	}

	private String buildTransactionNotFoundMessage(String txId) {
		return "Nessun monitoring flusso trovato per transactionId=" + txId;
	}

	@Schema(name = "MonitoringFlussiGenericResponse")
	public static class MonitoringFlussiGenericResponse extends GenericResponse<MonitoringFlussiDTO> {

		private static final long serialVersionUID = 1L;
	}

	@Schema(name = "MonitoringFlussiListGenericResponse")
	public static class MonitoringFlussiListGenericResponse extends GenericResponse<List<MonitoringFlussiDTO>> {

		private static final long serialVersionUID = 1L;
	}
}
