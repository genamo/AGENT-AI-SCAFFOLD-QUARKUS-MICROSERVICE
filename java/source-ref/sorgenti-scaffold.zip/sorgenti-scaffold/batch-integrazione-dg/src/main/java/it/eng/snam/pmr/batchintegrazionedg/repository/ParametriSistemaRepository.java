package it.eng.snam.pmr.batchintegrazionedg.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import it.eng.snam.pmr.batchintegrazionedg.domain.IntegrazioneParametriSistema;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

@ApplicationScoped
public class ParametriSistemaRepository implements PanacheRepository<IntegrazioneParametriSistema> {

    @Inject
    EntityManager em;

    public List<IntegrazioneParametriSistema> findParametriSistema(LocalDate dataInput, List<String> codiceList) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<IntegrazioneParametriSistema> cq = cb.createQuery(IntegrazioneParametriSistema.class);
        Root<IntegrazioneParametriSistema> root = cq.from(IntegrazioneParametriSistema.class);

        List<Predicate> predicates = new ArrayList<>();

        predicates.add(cb.lessThanOrEqualTo(root.get("dataInizio"), dataInput));
        predicates.add(cb.greaterThanOrEqualTo(root.get("dataFine"), dataInput));
        predicates.add(cb.equal(root.get("isDeleted"), 0));

        if (codiceList != null && !codiceList.isEmpty()) {
            predicates.add(root.get("codice").in(codiceList));
        }

        cq.select(root).where(predicates.toArray(new Predicate[0]));

        return em.createQuery(cq).getResultList();
    }
}
