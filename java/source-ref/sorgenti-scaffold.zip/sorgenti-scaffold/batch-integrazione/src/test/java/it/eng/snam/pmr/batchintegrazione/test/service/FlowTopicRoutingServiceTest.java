package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Map;

import org.junit.jupiter.api.Test;

import it.eng.snam.pmr.batchintegrazione.service.FlowTopicRoutingService;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;

class FlowTopicRoutingServiceTest {

    private final FlowTopicRoutingService service = new FlowTopicRoutingService();

    @Test
    void resolveTopic_supportedFlows_returnExpectedTopics() {
        Map<String, String> expected = Map.ofEntries(
            Map.entry(Constants.Flussi.ANAG_REMI_FLOW, Constants.Topic.PMR001A_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ANAG_CLIENTI_FLOW, Constants.Topic.PMR001B_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ASS_REMI_CLIENTI_FLOW, Constants.Topic.PMR001C_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ASS_REMI_TITOLARI_FLOW, Constants.Topic.PMR001D_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ASS_REMI_AOP_FLOW, Constants.Topic.PMR001E_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ASS_STATO_REMI_FLOW, Constants.Topic.PMR001F_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ASS_REMI_TIPO_BILANCIO_TECNICO_FLOW, Constants.Topic.PMR001G_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ANAG_AREA_TECNICA_FLOW, Constants.Topic.PMR001H_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ANAG_POLO_FLOW, Constants.Topic.PMR001I_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ANAG_MACRO_POLO_FLOW, Constants.Topic.PMR001L_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.CONTATTO_FLOW, Constants.Topic.PMR001M_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ANAG_RAGGRUPPAMENTI_FLOW, Constants.Topic.PMR001N_SUMMER_IN_TOPIC),
            Map.entry(Constants.Flussi.ASS_RAGGRUPPAMENTI_REMI_FLOW, Constants.Topic.PMR001O_SUMMER_IN_TOPIC)
        );

        expected.forEach((flow, topic) ->
            assertEquals(topic, service.resolveTopic(flow), "flow=" + flow)
        );
    }

    @Test
    void resolveTopic_unknownFlow_throwsIllegalArgumentException() {
        IllegalArgumentException ex = assertThrows(
            IllegalArgumentException.class,
            () -> service.resolveTopic("UNKNOWN_FLOW")
        );

        assertEquals("Flow non supportato: UNKNOWN_FLOW", ex.getMessage());
    }

    @Test
    void resolveTopic_nullFlow_throwsNullPointerException() {
        assertThrows(
            NullPointerException.class,
            () -> service.resolveTopic(null)
        );
    }

}
