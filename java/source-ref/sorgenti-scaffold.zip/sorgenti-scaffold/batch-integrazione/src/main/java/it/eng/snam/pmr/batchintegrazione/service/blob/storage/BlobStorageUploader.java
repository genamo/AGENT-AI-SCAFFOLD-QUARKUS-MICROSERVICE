package it.eng.snam.pmr.batchintegrazione.service.blob.storage;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;

import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.BlobUploadStatus;
import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.FileDataContext;
import it.eng.snam.pmr.batchintegrazione.utils.blob.storage.BlobContainerNormalizer;
import it.eng.snam.pmr.batchintegrazione.utils.blob.storage.BlobNameNormalizer;
import it.eng.snam.pmr.batchintegrazione.utils.blob.storage.BlobStorageExecutor;
import it.eng.snam.pmr.batchintegrazione.utils.blob.storage.BlobUploadStatusInitializer;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class BlobStorageUploader {

    private final BlobServiceClient blobServiceClient;

    public BlobUploadStatus uploadAndVerify(FileDataContext resource) {
        String containerName = BlobContainerNormalizer.normalize(resource.getExecutioner());
        BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(containerName);
        log.debug("Container URL: {}", containerClient.getBlobContainerUrl());
        containerClient.createIfNotExists();

        String blobName = BlobNameNormalizer.normalize(resource.getActivity(), resource.getFileName());
        BlobClient blobClient = containerClient.getBlobClient(blobName);
        log.debug("Blob URL: {}", blobClient.getBlobUrl());
        log.info("Creating new resource to Blob Storage. containerName={}, blobName={}", containerName, blobName);

        log.info("Writing ZIP to Blob Storage");
        BlobStorageExecutor.upload(resource, blobClient);

        log.info("Verifying ZIP writing");
        BlobStorageExecutor.verifyWriterCompleted(resource, blobClient);

        log.info("Attaching metadata to ZIP");
        BlobStorageExecutor.applyBlobProperties(resource, blobClient);

        log.info("Checking ZIP existence");
        boolean exists = blobClient.exists();

        log.info("Blob upload finished. exists={}", exists);
        return BlobUploadStatusInitializer.initialize(exists, blobName, containerName);
    }
}