package it.eng.snam.pmr.common.service.jwt;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.auth0.jwk.JwkProvider;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;

import it.eng.snam.pmr.common.config.jwt.CompositeJwkProvider;
import it.eng.snam.pmr.common.config.jwt.JwksRsaKeyProvider;
import it.eng.snam.pmr.common.config.jwt.JwtSecurityConfig;
import it.eng.snam.pmr.common.config.jwt.Provider;
import it.eng.snam.pmr.common.config.jwt.TrustedJwtVerifier;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.Utility;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class JwtVerificationService {

    private final JwtSecurityConfig config;
    private final CachedJwkProviderFactory jwkProviderFactory;
    private final Utility utility;

    private Map<String, TrustedJwtVerifier> verifiersByIssuer = Map.of();

    @PostConstruct
    void initialize() {
        validateGlobalConfiguration();

        Map<String, TrustedJwtVerifier> initializedVerifiers = new HashMap<>();
        config.providers().forEach((providerName, providerConfig) -> {
            validateProviderConfiguration(providerName, providerConfig);

            TrustedJwtVerifier trustedVerifier = createVerifier(providerName, providerConfig);
            TrustedJwtVerifier previous = initializedVerifiers.put(providerConfig.issuer(), trustedVerifier);
            if (previous != null)
                throw new IllegalStateException("Duplicate JWT issuer configured: " + providerConfig.issuer());

            log.info("JWT provider initialized. " + "name={}, issuer={}, audiences={}, jwksUris={}",
                     providerName, providerConfig.issuer(), providerConfig.audiences(), providerConfig.jwksUris());
        });

        verifiersByIssuer = Map.copyOf(initializedVerifiers);
    }

    public DecodedJWT verify(String bearer) {
        String token = AuthorizationUtils.extractToken(bearer);

        /*
         * Questa prima decodifica non verifica il token.
         * Serve esclusivamente per scegliere il verifier associato
         * all'issuer dichiarato.
         */
        String unverifiedIssuer = readUnverifiedIssuer(token);
        TrustedJwtVerifier trustedVerifier = verifiersByIssuer.get(unverifiedIssuer);
        if (trustedVerifier == null) {
            log.warn("Untrusted JWT issuer: {}", unverifiedIssuer);
            String errorMessage = "Untrusted JWT issuer";
            throw new NotAuthorizedException(errorMessage, unathorizedResponse(errorMessage));
        }

        try {
            DecodedJWT verifiedJwt = trustedVerifier.verifier().verify(token);
            log.debug("JWT successfully verified. provider={}, issuer={}, kid={}, subject={}",
                      trustedVerifier.providerName(), verifiedJwt.getIssuer(), verifiedJwt.getKeyId(), verifiedJwt.getSubject());

            return verifiedJwt;
        } catch (JWTVerificationException exception) {
            log.warn("JWT verification failed. provider={}, issuer={}, reason={}",
                     trustedVerifier.providerName(), unverifiedIssuer, exception.getMessage());
            String errorMessage = "Invalid or expired JWT";
            throw new NotAuthorizedException(errorMessage, exception, unathorizedResponse(errorMessage));
        } catch (NotAuthorizedException exception) {
            String errorMessage = exception.getMessage();
            throw new NotAuthorizedException(errorMessage, exception, unathorizedResponse(errorMessage));
        } catch (RuntimeException exception) {
            log.error("Unexpected JWT verification error. provider={}, issuer={}",
                      trustedVerifier.providerName(), unverifiedIssuer, exception);
            String errorMessage = "Unable to verify JWT";
            throw new NotAuthorizedException(errorMessage, exception, unathorizedResponse(errorMessage));
        }
    }

    private TrustedJwtVerifier createVerifier(String providerName, Provider providerConfig) {
        List<JwkProvider> providers = providerConfig.jwksUris().stream().map(jwkProviderFactory::create).toList();
        CompositeJwkProvider compositeJwkProvider = new CompositeJwkProvider(providers);
        JwksRsaKeyProvider rsaKeyProvider = new JwksRsaKeyProvider(compositeJwkProvider);

        Algorithm algorithm = Algorithm.RSA256(rsaKeyProvider);
        JWTVerifier verifier = JWT.require(algorithm)
                                  /*
                                   * Verifica che l'issuer del token coincida con
                                   * quello associato alle chiavi utilizzate.
                                   */
                                  .withIssuer(providerConfig.issuer())
                                  /*
                                   * È sufficiente almeno una corrispondenza fra
                                   * le audience del token e quelle configurate.
                                   */
                                  .withAnyOfAudience(providerConfig.audiences().toArray(String[]::new))
                                  /*
                                   * I tre claim devono essere presenti.
                                   * java-jwt ne verifica anche la validità temporale.
                                   */
                                  .withClaimPresence("iat")
                                  .withClaimPresence("nbf")
                                  .withClaimPresence("exp")
                                  /*
                                   * Devono essere presenti e contenere stringhe
                                   * non nulle e non vuote.
                                   */
                                  .withClaim("sub", this::isNonBlankStringClaim)
                                  .withClaim("unique_name", this::isNonBlankStringClaim)
                                  .withClaim("UserID", this::isNonBlankStringClaim)
                                  /*
                                   * Tolleranza temporale per differenze fra gli orologi.
                                   * Si applica a exp, nbf e iat.
                                   */
                                  .acceptLeeway(config.clockSkewSeconds())
                                  .build();

        return new TrustedJwtVerifier(providerName, providerConfig.issuer(), verifier);
    }

    private boolean isNonBlankStringClaim(Claim claim, DecodedJWT jwt) {
        return StringUtils.isNotBlank(claim.asString());
    }

    private String readUnverifiedIssuer(String token) {
        try {
            DecodedJWT decodedJWT = JWT.decode(token);
            String issuer = decodedJWT.getIssuer();

            if (issuer == null || issuer.isBlank()) {
                String errorMessage = "JWT issuer is missing";
                throw new NotAuthorizedException(errorMessage, unathorizedResponse(errorMessage));
            }

            return issuer;
        } catch (JWTDecodeException exception) {
            String errorMessage = "Invalid JWT structure";
            throw new NotAuthorizedException(errorMessage, exception, unathorizedResponse(errorMessage));
        }
    }

    private void validateGlobalConfiguration() {
        if (config.clockSkewSeconds() < 0)
            throw new IllegalStateException("JWT clock skew cannot be negative");

        if (config.providers() == null || config.providers().isEmpty())
            throw new IllegalStateException("No trusted JWT providers configured");
    }

    private void validateProviderConfiguration(String providerName, Provider provider) {
        if (providerName == null || providerName.isBlank())
            throw new IllegalStateException("JWT provider name is null or blank");

        if (provider == null)
            throw new IllegalStateException("JWT provider configuration is null: " + providerName);

        if (provider.issuer() == null || provider.issuer().isBlank())
            throw new IllegalStateException("Missing issuer for JWT provider: " + providerName);

        validateAudiences(providerName, provider.audiences());

        validateJwksUris(providerName, provider.jwksUris());
    }

    private void validateAudiences(String providerName, Set<String> audiences) {
        if (audiences == null || audiences.isEmpty())
            throw new IllegalStateException("Missing audiences for JWT provider: " + providerName);

        boolean containsInvalidAudience = audiences.stream().anyMatch(value -> value == null || value.isBlank());
        if (containsInvalidAudience)
            throw new IllegalStateException("Invalid audience configured for JWT provider: " + providerName);
    }

    private void validateJwksUris(String providerName, List<String> jwksUris) {
        if (jwksUris == null || jwksUris.isEmpty())
            throw new IllegalStateException("Missing JWKS URIs for JWT provider: " + providerName);

        boolean containsInvalidUri = jwksUris.stream().anyMatch(value -> value == null || value.isBlank());
        if (containsInvalidUri)
            throw new IllegalStateException("Invalid JWKS URI configured for JWT provider: " + providerName);
    }

    private Response unathorizedResponse(String message) {
        return utility.errorResponse(message, Response.Status.UNAUTHORIZED);
    }
}