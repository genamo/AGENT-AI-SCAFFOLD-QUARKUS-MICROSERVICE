package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mockStatic;

import java.lang.reflect.Field;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import it.eng.snam.pmr.batchintegrazione.service.abstracts.TopicService;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import it.eng.snam.pmr.batchintegrazione.utils.Constants.Topic;

class TopicServiceTest {

    private TopicService topicService;

    @BeforeEach
    void setUp() throws Exception {
        topicService = new TopicService();
        setPrefix("test-env");
    }

    private void setPrefix(String value) throws Exception {
        Field f = TopicService.class.getDeclaredField("prefix");
        f.setAccessible(true);
        f.set(topicService, value);
    }

    @Test
    void getRealTopic_integrazioneFlussi() {
        String result = topicService.getRealTopic(Constants.Topic.PMR001A_SUMMER_IN_TOPIC);
        assertEquals("test-env-" + Constants.Topic.PMR001A_SUMMER_IN_TOPIC, result);
    }

    @Test
    void getRealTopic_integrazioneBatch() {
        String result = topicService.getRealTopic(Constants.Topic.PMR001A_SUMMER_IN_TOPIC);
        assertEquals("test-env-" + Constants.Topic.PMR001A_SUMMER_IN_TOPIC, result);
    }

    @Test
    void getRealTopic_cacheReused() {
        String r1 = topicService.getRealTopic(Constants.Topic.PMR001A_SUMMER_IN_TOPIC);
        String r2 = topicService.getRealTopic(Constants.Topic.PMR001A_SUMMER_IN_TOPIC);
        assertEquals(r1, r2);
    }

    @Test
    void getRealTopic_nullTopic_throwsIllegalArgument() {
        assertThrows(IllegalArgumentException.class, () -> topicService.getRealTopic(null));
    }

    @Test
    void getRealTopic_blankTopic_throwsIllegalArgument() {
        assertThrows(IllegalArgumentException.class, () -> topicService.getRealTopic("   "));
    }

    @Test
    void getRealTopic_unknownTopic_throwsIllegalArgument() {
        assertThrows(IllegalArgumentException.class,
                () -> topicService.getRealTopic("non-existent-topic"));
    }

    @Test
    void getRealTopic_emptyPrefix_throwsIllegalState() throws Exception {
        setPrefix("");
        assertThrows(IllegalStateException.class,
                () -> topicService.getRealTopic(Constants.Topic.PMR001A_SUMMER_IN_TOPIC));
    }

    @Test
    void getRealTopic_blankPrefix_throwsIllegalState() throws Exception {
        setPrefix("   ");
        assertThrows(IllegalStateException.class,
                () -> topicService.getRealTopic(Constants.Topic.PMR001A_SUMMER_IN_TOPIC));
    }

    @Test
    void getRealTopic_cacheInitFails_logsWarningAndThrows() {
        try (MockedStatic<Topic> mockTopic = mockStatic(Topic.class)) {
            mockTopic.when(Topic::getAllTopicsValue).thenThrow(new RuntimeException("init failure"));
            assertThrows(IllegalArgumentException.class,
                    () -> topicService.getRealTopic(Constants.Topic.PMR001A_SUMMER_IN_TOPIC));
        }
    }
}
