package it.eng.snam.pmr.batchintegrazione.dto.flussi;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagRemiDto;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.ValidationInterface;
import lombok.Builder;

@Builder
public record AnagRemiPayloadDto(

		@JsonProperty("summer_transaction_id") String summerTransactionId,
		@JsonProperty("operation") 
        String operation,
		List<AnagRemiDto> data

) implements ValidationInterface {

	@Override
	public String getCorrelationId() {
		return summerTransactionId;
	}
	
	@Override
    public int getElementNumber() {
        return data != null ? data.size() : 0;
    }

}
