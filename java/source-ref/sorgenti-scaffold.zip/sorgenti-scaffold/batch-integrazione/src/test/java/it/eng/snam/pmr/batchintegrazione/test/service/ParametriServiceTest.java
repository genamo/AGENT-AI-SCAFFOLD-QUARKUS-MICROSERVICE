package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.IntegrazioneParametriSistemaDTO;
import it.eng.snam.pmr.batchintegrazione.dto.ParametriSistemaRequestSearch;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.ParametriService;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class ParametriServiceTest {

    @Mock BatchIntegrazioneDgClient client;
    @Mock ObjectMapper objectMapper;
    @Mock RequestHeadersContext headersCtx;
    @InjectMocks ParametriService service;

    private ParametriSistemaRequestSearch buildRequest() {
        return ParametriSistemaRequestSearch.builder().build();
    }

    // ---- searchParametri ----

    @Test
    void searchParametri_204_returnsEmptyList() {
        Response resp = mockResponse(204);
        when(client.searchParametri(any())).thenReturn(resp);

        List<IntegrazioneParametriSistemaDTO> result = service.searchParametri(buildRequest());
        assertTrue(result.isEmpty());
    }

    @Test
    void searchParametri_200_emptyBody_returnsEmptyList() {
        Response resp = mockResponse(200);
        when(resp.readEntity(String.class)).thenReturn("");
        when(client.searchParametri(any())).thenReturn(resp);

        List<IntegrazioneParametriSistemaDTO> result = service.searchParametri(buildRequest());
        assertTrue(result.isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void searchParametri_200_validJson_returnsList() throws Exception {
        Response resp = mockResponse(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(client.searchParametri(any())).thenReturn(resp);

        IntegrazioneParametriSistemaDTO dto = new IntegrazioneParametriSistemaDTO(
                1L, "COD", "VAL", null, null, null, null, null);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(dto));

        List<IntegrazioneParametriSistemaDTO> result = service.searchParametri(buildRequest());
        assertEquals(1, result.size());
        assertEquals("COD", result.get(0).codice());
    }

    @Test
    void searchParametri_400_withBody_throwsIllegalArgument() {
        Response resp = mockResponse(400);
        when(resp.hasEntity()).thenReturn(true);
        when(resp.readEntity(String.class)).thenReturn("campo obbligatorio");
        when(client.searchParametri(any())).thenReturn(resp);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> service.searchParametri(buildRequest()));
        assertTrue(ex.getMessage().contains("campo obbligatorio"));
    }

    @Test
    void searchParametri_400_emptyBody_throwsIllegalArgument() {
        Response resp = mockResponse(400);
        when(resp.hasEntity()).thenReturn(false);
        when(client.searchParametri(any())).thenReturn(resp);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> service.searchParametri(buildRequest()));
        assertTrue(ex.getMessage().contains("Bad Request"));
    }

    @Test
    void searchParametri_500_throwsRemoteCallException() {
        Response resp = mockResponse(500);
        when(resp.hasEntity()).thenReturn(false);
        when(client.searchParametri(any())).thenReturn(resp);
        when(headersCtx.getKeyLogic()).thenReturn("kl");
        when(headersCtx.getTransactionId()).thenReturn("tid");
        when(headersCtx.getProcessType()).thenReturn("BATCH");

        RemoteCallException ex = assertThrows(RemoteCallException.class,
                () -> service.searchParametri(buildRequest()));
        assertTrue(ex.getMessage().contains("HTTP 500"));
    }

    @Test
    void searchParametri_503_throwsRemoteCallException() {
        Response resp = mockResponse(503);
        when(resp.hasEntity()).thenReturn(true);
        when(resp.readEntity(String.class)).thenReturn("unavailable");
        when(client.searchParametri(any())).thenReturn(resp);
        when(headersCtx.getKeyLogic()).thenReturn("kl");
        when(headersCtx.getTransactionId()).thenReturn("tid");
        when(headersCtx.getProcessType()).thenReturn("BATCH");

        RemoteCallException ex = assertThrows(RemoteCallException.class,
                () -> service.searchParametri(buildRequest()));
        assertTrue(ex.getMessage().contains("503"));
    }

    private Response mockResponse(int status) {
        Response resp = mock(Response.class);
        when(resp.getStatus()).thenReturn(status);
        return resp;
    }
}
