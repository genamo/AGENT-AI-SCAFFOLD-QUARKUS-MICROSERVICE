package it.eng.snam.pmr.batchintegrazione.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.DatiPrimariClient;
import it.eng.snam.pmr.batchintegrazione.dto.datiprimari.AnalisiQualitaGasGiornDto;
import it.eng.snam.pmr.batchintegrazione.dto.datiprimari.AnalisiQualitaGasGiornSearchDto;
import it.eng.snam.pmr.batchintegrazione.dto.datiprimari.QualitaGasGiornDto;
import it.eng.snam.pmr.batchintegrazione.dto.datiprimari.QualitaGasGiornSearchDto;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.B2BTokenUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class DatiPrimariService extends AbstractService {

	private static final Logger LOG = Logger.getLogger(DatiPrimariService.class);

	@Inject
	@RestClient
	DatiPrimariClient datiPrimariClient;

	@Inject
	ObjectMapper objectMapper;

	@Inject
	B2BTokenUtils tokenUtil;

	// ======================================================
	// QUALITA GAS GIORN
	// ======================================================

	public List<QualitaGasGiornSearchDto> getAllQualitaGasGiorn() {
		try (Response resp = datiPrimariClient.getAllQualitaGasGiorn()) {
			return handleListRespDatiPrimari(resp, new TypeReference<>() {
			});
		}
	}

	public Optional<QualitaGasGiornSearchDto> findQualitaGasGiornById(Integer codiceAop, LocalDateTime dataIniPre) {

		try (Response resp = datiPrimariClient.findQualitaGasGiornById(codiceAop, dataIniPre)) {

			return handleOptionalRespDatiPrimari(resp, QualitaGasGiornSearchDto.class);
		}
	}

	public QualitaGasGiornDto saveQualitaGasGiorn(QualitaGasGiornDto dto) {

		try (Response resp = datiPrimariClient.saveQualitaGasGiorn(dto)) {

			return handleSaveRespDatiPrimari(resp, QualitaGasGiornDto.class);
		}
	}

	public QualitaGasGiornDto deleteQualitaGasGiorn(Integer codiceAop, LocalDateTime dataIniPre) {

		try (Response resp = datiPrimariClient.deleteQualitaGasGiorn(codiceAop, dataIniPre)) {

			return handleSaveRespDatiPrimari(resp, QualitaGasGiornDto.class);
		}
	}

	public QualitaGasGiornDto restoreQualitaGasGiorn(Integer codiceAop, LocalDateTime dataIniPre) {

		try (Response resp = datiPrimariClient.restoreQualitaGasGiorn(codiceAop, dataIniPre)) {

			return handleSaveRespDatiPrimari(resp, QualitaGasGiornDto.class);
		}
	}

	// ======================================================
	// ANALISI QUALITA GAS GIORN
	// ======================================================

	public List<AnalisiQualitaGasGiornSearchDto> getAllAnalisiQualitaGasGiorn() {
		try (Response resp = datiPrimariClient.getAllAnalisiQualitaGasGiorn()) {
			return handleListRespDatiPrimari(resp, new TypeReference<>() {
			});
		}
	}

	public Optional<AnalisiQualitaGasGiornSearchDto> findAnalisiQualitaGasGiornById(String remiAssoluto, LocalDateTime dataIniAnalisi) {

		try (Response resp = datiPrimariClient.findAnalisiQualitaGasGiornById(remiAssoluto, dataIniAnalisi)) {

			return handleOptionalRespDatiPrimari(resp, AnalisiQualitaGasGiornSearchDto.class);
		}
	}

	public AnalisiQualitaGasGiornDto saveAnalisiQualitaGasGiorn(AnalisiQualitaGasGiornDto dto) {

		try (Response resp = datiPrimariClient.saveAnalisiQualitaGasGiorn(dto)) {

			return handleSaveRespDatiPrimari(resp, AnalisiQualitaGasGiornDto.class);
		}
	}

	public AnalisiQualitaGasGiornDto deleteAnalisiQualitaGasGiorn(String remiAssoluto, LocalDateTime dataIniAnalisi) {

		try (Response resp = datiPrimariClient.deleteAnalisiQualitaGasGiorn(remiAssoluto, dataIniAnalisi)) {

			return handleSaveRespDatiPrimari(resp, AnalisiQualitaGasGiornDto.class);
		}
	}

	public AnalisiQualitaGasGiornDto restoreAnalisiQualitaGasGiorn(String remiAssoluto, LocalDateTime dataIniAnalisi) {

		try (Response resp = datiPrimariClient.restoreAnalisiQualitaGasGiorn(remiAssoluto, dataIniAnalisi)) {

			return handleSaveRespDatiPrimari(resp, AnalisiQualitaGasGiornDto.class);
		}
	}

	// ======================================================
	// Helpers generici
	// ======================================================

	private <T> List<T> handleListRespDatiPrimari(Response respDatiPrimari, TypeReference<List<T>> refDatiPrimari) {

		int status = respDatiPrimari.getStatus();

		if (status == Response.Status.NO_CONTENT.getStatusCode()) {
			return List.of();
		}

		if (status == Response.Status.OK.getStatusCode()) {
			String json = respDatiPrimari.readEntity(String.class);

			if (json == null || json.isBlank()) {
				return List.of();
			}

			try {
				return objectMapper.readValue(json, refDatiPrimari);
			} catch (Exception e) {
				throw new RemoteCallException("Impossibile deserializzare la risposta", e);
			}
		}

		if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
			String body = safeReadBody(respDatiPrimari);

			throw new IllegalArgumentException("Richiesta non valida: " + extractErrorDetail(body));
		}

		throw remoteError("dati-primari", status, respDatiPrimari);
	}

	private <T> Optional<T> handleOptionalRespDatiPrimari(Response respDatiPrimari, Class<T> typeDatiPrimari) {

		int status = respDatiPrimari.getStatus();

		if (status == Response.Status.NOT_FOUND.getStatusCode() || status == Response.Status.NO_CONTENT.getStatusCode()) {

			return Optional.empty();
		}

		if (status == Response.Status.OK.getStatusCode()) {
			return Optional.ofNullable(respDatiPrimari.readEntity(typeDatiPrimari));
		}

		if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
			String body = safeReadBody(respDatiPrimari);

			throw new IllegalArgumentException("Richiesta non valida: " + extractErrorDetail(body));
		}

		throw remoteError("dati-primari", status, respDatiPrimari);
	}

	private <T> T handleSaveRespDatiPrimari(Response respDatiPrimari, Class<T> typeDatiPrimari) {

		int status = respDatiPrimari.getStatus();

		if (status == Response.Status.OK.getStatusCode() || status == Response.Status.CREATED.getStatusCode()) {

			return respDatiPrimari.readEntity(typeDatiPrimari);
		}

		if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
			String body = safeReadBody(respDatiPrimari);

			throw new IllegalArgumentException("Richiesta non valida: " + extractErrorDetail(body));
		}

		throw remoteError("dati-primari", status, respDatiPrimari);
	}
}