package it.eng.snam.pmr.common.response.swagger;

import java.io.Serial;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import it.eng.snam.pmr.common.dto.page.PageDTO;
import it.eng.snam.pmr.common.response.GenericResponse;

@Schema(name = "PageResponse")
public class PageResponse<T> extends GenericResponse<PageDTO<T>> {
    @Serial
    private static final long serialVersionUID = -7914070223098973045L;
}
