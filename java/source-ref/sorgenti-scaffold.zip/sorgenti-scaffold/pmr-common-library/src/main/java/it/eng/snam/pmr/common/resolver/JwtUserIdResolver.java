package it.eng.snam.pmr.common.resolver;

import com.auth0.jwt.interfaces.DecodedJWT;

import it.eng.snam.pmr.common.util.AuthorizationUtils;

public final class JwtUserIdResolver {

    private JwtUserIdResolver() {}

    public static String resolve(String bearer) {

        if (bearer == null || bearer.isBlank()) {
            return null;
        }

        DecodedJWT jwt = AuthorizationUtils.decode(bearer);
        return AuthorizationUtils.resolveUserId(jwt);
    }
}
