package it.eng.snam.pmr.common.repository;

import it.eng.snam.pmr.common.databricks.DatabricksDS;
import it.eng.snam.pmr.common.databricks.DatabricksRetry;
import it.eng.snam.pmr.common.dto.UserMeterModuleAuthorizationDTO;
import it.eng.snam.pmr.common.mapper.UserMeterModuleAuthorizationJdbcMapper;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class UserMeterModuleAuthorizationRepository {

    @Inject
    @ConfigProperty(name = "databricks.schema")
    String schemaForUsermetermoduleauthorization;

    @Inject
    @DatabricksDS
    DataSource dataSource;

    @Inject
    DatabricksRetry retry;

    private String table() {
        if (schemaForUsermetermoduleauthorization == null || schemaForUsermetermoduleauthorization.isBlank()) {
            throw new IllegalStateException("databricks.schema NOT configured");
        }
        return schemaForUsermetermoduleauthorization + ".usermetermoduleauthorization";
    }

    /**
     * ✅ BASE SELECT CON FILTRO GLOBALE
     */
    private String baseSelectUsermetermoduleauthorization() {
        return """
            SELECT
              UserMeterModuleAuthorizationId,
              UserCode,
              UserId,
              MeterCode,
              MeterId,
              ModuleCode,
              InsertDate,
              UpdateDate,
              OrganizationCode,
              OrganizationId,
              WeakSapCode,
              FlowId,
              EntityId,
              CancelledFlag,
              PkSource,
              Denominatore,
              Penalita,
              IdErrore
            FROM %s
            WHERE ModuleCode = 'PDM'
            """.formatted(table());
    }

    public Optional<UserMeterModuleAuthorizationDTO> findById(long id) {
        String sql = baseSelectUsermetermoduleauthorization() +
                " AND UserMeterModuleAuthorizationId = ?";
        return singleResult(sql, ps -> ps.setLong(1, id));
    }

    public List<UserMeterModuleAuthorizationDTO> findByFlowId(long flowId) {
        String sql = baseSelectUsermetermoduleauthorization() +
                " AND FlowId = ?";
        return listResult(sql, ps -> ps.setLong(1, flowId));
    }

    public List<UserMeterModuleAuthorizationDTO> findByUserCode(String userCode) {
        String sql = baseSelectUsermetermoduleauthorization() +
                " AND UserCode = ?";
        return listResult(sql, ps -> ps.setString(1, userCode));
    }

    public List<UserMeterModuleAuthorizationDTO> findActiveByUserCode(String userCode) {
        String sql = baseSelectUsermetermoduleauthorization() + """
              AND UserCode = ?
              AND (CancelledFlag IS NULL OR CancelledFlag = 0)
            """;

        return listResult(sql, ps -> ps.setString(1, userCode));
    }
    
    public List<UserMeterModuleAuthorizationDTO> findAllActive() {
        String sql = baseSelectUsermetermoduleauthorization() + """
              AND (CancelledFlag IS NULL OR CancelledFlag = 0)
            """;

        return listResult(sql, ps -> {});
    }

    public List<UserMeterModuleAuthorizationDTO> findByKeys(
            String userCode, String meterCode, String moduleCode, String organizationCode) {

        String sql = baseSelectUsermetermoduleauthorization() + """
              AND UserCode = ?
              AND MeterCode = ?
              AND ModuleCode = ?
              AND OrganizationCode = ?
            """;

        return listResult(sql, ps -> {
            ps.setString(1, userCode);
            ps.setString(2, meterCode);
            ps.setString(3, moduleCode);
            ps.setString(4, organizationCode);
        });
    }

    public List<UserMeterModuleAuthorizationDTO> findActiveByKeys(
            String userCode, String meterCode, String moduleCode, String organizationCode) {

        String sql = baseSelectUsermetermoduleauthorization() + """
              AND UserCode = ?
              AND MeterCode = ?
              AND ModuleCode = ?
              AND OrganizationCode = ?
              AND (CancelledFlag IS NULL OR CancelledFlag = 0)
            """;

        return listResult(sql, ps -> {
            ps.setString(1, userCode);
            ps.setString(2, meterCode);
            ps.setString(3, moduleCode);
            ps.setString(4, organizationCode);
        });
    }

    public List<UserMeterModuleAuthorizationDTO> findByUserCodePaged(String userCode, int limit, int offset) {

        String sql = baseSelectUsermetermoduleauthorization() + """
              AND UserCode = ?
            LIMIT ? OFFSET ?
            """;

        return listResult(sql, ps -> {
            ps.setString(1, userCode);
            ps.setInt(2, limit);
            ps.setInt(3, offset);
        });
    }
    
    public List<UserMeterModuleAuthorizationDTO> getAllActiveUsers() {

        String sql = baseSelectUsermetermoduleauthorization() + """
              AND (CancelledFlag IS NULL OR CancelledFlag = 0)
            """;

        return listResult(sql, ps -> {
        
        });
    }

    private Optional<UserMeterModuleAuthorizationDTO> singleResult(
            String sql, SqlConsumer<PreparedStatement> binder) {

        return retry.execute(() -> {
            try (Connection c = dataSource.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {

                binder.accept(ps);

                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) return Optional.empty();
                    return Optional.of(UserMeterModuleAuthorizationJdbcMapper.map(rs));
                }
            }
        });
    }

    private List<UserMeterModuleAuthorizationDTO> listResult(
            String sql, SqlConsumer<PreparedStatement> binder) {

        return retry.execute(() -> {
            try (Connection c = dataSource.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {

                binder.accept(ps);

                try (ResultSet rs = ps.executeQuery()) {
                    return mapAll(rs);
                }
            }
        });
    }

    public List<UserMeterModuleAuthorizationDTO> findActiveByOrganizationCodes(List<String> organizationCodes) {
        if (organizationCodes == null || organizationCodes.isEmpty()) {
            return List.of();
        }

        String placeholders = String.join(", ", java.util.Collections.nCopies(organizationCodes.size(), "?"));

        String sql = baseSelectUsermetermoduleauthorization() + """
              AND OrganizationCode IN (%s)
              AND (CancelledFlag IS NULL OR CancelledFlag = 0)
            """.formatted(placeholders);

        return listResult(sql, ps -> {
            for (int i = 0; i < organizationCodes.size(); i++) {
                ps.setString(i + 1, organizationCodes.get(i));
            }
        });
    }

    
    
    private static List<UserMeterModuleAuthorizationDTO> mapAll(ResultSet rs) throws SQLException {
        List<UserMeterModuleAuthorizationDTO> out = new ArrayList<>();
        while (rs.next()) {
            out.add(UserMeterModuleAuthorizationJdbcMapper.map(rs));
        }
        return out;
    }

    @FunctionalInterface
    interface SqlConsumer<T> {
        void accept(T t) throws SQLException;
    }
}
