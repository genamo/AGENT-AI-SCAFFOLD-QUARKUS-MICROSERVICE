package it.eng.snam.pmr.batchintegrazionedg.mapper;


import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;

import it.eng.snam.pmr.batchintegrazionedg.domain.MonitoringBatch;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringBatchDTO;


@Mapper(componentModel = MappingConstants.ComponentModel.CDI)
public interface MonitoringBatchMapper {

    // Entity -> DTO (DTO NON ha "id": quindi niente mapping su id)
    MonitoringBatchDTO toDto(MonitoringBatch entity);

    // DTO -> Entity (Entity ha "id" identity: IGNORA id)
    @Mapping(target = "id", ignore = true)
    MonitoringBatch toEntity(MonitoringBatchDTO dto);

    // Liste Entity -> DTO (niente mapping su id)
    List<MonitoringBatchDTO> toDtoList(List<MonitoringBatch> entities);
    
 // Update DTO -> Entity (non sovrascrivere l'ID identity)
    @Mapping(target = "id", ignore = true)
    void updateEntityFromDto(MonitoringBatchDTO dto, @MappingTarget MonitoringBatch entity);
}

