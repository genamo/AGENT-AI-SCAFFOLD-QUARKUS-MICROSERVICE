package it.eng.snam.pmr.common.request;

import java.util.Set;

public record AuthzRequest(
        String profile,
        String resource,
        String permit,
        Set<String> roles,
        String userType  
) {}
