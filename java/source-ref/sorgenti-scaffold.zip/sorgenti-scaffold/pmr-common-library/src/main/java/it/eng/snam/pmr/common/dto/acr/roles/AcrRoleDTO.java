package it.eng.snam.pmr.common.dto.acr.roles;

import lombok.Builder;

@Builder
public record AcrRoleDTO(
        String code
) {}
