package it.eng.snam.pmr.common.functional.interfaces.kafka.consumer;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.function.BiConsumer;

import org.apache.kafka.common.header.Headers;

import com.fasterxml.jackson.core.type.TypeReference;

import it.eng.snam.pmr.common.util.JsonUtils;
import it.eng.snam.pmr.common.util.kafka.consumer.UnknownMessageHandler;

@FunctionalInterface
public interface MessageHandlerFactory {

    void handle(byte[] payload, Headers headers) throws IOException;

    static MessageHandlerFactory bytes(BiConsumer<byte[], Headers> consumer) {
        return consumer::accept;
    }

    static MessageHandlerFactory string(BiConsumer<String, Headers> consumer) {
        return (payload, headers) -> consumer.accept(new String(payload, StandardCharsets.UTF_8), headers);
    }

    static <T> MessageHandlerFactory json(Class<T> wrapper, BiConsumer<T, Headers> consumer) {
        return (payload, headers) -> consumer.accept(JsonUtils.getObject(payload, wrapper), headers);
    }

    static <T> MessageHandlerFactory json(TypeReference<T> wrapper, BiConsumer<T, Headers> consumer) {
        return (payload, headers) -> consumer.accept(JsonUtils.getObject(payload, wrapper), headers);
    }

    static MessageHandlerFactory unknown(String topic) {
        return (payload, headers) -> UnknownMessageHandler.handle(topic, payload, headers);
    }
}
