package it.eng.snam.pmr.common.response;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ResponseStatusTest {

    @Test
    void elaborato_hasCorrectStatus() {
        assertThat(ResponseStatus.ELABORATO.getStatus()).isEqualTo("ELABORATO");
        assertThat(ResponseStatus.ELABORATO.toString()).isEqualTo("ELABORATO");
    }

    @Test
    void inElaborazione_hasCorrectStatus() {
        assertThat(ResponseStatus.IN_ELABORAZIONE.getStatus()).isEqualTo("IN ELABORAZIONE");
    }

    @Test
    void inErrore_hasCorrectStatus() {
        assertThat(ResponseStatus.IN_ERRORE.getStatus()).isEqualTo("IN ERRORE");
    }

    @Test
    void presoInCarico_hasCorrectStatus() {
        assertThat(ResponseStatus.PRESO_IN_CARICO.getStatus()).isEqualTo("PRESO IN CARICO");
    }

    @Test
    void allValues_fourConstants() {
        assertThat(ResponseStatus.values()).hasSize(4);
    }
}
