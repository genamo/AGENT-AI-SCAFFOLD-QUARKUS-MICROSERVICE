package it.eng.snam.pmr.batchintegrazione.service.monitoring.integration;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import java.io.Serial;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Riferimento ad una mail di Riepilogo Tabellare da inviare")
public class UpdateMailVerbale implements Serializable {

    @Serial
    private static final long serialVersionUID = 1395551282882269014L;

    @Schema(description = "Identificativo mail", required = true)
    private Long idMail;

    @Schema(description = "Stato mail (0='Da elaborare/inviare' - 1='In attesa' - 2='Inviato' - 3='Errore')", required = true)
    private String statoMail;
}
