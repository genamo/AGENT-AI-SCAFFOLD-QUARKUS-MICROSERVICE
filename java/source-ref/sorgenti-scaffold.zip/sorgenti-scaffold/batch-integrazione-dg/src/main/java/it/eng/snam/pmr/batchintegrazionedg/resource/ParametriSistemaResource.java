package it.eng.snam.pmr.batchintegrazionedg.resource;

import java.util.List;

import org.jboss.logging.Logger;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.dto.IntegrazioneParametriSistemaDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.ParametriSistemaRequestSearch;
import it.eng.snam.pmr.batchintegrazionedg.service.ParametriService;
import it.eng.snam.pmr.batchintegrazionedg.utils.Utility;
import it.eng.snam.pmr.common.annotation.LogPmr;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/parametri-sistema")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RunOnVirtualThread
@LogPmr
public class ParametriSistemaResource extends AbstractResource {

    private static final Logger LOG =
            Logger.getLogger(ParametriSistemaResource.class);

    @Inject
    ParametriService parametriService;

    @Context
    ContainerRequestContext ctx;

    @POST
    @Path("/search")
    public Response searchParametri(ParametriSistemaRequestSearch request) {

        ReqContext c = init(ctx, "/parametri-sistema/search");

        if (request == null) {
            Response response = Utility.badRequest(
                    "Request body mancante o non valido",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );

            LOG.infof("OUT http=%d elapsedMs=%d",
                    response.getStatus(),
                    Utility.elapsedMs(c.start()));

            return response;
        }

        List<IntegrazioneParametriSistemaDTO> risultati =
                parametriService.search(request);

        return Utility.okOrEmpty(
                risultati,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }
}
