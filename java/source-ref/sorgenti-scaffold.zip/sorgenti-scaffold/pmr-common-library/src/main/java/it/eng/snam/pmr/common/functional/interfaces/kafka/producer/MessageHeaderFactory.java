package it.eng.snam.pmr.common.functional.interfaces.kafka.producer;

import java.util.Arrays;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

import it.eng.snam.pmr.common.dto.kafka.produce.MessageHeaderContext;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.mdc.MdcManager;

@FunctionalInterface
public interface MessageHeaderFactory {

    MessageHeaderContext create();

    static MessageHeaderFactory mdc() {
        return () -> MessageHeaderContext.builder().transactionId(MdcManager.getHeader(CommonConstants.LogParams.TN))
                                         .userId(MdcManager.getHeader(AuthorizationUtils.USER_ID))
                                         .keyLogic(MdcManager.getHeader(CommonConstants.LogParams.KL))
                                         .processType(MdcManager.getHeader(CommonConstants.LogParams.PT))
                                         .flowType(MdcManager.getHeader(CommonConstants.LogParams.FT))
                                         .messageKey(MdcManager.getHeader(CommonConstants.LogParams.MK)).build();
    }

    static MessageHeaderFactory merge(MessageHeaderContext override) {
        return () -> mergeContexts(mdc().create(), override);
    }

    static MessageHeaderContext resolve(MessageHeaderFactory factory) {
        MessageHeaderContext context = factory != null ? factory.create() : mdc().create();
        return applyDefaults(context);
    }

    private static MessageHeaderContext mergeContexts(MessageHeaderContext base, MessageHeaderContext override) {
        MessageHeaderContext safeBase = safeContext(base);
        MessageHeaderContext safeOverride = safeContext(override);
        return MessageHeaderContext.builder().transactionId(firstNotBlank(safeOverride.getTransactionId(), safeBase.getTransactionId()))
                                   .userId(firstNotBlank(safeOverride.getUserId(), safeBase.getUserId()))
                                   .keyLogic(firstNotBlank(safeOverride.getKeyLogic(), safeBase.getKeyLogic()))
                                   .processType(firstNotBlank(safeOverride.getProcessType(), safeBase.getProcessType()))
                                   .flowType(firstNotBlank(safeOverride.getFlowType(), safeBase.getFlowType()))
                                   .messageKey(firstNotBlank(safeOverride.getMessageKey(), safeBase.getMessageKey())).build();
    }

    private static MessageHeaderContext applyDefaults(MessageHeaderContext context) {
        MessageHeaderContext safeContext = safeContext(context);
        return MessageHeaderContext.builder().transactionId(firstNotBlank(safeContext.getTransactionId(), ""))
                                   .userId(firstNotBlank(safeContext.getUserId(), ""))
                                   .keyLogic(firstNotBlank(safeContext.getKeyLogic(), ""))
                                   .processType(firstNotBlank(safeContext.getProcessType(), "N/A"))
                                   .flowType(firstNotBlank(safeContext.getFlowType(), "UNKNOWN"))
                                   .messageKey(firstNotBlank(safeContext.getMessageKey(), UUID.randomUUID().toString())).build();
    }

    private static MessageHeaderContext safeContext(MessageHeaderContext context) {
        return context != null ? context : MessageHeaderContext.builder().build();
    }

    private static String firstNotBlank(String... values) {
        if (values == null)
            return null;

        return Arrays.stream(values).filter(StringUtils::isNotBlank)
                     .findFirst().orElse(null);
    }
}
