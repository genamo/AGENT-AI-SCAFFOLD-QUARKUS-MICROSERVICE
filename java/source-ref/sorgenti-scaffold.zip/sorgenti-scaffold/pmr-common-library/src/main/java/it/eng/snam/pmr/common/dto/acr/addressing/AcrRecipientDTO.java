package it.eng.snam.pmr.common.dto.acr.addressing;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;

@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public record AcrRecipientDTO(
        String userId,
        String firstname,
        String lastname,
        String email,
        String profileId,
        Integer territoryId
) {}
