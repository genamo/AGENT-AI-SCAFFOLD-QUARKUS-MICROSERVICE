package it.eng.snam.pmr.batchintegrazionedg.kafka;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum KafkaTopic {
    MONITORING_INTEGRATION("monitoringintegration"),
    MONITORING_INTEGRATION_OUTCOME("monitoringintegrationoutcome"),
    INTEGRAZIONE_FLUSSI_TOPIC("integrazioneflussi"),
    DELIBERA_BIOMETANO_TOPIC("deliberabiometanoengine"),
    UNKNOWN("unknown");

    private final String topic;
}
