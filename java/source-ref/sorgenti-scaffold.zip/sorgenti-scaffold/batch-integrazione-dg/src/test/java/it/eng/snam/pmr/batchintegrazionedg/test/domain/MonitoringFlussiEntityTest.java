package it.eng.snam.pmr.batchintegrazionedg.test.domain;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import it.eng.snam.pmr.batchintegrazionedg.domain.MonitoringFlussi;
import java.time.LocalDateTime;

class MonitoringFlussiEntityTest {

    @Test
    void gettersAndSetters_workCorrectly() {
        MonitoringFlussi e = new MonitoringFlussi();
        LocalDateTime now = LocalDateTime.now();

        e.setId(10L);
        e.setTransactionId("TXN-001");
        e.setCorrelationId("CORR-001");
        e.setFlowId("FLOW-001");
        e.setDayNumber(20260522);
        e.setMonthNumber(202605);
        e.setGranularita("G");
        e.setSender("PMR");
        e.setIsWorkaround(false);
        e.setStatusDescription("OK");
        e.setFileFlusso("file content");
        e.setFileOutput("output");
        e.setStatus(1);
        e.setActionDate(now);
        e.setUserAction("batch");
        e.setIsDeleted(0);

        assertEquals(10L, e.getId());
        assertEquals("TXN-001", e.getTransactionId());
        assertEquals("CORR-001", e.getCorrelationId());
        assertEquals("FLOW-001", e.getFlowId());
        assertEquals(20260522, e.getDayNumber());
        assertEquals(202605, e.getMonthNumber());
        assertEquals("G", e.getGranularita());
        assertEquals("PMR", e.getSender());
        assertFalse(e.getIsWorkaround());
        assertEquals("OK", e.getStatusDescription());
        assertEquals("file content", e.getFileFlusso());
        assertEquals("output", e.getFileOutput());
        assertEquals(1, e.getStatus());
        assertEquals(now, e.getActionDate());
        assertEquals("batch", e.getUserAction());
        assertEquals(0, e.getIsDeleted());
    }

    @Test
    void defaultIsDeleted_isZero() {
        MonitoringFlussi e = new MonitoringFlussi();
        assertEquals(0, e.getIsDeleted());
    }
}
