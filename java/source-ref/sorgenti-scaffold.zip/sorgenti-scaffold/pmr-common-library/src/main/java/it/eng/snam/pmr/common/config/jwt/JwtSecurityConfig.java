package it.eng.snam.pmr.common.config.jwt;

import java.util.Map;

import io.smallrye.config.ConfigMapping;
import io.smallrye.config.WithDefault;

@ConfigMapping(prefix = "security.jwt")
public interface JwtSecurityConfig {

    @WithDefault("60")
    long clockSkewSeconds();

    Jwks jwks();

    Map<String, Provider> providers();
}