package it.eng.snam.pmr.common.service;

import java.util.List;
import java.util.function.Supplier;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.MDC;

import com.fasterxml.jackson.core.type.TypeReference;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.common.client.AuthorizationClient;
import it.eng.snam.pmr.common.dto.AdministrationListDTO;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.CommonConstants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class AdministrationListService extends AbstractService {

    private static final TypeReference<GenericResponse<List<AdministrationListDTO>>> ADMIN_LIST_TYPE =
            new TypeReference<>() {};

    @Inject
    @RestClient
    AuthorizationClient authorizationClient;

    public List<AdministrationListDTO> getAll() {
        return emptyIfNull(execute(
                "GET /auth_administration-list_all",
                authorizationClient::getAllAdministrationLists,
                ADMIN_LIST_TYPE
        ));
    }

    private <T> T execute(
            String operation,
            Supplier<Response> call,
            TypeReference<GenericResponse<T>> typeReference
    ) {
        String previousApi = (String) MDC.get(CommonConstants.LogParams.API);

        try {
            MDC.put(CommonConstants.LogParams.API, operation);
            return executeClientCall(call, typeReference);
        } finally {
            restoreApi(previousApi);
        }
    }

    private <T> List<T> emptyIfNull(List<T> list) {
        return list == null ? List.of() : list;
    }

    private void restoreApi(String previousApi) {
        if (previousApi == null) {
            MDC.remove(CommonConstants.LogParams.API);
        } else {
            MDC.put(CommonConstants.LogParams.API, previousApi);
        }
    }
}
