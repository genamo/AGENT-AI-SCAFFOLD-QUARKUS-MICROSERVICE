package it.eng.snam.pmr.batchintegrazione.utils.blob.storage;

import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class BlobNameNormalizer {

    private final String BLOB_PATH_SEPARATOR = "/";

    public String normalize(String documentType, String fileName) {
        return String.join(BLOB_PATH_SEPARATOR, documentType, fileName);
    }
}
