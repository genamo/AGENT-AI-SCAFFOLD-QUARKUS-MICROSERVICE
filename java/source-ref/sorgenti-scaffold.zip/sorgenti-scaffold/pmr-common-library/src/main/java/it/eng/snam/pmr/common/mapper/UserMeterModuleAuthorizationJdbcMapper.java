package it.eng.snam.pmr.common.mapper;

import it.eng.snam.pmr.common.dto.UserMeterModuleAuthorizationDTO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public final class UserMeterModuleAuthorizationJdbcMapper {

    private UserMeterModuleAuthorizationJdbcMapper() {}

    public static UserMeterModuleAuthorizationDTO map(ResultSet rs) throws SQLException {
        Timestamp ins = rs.getTimestamp("InsertDate");
        Timestamp upd = rs.getTimestamp("UpdateDate");

        return new UserMeterModuleAuthorizationDTO(
                getLongNullable(rs, "UserMeterModuleAuthorizationId"),
                rs.getString("UserCode"),
                getLongNullable(rs, "UserId"),
                rs.getString("MeterCode"),
                rs.getString("MeterId"),
                rs.getString("ModuleCode"),
                ins != null ? ins.toInstant() : null,
                upd != null ? upd.toInstant() : null,
                rs.getString("OrganizationCode"),
                getLongNullable(rs, "OrganizationId"),
                rs.getString("WeakSapCode"),
                getLongNullable(rs, "FlowId"),
                getLongNullable(rs, "EntityId"),
                getIntNullable(rs, "CancelledFlag"),
                rs.getString("PkSource"),
                getIntNullable(rs, "Denominatore"),
                getIntNullable(rs, "Penalita"),
                rs.getString("IdErrore")
        );
    }

    private static Long getLongNullable(ResultSet rs, String col) throws SQLException {
        Object v = rs.getObject(col);
        return v == null ? null : ((Number) v).longValue();
    }

    private static Integer getIntNullable(ResultSet rs, String col) throws SQLException {
        Object v = rs.getObject(col);
        return v == null ? null : ((Number) v).intValue();
    }
}
