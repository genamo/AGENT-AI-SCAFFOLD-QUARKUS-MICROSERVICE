package it.eng.snam.pmr.common.databricks;

import java.security.SecureRandom;
import java.sql.SQLException;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class DatabricksRetry {
	
	private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    @ConfigProperty(name = "databricks.retry.max-attempts", defaultValue = "4")
    int maxAttempts;

    @ConfigProperty(name = "databricks.retry.initial-delay-ms", defaultValue = "500")
    long initialDelayMs;

    @ConfigProperty(name = "databricks.retry.max-delay-ms", defaultValue = "5000")
    long maxDelayMs;

    @ConfigProperty(name = "databricks.retry.jitter-pct", defaultValue = "0.2")
    double jitterPct;

    @FunctionalInterface
    public interface SqlSupplier<T> {
        T get() throws SQLException;
    }

    public <T> T execute(SqlSupplier<T> action) {
        long delay = initialDelayMs;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                return action.get();
            } catch (SQLException e) {
                boolean retryable = isRetryable(e);

                // Stop conditions
                if (!retryable || attempt == maxAttempts) {
                    throw new RuntimeException(
                        "Databricks query failed (attempt " + attempt + "/" + maxAttempts +
                        ", retryable=" + retryable + ", sqlState=" + e.getSQLState() + ")", e);
                }

                // backoff + jitter
                sleepWithJitter(delay);
                delay = Math.min(delay * 2, maxDelayMs);
            }
        }
        // non dovrebbe mai arrivare qui
        throw new IllegalStateException("Retry loop ended unexpectedly");
    }

    


	private void sleepWithJitter(long baseDelayMs) {
	    long jitter = (long) (baseDelayMs * jitterPct);
	    long min = Math.max(0, baseDelayMs - jitter);
	    long max = baseDelayMs + jitter;
	
	    long actual = SECURE_RANDOM
	            .longs(min, max + 1)   
	            .findFirst()
	            .orElse(baseDelayMs);
	
	    try {
	        Thread.sleep(actual);
	    } catch (InterruptedException e) {
	        Thread.currentThread().interrupt();
	    }
	}


    private boolean isRetryable(SQLException e) {
        String sqlState = e.getSQLState();

        // SQLSTATE class 08 = connection exception (transient), includes SERVER_IS_BUSY etc.
        if (sqlState != null) {
            if (sqlState.startsWith("08")) return true;      // connection exception [2](https://docs.databricks.com/aws/en/error-messages/sqlstates)[3](https://docs.databricks.com/aws/en/error-messages)
            if ("08KD1".equals(sqlState)) return true;       // SERVER_IS_BUSY [2](https://docs.databricks.com/aws/en/error-messages/sqlstates)
            if ("42P01".equals(sqlState)) return false;      // TABLE_OR_VIEW_NOT_FOUND -> no retry [3](https://docs.databricks.com/aws/en/error-messages)
        }

        // Fallback su messaggio (utile per 503/temporarily unavailable)
        String msg = (e.getMessage() == null) ? "" : e.getMessage().toLowerCase();
        return msg.contains("http response code: 503")
            || msg.contains("temporarily unavailable");      // tipico 503/500 transient [4](https://learn.microsoft.com/en-gb/answers/questions/2261073/target-system-temporarily-unavailable-please-try-a)
    }
}