package it.eng.snam.pmr.batchintegrazione.dto.datifiscali;

import java.time.LocalDateTime;

public record VerbaliMisuraGiornSearchDto(
        String remiAssoluto,
        LocalDateTime dataVolPunta,
        LocalDateTime dataIniVerb
) {}
