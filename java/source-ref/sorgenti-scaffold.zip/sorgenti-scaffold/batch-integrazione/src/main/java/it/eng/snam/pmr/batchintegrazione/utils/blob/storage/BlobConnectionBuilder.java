package it.eng.snam.pmr.batchintegrazione.utils.blob.storage;

import org.apache.commons.lang3.StringUtils;

import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;

import it.eng.snam.pmr.batchintegrazione.config.properties.BlobStorageProperties;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class BlobConnectionBuilder {

    private final String PROPERTY_DELIMITER = ";";

    private final String ENDPOINTS_PROTOCOL = "DefaultEndpointsProtocol=https";
    private final String ACCOUNT_NAME = "AccountName=";
    private final String PLACEHOLDER_ACCOUNT_NAME = "${ACCOUNT_NAME}";
    private final String ACCOUNT_KEY = "AccountKey=";
    private final String PLACEHOLDER_ACCOUNT_KEY = "${ACCOUNT_KEY}";
    private final String ENDPOINT_SUFFIX = "EndpointSuffix=core.windows.net";

    private final String BASE_CONNECTION_STRING = String.join(StringUtils.EMPTY, ENDPOINTS_PROTOCOL, PROPERTY_DELIMITER, ACCOUNT_NAME, PLACEHOLDER_ACCOUNT_NAME, PROPERTY_DELIMITER,
                                                              ACCOUNT_KEY, PLACEHOLDER_ACCOUNT_KEY, PROPERTY_DELIMITER, ENDPOINT_SUFFIX, PROPERTY_DELIMITER);

    public BlobServiceClient init(BlobStorageProperties properties) {
        BlobArgumentsValidator.validateConnection(properties);

        String accountName = properties.accountName();
        String accountKey = properties.accountKey();
        String connectionString = BASE_CONNECTION_STRING.replace(PLACEHOLDER_ACCOUNT_NAME, accountName).replace(PLACEHOLDER_ACCOUNT_KEY, accountKey);
        log.debug("BlobServiceClient's accountName: {}", accountName);
        log.debug("BlobServiceClient's accountKey: {}", accountKey);
        log.debug("BlobServiceClient's ConnectionString: {}", connectionString);

        BlobServiceClient serviceClient = new BlobServiceClientBuilder().connectionString(connectionString).buildClient();
        log.info("Initialized BlobServiceClient, accountUrl={}", serviceClient.getAccountUrl());
        return serviceClient;
    }
}
