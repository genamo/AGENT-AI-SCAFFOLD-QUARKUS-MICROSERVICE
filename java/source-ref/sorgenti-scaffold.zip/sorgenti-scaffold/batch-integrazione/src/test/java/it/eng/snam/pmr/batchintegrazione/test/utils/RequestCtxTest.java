package it.eng.snam.pmr.batchintegrazione.test.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.filter.MdcHeadersFilter;
import it.eng.snam.pmr.batchintegrazione.utils.RequestCtx;
import jakarta.ws.rs.container.ContainerRequestContext;

@ExtendWith(MockitoExtension.class)
class RequestCtxTest {

    @Mock
    ContainerRequestContext ctx;

    @Test
    void kl_returnsProperty() {
        when(ctx.getProperty(MdcHeadersFilter.PROP_KL)).thenReturn("kl-value");
        assertEquals("kl-value", RequestCtx.kl(ctx));
    }

    @Test
    void kl_returnsNull_whenNotSet() {
        when(ctx.getProperty(MdcHeadersFilter.PROP_KL)).thenReturn(null);
        assertNull(RequestCtx.kl(ctx));
    }

    @Test
    void tid_returnsProperty() {
        when(ctx.getProperty(MdcHeadersFilter.PROP_TID)).thenReturn("tx-001");
        assertEquals("tx-001", RequestCtx.tid(ctx));
    }

    @Test
    void modAsync_trueWhenBooleanTrue() {
        when(ctx.getProperty(MdcHeadersFilter.PROP_MOD_ASYNC)).thenReturn(Boolean.TRUE);
        assertTrue(RequestCtx.modAsync(ctx));
    }

    @Test
    void modAsync_falseWhenBooleanFalse() {
        when(ctx.getProperty(MdcHeadersFilter.PROP_MOD_ASYNC)).thenReturn(Boolean.FALSE);
        assertFalse(RequestCtx.modAsync(ctx));
    }

    @Test
    void modAsync_falseWhenNull() {
        when(ctx.getProperty(MdcHeadersFilter.PROP_MOD_ASYNC)).thenReturn(null);
        assertFalse(RequestCtx.modAsync(ctx));
    }

    @Test
    void modAsync_falseWhenString() {
        when(ctx.getProperty(MdcHeadersFilter.PROP_MOD_ASYNC)).thenReturn("true");
        assertFalse(RequestCtx.modAsync(ctx)); // non-Boolean -> false
    }

    @Test
    void processType_returnsValue() {
        when(ctx.getProperty("CTX_PROCESS_TYPE")).thenReturn("BATCH");
        assertEquals("BATCH", RequestCtx.processType(ctx));
    }

    @Test
    void processType_returnsNA_whenNull() {
        when(ctx.getProperty("CTX_PROCESS_TYPE")).thenReturn(null);
        assertEquals("N/A", RequestCtx.processType(ctx));
    }

    @Test
    void processType_returnsToString_whenNotNull() {
        when(ctx.getProperty("CTX_PROCESS_TYPE")).thenReturn(42);
        assertEquals("42", RequestCtx.processType(ctx));
    }
}
