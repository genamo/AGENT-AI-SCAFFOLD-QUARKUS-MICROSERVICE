package it.eng.snam.pmr.common.util.async;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.function.Supplier;

import org.apache.commons.collections4.MapUtils;
import org.slf4j.MDC;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

public final class AsyncProcessExecutor {

    private static final String DEFAULT_VIRTUAL_THREAD_NAME = "pmr-virtual-thread-";

    private static final String DEFAULT_PLATFORM_THREAD_NAME = "pmr-platform-thread-";
    private static final int DEFAULT_PLATFORM_POOL_SIZE = Math.max(16, Runtime.getRuntime().availableProcessors());

    private static final Map<ExecutorKey, AsyncProcessExecutor> EXECUTOR_CACHE = new ConcurrentHashMap<>();

    private final ExecutorKey executorKey;
    private final ExecutorService executorService;

    private AsyncProcessExecutor(ExecutorKey executorKey, ExecutorService executorService) {
        this.executorKey = Objects.requireNonNull(executorKey, "'executorKey' must not be null");
        this.executorService = Objects.requireNonNull(executorService, "'executorService' must not be null");
        ExecutorRegistry.register(executorService);
    }

    /**
     * Restituisce l'executor virtuale predefinito.
     */
    public static AsyncProcessExecutor ofVirtual() {
        return ofVirtual(DEFAULT_VIRTUAL_THREAD_NAME);
    }

    /**
     * Restituisce un executor virtuale dalla cache.
     * A parità di prefisso viene restituita la stessa istanza,
     * purché l'executor non sia stato chiuso.
     */
    public static AsyncProcessExecutor ofVirtual(String threadNamePrefix) {
        ExecutorKey key = ExecutorKey.virtual(requireThreadNamePrefix(threadNamePrefix));
        return getOrCreate(key, () -> createVirtual(key));
    }

    /**
     * Restituisce l'executor platform predefinito.
     */
    public static AsyncProcessExecutor ofPlatform() {
        return ofPlatform(DEFAULT_PLATFORM_POOL_SIZE, DEFAULT_PLATFORM_THREAD_NAME);
    }

    /**
     * Restituisce un executor platform dalla cache,
     * usando il prefisso in input.
     */
    public static AsyncProcessExecutor ofPlatform(String threadNamePrefix) {
        return ofPlatform(DEFAULT_PLATFORM_POOL_SIZE, threadNamePrefix);
    }

    /**
     * Restituisce un executor platform dalla cache,
     * usando il pool input ed il prefisso predefinito.
     */
    public static AsyncProcessExecutor ofPlatform(int poolSize) {
        return ofPlatform(poolSize, DEFAULT_PLATFORM_THREAD_NAME);
    }

    /**
     * Restituisce un executor platform dalla cache.
     * A parità di pool size e prefisso viene restituita
     * la stessa istanza, purché l'executor non sia stato chiuso.
     */
    public static AsyncProcessExecutor ofPlatform(int poolSize, String threadNamePrefix) {
        ExecutorKey key = ExecutorKey.platform(requireValidPoolSize(poolSize), requireThreadNamePrefix(threadNamePrefix));
        return getOrCreate(key, () -> createPlatform(key));
    }

    public CompletableFuture<Void> runAsync(Runnable task) {
        Objects.requireNonNull(task, "'task' must not be null");
        Map<String, String> capturedMdc = captureMdc();
        return CompletableFuture.runAsync(wrap(task, capturedMdc), executorService);
    }

    public <T> CompletableFuture<T> supplyAsync(Supplier<? extends T> supplier) {
        Objects.requireNonNull(supplier, "'supplier' must not be null");
        Map<String, String> capturedMdc = captureMdc();
        return CompletableFuture.supplyAsync(wrap(supplier, capturedMdc), executorService);
    }

    public <T> CompletableFuture<T> callAsync(Callable<? extends T> callable) {
        Objects.requireNonNull(callable, "'callable' must not be null");
        Map<String, String> capturedMdc = captureMdc();
        return CompletableFuture.supplyAsync(wrap(callable, capturedMdc), executorService);
    }

    public void run(Runnable task) {
        runAsync(task).join();
    }

    public <T> T supply(Supplier<? extends T> supplier) {
        return supplyAsync(supplier).join();
    }

    public <T> T call(Callable<? extends T> callable) {
        return callAsync(callable).join();
    }

    public boolean isVirtual() {
        return executorKey.threadType() == ThreadType.VIRTUAL;
    }

    public boolean isPlatform() {
        return executorKey.threadType() == ThreadType.PLATFORM;
    }

    /**
     * Restituisce la dimensione del pool.
     * Per gli executor virtuali restituisce null.
     */
    public Integer poolSize() {
        return executorKey.poolSize();
    }

    public String threadNamePrefix() {
        return executorKey.threadNamePrefix();
    }

    public ExecutorService unwrap() {
        return executorService;
    }

    public boolean isShutdown() {
        return executorService.isShutdown();
    }

    public boolean isTerminated() {
        return executorService.isTerminated();
    }

    /**
     * Numero di configurazioni attualmente presenti in cache.
     */
    public static int cacheSize() {
        return EXECUTOR_CACHE.size();
    }

    /**
     * Rimuove dalla cache tutti gli executor già chiusi.
     * Non esegue lo shutdown: elimina soltanto le entry non più utilizzabili.
     */
    public static int evictShutdownExecutors() {
        int initialSize = EXECUTOR_CACHE.size();
        EXECUTOR_CACHE.entrySet().removeIf(entry -> entry.getValue().executorService.isShutdown());
        return initialSize - EXECUTOR_CACHE.size();
    }

    /**
     * Rimuove dalla cache l'executor associato all'ExecutorService.
     * Utile nel componente centralizzato di shutdown.
     */
    public static boolean evict(ExecutorService executorService) {
        Objects.requireNonNull(executorService, "'executorService' must not be null");
        return EXECUTOR_CACHE.entrySet().removeIf(entry -> entry.getValue().executorService == executorService);
    }

    /**
     * Svuota la cache senza chiudere gli executor.
     * Da usare principalmente nei test.
     */
    static void clearCache() {
        EXECUTOR_CACHE.clear();
    }

    private static AsyncProcessExecutor getOrCreate(ExecutorKey key, Supplier<AsyncProcessExecutor> creator) {
        return EXECUTOR_CACHE.compute(key, (ignored, cachedExecutor) -> {
            if (cachedExecutor == null)
                return creator.get();

            if (cachedExecutor.executorService.isShutdown() || cachedExecutor.executorService.isTerminated()) {
                ExecutorRegistry.unregister(cachedExecutor.executorService);
                return creator.get();
            }

            return cachedExecutor;
        });
    }

    private Runnable wrap(Runnable task, Map<String, String> capturedMdc) {
        return () -> {
            Map<String, String> previousMdc = captureMdc();
            try {
                restoreMdc(capturedMdc);
                task.run();
            } finally {
                restoreMdc(previousMdc);
            }
        };
    }

    private <T> Supplier<T> wrap(Supplier<? extends T> supplier, Map<String, String> capturedMdc) {
        return () -> {
            Map<String, String> previousMdc = captureMdc();
            try {
                restoreMdc(capturedMdc);
                return supplier.get();
            } finally {
                restoreMdc(previousMdc);
            }
        };
    }

    private <T> Supplier<T> wrap(Callable<? extends T> callable, Map<String, String> capturedMdc) {
        return () -> {
            Map<String, String> previousMdc = captureMdc();
            try {
                restoreMdc(capturedMdc);
                return callable.call();
            } catch (CompletionException exception) {
                throw exception;
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                throw new CompletionException(executorKey.threadType().getDescription() + " task interrupted", exception);
            } catch (Exception exception) {
                throw new CompletionException(exception);
            } finally {
                restoreMdc(previousMdc);
            }
        };
    }

    private Map<String, String> captureMdc() {
        return MDC.getCopyOfContextMap();
    }

    private void restoreMdc(Map<String, String> context) {
        if (MapUtils.isEmpty(context))
            MDC.clear();
        else
            MDC.setContextMap(context);
    }

    private static AsyncProcessExecutor createVirtual(ExecutorKey key) {
        ThreadFactory threadFactory = Thread.ofVirtual().name(key.threadNamePrefix(), 0).factory();
        ExecutorService executorService = Executors.newThreadPerTaskExecutor(threadFactory);
        return new AsyncProcessExecutor(key, executorService);
    }

    private static AsyncProcessExecutor createPlatform(ExecutorKey key) {
        ThreadFactory threadFactory = Thread.ofPlatform().name(key.threadNamePrefix(), 0).factory();
        ExecutorService executorService = Executors.newFixedThreadPool(key.poolSize(), threadFactory);
        return new AsyncProcessExecutor(key, executorService);
    }

    private static int requireValidPoolSize(int poolSize) {
        if (poolSize <= 0)
            throw new IllegalArgumentException("'poolSize' must be greater than zero: " + poolSize);

        return poolSize;
    }

    private static String requireThreadNamePrefix(String threadNamePrefix) {
        Objects.requireNonNull(threadNamePrefix, "'threadNamePrefix' must not be null");
        if (threadNamePrefix.isBlank())
            throw new IllegalArgumentException("'threadNamePrefix' must not be blank");

        return threadNamePrefix;
    }

    private record ExecutorKey(ThreadType threadType, String threadNamePrefix, Integer poolSize) {

        private ExecutorKey {
            Objects.requireNonNull(threadType, "'threadType' must not be null");

            threadNamePrefix = requireThreadNamePrefix(threadNamePrefix);

            if (threadType == ThreadType.VIRTUAL) {
                if (poolSize != null)
                    throw new IllegalArgumentException("'poolSize' must be null for virtual executor");
            } else {
                Objects.requireNonNull(poolSize, "'poolSize' must not be null for platform executor");
                requireValidPoolSize(poolSize);
            }
        }

        private static ExecutorKey virtual(String threadNamePrefix) {
            return new ExecutorKey(ThreadType.VIRTUAL, threadNamePrefix, null);
        }

        private static ExecutorKey platform(int poolSize, String threadNamePrefix) {
            return new ExecutorKey(ThreadType.PLATFORM, threadNamePrefix, poolSize);
        }
    }

    @Getter
    @RequiredArgsConstructor
    private enum ThreadType {

        VIRTUAL("Virtual"), PLATFORM("Platform");

        private final String description;
    }
}