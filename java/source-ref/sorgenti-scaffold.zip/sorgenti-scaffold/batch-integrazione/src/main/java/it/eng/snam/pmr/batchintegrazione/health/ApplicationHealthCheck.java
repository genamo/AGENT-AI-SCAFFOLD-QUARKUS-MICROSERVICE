package it.eng.snam.pmr.batchintegrazione.health;

import org.eclipse.microprofile.health.HealthCheck;
import org.eclipse.microprofile.health.HealthCheckResponse;
import org.eclipse.microprofile.health.Liveness;
import org.eclipse.microprofile.health.Readiness;
import org.jboss.logging.Logger;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ApplicationHealthCheck {

    private static final Logger LOG = Logger.getLogger(ApplicationHealthCheck.class);

    @Liveness
    HealthCheck liveness() {
        return () -> HealthCheckResponse.up("service-alive");
    }

    @Readiness
    @ApplicationScoped
    public static class RedisReadinessCheck implements HealthCheck {

        @Override
        public HealthCheckResponse call() {
            return HealthCheckResponse.up("service-ready");
        }
    }
}
