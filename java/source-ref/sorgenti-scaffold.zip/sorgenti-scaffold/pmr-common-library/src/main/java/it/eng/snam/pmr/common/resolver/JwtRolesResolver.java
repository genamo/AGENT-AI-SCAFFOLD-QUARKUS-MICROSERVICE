package it.eng.snam.pmr.common.resolver;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.util.*;

public final class JwtRolesResolver {

    private JwtRolesResolver() {}

    public static Set<String> resolveAllRoles(String bearer) {

        if (bearer == null || bearer.isBlank()) {
            return Collections.emptySet();
        }

        DecodedJWT jwt = decode(bearer);
        Set<String> roles = new HashSet<>();

        // ✅ roles array
        List<String> rolesList = jwt.getClaim("roles").asList(String.class);
        if (rolesList != null) {
            roles.addAll(rolesList);
        }

        // ✅ role singolo
        String role = jwt.getClaim("role").asString();
        if (role != null && !role.isBlank()) {
            roles.add(role);
        }

        return roles;
    }

    private static DecodedJWT decode(String bearer) {
        return JWT.decode(stripBearer(bearer));
    }

    private static String stripBearer(String bearer) {
        return bearer.startsWith("Bearer ") ? bearer.substring(7) : bearer;
    }
}