package it.eng.snam.pmr.batchintegrazionedg.repository;

import java.util.List;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import it.eng.snam.pmr.batchintegrazionedg.domain.DlqFlusso;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class DlqFlussoRepository implements PanacheRepository<DlqFlusso> {

    public List<DlqFlusso> findAllByTransactionId(String transactionId) {
        return find("transactionId = ?1 AND isDeleted = 0 order by createdAt desc", transactionId)
                .list();
    }

    public List<DlqFlusso> findByStatus(String status) {
        return find("status = ?1 AND isDeleted = 0 order by createdAt desc", status)
                .list();
    }

    public List<DlqFlusso> findLatest(int limit) {
        return find("isDeleted = 0 order by createdAt desc")
                .page(0, limit)
                .list();
    }
    

    public List<DlqFlusso> findByControlKey(String controlKey) {
        return find("controlKey = ?1 and isDeleted = 0", controlKey).list();
    }

    public long countByControlKey(String controlKey) {
        return count("controlKey = ?1 and isDeleted = 0", controlKey);
    }

}