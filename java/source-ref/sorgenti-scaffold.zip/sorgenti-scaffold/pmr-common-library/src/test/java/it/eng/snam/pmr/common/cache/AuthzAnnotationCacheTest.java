package it.eng.snam.pmr.common.cache;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.common.annotation.AuthzRead;
import it.eng.snam.pmr.common.annotation.AuthzWrite;
import it.eng.snam.pmr.common.annotation.RemiConeCheck;
import it.eng.snam.pmr.common.annotation.UserType;
import jakarta.ws.rs.container.ResourceInfo;

@ExtendWith(MockitoExtension.class)
class AuthzAnnotationCacheTest {

    @Mock
    ResourceInfo resourceInfo;

    @BeforeEach
    void clearCache() throws Exception {
        Field cacheField = AuthzAnnotationCache.class.getDeclaredField("CACHE");
        cacheField.setAccessible(true);
        ((Map<?, ?>) cacheField.get(null)).clear();
    }

    // -----------------------------------------------------------------------
    // Fixture resource classes
    // -----------------------------------------------------------------------

    @RemiConeCheck(mode = RemiConeCheck.Mode.RESPONSE, responseField = "code")
    static class ClassAnnotatedRemiCone {
        public void method() {}
    }

    static class MethodAnnotatedRemiCone {
        @RemiConeCheck(mode = RemiConeCheck.Mode.REQUEST, queryParam = "code")
        public void remiMethod() {}

        public void noAnnotation() {}
    }

    
    
    @AuthzRead(userType = UserType.EXTERNAL)
    static class ClassAnnotatedRead {
        public void method() {}
    }

    static class MethodAnnotatedRead {
        @AuthzRead(userType = UserType.INTERNAL)
        public void readMethod() {}

        public void noAnnotation() {}
    }

    @AuthzWrite
    static class ClassAnnotatedWrite {
        public void method() {}
    }

    static class MethodAnnotatedWrite {
        @AuthzWrite(userType = UserType.EXTERNAL)
        public void writeMethod() {}
    }

    // -----------------------------------------------------------------------
    // getAuthzRead
    // -----------------------------------------------------------------------

    @Test
    void getAuthzRead_annotationOnMethod_returnsMethodAnnotation() throws Exception {
        Method m = MethodAnnotatedRead.class.getMethod("readMethod");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        // getResourceClass() is NOT called when annotation is found on the method itself

        AuthzRead ann = AuthzAnnotationCache.getAuthzRead(resourceInfo);
        assertThat(ann).isNotNull();
        assertThat(ann.userType()).isEqualTo(UserType.INTERNAL);
    }

    @Test
    void getAuthzRead_annotationOnClass_fallbackToClass() throws Exception {
        Method m = ClassAnnotatedRead.class.getMethod("method");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        when(resourceInfo.getResourceClass()).thenAnswer(i -> ClassAnnotatedRead.class);

        AuthzRead ann = AuthzAnnotationCache.getAuthzRead(resourceInfo);
        assertThat(ann).isNotNull();
        assertThat(ann.userType()).isEqualTo(UserType.EXTERNAL);
    }

    @Test
    void getAuthzRead_noAnnotation_returnsNull() throws Exception {
        Method m = MethodAnnotatedRead.class.getMethod("noAnnotation");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        when(resourceInfo.getResourceClass()).thenAnswer(i -> MethodAnnotatedRead.class);

        AuthzRead ann = AuthzAnnotationCache.getAuthzRead(resourceInfo);
        assertThat(ann).isNull();
    }

    @Test
    void getAuthzRead_calledTwice_usesCache() throws Exception {
        Method m = MethodAnnotatedRead.class.getMethod("readMethod");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        // getResourceClass() is NOT called when annotation is on method

        AuthzRead first = AuthzAnnotationCache.getAuthzRead(resourceInfo);
        AuthzRead second = AuthzAnnotationCache.getAuthzRead(resourceInfo);
        // Same instance from cache
        assertThat(first).isSameAs(second);
    }

    // -----------------------------------------------------------------------
    // getAuthzWrite
    // -----------------------------------------------------------------------

    @Test
    void getAuthzWrite_annotationOnMethod_returnsMethodAnnotation() throws Exception {
        Method m = MethodAnnotatedWrite.class.getMethod("writeMethod");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        // getResourceClass() is NOT called when annotation is on the method itself

        AuthzWrite ann = AuthzAnnotationCache.getAuthzWrite(resourceInfo);
        assertThat(ann).isNotNull();
        assertThat(ann.userType()).isEqualTo(UserType.EXTERNAL);
    }

    @Test
    void getAuthzWrite_annotationOnClass_fallbackToClass() throws Exception {
        Method m = ClassAnnotatedWrite.class.getMethod("method");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        when(resourceInfo.getResourceClass()).thenAnswer(i -> ClassAnnotatedWrite.class);

        AuthzWrite ann = AuthzAnnotationCache.getAuthzWrite(resourceInfo);
        assertThat(ann).isNotNull();
    }
    
    @Test
    void getRemiConeCheck_annotationOnMethod_returnsMethodAnnotation() throws Exception {
        Method m = MethodAnnotatedRemiCone.class.getMethod("remiMethod");
        when(resourceInfo.getResourceMethod()).thenReturn(m);

        RemiConeCheck ann = AuthzAnnotationCache.getRemiConeCheck(resourceInfo);

        assertThat(ann).isNotNull();
        assertThat(ann.mode()).isEqualTo(RemiConeCheck.Mode.REQUEST);
        assertThat(ann.queryParam()).isEqualTo("code");
    }

    @Test
    void getRemiConeCheck_annotationOnClass_fallbackToClass() throws Exception {
        Method m = ClassAnnotatedRemiCone.class.getMethod("method");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        when(resourceInfo.getResourceClass()).thenAnswer(i -> ClassAnnotatedRemiCone.class);

        RemiConeCheck ann = AuthzAnnotationCache.getRemiConeCheck(resourceInfo);

        assertThat(ann).isNotNull();
        assertThat(ann.mode()).isEqualTo(RemiConeCheck.Mode.RESPONSE);
        assertThat(ann.responseField()).isEqualTo("code");
    }

    @Test
    void getRemiConeCheck_noAnnotation_returnsNull() throws Exception {
        Method m = MethodAnnotatedRemiCone.class.getMethod("noAnnotation");
        when(resourceInfo.getResourceMethod()).thenReturn(m);
        when(resourceInfo.getResourceClass()).thenAnswer(i -> MethodAnnotatedRemiCone.class);

        RemiConeCheck ann = AuthzAnnotationCache.getRemiConeCheck(resourceInfo);

        assertThat(ann).isNull();
    }

}
