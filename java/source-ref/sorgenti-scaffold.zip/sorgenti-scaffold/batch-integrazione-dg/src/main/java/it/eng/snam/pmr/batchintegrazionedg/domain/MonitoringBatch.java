package it.eng.snam.pmr.batchintegrazionedg.domain;

import java.time.LocalDateTime;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.hibernate.type.SqlTypes;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Audited
@Table(
    name = "monitoring_batch",
    indexes = @Index(
        name = "uk_monitoring_batch",
        columnList = "transaction_id, is_deleted",
        unique = true
    )
)
public class MonitoringBatch extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @NotBlank
    @Column(name = "transaction_id", nullable = false, length = 100)
    private String transactionId;

    @NotBlank
    @Column(name = "correlation_id", nullable = false, length = 100)
    private String correlationId;

    @NotBlank
    @Column(name = "flow_id", nullable = false, length = 50)
    private String flowId;

    @NotNull
    @Column(name = "day_number", nullable = false)
    private Integer dayNumber;

    @NotNull
    @Column(name = "month_number", nullable = false)
    private Integer monthNumber;

    @NotBlank
    @Column(name = "granularita", nullable = false, length = 2)
    private String granularita;

    @NotBlank
    @Column(name = "sender", nullable = false, length = 50)
    private String sender;

    @NotNull
    @Column(name = "isworkaround", nullable = false)
    private Boolean isWorkaround;

    @Column(name = "status_desc", nullable = false, length = 50)
    private String statusDescription;

    @NotAudited
    @Column(name = "file_batch")
    private String fileBatch;

    @NotAudited
    @Column(name = "file_output")
    private String fileOutput;

    @NotNull
    @Column(name = "status", nullable = false)
    private Integer status;

    @Column(name = "action_date", nullable = false)
    private LocalDateTime actionDate;

    @Column(name = "user_action", nullable = false, length = 50)
    private String userAction;

    @NotNull
    @Column(name = "is_deleted", nullable = false)
    private Integer isDeleted = 0;

    // ===== getter / setter =====

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public String getCorrelationId() { return correlationId; }
    public void setCorrelationId(String correlationId) { this.correlationId = correlationId; }

    public String getFlowId() { return flowId; }
    public void setFlowId(String flowId) { this.flowId = flowId; }

    public Integer getDayNumber() { return dayNumber; }
    public void setDayNumber(Integer dayNumber) { this.dayNumber = dayNumber; }

    public Integer getMonthNumber() { return monthNumber; }
    public void setMonthNumber(Integer monthNumber) { this.monthNumber = monthNumber; }

    public String getGranularita() { return granularita; }
    public void setGranularita(String granularita) { this.granularita = granularita; }

    public String getSender() { return sender; }
    public void setSender(String sender) { this.sender = sender; }

    public Boolean getIsWorkaround() { return isWorkaround; }
    public void setIsWorkaround(Boolean isWorkaround) { this.isWorkaround = isWorkaround; }

    public String getStatusDescription() { return statusDescription; }
    public void setStatusDescription(String statusDescription) { this.statusDescription = statusDescription; }

    public String getFileBatch() { return fileBatch; }
    public void setFileBatch(String fileBatch) { this.fileBatch = fileBatch; }

    public String getFileOutput() { return fileOutput; }
    public void setFileOutput(String fileOutput) { this.fileOutput = fileOutput; }

    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }

    public LocalDateTime getActionDate() { return actionDate; }
    public void setActionDate(LocalDateTime actionDate) { this.actionDate = actionDate; }

    public String getUserAction() { return userAction; }
    public void setUserAction(String userAction) { this.userAction = userAction; }

    public Integer getIsDeleted() { return isDeleted; }
    public void setIsDeleted(Integer isDeleted) { this.isDeleted = isDeleted; }
}