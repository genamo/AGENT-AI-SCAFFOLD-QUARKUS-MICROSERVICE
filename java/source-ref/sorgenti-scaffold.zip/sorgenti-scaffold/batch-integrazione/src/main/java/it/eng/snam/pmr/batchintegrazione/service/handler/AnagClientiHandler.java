package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AnagClientiPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AnagClientiHandler extends AbstractFlussoHandler<AnagClientiPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AnagClientiPayloadDto> getDtoClass() {
        return AnagClientiPayloadDto.class;
    }

    @Override
    protected void handle(AnagClientiPayloadDto dto) {
    	
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAnagClienti(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteAnagClienti(dto.data().getFirst().codiceCliente());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}
    	
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ANAG_CLIENTI_FLOW;
    }
}