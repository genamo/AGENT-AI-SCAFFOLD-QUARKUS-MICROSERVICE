package it.eng.snam.pmr.common.config.jwt;

import java.util.List;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;

public class CompositeJwkProvider implements JwkProvider {

    private final List<JwkProvider> providers;

    public CompositeJwkProvider(List<JwkProvider> providers) {
        if (providers == null || providers.isEmpty())
            throw new IllegalArgumentException("At least one JWK provider is required");

        this.providers = List.copyOf(providers);
    }

    @Override
    public Jwk get(String keyId) throws JwkException {
        if (keyId == null || keyId.isBlank())
            throw new IllegalArgumentException("JWT kid is null or blank");

        JwkException lastException = null;
        for (JwkProvider provider : providers) {
            try {
                return provider.get(keyId);
            } catch (JwkException exception) {
                lastException = exception;
            }
        }

        throw new JwkException("Unable to find JWK for kid: " + keyId, lastException);
    }
}