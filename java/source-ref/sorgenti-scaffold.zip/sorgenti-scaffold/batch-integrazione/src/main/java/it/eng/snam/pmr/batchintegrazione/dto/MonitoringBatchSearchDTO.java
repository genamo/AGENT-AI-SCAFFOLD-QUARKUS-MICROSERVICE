package it.eng.snam.pmr.batchintegrazione.dto;

import lombok.Builder;

/**
 * DTO di ricerca per MonitoringFlussi.
 * Tutti i campi sono opzionali: se null/vuoto non vengono applicati come filtro.
 */
@Builder
public record MonitoringBatchSearchDTO(
        String transactionId,
        String correlationId,
        String flowId,
        Integer dayNumber,
        Integer monthNumber,
        String granularita,
        String sender,
        Boolean isWorkaround,
        Integer status
) {}
