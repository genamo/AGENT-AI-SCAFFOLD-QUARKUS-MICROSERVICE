package it.eng.snam.pmr.batchintegrazionedg.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.apache.kafka.common.header.Headers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration.MonitoringIntegrationOutcome;
import it.eng.snam.pmr.batchintegrazionedg.entity.MonitoringIntegrationMetadata;
import it.eng.snam.pmr.batchintegrazionedg.entity.MonitoringIntegrationRequest;
import it.eng.snam.pmr.batchintegrazionedg.entity.MonitoringIntegrationStatus;
import it.eng.snam.pmr.batchintegrazionedg.kafka.KafkaTopic;
import it.eng.snam.pmr.batchintegrazionedg.kafka.producer.KafkaGenericProducer;
import it.eng.snam.pmr.batchintegrazionedg.repository.MonitoringIntegrationMetadataRepository;
import it.eng.snam.pmr.batchintegrazionedg.repository.MonitoringIntegrationRequestRepository;
import it.eng.snam.pmr.batchintegrazionedg.repository.MonitoringIntegrationStatusRepository;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringIntegrationService;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.mdc.MdcManager;

@ExtendWith(MockitoExtension.class)
class MonitoringIntegrationServiceTest {

    @Test
    void sendRequestGenerateSend_shouldPersistRequestMetadataStatusSendKafkaAndReturnId() {
        MonitoringIntegrationRequestRepository requestRepository = mock(MonitoringIntegrationRequestRepository.class);
        MonitoringIntegrationMetadataRepository metadataRepository = mock(
                MonitoringIntegrationMetadataRepository.class);
        MonitoringIntegrationStatusRepository statusRepository = mock(MonitoringIntegrationStatusRepository.class);
        KafkaGenericProducer producer = mock(KafkaGenericProducer.class);

        MonitoringIntegrationService service = new MonitoringIntegrationService(requestRepository, metadataRepository,
                                                                                statusRepository, producer);

        MonitoringIntegration integrationRequest = new MonitoringIntegration();
        integrationRequest.setIntegrationType("TYPE_TEST");
        integrationRequest.setRequestBody("{\"a\":1}");

        when(requestRepository.findIdByTransactionId("TN-001")).thenReturn(Optional.of(55L));

        try (MockedStatic<MdcManager> mdc = mockStatic(MdcManager.class)) {
            mdc.when(() -> MdcManager.getHeader(AuthorizationUtils.USER_ID)).thenReturn("USER-001");
            mdc.when(() -> MdcManager.getHeader(CommonConstants.LogParams.TN)).thenReturn("TN-001");

            Long result = service.sendRequestGenerateSend(integrationRequest);

            assertEquals(55L, result);
        }

        ArgumentCaptor<MonitoringIntegrationRequest> requestCaptor = ArgumentCaptor.forClass(
                MonitoringIntegrationRequest.class);
        ArgumentCaptor<MonitoringIntegrationMetadata> metadataCaptor = ArgumentCaptor.forClass(
                MonitoringIntegrationMetadata.class);
        ArgumentCaptor<MonitoringIntegrationStatus> statusCaptor = ArgumentCaptor.forClass(
                MonitoringIntegrationStatus.class);

        verify(requestRepository).persist(requestCaptor.capture());
        verify(requestRepository).findIdByTransactionId("TN-001");
        verify(metadataRepository).persist(metadataCaptor.capture());
        verify(statusRepository).persist(statusCaptor.capture());
        verify(producer).sendEventWithHeaders(KafkaTopic.MONITORING_INTEGRATION, integrationRequest, null);

        MonitoringIntegrationRequest persistedRequest = requestCaptor.getValue();
        assertEquals("TYPE_TEST", persistedRequest.getIntegrationType());
        assertEquals("USER-001", persistedRequest.getUserId());
        assertEquals("TN-001", persistedRequest.getTransactionId());

        MonitoringIntegrationMetadata metadata = metadataCaptor.getValue();
        assertEquals(55L, metadata.getIntegrationRequestId());
        assertEquals("{\"a\":1}", metadata.getRequest());

        MonitoringIntegrationStatus status = statusCaptor.getValue();
        assertEquals(55L, status.getIntegrationRequestId());
    }

    @Test
    void persist_shouldUpdateRequestMetadataAndStatus() {
        MonitoringIntegrationRequestRepository requestRepository = mock(MonitoringIntegrationRequestRepository.class);
        MonitoringIntegrationMetadataRepository metadataRepository = mock(
                MonitoringIntegrationMetadataRepository.class);
        MonitoringIntegrationStatusRepository statusRepository = mock(MonitoringIntegrationStatusRepository.class);
        KafkaGenericProducer producer = mock(KafkaGenericProducer.class);

        MonitoringIntegrationService service = new MonitoringIntegrationService(requestRepository, metadataRepository,
                                                                                statusRepository, producer);

        MonitoringIntegrationOutcome payload = new MonitoringIntegrationOutcome();
        payload.setIntegrationType("TYPE_UPDATED");
        payload.setResponseBody("RESPONSE_BODY");
        payload.setContentType("application/json");
        payload.setResponseStatusCode(200);
        payload.setResponseStatus("OK");

        MonitoringIntegrationRequest request = new MonitoringIntegrationRequest();
        request.setId(99L);
        request.setTransactionId("TN-001");
        request.setUserId("USER-001");

        MonitoringIntegrationMetadata metadata = new MonitoringIntegrationMetadata();
        MonitoringIntegrationStatus status = new MonitoringIntegrationStatus();

        when(requestRepository.findByTransactionIdAndUserId("TN-001", "USER-001")).thenReturn(Optional.of(request));
        when(metadataRepository.findByIntegrationRequestId(99L)).thenReturn(Optional.of(metadata));
        when(statusRepository.findByUploadRequestId(99L)).thenReturn(Optional.of(status));

        Headers headers = mock(Headers.class);

        try (MockedStatic<MdcManager> mdc = mockStatic(MdcManager.class)) {
            mdc.when(() -> MdcManager.getHeader(CommonConstants.LogParams.TN)).thenReturn("TN-001");
            mdc.when(() -> MdcManager.getHeader(AuthorizationUtils.USER_ID)).thenReturn("USER-001");

            service.persist(payload, headers);
        }

        verify(requestRepository).findByTransactionIdAndUserId("TN-001", "USER-001");
        verify(metadataRepository).findByIntegrationRequestId(99L);
        verify(statusRepository).findByUploadRequestId(99L);

        verify(requestRepository).persist(request);
        verify(metadataRepository).persist(metadata);
        verify(statusRepository).persist(status);

        assertEquals("TYPE_UPDATED", request.getIntegrationType());
        assertEquals("RESPONSE_BODY", metadata.getResponse());

        assertEquals("application/json", status.getContentType());
        assertEquals(200, status.getStatus());
        assertEquals("OK", status.getStatusMessage());

        verifyNoInteractions(producer);
    }

    @Test
    void sendRequestGenerateSend_shouldThrowWhenRequestIdNotFound() {
        MonitoringIntegrationRequestRepository requestRepository = mock(MonitoringIntegrationRequestRepository.class);
        MonitoringIntegrationMetadataRepository metadataRepository = mock(
                MonitoringIntegrationMetadataRepository.class);
        MonitoringIntegrationStatusRepository statusRepository = mock(MonitoringIntegrationStatusRepository.class);
        KafkaGenericProducer producer = mock(KafkaGenericProducer.class);

        MonitoringIntegrationService service = new MonitoringIntegrationService(requestRepository, metadataRepository,
                                                                                statusRepository, producer);

        MonitoringIntegration integrationRequest = new MonitoringIntegration();
        integrationRequest.setIntegrationType("TYPE_TEST");
        integrationRequest.setRequestBody("{}");

        when(requestRepository.findIdByTransactionId("TN-001")).thenReturn(Optional.empty());

        try (MockedStatic<MdcManager> mdc = mockStatic(MdcManager.class)) {
            mdc.when(() -> MdcManager.getHeader(AuthorizationUtils.USER_ID)).thenReturn("USER-001");
            mdc.when(() -> MdcManager.getHeader(CommonConstants.LogParams.TN)).thenReturn("TN-001");

            assertThrows(NoSuchElementException.class, () -> service.sendRequestGenerateSend(integrationRequest));
        }

        verify(requestRepository).persist(any(MonitoringIntegrationRequest.class));
        verify(requestRepository).findIdByTransactionId("TN-001");
        verifyNoInteractions(metadataRepository, statusRepository, producer);
    }

    @Test
    void persist_shouldThrowWhenRequestNotFound() {
        MonitoringIntegrationRequestRepository requestRepository = mock(MonitoringIntegrationRequestRepository.class);
        MonitoringIntegrationMetadataRepository metadataRepository = mock(
                MonitoringIntegrationMetadataRepository.class);
        MonitoringIntegrationStatusRepository statusRepository = mock(MonitoringIntegrationStatusRepository.class);
        KafkaGenericProducer producer = mock(KafkaGenericProducer.class);

        MonitoringIntegrationService service = new MonitoringIntegrationService(requestRepository, metadataRepository,
                                                                                statusRepository, producer);

        MonitoringIntegrationOutcome payload = new MonitoringIntegrationOutcome();

        when(requestRepository.findByTransactionIdAndUserId("TN-001", "USER-001")).thenReturn(Optional.empty());

        try (MockedStatic<MdcManager> mdc = mockStatic(MdcManager.class)) {
            mdc.when(() -> MdcManager.getHeader(CommonConstants.LogParams.TN)).thenReturn("TN-001");
            mdc.when(() -> MdcManager.getHeader(AuthorizationUtils.USER_ID)).thenReturn("USER-001");

            assertThrows(NoSuchElementException.class, () -> service.persist(payload, mock(Headers.class)));
        }

        verify(requestRepository).findByTransactionIdAndUserId("TN-001", "USER-001");
        verifyNoInteractions(metadataRepository, statusRepository, producer);
    }
}
