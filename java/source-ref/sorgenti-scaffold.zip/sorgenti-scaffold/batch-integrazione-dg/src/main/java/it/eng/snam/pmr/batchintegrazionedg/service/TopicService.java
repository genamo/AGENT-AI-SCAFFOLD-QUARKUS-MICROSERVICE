package it.eng.snam.pmr.batchintegrazionedg.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import it.eng.snam.pmr.batchintegrazionedg.utils.Constants.Topic;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class TopicService {

    private static final Logger logger = LoggerFactory.getLogger(TopicService.class);

    @ConfigProperty(name = "kafka-prefix.topics")
    String prefix;

    private final Map<String, String> realTopics = new ConcurrentHashMap<>();

    public String getRealTopic(String topicName) {
        if (topicName == null || topicName.isBlank()) {
            throw new IllegalArgumentException("Topic non valido");
        }
        if (prefix == null || prefix.isBlank()) {
            throw new IllegalStateException("Property 'kafka-prefix.topics' non configurata o vuota");
        }

        // inizializza una sola volta in modo thread-safe
        if (realTopics.isEmpty()) {
            synchronized (this) {
                if (realTopics.isEmpty()) {
                    try {
						Topic.getAllTopicsValue()
						    .forEach(t -> realTopics.put(t, prefix +"-" + t));
					} catch (Exception e) {
						
					} 
                    logger.info("TopicService cache inizializzata. prefix={}", prefix);
                }
            }
        }

        String real = realTopics.get(topicName);
        if (real == null) {
            throw new IllegalArgumentException("Topic sconosciuto: " + topicName);
        }
        return real;
    }
}
