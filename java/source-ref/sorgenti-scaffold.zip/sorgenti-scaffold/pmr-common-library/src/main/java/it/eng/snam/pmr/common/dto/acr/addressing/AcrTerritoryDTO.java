package it.eng.snam.pmr.common.dto.acr.addressing;

import lombok.Builder;

@Builder
public record AcrTerritoryDTO(
        Integer territoryId,
        String territoryDescription,
        String sapTerritoryCode
) {}
