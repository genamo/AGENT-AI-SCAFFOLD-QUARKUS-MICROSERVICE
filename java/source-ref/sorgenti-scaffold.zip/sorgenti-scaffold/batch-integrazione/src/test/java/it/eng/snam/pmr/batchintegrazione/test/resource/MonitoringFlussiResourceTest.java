package it.eng.snam.pmr.batchintegrazione.test.resource;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.dto.MonitoringFlussiDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringFlussiSearchDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.resource.MonitoringFlussiResource;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringFlussiService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class MonitoringFlussiResourceTest {

    @Mock MonitoringFlussiService service;
    @Mock Utility utility;
    @InjectMocks MonitoringFlussiResource resource;

    private Response mockResp() { return mock(Response.class); }

    // ---- getAll ----

    @Test
    void getAll_success() {
        List<MonitoringFlussiDTO> list = List.of(MonitoringFlussiDTO.builder().build());
        when(service.getAll()).thenReturn(list);
        Response resp = mockResp();
        when(utility.okOrEmpty(list)).thenReturn(resp);
        assertSame(resp, resource.getAll());
    }

    @Test
    void getAll_illegalArg() {
        when(service.getAll()).thenThrow(new IllegalArgumentException("bad"));
        Response resp = mockResp();
        when(utility.badRequest("bad")).thenReturn(resp);
        assertSame(resp, resource.getAll());
    }

    @Test
    void getAll_remoteError() {
        RemoteCallException ex = new RemoteCallException("err");
        when(service.getAll()).thenThrow(ex);
        Response resp = mockResp();
        when(utility.badGateway(ex)).thenReturn(resp);
        assertSame(resp, resource.getAll());
    }

    // ---- getById ----

    @Test
    void getById_null_badRequest() {
        Response resp = mockResp();
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.getById(null));
        verify(service, never()).getById(any());
    }

    @Test
    void getById_zero_badRequest() {
        Response resp = mockResp();
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.getById(0L));
    }

    @Test
    void getById_negative_badRequest() {
        Response resp = mockResp();
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.getById(-5L));
    }

    @Test
    void getById_found() {
        Optional<MonitoringFlussiDTO> opt = Optional.of(MonitoringFlussiDTO.builder().build());
        when(service.getById(1L)).thenReturn(opt);
        Response resp = mockResp();
        when(utility.okOrNotFound(eq(opt), anyString())).thenReturn(resp);
        assertSame(resp, resource.getById(1L));
    }

    @Test
    void getById_notFound() {
        Optional<MonitoringFlussiDTO> opt = Optional.empty();
        when(service.getById(99L)).thenReturn(opt);
        Response resp = mockResp();
        when(utility.okOrNotFound(eq(opt), anyString())).thenReturn(resp);
        assertSame(resp, resource.getById(99L));
    }

    @Test
    void getById_illegalArg() {
        when(service.getById(1L)).thenThrow(new IllegalArgumentException("bad"));
        Response resp = mockResp();
        when(utility.badRequest("bad")).thenReturn(resp);
        assertSame(resp, resource.getById(1L));
    }

    @Test
    void getById_remoteError() {
        RemoteCallException ex = new RemoteCallException("err");
        when(service.getById(1L)).thenThrow(ex);
        Response resp = mockResp();
        when(utility.badGateway(ex)).thenReturn(resp);
        assertSame(resp, resource.getById(1L));
    }

    // ---- getByTransactionId ----

    @Test
    void getByTransactionId_null_badRequest() {
        Response resp = mockResp();
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.getByTransactionId(null));
        verify(service, never()).getByTransactionId(any());
    }

    @Test
    void getByTransactionId_blank_badRequest() {
        Response resp = mockResp();
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.getByTransactionId("  "));
    }

    @Test
    void getByTransactionId_found() {
        Optional<MonitoringFlussiDTO> opt = Optional.of(MonitoringFlussiDTO.builder().build());
        when(service.getByTransactionId("tx1")).thenReturn(opt);
        Response resp = mockResp();
        when(utility.okOrNotFound(eq(opt), anyString())).thenReturn(resp);
        assertSame(resp, resource.getByTransactionId("tx1"));
    }

    @Test
    void getByTransactionId_illegalArg() {
        when(service.getByTransactionId("tx1")).thenThrow(new IllegalArgumentException("bad"));
        Response resp = mockResp();
        when(utility.badRequest("bad")).thenReturn(resp);
        assertSame(resp, resource.getByTransactionId("tx1"));
    }

    @Test
    void getByTransactionId_remoteError() {
        RemoteCallException ex = new RemoteCallException("err");
        when(service.getByTransactionId("tx1")).thenThrow(ex);
        Response resp = mockResp();
        when(utility.badGateway(ex)).thenReturn(resp);
        assertSame(resp, resource.getByTransactionId("tx1"));
    }

    // ---- getLastExecutions ----

    @Test
    void getLastExecutions_null_defaultsTo10() {
        List<MonitoringFlussiDTO> list = List.of();
        when(service.getLastExecutions(10)).thenReturn(list);
        Response resp = mockResp();
        when(utility.okOrEmpty(list)).thenReturn(resp);
        assertSame(resp, resource.getLastExecutions(null));
        verify(service).getLastExecutions(10);
    }

    @Test
    void getLastExecutions_zero_badRequest() {
        Response resp = mockResp();
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.getLastExecutions(0));
    }

    @Test
    void getLastExecutions_negative_badRequest() {
        Response resp = mockResp();
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.getLastExecutions(-3));
    }

    @Test
    void getLastExecutions_validLimit() {
        List<MonitoringFlussiDTO> list = List.of(MonitoringFlussiDTO.builder().build());
        when(service.getLastExecutions(5)).thenReturn(list);
        Response resp = mockResp();
        when(utility.okOrEmpty(list)).thenReturn(resp);
        assertSame(resp, resource.getLastExecutions(5));
    }

    @Test
    void getLastExecutions_remoteError() {
        RemoteCallException ex = new RemoteCallException("err");
        when(service.getLastExecutions(5)).thenThrow(ex);
        Response resp = mockResp();
        when(utility.badGateway(ex)).thenReturn(resp);
        assertSame(resp, resource.getLastExecutions(5));
    }

    // ---- getByPeriod ----

    @Test
    void getByPeriod_success() {
        List<MonitoringFlussiDTO> list = List.of();
        when(service.getByPeriod(1, 15)).thenReturn(list);
        Response resp = mockResp();
        when(utility.okOrEmpty(list)).thenReturn(resp);
        assertSame(resp, resource.getByPeriod(1, 15));
    }

    @Test
    void getByPeriod_illegalArg() {
        when(service.getByPeriod(any(), any())).thenThrow(new IllegalArgumentException("bad"));
        Response resp = mockResp();
        when(utility.badRequest("bad")).thenReturn(resp);
        assertSame(resp, resource.getByPeriod(1, 15));
    }

    @Test
    void getByPeriod_remoteError() {
        RemoteCallException ex = new RemoteCallException("err");
        when(service.getByPeriod(any(), any())).thenThrow(ex);
        Response resp = mockResp();
        when(utility.badGateway(ex)).thenReturn(resp);
        assertSame(resp, resource.getByPeriod(1, 15));
    }

    // ---- save ----

    @Test
    void save_null_badRequest() {
        Response resp = mockResp();
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.save(null));
        verify(service, never()).save(any());
    }

    @Test
    void save_success() {
        MonitoringFlussiDTO dto = MonitoringFlussiDTO.builder().transactionId("tx1").build();
        when(service.save(dto)).thenReturn(dto);
        Response resp = mockResp();
        when(utility.ok(dto)).thenReturn(resp);
        assertSame(resp, resource.save(dto));
    }

    @Test
    void save_illegalArg() {
        MonitoringFlussiDTO dto = MonitoringFlussiDTO.builder().build();
        when(service.save(dto)).thenThrow(new IllegalArgumentException("bad"));
        Response resp = mockResp();
        when(utility.badRequest("bad")).thenReturn(resp);
        assertSame(resp, resource.save(dto));
    }

    @Test
    void save_remoteError() {
        MonitoringFlussiDTO dto = MonitoringFlussiDTO.builder().build();
        RemoteCallException ex = new RemoteCallException("err");
        when(service.save(dto)).thenThrow(ex);
        Response resp = mockResp();
        when(utility.badGateway(ex)).thenReturn(resp);
        assertSame(resp, resource.save(dto));
    }

    // ---- findByCustomSearch ----

    @Test
    void findByCustomSearch_null_badRequest() {
        Response resp = mockResp();
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.findByCustomSearch(null));
        verify(service, never()).findByCustomSearch(any());
    }

    @Test
    void findByCustomSearch_success() {
        MonitoringFlussiSearchDTO search = MonitoringFlussiSearchDTO.builder().build();
        List<MonitoringFlussiDTO> list = List.of();
        when(service.findByCustomSearch(search)).thenReturn(list);
        Response resp = mockResp();
        when(utility.okOrEmpty(list)).thenReturn(resp);
        assertSame(resp, resource.findByCustomSearch(search));
    }

    @Test
    void findByCustomSearch_illegalArg() {
        MonitoringFlussiSearchDTO search = MonitoringFlussiSearchDTO.builder().build();
        when(service.findByCustomSearch(search)).thenThrow(new IllegalArgumentException("bad"));
        Response resp = mockResp();
        when(utility.badRequest("bad")).thenReturn(resp);
        assertSame(resp, resource.findByCustomSearch(search));
    }

    @Test
    void findByCustomSearch_remoteError() {
        MonitoringFlussiSearchDTO search = MonitoringFlussiSearchDTO.builder().build();
        RemoteCallException ex = new RemoteCallException("err");
        when(service.findByCustomSearch(search)).thenThrow(ex);
        Response resp = mockResp();
        when(utility.badGateway(ex)).thenReturn(resp);
        assertSame(resp, resource.findByCustomSearch(search));
    }
}
