package it.eng.snam.pmr.common.client;

import static org.assertj.core.api.Assertions.assertThat;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import org.junit.jupiter.api.Test;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

class AnagraficheConeClientTest {

    @Test
    void interface_hasExpectedRestClientAnnotations() {
        Path path = AnagraficheConeClient.class.getAnnotation(Path.class);
        RegisterRestClient restClient = AnagraficheConeClient.class.getAnnotation(RegisterRestClient.class);
        Consumes consumes = AnagraficheConeClient.class.getAnnotation(Consumes.class);
        Produces produces = AnagraficheConeClient.class.getAnnotation(Produces.class);

        assertThat(path).isNotNull();
        assertThat(path.value()).isEqualTo("/");

        assertThat(restClient).isNotNull();
        assertThat(restClient.configKey()).isEqualTo("anagrafiche-client");

        assertThat(consumes).isNotNull();
        assertThat(consumes.value()).containsExactly(MediaType.APPLICATION_JSON);

        assertThat(produces).isNotNull();
        assertThat(produces.value()).containsExactly(MediaType.APPLICATION_JSON);
    }

    @Test
    void getCurrentUserCone_hasExpectedContract() throws Exception {
        Method method = AnagraficheConeClient.class.getMethod("getCurrentUserCone", String.class);

        assertThat(method.getAnnotation(GET.class)).isNotNull();

        Path path = method.getAnnotation(Path.class);
        assertThat(path).isNotNull();
        assertThat(path.value()).isEqualTo("/an_remi-cone_getCurrentUser");

        assertThat(method.getReturnType()).isEqualTo(Response.class);

        Annotation[][] paramAnnotations = method.getParameterAnnotations();
        
        assertThat(paramAnnotations[0]).hasSize(1);
        assertThat(paramAnnotations[0][0]).isInstanceOf(HeaderParam.class);
        assertThat(((HeaderParam) paramAnnotations[0][0]).value()).isEqualTo("Authorization");
    }
}
