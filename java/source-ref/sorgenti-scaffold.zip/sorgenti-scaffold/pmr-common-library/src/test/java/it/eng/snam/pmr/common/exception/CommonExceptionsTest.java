package it.eng.snam.pmr.common.exception;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CommonExceptionsTest {

    @Test
    void remoteCallException_constructors_work() {
        Throwable cause = new IllegalStateException("cause");

        RemoteCallException ex1 = new RemoteCallException("msg");
        RemoteCallException ex2 = new RemoteCallException("msg", cause);

        assertThat(ex1).hasMessage("msg");
        assertThat(ex2).hasMessage("msg").hasCause(cause);
    }

    @Test
    void internalServerException_constructors_work() {
        Throwable cause = new IllegalStateException("cause");

        InternalServerException ex1 = new InternalServerException("msg");
        InternalServerException ex2 = new InternalServerException("msg", cause);

        assertThat(ex1).hasMessage("msg");
        assertThat(ex2).hasMessage("msg").hasCause(cause);
    }

    @Test
    void retryableRemoteException_constructors_work() {
        Throwable cause = new IllegalStateException("cause");

        RetryableRemoteException ex1 = new RetryableRemoteException("msg");
        RetryableRemoteException ex2 = new RetryableRemoteException("msg", cause);

        assertThat(ex1).hasMessage("msg");
        assertThat(ex2).hasMessage("msg").hasCause(cause);
    }
}
