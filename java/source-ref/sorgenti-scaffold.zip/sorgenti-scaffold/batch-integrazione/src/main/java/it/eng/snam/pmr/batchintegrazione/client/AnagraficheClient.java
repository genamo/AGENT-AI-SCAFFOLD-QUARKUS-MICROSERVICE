package it.eng.snam.pmr.batchintegrazione.client;

import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagAreaTecnicaDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagClientiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagMacroPoloDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagPoloDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagRaggruppamentiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagTipoStatoRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssAreaTecnicaDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRaggruppamentiRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiAopDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiClientiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiTipoBilancioTecnicoDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiTitolariDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssStatoRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.ContattoDto;
import it.eng.snam.pmr.batchintegrazione.filter.RestClientHeadersFilter;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Produces(MediaType.APPLICATION_JSON)
@RegisterRestClient(configKey = "anagrafiche-client")
@RegisterProvider(RestClientHeadersFilter.class)
public interface AnagraficheClient {

	// ======================================================
	// ANAG AREA TECNICA
	// ======================================================

	@GET
	@Path("/an_anag-area-tecnica_getAll")
	Response getAllAnagAreaTecnica(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_anag-area-tecnica_searchByCodiceArea")
	Response findAnagAreaTecnicaByCodiceArea(@HeaderParam("Authorization") String auth, @QueryParam("codiceArea") String codiceArea);

	@POST
	@Path("/an_anag-area-tecnica_save")
	Response saveAnagAreaTecnica(@HeaderParam("Authorization") String auth, AnagAreaTecnicaDto dto);

	@DELETE
	@Path("/an_anag-area-tecnica_delete")
	Response deleteAnagAreaTecnica(@HeaderParam("Authorization") String auth, @QueryParam("codiceArea") String codiceArea);

	@PUT
	@Path("/an_anag-area-tecnica_restore")
	Response restoreAnagAreaTecnica(@HeaderParam("Authorization") String auth, @QueryParam("codiceArea") String codiceArea);

	// ======================================================
	// ANAG CLIENTI
	// ======================================================

	@GET
	@Path("/an_anag-clienti_getAll")
	Response getAllAnagClienti(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_anag-clienti_searchByCodiceCliente")
	Response findAnagClientiByCodiceCliente(@HeaderParam("Authorization") String auth, @QueryParam("codiceCliente") String codiceCliente);

	@POST
	@Path("/an_anag-clienti_save")
	Response saveAnagClienti(@HeaderParam("Authorization") String auth, AnagClientiDto dto);

	@DELETE
	@Path("/an_anag-clienti_delete")
	Response deleteAnagClienti(@HeaderParam("Authorization") String auth, @QueryParam("codiceCliente") String codiceCliente);

	@PUT
	@Path("/an_anag-clienti_restore")
	Response restoreAnagClienti(@HeaderParam("Authorization") String auth, @QueryParam("codiceCliente") String codiceCliente);

	// ======================================================
	// ANAG MACRO POLO
	// ======================================================

	@GET
	@Path("/an_anag-macro-polo_getAll")
	Response getAllAnagMacroPolo(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_anag-macro-polo_searchByCodice")
	Response findAnagMacroPoloByCodiceMacroPolo(@HeaderParam("Authorization") String auth, @QueryParam("codiceMacroPolo") String codiceMacroPolo);

	@POST
	@Path("/an_anag-macro-polo_save")
	Response saveAnagMacroPolo(@HeaderParam("Authorization") String auth, AnagMacroPoloDto dto);

	@DELETE
	@Path("/an_anag-macro-polo_delete")
	Response deleteAnagMacroPolo(@HeaderParam("Authorization") String auth, @QueryParam("codiceMacroPolo") String codiceMacroPolo);

	@PUT
	@Path("/an_anag-macro-polo_restore")
	Response restoreAnagMacroPolo(@HeaderParam("Authorization") String auth, @QueryParam("codiceMacroPolo") String codiceMacroPolo);

	// ======================================================
	// ANAG POLO
	// ======================================================

	@GET
	@Path("/an_anag-polo_getAll")
	Response getAllAnagPolo(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_anag-polo_searchByCodicePolo")
	Response findAnagPoloByCodicePolo(@HeaderParam("Authorization") String auth, @QueryParam("codicePolo") String codicePolo);

	@GET
	@Path("/an_anag-polo_searchByCodiceMacroPolo")
	Response findAnagPoloByCodiceMacroPolo(@HeaderParam("Authorization") String auth, @QueryParam("codiceMacroPolo") String codiceMacroPolo);

	@POST
	@Path("/an_anag-polo_save")
	Response saveAnagPolo(@HeaderParam("Authorization") String auth, AnagPoloDto dto);
	
	@DELETE
	@Path("/an_anag-polo_delete")
	Response deleteAnagPolo(@HeaderParam("Authorization") String auth, @QueryParam("codicePolo") String codicePolo);

	// ======================================================
	// ANAG RAGGRUPPAMENTI
	// ======================================================

	@GET
	@Path("/an_anag-raggruppamenti_getAll")
	Response getAllAnagRaggruppamenti(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_anag-raggruppamenti_searchByCodice")
	Response findAnagRaggruppamentiByCodiceRaggrRemi(@HeaderParam("Authorization") String auth, @QueryParam("codiceRaggrRemi") String codiceRaggrRemi);

	@POST
	@Path("/an_anag-raggruppamenti_save")
	Response saveAnagRaggruppamenti(@HeaderParam("Authorization") String auth, AnagRaggruppamentiDto dto);

	@DELETE
	@Path("/an_anag-raggruppamenti_delete")
	Response deleteAnagRaggruppamenti(@HeaderParam("Authorization") String auth, @QueryParam("codiceRaggrRemi") String codiceRaggrRemi);

	@PUT
	@Path("/an_anag-raggruppamenti_restore")
	Response restoreAnagRaggruppamenti(@HeaderParam("Authorization") String auth, @QueryParam("codiceRaggrRemi") String codiceRaggrRemi);

	// ======================================================
	// ANAG REMI
	// ======================================================

	@GET
	@Path("/an_anag-remi_getAll")
	Response getAllAnagRemi(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_anag-remi_searchByRemiAssoluto")
	Response findAnagRemiByRemiAssoluto(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto);

	@POST
	@Path("/an_anag-remi_save")
	Response saveAnagRemi(@HeaderParam("Authorization") String auth, AnagRemiDto dto);

	@DELETE
	@Path("/an_anag-remi_delete")
	Response deleteAnagRemi(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto);

	@PUT
	@Path("/an_anag-remi_restore")
	Response restoreAnagRemi(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto);

	// ======================================================
	// ANAG TIPO STATO REMI
	// ======================================================

	@GET
	@Path("/an_anag-tipo-stato-remi_getAll")
	Response getAllAnagTipoStatoRemi(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_anag-tipo-stato-remi_searchByCodice")
	Response findAnagTipoStatoRemiByCodiceStato(@HeaderParam("Authorization") String auth, @QueryParam("codiceStato") String codiceStato);

	@POST
	@Path("/an_anag-tipo-stato-remi_save")
	Response saveAnagTipoStatoRemi(@HeaderParam("Authorization") String auth, AnagTipoStatoRemiDto dto);

	@DELETE
	@Path("/an_anag-tipo-stato-remi_delete")
	Response deleteAnagTipoStatoRemi(@HeaderParam("Authorization") String auth, @QueryParam("codiceStato") String codiceStato);

	@PUT
	@Path("/an_anag-tipo-stato-remi_restore")
	Response restoreAnagTipoStatoRemi(@HeaderParam("Authorization") String auth, @QueryParam("codiceStato") String codiceStato);

	// ======================================================
	// ASS AREA TECNICA
	// ======================================================

	@GET
	@Path("/an_ass-area-tecnica_getAll")
	Response getAllAssAreaTecnica(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_ass-area-tecnica_searchByCodice")
	Response findAssAreaTecnicaByCodiceAreaTecnica(@HeaderParam("Authorization") String auth, @QueryParam("codiceAreaTecnica") String codiceAreaTecnica);

	@POST
	@Path("/an_ass-area-tecnica_save")
	Response saveAssAreaTecnica(@HeaderParam("Authorization") String auth, AssAreaTecnicaDto dto);

	@DELETE
	@Path("/an_ass-area-tecnica_delete")
	Response deleteAssAreaTecnica(@HeaderParam("Authorization") String auth, @QueryParam("codiceAreaTecnica") String codiceAreaTecnica);

	@PUT
	@Path("/an_ass-area-tecnica_restore")
	Response restoreAssAreaTecnica(@HeaderParam("Authorization") String auth, @QueryParam("codiceAreaTecnica") String codiceAreaTecnica);

	// ======================================================
	// ASS RAGGRUPPAMENTI REMI
	// ======================================================

	@GET
	@Path("/an_ass-raggruppamenti-remi_getAll")
	Response getAllAssRaggruppamentiRemi(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_ass-raggruppamenti-remi_searchByRemi")
	Response findAssRaggruppamentiRemiByRemiAssoluto(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto);

	@POST
	@Path("/an_ass-raggruppamenti-remi_save")
	Response saveAssRaggruppamentiRemi(@HeaderParam("Authorization") String auth, AssRaggruppamentiRemiDto dto);

	@DELETE
	@Path("/an_ass-raggruppamenti-remi_delete")
	Response deleteAssRaggruppamentiRemi(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto,@QueryParam("codiceRaggrRemi") String codiceRaggrRemi);

	@PUT
	@Path("/an_ass-raggruppamenti-remi_restore")
	Response restoreAssRaggruppamentiRemi(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto);

	// ======================================================
	// ASS REMI AOP
	// ======================================================

	@GET
	@Path("/an_ass-remi-aop_getAll")
	Response getAllAssRemiAop(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_ass-remi-aop_searchByRemiAssoluto")
	Response findAssRemiAopByRemiAssoluto(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto);

	@GET
	@Path("/an_ass-remi-aop_searchByPk")
	Response findAssRemiAopByPk(@HeaderParam("Authorization") String auth, @QueryParam("codiceAop") Long codiceAop, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataInizioAopInt") Long dataInizioAopInt);

	@POST
	@Path("/an_ass-remi-aop_save")
	Response saveAssRemiAop(@HeaderParam("Authorization") String auth, AssRemiAopDto dto);

	@DELETE
	@Path("/an_ass-remi-aop_delete")
	Response deleteAssRemiAop(@HeaderParam("Authorization") String auth, @QueryParam("codiceAop") Long codiceAop, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataInizioAopInt") Long dataInizioAopInt);

	@PUT
	@Path("/an_ass-remi-aop_restore")
	Response restoreAssRemiAop(@HeaderParam("Authorization") String auth, @QueryParam("codiceAop") Long codiceAop, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataInizioAopInt") Long dataInizioAopInt);

	// ======================================================
	// ASS REMI CLIENTI
	// ======================================================
	
	@POST
	@Path("/an_ass-remi-clienti_save")
	Response saveAssRemiClienti(@HeaderParam("Authorization") String auth, AssRemiClientiDto dto);
	
	@DELETE
	@Path("/an_ass-remi-clienti_delete")
	Response deleteAssRemiClienti(@HeaderParam("Authorization") String auth,  @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataInizioValiditaInt") Long dataInizioValiditaInt);

	
	// ======================================================
	// ASS REMI TIPO BILANCIO TECNICO
	// ======================================================

	@GET
	@Path("/an_ass-remi-tipo-bilancio-tecnico_getAll")
	Response getAllAssRemiTipoBilancioTecnico(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_ass-remi-tipo-bilancio-tecnico_searchByPk")
	Response findAssRemiTipoBilancioTecnicoByPk(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataInizioInt") Long dataInizioInt);

	@POST
	@Path("/an_ass-remi-tipo-bilancio-tecnico_save")
	Response saveAssRemiTipoBilancioTecnico(@HeaderParam("Authorization") String auth, AssRemiTipoBilancioTecnicoDto dto);

	@DELETE
	@Path("/an_ass-remi-tipo-bilancio-tecnico_delete")
	Response deleteAssRemiTipoBilancioTecnico(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataInizioInt") Long dataInizioInt);

	@PUT
	@Path("/an_ass-remi-tipo-bilancio-tecnico_restore")
	Response restoreAssRemiTipoBilancioTecnico(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataInizioInt") Long dataInizioInt);

	// ======================================================
	// ASS REMI TITOLARI
	// ======================================================

	@GET
	@Path("/an_ass-remi-titolari_getAll")
	Response getAllAssRemiTitolari(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_ass-remi-titolari_searchByCodiceCliente")
	Response findAssRemiTitolariByCodiceCliente(@HeaderParam("Authorization") String auth, @QueryParam("codiceCliente") String codiceCliente);

	@GET
	@Path("/an_ass-remi-titolari_searchByPk")
	Response findAssRemiTitolariByPk(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataInizioValiditaInt") Long dataInizioValiditaInt);

	@POST
	@Path("/an_ass-remi-titolari_save")
	Response saveAssRemiTitolari(@HeaderParam("Authorization") String auth, AssRemiTitolariDto dto);

	@DELETE
	@Path("/an_ass-remi-titolari_delete")
	Response deleteAssRemiTitolari(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataInizioValiditaInt") Long dataInizioValiditaInt);

	@PUT
	@Path("/an_ass-remi-titolari_restore")
	Response restoreAssRemiTitolari(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataInizioValiditaInt") Long dataInizioValiditaInt);

	// ======================================================
	// ASS STATO REMI
	// ======================================================

	@GET
	@Path("/an_ass-stato-remi_getAll")
	Response getAllAssStatoRemi(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_ass-stato-remi_searchAssStatoRemiByRemiAssoluto")
	Response findAssStatoRemiByRemiAssoluto(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto);

	@GET
	@Path("/an_ass-stato-remi_searchAssStatoRemiByRemiAssolutoAndDataEvento")
	Response findAssStatoRemiByRemiAssolutoAndDataEvento(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataEvento") String dataEvento);

	@POST
	@Path("/an_ass-stato-remi_saveAssStatoRemi")
	Response saveAssStatoRemi(@HeaderParam("Authorization") String auth, AssStatoRemiDto dto);

	@DELETE
	@Path("/an_ass-stato-remi_deleteAssStatoRemi")
	Response deleteAssStatoRemi(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataEvento") String dataEvento);

	@PUT
	@Path("/an_ass-stato-remi_restoreAssStatoRemi")
	Response restoreAssStatoRemi(@HeaderParam("Authorization") String auth, @QueryParam("remiAssoluto") String remiAssoluto, @QueryParam("dataEvento") String dataEvento);

	// ======================================================
	// CONTATTO
	// ======================================================

	@GET
	@Path("/an_contatto_getAll")
	Response getAllContatto(@HeaderParam("Authorization") String auth);

	@GET
	@Path("/an_contatto_searchByIdContatto")
	Response findContattoByIdContatto(@HeaderParam("Authorization") String auth, @QueryParam("idContatto") Integer idContatto);

	@POST
	@Path("/an_contatto_save")
	Response saveContatto(@HeaderParam("Authorization") String auth, ContattoDto dto);

	@DELETE
	@Path("/an_contatto_delete")
	Response deleteContatto(@HeaderParam("Authorization") String auth, @QueryParam("idContatto") Integer idContatto);

	@PUT
	@Path("/an_contatto_restore")
	Response restoreContatto(@HeaderParam("Authorization") String auth, @QueryParam("idContatto") Integer idContatto);
}
