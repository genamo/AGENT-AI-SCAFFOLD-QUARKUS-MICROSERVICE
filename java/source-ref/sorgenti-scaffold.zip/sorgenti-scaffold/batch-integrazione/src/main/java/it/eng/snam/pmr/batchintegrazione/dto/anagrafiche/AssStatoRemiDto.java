package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AssStatoRemiDto(
        String remiAssoluto,
        LocalDateTime dataEvento,
        String codiceStato,
        String tipoIntervento,
        LocalDateTime actionDate,
        String userAction,
        Integer isDeleted
) {}