package it.eng.snam.pmr.batchintegrazionedg.service.abstracts;

import java.util.Optional;

import org.jboss.logging.Logger;

import jakarta.persistence.PersistenceException;

public abstract class AbstractPersistenceRetryService<REQ, RES> {

    protected static final int MAX_DB_RETRIES = 5;
    private static final long BASE_DELAY_MS = 600L;

    private static final String[] DUPLICATE_MARKERS = { "2601", "2627", "duplicate" };
    private static final String[] DEADLOCK_MARKERS = { "1205" };
    private static final String[] LOCK_TIMEOUT_MARKERS = {
            "1222",
            "lock request time out period exceeded"
    };
    private static final String[] TIMEOUT_MARKERS = { "timeout", "timed out" };

    protected final RES executeWithRetry(
            REQ request,
            RetryableOperation<REQ, RES> operation,
            String opName) {

        for (int attempt = 1; attempt <= MAX_DB_RETRIES; attempt++) {
            try {
                return operation.execute(request);

            } catch (PersistenceException e) {

                Optional<RES> handled = handlePersistenceException(request, e);
                if (handled.isPresent()) {
                    return handled.get();
                }

                if (isRetryablePersistenceError(e)) {
                    logger().warnf(
                            e,
                            "Tentativo %s %d/%d fallito per transactionId=%s (transiente DB/lock)",
                            opName, attempt, MAX_DB_RETRIES, transactionIdOf(request));

                    if (attempt == MAX_DB_RETRIES) {
                        return fallbackError(request, "DB_RETRY_EXHAUSTED_" + opName);
                    }

                    sleepBackoff(attempt);
                    continue;
                }

                logger().errorf(
                        e,
                        "Errore DB non transient durante %s transactionId=%s",
                        opName, transactionIdOf(request));
                return fallbackError(request, "DB_ERROR_" + opName);

            } catch (Exception e) {
                logger().errorf(
                        e,
                        "Errore inatteso durante %s transactionId=%s",
                        opName, transactionIdOf(request));
                return fallbackError(request, "UNEXPECTED_" + opName);
            }
        }

        return fallbackError(request, "UNKNOWN_" + opName);
    }

    protected Optional<RES> handlePersistenceException(REQ request, PersistenceException e) {
        return Optional.empty();
    }

    protected final boolean isDuplicateKey(Exception e) {
        return messageContainsAny(e, DUPLICATE_MARKERS);
    }

    protected final boolean isRetryablePersistenceError(Exception e) {
        return messageContainsAny(e, DEADLOCK_MARKERS)
                || messageContainsAny(e, LOCK_TIMEOUT_MARKERS)
                || messageContainsAny(e, TIMEOUT_MARKERS);
    }

    protected abstract Logger logger();

    protected abstract String transactionIdOf(REQ request);

    protected abstract RES fallbackError(REQ request, String reason);

    protected String interruptedRetryLogMessage() {
        return "Retry DB interrotto";
    }

    @FunctionalInterface
    protected interface RetryableOperation<REQ, RES> {
        RES execute(REQ request) throws Exception;
    }

    protected void sleepBackoff(int attempt) {
        try {
            Thread.sleep(BASE_DELAY_MS * attempt);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            logger().warn(interruptedRetryLogMessage(), ie);
        }
    }

    private boolean messageContainsAny(Exception e, String[] markers) {
        String message = extractMessage(e).toLowerCase();
        for (String marker : markers) {
            if (message.contains(marker.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    private String extractMessage(Exception e) {
        if (e == null) {
            return "";
        }
        Throwable cause = e.getCause();
        if (cause != null && cause.getMessage() != null) {
            return cause.getMessage();
        }
        return e.getMessage() != null ? e.getMessage() : "";
    }
}
