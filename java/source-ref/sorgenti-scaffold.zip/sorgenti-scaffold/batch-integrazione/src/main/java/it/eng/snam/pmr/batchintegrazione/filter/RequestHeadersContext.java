package it.eng.snam.pmr.batchintegrazione.filter;

import java.io.Serializable;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class RequestHeadersContext {

    private static final InheritableThreadLocal<State> CTX = new InheritableThreadLocal<>() {
        @Override
        protected State initialValue() {
            return new State();
        }

        @Override
        protected State childValue(State parentValue) {
            return parentValue == null ? new State() : new State(parentValue);
        }
    };

    private State state() {
        return CTX.get();
    }

    public String getKeyLogic() {
        return state().keyLogic;
    }

    public void setKeyLogic(String keyLogic) {
        state().keyLogic = keyLogic;
    }

    public String getTransactionId() {
        return state().transactionId;
    }

    public void setTransactionId(String transactionId) {
        state().transactionId = transactionId;
    }

    public boolean isModAsync() {
        return state().modAsync;
    }

    public void setModAsync(boolean modAsync) {
        state().modAsync = modAsync;
    }

    public String getProcessType() {
        return state().processType;
    }

    public void setProcessType(String processType) {
        state().processType = processType;
    }

    public String getCorrelationId() {
        return state().correlationId;
    }

    public void setCorrelationId(String correlationId) {
        state().correlationId = correlationId;
    }

    public String getPath() {
        return state().path;
    }

    public void setPath(String path) {
        state().path = path;
    }

    public long getStartNanos() {
        return state().startNanos;
    }

    public void setStartNanos(long startNanos) {
        state().startNanos = startNanos;
    }

    public Snapshot snapshot() {
        State s = state();
        return new Snapshot(
                s.keyLogic,
                s.transactionId,
                s.modAsync,
                s.processType,
                s.correlationId,
                s.path,
                s.startNanos
        );
    }

    public void restore(Snapshot snapshot) {
        if (snapshot == null) {
            clear();
            return;
        }

        State s = state();
        s.keyLogic = snapshot.keyLogic();
        s.transactionId = snapshot.transactionId();
        s.modAsync = snapshot.modAsync();
        s.processType = snapshot.processType();
        s.correlationId = snapshot.correlationId();
        s.path = snapshot.path();
        s.startNanos = snapshot.startNanos();
    }

    public void clear() {
        CTX.remove();
    }

    private static final class State {
        private String keyLogic;
        private String transactionId;
        private boolean modAsync;
        private String processType;
        private String correlationId;
        private String path;
        private long startNanos;

        private State() {
        }

        private State(State other) {
            this.keyLogic = other.keyLogic;
            this.transactionId = other.transactionId;
            this.modAsync = other.modAsync;
            this.processType = other.processType;
            this.correlationId = other.correlationId;
            this.path = other.path;
            this.startNanos = other.startNanos;
        }
    }

    public record Snapshot(
            String keyLogic,
            String transactionId,
            boolean modAsync,
            String processType,
            String correlationId,
            String path,
            long startNanos
    ) implements Serializable {
        private static final long serialVersionUID = 1L;
    }
}
