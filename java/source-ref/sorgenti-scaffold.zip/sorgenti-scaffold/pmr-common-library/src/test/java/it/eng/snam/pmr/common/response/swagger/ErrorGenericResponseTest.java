package it.eng.snam.pmr.common.response.swagger;

import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.response.ResponseStatus;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ErrorGenericResponseTest {

    @Test
    void inheritsGenericResponseDefaults() {
        ErrorGenericResponse response = new ErrorGenericResponse();

        assertThat(response).isInstanceOf(GenericResponse.class);
        assertThat(response.getStatus()).isEqualTo(ResponseStatus.ELABORATO.toString());
        assertThat(response.getTimestamp()).isNotBlank();
    }
}
