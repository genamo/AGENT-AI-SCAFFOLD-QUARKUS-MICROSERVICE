package it.eng.snam.pmr.common.service.abstracts;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

import org.slf4j.LoggerFactory;

import it.eng.snam.pmr.common.dto.page.PageDTO;
import it.eng.snam.pmr.common.model.PageFilter;
import it.eng.snam.pmr.common.model.PagedSearchQuery;
import it.eng.snam.pmr.common.util.dto.PageInitializer;

public abstract class PageService<F extends PageFilter, E, D> {

    protected abstract Consumer<F> validator();

    protected abstract Function<F, PagedSearchQuery> searchQueryBuilder();

    protected abstract Function<PagedSearchQuery, PageDTO<E>> filteredSearcher();

    protected abstract Function<List<E>, List<D>> mapper();

    public PageDTO<D> filteredSearch(F filter) {
        validator().accept(filter);

        PagedSearchQuery searchQuery = searchQueryBuilder().apply(filter);
        PageDTO<E> entityPage = filteredSearcher().apply(searchQuery);

        LoggerFactory.getLogger(getClass())
                     .info("ElementsSize={} - ElementsAmount={} - CurrentPage={} - TotalPages={} - Filter={}",
                           entityPage.getElementsSize(), entityPage.getElementsAmount(), entityPage.getCurrentPage(), entityPage.getTotalPages(), filter);

        return PageInitializer.dto(entityPage, mapper());
    }
}
