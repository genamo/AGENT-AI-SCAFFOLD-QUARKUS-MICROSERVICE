package it.eng.snam.pmr.common.util.retry;

import it.eng.snam.pmr.common.dto.retry.RetryableProcessContext;
import it.eng.snam.pmr.common.functional.interfaces.RetryableCommand;
import it.eng.snam.pmr.common.util.ThreadSleeper;
import it.eng.snam.pmr.common.util.exception.ExceptionUnwrapper;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class RetryableProcessExecutor {

    public <T> T execute(RetryableProcessContext context, RetryableCommand<T> command) {
        RetryableProcessValidator.validate(context, command);

        Throwable lastError = null;
        Integer retryLimit = context.getRetryLimit();
        String operationName = context.getOperationName();

        for (Integer attempt = 1; attempt <= retryLimit; attempt++) {
            try {
                log.info("{} attempt {}/{}", operationName, attempt, retryLimit);
                return command.execute();
            } catch (Exception ex) {
                lastError = ExceptionUnwrapper.unwrapCompletion(ex);
                String lastErrorMessage = lastError.getMessage();
                if (!context.getRetryPredicate().test(lastError)) {
                    log.warn("{} attempt {}/{} failed but it was NON retryable: {}", operationName, attempt, retryLimit, lastErrorMessage);
                    throw context.getExceptionFactory().build(operationName, lastError);
                }

                log.warn("{} attempt {}/{} failed: {}", operationName, attempt, retryLimit, lastErrorMessage);
                if (attempt < retryLimit)
                    ThreadSleeper.attempt(attempt, context.getRetryDelay());
            }
        }

        throw context.getExceptionFactory().build(operationName, lastError);
    }
}
