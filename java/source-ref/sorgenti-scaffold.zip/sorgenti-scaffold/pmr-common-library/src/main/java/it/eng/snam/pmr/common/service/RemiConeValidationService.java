package it.eng.snam.pmr.common.service;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;
import org.jboss.logging.MDC;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.common.annotation.UserType;
import it.eng.snam.pmr.common.client.AnagraficheConeClient;
import it.eng.snam.pmr.common.dto.RemiConeDTO;
import it.eng.snam.pmr.common.dto.RemiExternalUserConeResponseDTO;
import it.eng.snam.pmr.common.dto.RemiExternalUserConeScenarioDTO;
import it.eng.snam.pmr.common.dto.RemiSpecializzazioneDTO;
import it.eng.snam.pmr.common.dto.RemiSpecializzazioneModuleResponseDTO;
import it.eng.snam.pmr.common.dto.RemiSpecializzazioneResponseDTO;
import it.eng.snam.pmr.common.filter.B2BTokenFilter;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.spi.InternalConeResolver;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Instance;
import jakarta.inject.Inject;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
public class RemiConeValidationService {

    private static final Logger LOG = Logger.getLogger(RemiConeValidationService.class);

    /** Chiave usata da AuthzReadFilter/AuthzWriteFilter per propagare UserType nella request. */
    public static final String PMR_USER_TYPE_PROP = "PMR_USER_TYPE";

    /** Chiave usata per cachare il cono dati già risolto nella stessa request. */
    public static final String PMR_REMI_CONE_PROP = "PMR_REMI_CONE";

    /** Chiave usata per propagare i moduleCodes definiti su @RemiConeCheck. */
    public static final String PMR_REMI_MODULE_CODES_PROP = "PMR_REMI_MODULE_CODES";

    @Inject
    @RestClient
    AnagraficheConeClient anagraficheConeClient;

    /**
     * SPI opzionale: se il MS corrente è anagrafiche stesso, questo bean è presente
     * e viene usato al posto della chiamata HTTP (evita self-call).
     * Su tutti gli altri MS è unsatisfied → si usa il client HTTP.
     */
    @Inject
    Instance<InternalConeResolver> localConeResolver;

    @Inject
    ObjectMapper objectMapper;

    @ConfigProperty(name = "security.enabled", defaultValue = "true")
    boolean securityEnabled;

    @ConfigProperty(name = "security.authz.bypass", defaultValue = "false")
    boolean authzBypass;

    /**
     * Risolve il cono dati dell'utente corrente e lo caches nella request.
     * Se già risolto in questa request, restituisce il valore cached.
     * Aggiorna MDC con {@code coneUnrestricted} e {@code coneSize} per il logging.
     */
    public RemiConeDTO resolveAndCache(ContainerRequestContext req) {
        Object cached = req.getProperty(PMR_REMI_CONE_PROP);
        if (cached instanceof RemiConeDTO cone) {
            return cone;
        }

        RemiConeDTO cone = resolve(req);
        req.setProperty(PMR_REMI_CONE_PROP, cone);
        MDC.put("coneUnrestricted", String.valueOf(cone.fullAccess()));
        MDC.put("coneSize", cone.fullAccess() ? "ALL" : String.valueOf(cone.remiAssoluti().size()));
        return cone;
    }

    private RemiConeDTO resolve(ContainerRequestContext req) {
        if (!securityEnabled) {
            LOG.debug("Security disabled → cono dati unrestricted");
            return new RemiConeDTO(true, List.of());
        }

        if (authzBypass) {
            LOG.debug("AuthzBypass attivo → cono dati unrestricted");
            return new RemiConeDTO(true, List.of());
        }

        if (Boolean.TRUE.equals(req.getProperty(B2BTokenFilter.B2B_SUPER_USER_KEY))) {
            LOG.debug("B2B super user → cono dati unrestricted");
            return new RemiConeDTO(true, List.of());
        }

        String userTypeStr = (String) req.getProperty(PMR_USER_TYPE_PROP);
        UserType userType = parseUserType(userTypeStr);

        String userId = (String) MDC.get(AuthorizationUtils.USER_ID);
        if (userId == null || userId.isBlank()) {
            LOG.warn("UserId non disponibile in MDC → cono dati vuoto");
            return new RemiConeDTO(false, List.of());
        }

        String bearer = (String) MDC.get(AuthorizationUtils.JWT_AUTHZ);

        if (userType == UserType.EXTERNAL) {
            return resolveExternalCone(req, bearer, userId);
        }

        return resolveInternalCone(bearer, userId);
    }

    /**
     * Utente INTERNO: se il MS corrente è anagrafiche usa la SPI locale (CDI, no HTTP),
     * altrimenti delega via HTTP ad AnagraficheConeClient.
     */
    private RemiConeDTO resolveInternalCone(String bearer, String userId) {
        LOG.debugf("Risoluzione cono INTERNAL per userId=%s", userId);

        if (localConeResolver.isResolvable()) {
            LOG.debugf("Uso SPI locale (nessuna chiamata HTTP) per userId=%s", userId);
            try {
                return localConeResolver.get().resolve(userId);
            } catch (Exception e) {
                LOG.errorf(e, "Errore SPI locale cono INTERNAL per userId=%s → cono vuoto", userId);
                return new RemiConeDTO(false, List.of());
            }
        }

        try (Response resp = anagraficheConeClient.getCurrentUserCone(bearer)) {
            int status = resp.getStatus();
            if (status != 200) {
                LOG.warnf("AnagraficheConeClient HTTP %d per userId=%s → cono vuoto", status, userId);
                return new RemiConeDTO(false, List.of());
            }

            String body = resp.readEntity(String.class);
            GenericResponse<RemiConeDTO> wrapper = objectMapper.readValue(
                    body, new TypeReference<GenericResponse<RemiConeDTO>>() {}
            );

            if (wrapper == null || wrapper.getData() == null) {
                return new RemiConeDTO(false, List.of());
            }

            return wrapper.getData();
        } catch (Exception e) {
            LOG.errorf(e, "Errore risoluzione cono INTERNAL per userId=%s → cono vuoto", userId);
            return new RemiConeDTO(false, List.of());
        }
    }

    /**
     * Utente ESTERNO: il cono dati viene delegato al servizio anagrafiche.
     * Se @RemiConeCheck definisce moduleCodes, vengono considerati solo quei moduli.
     */
    private RemiConeDTO resolveExternalCone(ContainerRequestContext req, String bearer, String userId) {
        LOG.debugf("Risoluzione cono EXTERNAL per userId=%s", userId);

        if (bearer == null || bearer.isBlank()) {
            LOG.warnf("Bearer non disponibile per userId=%s → cono vuoto", userId);
            return new RemiConeDTO(false, List.of());
        }

        Set<String> annotatedModuleCodes = extractAnnotatedModuleCodes(req);

        try (Response resp = anagraficheConeClient.getConeByExternalUser(bearer, userId)) {
            int status = resp.getStatus();
            if (status != 200) {
                LOG.warnf("AnagraficheConeClient EXTERNAL HTTP %d per userId=%s → cono vuoto", status, userId);
                return new RemiConeDTO(false, List.of());
            }

            String body = resp.readEntity(String.class);
            GenericResponse<RemiExternalUserConeResponseDTO> wrapper = objectMapper.readValue(
                    body, new TypeReference<GenericResponse<RemiExternalUserConeResponseDTO>>() {}
            );

            RemiExternalUserConeResponseDTO data = wrapper != null ? wrapper.getData() : null;
            if (data == null || data.scenarios() == null || data.scenarios().isEmpty()) {
                LOG.debugf("Cono EXTERNAL assente per userId=%s → cono vuoto", userId);
                return new RemiConeDTO(false, List.of());
            }

            boolean unrestricted = data.scenarios().stream()
                    .filter(Objects::nonNull)
                    .anyMatch(RemiExternalUserConeScenarioDTO::fullAccess);

            if (unrestricted) {
                LOG.debugf("Cono EXTERNAL unrestricted per userId=%s", userId);
                return new RemiConeDTO(true, List.of());
            }

            List<String> remi = data.scenarios().stream()
                    .filter(Objects::nonNull)
                    .map(RemiExternalUserConeScenarioDTO::conoRemiClientiList)
                    .filter(Objects::nonNull)
                    .flatMap(List::stream)
                    .filter(Objects::nonNull)
                    .map(RemiSpecializzazioneResponseDTO::moduleList)
                    .filter(Objects::nonNull)
                    .flatMap(List::stream)
                    .filter(Objects::nonNull)
                    .filter(moduleDto -> annotatedModuleCodes.isEmpty()
                            || isAnnotatedModule(moduleDto.module(), annotatedModuleCodes))
                    .map(RemiSpecializzazioneModuleResponseDTO::misuratori)
                    .filter(Objects::nonNull)
                    .flatMap(List::stream)
                    .filter(Objects::nonNull)
                    .map(RemiSpecializzazioneDTO::remiAssoluto)
                    .filter(Objects::nonNull)
                    .map(String::trim)
                    .filter(s -> !s.isBlank())
                    .distinct()
                    .toList();

            LOG.debugf("Cono EXTERNAL per userId=%s → %d remi trovati", userId, remi.size());
            return new RemiConeDTO(false, remi);

        } catch (Exception e) {
            LOG.errorf(e, "Errore risoluzione cono EXTERNAL per userId=%s → cono vuoto", userId);
            return new RemiConeDTO(false, List.of());
        }
    }
    
    private UserType parseUserType(String value) {
        if (value == null) {
            return UserType.INTERNAL;
        }
        try {
            return UserType.valueOf(value);
        } catch (IllegalArgumentException e) {
            return UserType.INTERNAL;
        }
    }

    @SuppressWarnings("unchecked")
    private Set<String> extractAnnotatedModuleCodes(ContainerRequestContext req) {
        if (req == null) {
            return Set.of();
        }

        Object raw = req.getProperty(PMR_REMI_MODULE_CODES_PROP);
        if (!(raw instanceof Set<?> rawSet) || rawSet.isEmpty()) {
            return Set.of();
        }

        return ((Set<String>) rawSet).stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .map(s -> s.toUpperCase(Locale.ROOT))
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    private boolean isAnnotatedModule(String moduleCode, Set<String> annotatedModuleCodes) {
        if (annotatedModuleCodes == null || annotatedModuleCodes.isEmpty()) {
            return true;
        }
        if (moduleCode == null || moduleCode.isBlank()) {
            return false;
        }

        return annotatedModuleCodes.contains(moduleCode.trim().toUpperCase(Locale.ROOT));
    }
}

   



