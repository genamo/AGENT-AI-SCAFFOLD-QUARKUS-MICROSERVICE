package it.eng.snam.pmr.batchintegrazione.config.async;

import java.util.concurrent.Executor;

import it.eng.snam.pmr.common.config.async.TaskExecutorQualifier;
import it.eng.snam.pmr.common.config.async.decorator.SubContextCopyingDecorator;
import it.eng.snam.pmr.common.config.async.properties.AsyncProperties;
import it.eng.snam.pmr.common.util.async.ExecutorCreator;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class TaskExecutorConfig {

    public static final String BLOB_UPLOAD_EXECUTOR = "blobUploadTaskExecutor";
    private static final String BLOB_UPLOAD_THREAD_PREFIX = "BlobUpload-";
    private static final String BLOB_UPLOAD_SUFFIX = "-" + BLOB_UPLOAD_THREAD_PREFIX;

    public static final String ZIP_EXECUTOR = "zipTaskExecutor";
    private static final String ZIP_GENERATOR_THREAD_PREFIX = "ZipGenerator-";
    private static final String ZIP_GENERATOR_SUFFIX = "-" + ZIP_GENERATOR_THREAD_PREFIX;

    private final AsyncProperties properties;

    @Produces
    @ApplicationScoped
    @TaskExecutorQualifier(BLOB_UPLOAD_EXECUTOR)
    public Executor blobUploadTaskExecutor() {
        return ExecutorCreator.createExecutor(properties, BLOB_UPLOAD_THREAD_PREFIX, new SubContextCopyingDecorator(BLOB_UPLOAD_SUFFIX));
    }

    @Produces
    @ApplicationScoped
    @TaskExecutorQualifier(ZIP_EXECUTOR)
    public Executor zipTaskExecutor() {
        return ExecutorCreator.createExecutor(properties, ZIP_GENERATOR_THREAD_PREFIX, new SubContextCopyingDecorator(ZIP_GENERATOR_SUFFIX));
    }
}
