package it.eng.snam.pmr.batchintegrazionedg.test.unit;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;

import it.eng.snam.pmr.batchintegrazionedg.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazionedg.utils.Utility;
import jakarta.ws.rs.core.Response;

class UtilityTest {

    // --- defaultUuidIfBlank ---

    @Test
    void defaultUuidIfBlank_null_returnsRandomUuid() {
        String result = Utility.defaultUuidIfBlank(null);
        assertNotNull(result);
        assertFalse(result.isBlank());
    }

    @Test
    void defaultUuidIfBlank_blank_returnsRandomUuid() {
        String result = Utility.defaultUuidIfBlank("  ");
        assertNotNull(result);
        assertFalse(result.isBlank());
    }

    @Test
    void defaultUuidIfBlank_value_returnsValue() {
        assertEquals("myValue", Utility.defaultUuidIfBlank("myValue"));
    }

    // --- parseBooleanOrDefault ---

    @Test
    void parseBooleanOrDefault_null_returnsDefault() {
        assertTrue(Utility.parseBooleanOrDefault(null, true));
        assertFalse(Utility.parseBooleanOrDefault(null, false));
    }

    @Test
    void parseBooleanOrDefault_blank_returnsDefault() {
        assertTrue(Utility.parseBooleanOrDefault("", true));
    }

    @Test
    void parseBooleanOrDefault_true_returnsTrue() {
        assertTrue(Utility.parseBooleanOrDefault("true", false));
        assertTrue(Utility.parseBooleanOrDefault("TRUE", false));
    }

    @Test
    void parseBooleanOrDefault_false_returnsFalse() {
        assertFalse(Utility.parseBooleanOrDefault("false", true));
        assertFalse(Utility.parseBooleanOrDefault("FALSE", true));
    }

    @Test
    void parseBooleanOrDefault_unknown_returnsDefault() {
        assertTrue(Utility.parseBooleanOrDefault("yes", true));
        assertFalse(Utility.parseBooleanOrDefault("yes", false));
    }

    // --- defaultIfBlank ---

    @Test
    void defaultIfBlank_null_returnsDefault() {
        assertEquals("def", Utility.defaultIfBlank(null, "def"));
    }

    @Test
    void defaultIfBlank_blank_returnsDefault() {
        assertEquals("def", Utility.defaultIfBlank("   ", "def"));
    }

    @Test
    void defaultIfBlank_value_returnsValue() {
        assertEquals("val", Utility.defaultIfBlank("val", "def"));
    }

    // --- withCommonHeaders ---

    @Test
    void withCommonHeaders_addsAllHeaders() {
        Response.ResponseBuilder rb = Response.ok("data");
        Response resp = Utility.withCommonHeaders(rb, "kl1", "tid1", true, "GUI").build();

        // ✅ FIXED: header names allineati allo standard reale
        assertNotNull(resp.getHeaderString("KEY-LOGIC"));
        assertNotNull(resp.getHeaderString("TRANSACTION-ID"));
        assertNotNull(resp.getHeaderString("MOD-ASYNC"));
        assertNotNull(resp.getHeaderString("PROCESS-TYPE"));
    }

    // --- ok ---

    @Test
    void ok_returns200() {
        Response r = Utility.ok("payload", "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(200, r.getStatus());
    }

    // --- created ---

    @Test
    void created_returns201() {
        Response r = Utility.created("payload", "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(201, r.getStatus());
    }

    // --- okOrEmpty ---

    @Test
    void okOrEmpty_nullList_returns200EmptyList() {
        Response r = Utility.okOrEmpty(null, "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(200, r.getStatus());
    }

    @Test
    void okOrEmpty_emptyList_returns200() {
        Response r = Utility.okOrEmpty(List.of(), "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(200, r.getStatus());
    }

    @Test
    void okOrEmpty_withData_returns200() {
        Response r = Utility.okOrEmpty(List.of("a", "b"), "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(200, r.getStatus());
    }

    // --- okOrNoContent ---

    @Test
    void okOrNoContent_emptyList_returns204() {
        Response r = Utility.okOrNoContent(List.of(), "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(204, r.getStatus());
    }

    @Test
    void okOrNoContent_nullList_returns204() {
        Response r = Utility.okOrNoContent(null, "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(204, r.getStatus());
    }

    @Test
    void okOrNoContent_withData_returns200() {
        Response r = Utility.okOrNoContent(List.of("x"), "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(200, r.getStatus());
    }

    // --- okOrNotFound ---

    @Test
    void okOrNotFound_present_returns200() {
        Response r = Utility.okOrNotFound(Optional.of("data"), "not found msg", "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(200, r.getStatus());
    }

    @Test
    void okOrNotFound_empty_returns404() {
        Response r = Utility.okOrNotFound(Optional.empty(), "not found", "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(404, r.getStatus());
    }

    @Test
    void okOrNotFound_null_notAllowed() {
        assertThrows(NullPointerException.class, () ->
            Utility.okOrNotFound(null, "not found", "/path", "kl", "tid", false, "N/A", System.nanoTime())
        );
    }

    // --- noContentOnlyHeaders ---

    @Test
    void noContentOnlyHeaders_returns204() {
        Response r = Utility.noContentOnlyHeaders("kl", "tid", false, "N/A");
        assertEquals(204, r.getStatus());
    }

    // --- badRequest ---

    @Test
    void badRequest_returns400() {
        Response r = Utility.badRequest("bad input", "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(400, r.getStatus());
    }

    // --- notFound ---

    @Test
    void notFound_returns404() {
        Response r = Utility.notFound("not found", "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(404, r.getStatus());
    }

    // --- badGateway ---

    @Test
    void badGateway_returns502() {
        RemoteCallException ex = new RemoteCallException("remote error");
        Response r = Utility.badGateway(ex, "/path", "kl", "tid", false, "N/A", System.nanoTime());
        assertEquals(502, r.getStatus());
    }

    // --- elapsedMs ---

    @Test
    void elapsedMs_returnsNonNegative() {
        long start = System.nanoTime();
        long elapsed = Utility.elapsedMs(start);
        assertTrue(elapsed >= 0);
    }

    // --- safe ---

    @Test
    void safe_null_returnsNull() {
        assertEquals("null", Utility.safe(null));
    }

    @Test
    void safe_blank_returnsBlank() {
        assertEquals("blank", Utility.safe(""));
        assertEquals("blank", Utility.safe("  "));
    }

    @Test
    void safe_shortString_returnsString() {
        assertEquals("hello", Utility.safe("hello"));
    }

    @Test
    void safe_longString_returnsTruncated() {
        String longStr = "a".repeat(200);
        String result = Utility.safe(longStr);
        assertTrue(result.endsWith("..."));
        assertTrue(result.length() <= 130);
    }
}
