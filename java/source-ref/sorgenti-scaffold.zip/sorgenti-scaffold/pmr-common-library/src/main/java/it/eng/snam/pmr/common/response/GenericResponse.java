package it.eng.snam.pmr.common.response;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import it.eng.snam.pmr.common.util.MessageTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonInclude(Include.NON_EMPTY)
public class GenericResponse<T> implements Serializable {
    private static final long serialVersionUID = 5007807046893745317L;
    private T data;
    private String status;
    private String executionTime;
    private String timestamp;
    private Integer numberOfElements;
    private Integer numberOfPages;
    private String path;
    @JsonInclude(Include.NON_NULL)
    private Message message;

    public GenericResponse() {
        this.timestamp = OffsetDateTime.now().toString();
        this.status = ResponseStatus.ELABORATO.toString();
    }
    public GenericResponse(T data, String resultDescription) { this(); this.data = data; }

    public void buildMessage(MessageTypeEnum e) {
        if (message == null) message = new Message();
        message.setMessageType(e.getMessageType()); message.setMessageCode(e.getMessageCode());
    }
    public void buildMessage(MessageTypeEnum e, String desc, List<String> ph) {
        if (message == null) message = new Message();
        message.setMessageType(e.getMessageType()); message.setMessageCode(e.getMessageCode());
        message.setMessageDescription(desc); message.setMessagePlaceholder(ph);
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    @JsonInclude(Include.NON_NULL)
    public static class Message implements Serializable {
        private static final long serialVersionUID = -3699628142644425282L;
        private String messageType;
        private String messageCode;
        private String messageDescription;
        private List<String> messagePlaceholder;
        public Message(String t, String c, List<String> ph) { this.messageType=t; this.messageCode=c; this.messagePlaceholder=ph; }
    }
}
