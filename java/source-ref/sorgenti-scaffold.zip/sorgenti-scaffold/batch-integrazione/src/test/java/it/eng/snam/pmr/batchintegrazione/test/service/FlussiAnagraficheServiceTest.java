package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.FlussiAnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.FlussoRegistry;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.FlussoHandler;

@ExtendWith(MockitoExtension.class)
class FlussiAnagraficheServiceTest {

    @Mock
    FlussoRegistry registry;

    @Mock
    RequestHeadersContext headersCtx;

    @Mock
    FlussoHandler handler;

    @InjectMocks
    FlussiAnagraficheService service;

    @BeforeEach
    void injectHeadersCtxIntoAbstractService() throws Exception {
        Field field = AbstractService.class.getDeclaredField("headersCtx");
        field.setAccessible(true);
        field.set(service, headersCtx);
    }

    @Test
    void process_managedFlow_setsTransactionIdAndDelegatesToHandler() {
        String flow = "PMR001A";
        String payload = "{\"key\":\"value\"}";

        when(registry.get(flow)).thenReturn(handler);

        service.process(flow, payload);

        InOrder inOrder = inOrder(headersCtx, registry, handler);

        inOrder.verify(headersCtx).setTransactionId(
                argThat(txId ->
                        txId != null
                        && txId.startsWith(flow + "_")
                        && txId.substring((flow + "_").length()).matches("\\d{17}")
                )
        );
        inOrder.verify(registry).get(flow);
        inOrder.verify(handler).process(payload);
    }

    @Test
    void process_unknownFlow_throwsIllegalArgumentException() {
        String flow = "UNKNOWN_FLOW";
        String payload = "{\"key\":\"value\"}";

        when(registry.get(flow)).thenReturn(null);

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> service.process(flow, payload)
        );

        assertEquals("Flow non gestito: " + flow, ex.getMessage());

        verify(headersCtx).setTransactionId(
                argThat(txId ->
                        txId != null
                        && txId.startsWith(flow + "_")
                        && txId.substring((flow + "_").length()).matches("\\d{17}")
                )
        );
        verify(registry).get(flow);
        verifyNoInteractions(handler);
    }
}
