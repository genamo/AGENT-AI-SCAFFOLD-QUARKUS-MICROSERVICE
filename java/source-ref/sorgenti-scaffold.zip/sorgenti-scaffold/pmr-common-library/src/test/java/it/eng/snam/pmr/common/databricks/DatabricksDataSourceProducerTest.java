package it.eng.snam.pmr.common.databricks;

import com.zaxxer.hikari.HikariDataSource;
import org.junit.jupiter.api.Test;

import javax.sql.DataSource;

import static org.assertj.core.api.Assertions.*;

class DatabricksDataSourceProducerTest {

    // -----------------------------------------------------------------------
    // normalizeHostForJdbc
    // -----------------------------------------------------------------------

    @Test
    void normalizeHost_withHttpsPrefix_stripsIt() {
        assertThat(DatabricksDataSourceProducer.normalizeHostForJdbc("https://myhost.azuredatabricks.net/"))
                .isEqualTo("myhost.azuredatabricks.net");
    }

    @Test
    void normalizeHost_withHttpPrefix_stripsIt() {
        assertThat(DatabricksDataSourceProducer.normalizeHostForJdbc("http://myhost.example.com"))
                .isEqualTo("myhost.example.com");
    }

    @Test
    void normalizeHost_withoutPrefix_returnsAsIs() {
        assertThat(DatabricksDataSourceProducer.normalizeHostForJdbc("myhost.azuredatabricks.net"))
                .isEqualTo("myhost.azuredatabricks.net");
    }

    @Test
    void normalizeHost_withPathAfterHost_stripsPath() {
        assertThat(DatabricksDataSourceProducer.normalizeHostForJdbc("https://host.example.com/some/path"))
                .isEqualTo("host.example.com");
    }

    @Test
    void normalizeHost_withPortInUrl_stripsPort() {
        assertThat(DatabricksDataSourceProducer.normalizeHostForJdbc("https://host.example.com:443/path"))
                .isEqualTo("host.example.com");
    }

    @Test
    void normalizeHost_null_returnsNull() {
        assertThat(DatabricksDataSourceProducer.normalizeHostForJdbc(null)).isNull();
    }

    @Test
    void normalizeHost_trailingSlashOnly_returnsEmpty() {
        assertThat(DatabricksDataSourceProducer.normalizeHostForJdbc("https://host.example.com/"))
                .isEqualTo("host.example.com");
    }

    // -----------------------------------------------------------------------
    // normalizeHttpPath
    // -----------------------------------------------------------------------

    @Test
    void normalizeHttpPath_withLeadingSlash_returnsSame() {
        assertThat(DatabricksDataSourceProducer.normalizeHttpPath("/sql/1.0/warehouses/abc"))
                .isEqualTo("/sql/1.0/warehouses/abc");
    }

    @Test
    void normalizeHttpPath_withoutLeadingSlash_addsIt() {
        assertThat(DatabricksDataSourceProducer.normalizeHttpPath("sql/1.0/warehouses/abc"))
                .isEqualTo("/sql/1.0/warehouses/abc");
    }

    @Test
    void normalizeHttpPath_null_returnsNull() {
        assertThat(DatabricksDataSourceProducer.normalizeHttpPath(null)).isNull();
    }

    @Test
    void normalizeHttpPath_alreadyHasSlash_doesNotDouble() {
        String path = "/sql/path";
        assertThat(DatabricksDataSourceProducer.normalizeHttpPath(path)).isEqualTo("/sql/path");
    }

    // -----------------------------------------------------------------------
    // dataSource
    // -----------------------------------------------------------------------

    @Test
    void dataSource_withValidConfig_createsDataSource() {
        DatabricksDataSourceProducer producer = new DatabricksDataSourceProducer();
        producer.host = "https://myhost.azuredatabricks.net/";
        producer.port = 443;
        producer.httpPath = "sql/1.0/warehouses/abc";
        producer.pat = "dummy-pat";
        producer.driver = "com.databricks.client.jdbc.Driver";
        producer.maxPoolSize = 5;
        producer.minIdle = 1;
        producer.connectionTimeout = 10000L;
        producer.maxLifetime = 60000L;
        producer.idleTimeout = 30000L;

        DataSource ds = producer.dataSource();
        assertThat(ds).isInstanceOf(HikariDataSource.class);
        try (HikariDataSource hds = (HikariDataSource) ds) {
            assertThat(hds.getJdbcUrl()).contains("jdbc:databricks://myhost.azuredatabricks.net:443/default");
            assertThat(hds.getUsername()).isEqualTo("token");
            assertThat(hds.getPassword()).isEqualTo("dummy-pat");
            assertThat(hds.getMaximumPoolSize()).isEqualTo(5);
            assertThat(hds.getMinimumIdle()).isEqualTo(1);
            assertThat(hds.getConnectionTimeout()).isEqualTo(10000L);
            assertThat(hds.getMaxLifetime()).isEqualTo(60000L);
            assertThat(hds.getIdleTimeout()).isEqualTo(30000L);
        }
    }


    @Test
    void dataSource_withMissingPat_throwsException() {
        DatabricksDataSourceProducer producer = new DatabricksDataSourceProducer();
        producer.host = "host";
        producer.port = 443;
        producer.httpPath = "sql/1.0/warehouses/abc";
        producer.pat = ""; // PAT mancante
        producer.driver = "com.databricks.client.jdbc.Driver";
        producer.maxPoolSize = 5;
        producer.minIdle = 1;
        producer.connectionTimeout = 10000L;
        producer.maxLifetime = 60000L;
        producer.idleTimeout = 30000L;

        assertThatThrownBy(producer::dataSource)
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("databricks.datasource.pat NOT configured");
    }
}
