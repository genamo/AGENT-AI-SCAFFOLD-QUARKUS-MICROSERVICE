package it.eng.snam.pmr.batchintegrazionedg.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

import it.eng.snam.pmr.batchintegrazionedg.domain.AnagFlussi;
import it.eng.snam.pmr.batchintegrazionedg.dto.AnagFlussiDTO;

@Mapper(componentModel = MappingConstants.ComponentModel.CDI)
public interface AnagFlussiMapper {

    // Da Entity a DTO
    AnagFlussiDTO toDto(AnagFlussi entity);

    // Da DTO a Entity
    AnagFlussi toEntity(AnagFlussiDTO dto);

    // Mapping di liste
    List<AnagFlussiDTO> toDtoList(List<AnagFlussi> entities);
}
