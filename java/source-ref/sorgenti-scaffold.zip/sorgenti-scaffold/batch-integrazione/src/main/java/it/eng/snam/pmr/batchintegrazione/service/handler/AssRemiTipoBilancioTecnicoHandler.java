package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AssRemiTipoBilancioTecnicoPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AssRemiTipoBilancioTecnicoHandler extends AbstractFlussoHandler<AssRemiTipoBilancioTecnicoPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AssRemiTipoBilancioTecnicoPayloadDto> getDtoClass() {
        return AssRemiTipoBilancioTecnicoPayloadDto.class;
    }

    @Override
    protected void handle(AssRemiTipoBilancioTecnicoPayloadDto dto) {
    	
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAssRemiTipoBilancioTecnico(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteAssRemiTipoBilancioTecnico(dto.data().getFirst().remiAssoluto(),dto.data().getFirst().dataInizioInt());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}	
        
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ASS_REMI_TIPO_BILANCIO_TECNICO_FLOW;
    }
}