package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AssRemiClientiPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AssRemiClientiHandler extends AbstractFlussoHandler<AssRemiClientiPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AssRemiClientiPayloadDto> getDtoClass() {
        return AssRemiClientiPayloadDto.class;
    }

    @Override
    protected void handle(AssRemiClientiPayloadDto dto) {
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAssRemiClienti(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteAssRemiClienti(dto.data().getFirst().remiAssoluto(), dto.data().getFirst().dataInizioValiditaInt());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}	
    	
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ASS_REMI_CLIENTI_FLOW;
    }
}