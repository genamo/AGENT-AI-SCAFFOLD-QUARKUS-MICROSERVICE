package it.eng.snam.pmr.common.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class RemoteCallException extends RuntimeException {
    @Serial
    private static final long serialVersionUID = -8564429885666035250L;
}
