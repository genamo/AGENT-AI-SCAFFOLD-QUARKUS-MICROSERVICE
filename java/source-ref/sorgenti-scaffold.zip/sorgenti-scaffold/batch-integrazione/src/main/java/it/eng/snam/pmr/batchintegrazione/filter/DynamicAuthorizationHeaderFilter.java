package it.eng.snam.pmr.batchintegrazione.filter;

import java.time.Duration;

import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;

import io.quarkus.oidc.client.OidcClient;
import io.quarkus.oidc.client.OidcClients;
import io.quarkus.oidc.client.Tokens;
import it.eng.snam.pmr.batchintegrazione.utils.AuthFilterHelper;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.B2BTokenUtils;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import jakarta.annotation.Priority;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.ServiceUnavailableException;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.core.HttpHeaders;
import lombok.RequiredArgsConstructor;



@ApplicationScoped
@Priority(Priorities.AUTHENTICATION)
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class DynamicAuthorizationHeaderFilter implements ClientRequestFilter {

	private static final Logger log = Logger.getLogger(DynamicAuthorizationHeaderFilter.class);
    private static final Duration TOKEN_TIMEOUT = Duration.ofSeconds(5);

    private final OidcClients oidcClients;
    private final B2BTokenUtils b2bTokenUtils;

    @Override
    public void filter(ClientRequestContext requestContext) {
        log.debug("Resolving RestClient's ConfigKey");
        String configKey = AuthFilterHelper.resolveConfigKey(requestContext);
        log.debugf("RestClient's ConfigKey: %s", configKey);

        log.debug("Resolving RestClient's AuthMode");
        String authMode = AuthFilterHelper.resolveAuthMode(configKey);
        log.debugf("RestClient's AuthMode detected: %s", authMode);

        if (AuthFilterHelper.isAuthModeM2M(authMode)) {
            log.debugf("Attempting to acquire M2M token for RestClient's ConfigKey: {}", configKey);
            putAuthorization(requestContext, fetchAuthTokenM2M(configKey));
            return;
        }

        if (AuthFilterHelper.hasAuthorization(requestContext)) {
            log.debug("JWT already present in request, skipping further operations");
            return;
        }

        log.debug("JWT not present in request, executing further operations");
        putAuthorization(requestContext, fetchAuthTokenJWT());
    }

    private String fetchAuthTokenM2M(String configKey) {
        try {
            log.debug("Resolving RestClient's OidcClient");
            OidcClient oidcClient = oidcClients.getClient(configKey);
            log.debug("RestClient's OidcClient resolved");

            log.debug("Resolving OidcClient's Tokens");
            Tokens tokens = oidcClient.getTokens().await().atMost(TOKEN_TIMEOUT);
            log.debugf("OidcClient's Tokens resolved: %s", tokens.toString());

            return tokens.getAccessToken();
        } catch (Exception ex) {
        	log.errorf(ex, "Unable to acquire M2M token for RestClient's configKey: %s", configKey);
            throw new ServiceUnavailableException("Unable to acquire M2M token for RestClient's configKey: " + configKey);
        }
    }

    private String fetchAuthTokenJWT() {
        String jwt = MdcManager.getHeader(AuthorizationUtils.JWT_AUTHZ);
        if (StringUtils.isNotBlank(jwt)) {
            log.debug("JWT token successfully retrieved from MDC");
            return jwt;
        } else {
            log.debug("JWT token not retrieved from MDC, generating SuperUser token");
            return b2bTokenUtils.generateSuperUserToken();
        }
    }

    private void putAuthorization(ClientRequestContext requestContext, String token) {
        log.debug("Normalizing token if necessary");
        String normalizedToken = AuthFilterHelper.normalizeBearer(token);

        log.debugf("Attaching normalized token to request: %s", normalizedToken);
        requestContext.getHeaders().putSingle(HttpHeaders.AUTHORIZATION, normalizedToken);
    }
}