package it.eng.snam.pmr.batchintegrazione.client;

import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import it.eng.snam.pmr.batchintegrazione.dto.DlqFlussoRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.IdempotenzaRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringBatchDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringBatchSearchDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringFlussiDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringFlussiSearchDTO;
import it.eng.snam.pmr.batchintegrazione.dto.ParametriSistemaRequestSearch;
import it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.batchintegrazione.filter.RestClientHeadersFilter;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Produces(MediaType.APPLICATION_JSON)
@RegisterRestClient(configKey = "batch-integrazione-dg-client")
@RegisterProvider(RestClientHeadersFilter.class)
public interface BatchIntegrazioneDgClient {

	// ======================================================
	// ANAG FLUSSI
	// ======================================================

	@GET
	@Path("/anag-flussi")
	Response getAll();

	@GET
	@Path("/anag-flussi/search")
	Response findByFlowId(@QueryParam("flowId") String flowId);

	// ======================================================
	// MONITORING FLUSSI
	// ======================================================

	@GET
	@Path("/monitoring-flussi")
	Response getAllMonitoringFlussi();

	@GET
	@Path("/monitoring-flussi/{id}")
	Response getByIdMonitoringFlussi(@PathParam("id") Long id);

	@GET
	@Path("/monitoring-flussi/transaction/{transactionId}")
	Response getByTransactionIdMonitoringFlussi(@PathParam("transactionId") String txId);

	@GET
	@Path("/monitoring-flussi/last-executions")
	Response getLastExecutionsMonitoringFlussi(@QueryParam("limit") @DefaultValue("10") int limit);

	@GET
	@Path("/monitoring-flussi/period")
	Response getByPeriodMonitoringFlussi(@QueryParam("monthNumber") Integer month, @QueryParam("dayNumber") Integer day);

	@POST
	@Path("/monitoring-flussi/save")
	Response saveMonitoringFlussi(MonitoringFlussiDTO dto);

	@POST
	@Path("/monitoring-flussi/search")
	Response findByCustomSearchMonitoringFlussi(MonitoringFlussiSearchDTO searchDto);

	// ======================================================
	// MONITORING BATCH
	// ======================================================

	@GET
	@Path("/monitoring-batch")
	Response getAllMonitoringBatch();

	@GET
	@Path("/monitoring-batch/{id}")
	Response getByIdMonitoringBatch(@PathParam("id") Long id);

	@GET
	@Path("/monitoring-batch/transaction/{transactionId}")
	Response getByTransactionIdMonitoringBatch(@PathParam("transactionId") String txId);

	@GET
	@Path("/monitoring-batch/last-executions")
	Response getLastExecutionsMonitoringBatch(@QueryParam("limit") @DefaultValue("10") int limit);

	@GET
	@Path("/monitoring-batch/period")
	Response getByPeriodMonitoringBatch(@QueryParam("monthNumber") Integer month, @QueryParam("dayNumber") Integer day);

	@POST
	@Path("/monitoring-batch/save")
	Response saveMonitoringBatch(MonitoringBatchDTO dto);

	@POST
	@Path("/monitoring-batch/search")
	Response findByCustomSearchMonitoringBatch(MonitoringBatchSearchDTO searchDto);

	// ======================================================
	// PARAMETRI SISTEMA
	// ======================================================

	@POST
	@Path("/parametri-sistema/search")
	Response searchParametri(ParametriSistemaRequestSearch request);

	// ======================================================
	// IDEMPOTENZA FLUSSI
	// ======================================================

	@POST
	@Path("/idempotenza-flussi/idempotenza-flussi-insert")
	Response insertIdempotenza(IdempotenzaRequestDTO request);

	@POST
	@Path("/idempotenza-flussi/idempotenza-flussi-update")
	Response updateIdempotenza(IdempotenzaRequestDTO request);

	@GET
	@Path("/idempotenza-flussi/search")
	Response findByTransactionIdIdempotenza(@QueryParam("transactionId") String transactionId);

	// ======================================================
    // DLQ FLUSSI
    // ======================================================

    @POST
    @Path("/dlq-flussi/save")
    Response saveDlqFlusso(DlqFlussoRequestDTO request);

    @GET
    @Path("/dlq-flussi/search")
    Response findDlqFlussiByTransactionId(@QueryParam("transactionId") String transactionId);

    @GET
    @Path("/dlq-flussi/control-key")
    Response findDlqFlussiByControlKey(@QueryParam("controlKey") String controlKey);

    @GET
    @Path("/dlq-flussi/control-key/count")
    Response countDlqFlussiByControlKey(@QueryParam("controlKey") String controlKey);

    @GET
    @Path("/dlq-flussi/status")
    Response findDlqFlussiByStatus(@QueryParam("status") String status);

    @GET
    @Path("/dlq-flussi/latest")
    Response findLatestDlqFlussi(@QueryParam("limit") @DefaultValue("20") int limit);

	@POST
	@Path("/monitoring-integration")
	Response sendRequestMonitoringIntegration(MonitoringIntegration request);
}
