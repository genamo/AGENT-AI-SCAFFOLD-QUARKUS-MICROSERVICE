package it.eng.snam.pmr.common.util.kafka.consumer;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;

import org.apache.kafka.common.header.Headers;
import org.eclipse.microprofile.reactive.messaging.Message;

import it.eng.snam.pmr.common.dto.kafka.consume.IncomingMessageContext;
import it.eng.snam.pmr.common.exception.KafkaProcessingException;
import it.eng.snam.pmr.common.functional.interfaces.RetryableCommand;
import it.eng.snam.pmr.common.functional.interfaces.kafka.consumer.MessageHandlerFactory;
import it.eng.snam.pmr.common.util.kafka.producer.MessageContextInitializer;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import it.eng.snam.pmr.common.util.retry.RetryableProcessDomain;
import it.eng.snam.pmr.common.util.retry.RetryableProcessExecutor;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class MessageProcessor {

    private final Integer MAX_PAYLOAD_BYTES = 1_000_000; // 1MB

    public CompletionStage<Void> auto(Message<byte[]> message, Map<String, MessageHandlerFactory> factoryMap) {
        return doProcess(message, factoryMap, ignored -> CompletableFuture.completedFuture(null), CompletableFuture::failedFuture);
    }

    public CompletionStage<Void> manual(Message<byte[]> message, Map<String, MessageHandlerFactory> factoryMap) {
        return doProcess(message, factoryMap, Message::ack, ex -> message.ack());
    }

    private CompletionStage<Void> doProcess(Message<byte[]> message, Map<String, MessageHandlerFactory> factoryMap,
                                            Function<Message<byte[]>, CompletionStage<Void>> onSuccess, Function<Throwable, CompletionStage<Void>> onError) {
        try {
            IncomingMessageContext context = MessageContextInitializer.incoming(message);
            Headers headers = context.getHeaders();
            String topic = context.getTopic();
            Integer size = context.getSize();
            if (size > MAX_PAYLOAD_BYTES) {
                log.warn("Kafka payload too large ({} bytes) on topic '{}' -> skip", size, topic);
                return onSuccess.apply(message);
            }

            MdcManager.putKafkaHeaders(headers);
            log.info("Processing message received on topic: {}", topic);

            MessageHandlerFactory handler = factoryMap.getOrDefault(topic, MessageHandlerFactory.unknown(topic));
            RetryableProcessExecutor.execute(RetryableProcessDomain.KAFKA, RetryableCommand.ofVoid(() -> handle(handler, context, headers)));

            log.info("Message processed successfully.");
            return onSuccess.apply(message);
        } catch (Exception ex) {
            log.error("Error while processing message: {}", ex.getMessage(), ex);
            return onError.apply(ex);
        } finally {
            MdcManager.clear();
        }
    }

    private void handle(MessageHandlerFactory handler, IncomingMessageContext context, Headers headers) {
        try {
            handler.handle(context.getPayload(), headers);
        } catch (IOException e) {
            throw new KafkaProcessingException("Error while handling message: " + e.getMessage(), e);
        }
    }
}
