package it.eng.snam.pmr.batchintegrazionedg.dto;

public record IdempotenzaResponseDTO(
    boolean started,
    String transactionId,
    String status
) {}