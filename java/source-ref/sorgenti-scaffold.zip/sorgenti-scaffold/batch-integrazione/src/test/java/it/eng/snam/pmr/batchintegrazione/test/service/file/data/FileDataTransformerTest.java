package it.eng.snam.pmr.batchintegrazione.test.service.file.data;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedConstruction;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.FileDataContext;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileDataRequest;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileReference;
import it.eng.snam.pmr.batchintegrazione.exception.FileDataExtractionException;
import it.eng.snam.pmr.batchintegrazione.service.file.data.FileDataTransformer;

@ExtendWith(MockitoExtension.class)
class FileDataTransformerTest {

    private final Executor executor = Runnable::run;
    private final FileDataTransformer transformer = new FileDataTransformer(executor);

    @Test
    void transform_buildsContextMetadataAndZipStreamWithDeduplicatedEntries() throws Exception {
        FileDataRequest request = validRequestWithDuplicates();

        FileDataContext context = transformer.transform(request);

        assertEquals("Executioner 01", context.getExecutioner());
        assertEquals("Monthly Closure", context.getActivity());
        assertEquals("application/zip", context.getContentType());
        assertNotNull(context.getInputStream());
        assertNotNull(context.getWriterFuture());
        assertFalse(context.getFileName().isBlank());
        assertTrue(context.getFileName().endsWith(".zip"));
        assertTrue(context.getFileName().contains("_"));

        Map<String, String> metadata = context.getMetadata();
        assertEquals("Executioner 01", metadata.get("executioner"));
        assertEquals("Monthly Closure", metadata.get("activity"));
        assertEquals("PMR", metadata.get("sourceSystem"));
        assertTrue(metadata.containsKey("transactionId"));
        assertTrue(metadata.containsKey("createdAtUTC"));

        Map<String, byte[]> zipEntries = readZipEntries(context.getInputStream());

        assertEquals(List.of("a.txt", "b.txt"), List.copyOf(zipEntries.keySet()));
        assertArrayEquals("first a".getBytes(StandardCharsets.UTF_8), zipEntries.get("a.txt"));
        assertArrayEquals("beta".getBytes(StandardCharsets.UTF_8), zipEntries.get("b.txt"));
        assertTrue(context.getWriterFuture().isDone());
        assertFalse(context.getWriterFuture().isCompletedExceptionally());
    }

    @Test
    void transform_acceptsEmptyFileContentAndStillCreatesZipEntry() throws Exception {
        FileDataRequest request = new FileDataRequest();
        request.setExecutioner("Exec");
        request.setActivity("Act");
        request.setSourceSystem("SYS");
        request.setFileReferences(List.of(new FileReference("empty.txt", new byte[0])));

        FileDataContext context = transformer.transform(request);
        Map<String, byte[]> zipEntries = readZipEntries(context.getInputStream());

        assertEquals(1, zipEntries.size());
        assertArrayEquals(new byte[0], zipEntries.get("empty.txt"));
        assertEquals("Exec", context.getMetadata().get("executioner"));
        assertEquals("Act", context.getMetadata().get("activity"));
        assertEquals("SYS", context.getMetadata().get("sourceSystem"));
    }

    private static FileDataRequest validRequestWithDuplicates() {
        FileDataRequest request = new FileDataRequest();
        request.setExecutioner("Executioner 01");
        request.setActivity("Monthly Closure");
        request.setSourceSystem("PMR");
        request.setFileReferences(List.of(new FileReference("a.txt", "first a".getBytes(StandardCharsets.UTF_8)),
                                          new FileReference("b.txt", "beta".getBytes(StandardCharsets.UTF_8)),
                                          new FileReference("a.txt",
                                                            "second a discarded".getBytes(StandardCharsets.UTF_8))));
        return request;
    }

    private static Map<String, byte[]> readZipEntries(InputStream inputStream) throws Exception {
        Map<String, byte[]> entries = new LinkedHashMap<>();
        try (ZipInputStream zipInputStream = new ZipInputStream(inputStream)) {
            ZipEntry entry;
            while ((entry = zipInputStream.getNextEntry()) != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                zipInputStream.transferTo(out);
                entries.put(entry.getName(), out.toByteArray());
                zipInputStream.closeEntry();
            }
        }
        return entries;
    }
}
