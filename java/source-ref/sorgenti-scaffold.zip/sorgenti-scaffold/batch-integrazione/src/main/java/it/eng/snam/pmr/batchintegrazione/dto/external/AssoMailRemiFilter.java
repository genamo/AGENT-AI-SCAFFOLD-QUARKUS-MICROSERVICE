package it.eng.snam.pmr.batchintegrazione.dto.external;

import java.time.LocalDate;
import java.time.YearMonth;

import jakarta.ws.rs.QueryParam;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AssoMailRemiFilter {

    @QueryParam("idMail")
    private Long idMail;

    @QueryParam("remiAssoluto")
    private String remiAssoluto;

    @QueryParam("codiceCliente")
    private String codiceCliente;

    @QueryParam("funzione")
    private String funzione;

    @QueryParam("ruolo")
    private String ruolo;

    @QueryParam("prefissoRiferimento2")
    private String prefissoRiferimento2;

    @QueryParam("tipo")
    private String tipo;

    @QueryParam("meseCompetenzaDa")
    private YearMonth meseCompetenzaDa;

    @QueryParam("meseCompetenzaA")
    private YearMonth meseCompetenzaA;

    @QueryParam("nomeFile")
    private String nomeFile;

    @QueryParam("dataEmissioneDa")
    private LocalDate dataEmissioneDa;

    @QueryParam("dataEmissioneA")
    private LocalDate dataEmissioneA;

    @QueryParam("statoInvio")
    private String statoInvio;
}