package it.eng.snam.pmr.batchintegrazionedg.resource;

import java.util.List;
import java.util.Optional;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringBatchDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringBatchSearchDTO;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringBatchService;
import it.eng.snam.pmr.batchintegrazionedg.utils.Utility;
import it.eng.snam.pmr.common.annotation.LogPmr;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/monitoring-batch")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RunOnVirtualThread
@LogPmr
public class MonitoringBatchResource extends AbstractResource {

    @Inject
    MonitoringBatchService service;

    @Context
    ContainerRequestContext ctx;

    // ======================================================
    // GET ALL
    // ======================================================
    @GET
    public Response getAll() {

        ReqContext c = init(ctx, "/monitoring-batch");

        List<MonitoringBatchDTO> list = service.getAll();

        return Utility.okOrEmpty(
                list,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // ======================================================
    // GET BY ID
    // ======================================================
    @GET
    @Path("/{id}")
    public Response getById(@PathParam("id") Long id) {

        ReqContext c = init(ctx, "/monitoring-batch/{id}");

        if (id == null || id <= 0) {
            return Utility.badRequest(
                    "Path param 'id' non valido",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        MonitoringBatchDTO dto = service.getById(id);

        return Utility.okOrNotFound(
                Optional.ofNullable(dto),
                "Nessun batch trovato per id=" + id,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // ======================================================
    // GET BY TRANSACTION ID
    // ======================================================
    @GET
    @Path("/transaction/{transactionId}")
    public Response getByTransactionId(@PathParam("transactionId") String txId) {

        ReqContext c = init(ctx, "/monitoring-batch/transaction/{transactionId}");

        if (txId == null || txId.isBlank()) {
            return Utility.badRequest(
                    "Path param 'transactionId' non valido",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        MonitoringBatchDTO dto = service.getByTransactionId(txId);

        return Utility.okOrNotFound(
                Optional.ofNullable(dto),
                "Nessun batch trovato per transactionId=" + txId,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // ======================================================
    // GET LAST EXECUTIONS
    // ======================================================
    @GET
    @Path("/last-executions")
    public Response getLastExecutions(
            @QueryParam("limit") @DefaultValue("10") int limit) {

        ReqContext c = init(ctx, "/monitoring-batch/last-executions");

        if (limit <= 0) {
            return Utility.badRequest(
                    "Query param 'limit' deve essere > 0",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        List<MonitoringBatchDTO> list = service.getLastExecutions(limit);

        return Utility.okOrEmpty(
                list,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // ======================================================
    // GET BY PERIOD
    // ======================================================
    @GET
    @Path("/period")
    public Response getByPeriod(
            @QueryParam("monthNumber") Integer month,
            @QueryParam("dayNumber") Integer day) {

        ReqContext c = init(ctx, "/monitoring-batch/period");

        List<MonitoringBatchDTO> list =
                service.getByPeriod(month, day);

        return Utility.okOrEmpty(
                list,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }

    // ======================================================
    // SAVE
    // ======================================================
    @POST
    @Path("/save")
    public Response save(MonitoringBatchDTO dto) {

        ReqContext c = init(ctx, "/monitoring-batch/save");

        if (dto == null) {
            return Utility.badRequest(
                    "Body mancante o non valido",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        boolean exists =
                dto.transactionId() != null
                && !dto.transactionId().isBlank()
                && service.getByTransactionId(dto.transactionId()) != null;

        MonitoringBatchDTO saved = service.save(dto);

        return exists
                ? Utility.ok(saved, c.path(), c.kl(), c.tid(), c.modAsync(), c.processType(), c.start())
                : Utility.created(saved, c.path(), c.kl(), c.tid(), c.modAsync(), c.processType(), c.start());
    }
    
    // ======================================================
    // CUSTOM SEARCH
    // ======================================================
    @POST
    @Path("/search")
    public Response findByCustomSearch(MonitoringBatchSearchDTO searchDto) {

        ReqContext c = init(ctx, "/monitoring-batch/search");

        if (searchDto == null) {
            return Utility.badRequest(
                    "Body di ricerca mancante o non valido",
                    c.path(),
                    c.kl(),
                    c.tid(),
                    c.modAsync(),
                    c.processType(),
                    c.start()
            );
        }

        List<MonitoringBatchDTO> list =
                service.findByCustomSearch(searchDto);

        return Utility.okOrEmpty(
                list,
                c.path(),
                c.kl(),
                c.tid(),
                c.modAsync(),
                c.processType(),
                c.start()
        );
    }
}