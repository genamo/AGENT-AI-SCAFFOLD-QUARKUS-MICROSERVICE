package it.eng.snam.pmr.common.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class RetryableRemoteException extends RemoteCallException {
    @Serial
    private static final long serialVersionUID = -971900124413296092L;
}
