package it.eng.snam.pmr.common.config.jwt;

import java.security.PublicKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkException;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwt.interfaces.RSAKeyProvider;

import jakarta.ws.rs.NotAuthorizedException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class JwksRsaKeyProvider implements RSAKeyProvider {

    private final JwkProvider jwkProvider;

    @Override
    public RSAPublicKey getPublicKeyById(String keyId) {
        if (keyId == null || keyId.isBlank())
            throw new NotAuthorizedException("JWT kid is missing");

        try {
            Jwk jwk = jwkProvider.get(keyId);
            PublicKey publicKey = jwk.getPublicKey();

            if (!(publicKey instanceof RSAPublicKey rsaPublicKey))
                throw new NotAuthorizedException("JWT signing key is not RSA. kid=" + keyId);

            return rsaPublicKey;
        } catch (JwkException exception) {
            log.warn("Unable to resolve JWT signing key. kid={}", keyId, exception);
            throw new NotAuthorizedException("Unknown JWT signing key");
        }
    }

    @Override
    public RSAPrivateKey getPrivateKey() {
        return null;
    }

    @Override
    public String getPrivateKeyId() {
        return null;
    }
}