package it.eng.snam.pmr.batchintegrazione.utils;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.response.ResponseStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
public class Utility {

    private static final String MSG_TYPE_ERROR = "ERROR";

    @Inject
    RequestHeadersContext headersCtx;

    // =========================
    // Helpers (puri) - static
    // =========================

    public static String defaultUuidIfBlank(String v) {
        return (v == null || v.isBlank()) ? UUID.randomUUID().toString() : v;
    }

    /**
     * MOD_ASYNC:
     * - null/vuoto -> defaultValue
     * - "true"/"false" (case-insensitive) -> parse
     * - altro -> defaultValue
     */
    public static boolean parseBooleanOrDefault(String v, boolean defaultValue) {
        if (v == null || v.isBlank()) return defaultValue;

        String s = v.trim().toLowerCase();
        if ("true".equals(s)) return true;
        if ("false".equals(s)) return false;

        return defaultValue;
    }

    public static String defaultIfBlank(String value, String defaultValue) {
        return (value == null || value.trim().isEmpty()) ? defaultValue : value;
    }

    public static long elapsedMs(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }

    public static String safe(Object v) {
        if (v == null) return "null";
        String s = String.valueOf(v).trim();
        if (s.isEmpty()) return "blank";
        return (s.length() > 120) ? s.substring(0, 120) + "..." : s;
    }

    // ==================================================
    // Context helpers (path + start automatici)
    // ==================================================

    private String currentPath() {
        String p = (headersCtx != null) ? headersCtx.getPath() : null;
        return (p == null || p.isBlank()) ? "N/A" : p;
    }

    private long startNanos() {
        long s = (headersCtx != null) ? headersCtx.getStartNanos() : 0L;
        // fallback: se qualcuno chiama Utility fuori dal flusso HTTP
        return (s > 0L) ? s : System.nanoTime();
    }

    private String executionTime() {
        long elapsedNanos = System.nanoTime() - startNanos();
        return Duration.ofNanos(elapsedNanos).toMillis() + "ms";
    }

    // ==================================================
    // Common headers (dal RequestHeadersContext)
    // ==================================================

    private Response.ResponseBuilder withCommonHeaders(Response.ResponseBuilder rb) {
        return rb
            .header(Constants.Headers.KEYLOGIC, headersCtx.getKeyLogic())
            .header(Constants.Headers.TRANSACTION_ID, headersCtx.getTransactionId())
            .header(Constants.Headers.MOD_ASYNC, String.valueOf(headersCtx.isModAsync()))
            .header(Constants.Headers.PROCESS_TYPE, headersCtx.getProcessType());
    }

    // ============================================================
    // GenericResponse builders (uniforma tutte le risposte)
    // ============================================================

    private static <T> GenericResponse<T> baseGeneric(String path) {
        GenericResponse<T> gr = new GenericResponse<>();
        gr.setTimestamp(OffsetDateTime.now().toString());
        gr.setPath(path);
        return gr;
    }

    // =========================
    // 200 OK (general)
    // =========================

    public <T> Response ok(T data) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);
        gr.setExecutionTime(executionTime());

        if (data instanceof List<?> l) {
            gr.setNumberOfElements(l.size());
        }

        return withCommonHeaders(Response.ok(gr)).build();
    }
    
    public <T> Response inProgress(T data) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);
        gr.setExecutionTime(executionTime());
        gr.setStatus(ResponseStatus.IN_ELABORAZIONE.toString());
        if (data instanceof List<?> l) {
            gr.setNumberOfElements(l.size());
        }

        return withCommonHeaders(Response.ok(gr)).build();
    }
    public <T> Response inCarico(T data) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);
        gr.setExecutionTime(executionTime());
        gr.setStatus(ResponseStatus.PRESO_IN_CARICO.toString());
        if (data instanceof List<?> l) {
            gr.setNumberOfElements(l.size());
        }

        return withCommonHeaders(Response.ok(gr)).build();
    }

    public <T> Response okWithMessageCustom(T data, GenericResponse.Message msg) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);
        gr.setExecutionTime(executionTime());
        gr.setMessage(msg);

        if (data instanceof List<?> l) {
            gr.setNumberOfElements(l.size());
        }

        return withCommonHeaders(Response.ok(gr)).build();
    }

    public <T> Response okEmpty() {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setExecutionTime(executionTime());
        gr.setNumberOfElements(0);

        return withCommonHeaders(Response.ok(gr)).build();
    }

    // =========================
    // 201 CREATED (general)
    // =========================

    public <T> Response created(T data) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);
        gr.setExecutionTime(executionTime());

        if (data instanceof List<?> l) {
            gr.setNumberOfElements(l.size());
        }

        return withCommonHeaders(Response.status(Response.Status.CREATED).entity(gr)).build();
    }

    // =========================
    // 404 NOT FOUND (general)
    // =========================

    public <T> Response notFound(String message) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setExecutionTime(executionTime());

        GenericResponse.Message msg = new GenericResponse.Message();
        msg.setMessageType(MSG_TYPE_ERROR);
        msg.setMessageCode("NOT_FOUND");
        msg.setMessageDescription(message);
        gr.setMessage(msg);

        return withCommonHeaders(Response.status(Response.Status.NOT_FOUND).entity(gr)).build();
    }

    public <T> Response notFoundWithMessageCustom(GenericResponse.Message message) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setExecutionTime(executionTime());
        gr.setMessage(message);

        return withCommonHeaders(Response.status(Response.Status.NOT_FOUND).entity(gr)).build();
    }

    // =========================
    // 400 BAD REQUEST (general)
    // =========================

    public <T> Response badRequest(String message) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setExecutionTime(executionTime());

        GenericResponse.Message msg = new GenericResponse.Message();
        msg.setMessageType(MSG_TYPE_ERROR);
        msg.setMessageCode("BAD_REQUEST");
        msg.setMessageDescription(message);
        gr.setMessage(msg);

        return withCommonHeaders(Response.status(Response.Status.BAD_REQUEST).entity(gr)).build();
    }

    // =========================
    // 502 BAD GATEWAY (general)
    // =========================

    public <T> Response badGateway(RemoteCallException e) {
        String path = currentPath();
        GenericResponse<T> gr = baseGeneric(path);
        gr.setExecutionTime(executionTime());

        GenericResponse.Message msg = new GenericResponse.Message();
        msg.setMessageType(MSG_TYPE_ERROR);
        msg.setMessageCode("BAD_GATEWAY");
        msg.setMessageDescription(e.getMessage());
        gr.setMessage(msg);

        return withCommonHeaders(Response.status(Response.Status.BAD_GATEWAY).entity(gr)).build();
    }

    // =========================
    // 204 NO CONTENT (solo headers)
    // =========================

    public Response noContentOnlyHeaders() {
        return withCommonHeaders(Response.noContent()).build();
    }

    // -----------------------------------------
    // Helper per Optional e List (general)
    // -----------------------------------------

    public <T> Response okOrNotFound(Optional<T> opt, String notFoundMessage) {
        if (opt.isPresent()) {
            return ok(opt.get());
        }
        return notFound(notFoundMessage);
    }

    public <T> Response okOrNotFoundWithCustomMessage(Optional<T> opt, GenericResponse.Message customMessage) {
        if (opt.isPresent()) {
            return okWithMessageCustom(opt.get(), customMessage);
        }
        return notFoundWithMessageCustom(customMessage);
    }

    public <T> Response okOrEmpty(List<T> list) {
        if (list == null || list.isEmpty()) {
            return okEmpty();
        }
        return ok(list);
    }

    public <T> Response okOrEmptyWithCustomMessage(List<T> list, GenericResponse.Message customMessage) {
        if (list == null || list.isEmpty()) {
            return okEmpty();
        }
        return okWithMessageCustom(list, customMessage);
    }

    // ============================================================
    // (Opzionale) overload compatibilità: se vuoi migrazione graduale
    // ============================================================

    /**
     * @deprecated Use {@link #ok(Object)} instead. Kept for gradual migration.
     */
    @Deprecated(forRemoval = false)
    public <T> Response ok(T data, String path, long startNanos) {
        // mantengo la vecchia signature se ti serve una migrazione graduale,
        // ma internamente usa comunque headers e builder standard.
        GenericResponse<T> gr = baseGeneric(path);
        gr.setData(data);

        long elapsedNanos = System.nanoTime() - startNanos;
        gr.setExecutionTime(Duration.ofNanos(elapsedNanos).toMillis() + "ms");

        if (data instanceof List<?> l) {
            gr.setNumberOfElements(l.size());
        }

        return withCommonHeaders(Response.ok(gr)).build();
    }
}