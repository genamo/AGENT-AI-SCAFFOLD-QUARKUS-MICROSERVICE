package it.eng.snam.pmr.batchintegrazione.dto;

import java.time.LocalDate;
import java.util.List;

import lombok.Builder;

@Builder
public record ParametriSistemaRequestSearch(
    LocalDate dataRiferimento,
    List<String> codici
) {}
