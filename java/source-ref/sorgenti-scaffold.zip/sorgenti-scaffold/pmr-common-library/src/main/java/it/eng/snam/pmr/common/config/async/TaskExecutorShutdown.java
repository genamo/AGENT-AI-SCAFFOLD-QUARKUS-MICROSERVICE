package it.eng.snam.pmr.common.config.async;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

import it.eng.snam.pmr.common.config.async.properties.AsyncProperties;
import it.eng.snam.pmr.common.util.async.AsyncProcessExecutor;
import it.eng.snam.pmr.common.util.async.ExecutorRegistry;
import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class TaskExecutorShutdown {

    private final AsyncProperties properties;

    @PreDestroy
    public void shutdown() {
        List<Executor> executorRegistry = ExecutorRegistry.getExecutorRegistry();
        log.info("Shutting down ExecutorRegistry with {} executors", executorRegistry.size());

        executorRegistry.forEach(this::shutdownExecutor);
    }

    private void shutdownExecutor(Executor executor) {
        if (!(executor instanceof ExecutorService executorService)) {
            log.warn("Registered executor does not support shutdown: {}", executor);
            ExecutorRegistry.unregister(executor);
            return;
        }

        try {
            log.info("Shutting down executor: {}", executor);
            executorService.shutdown();

            if (!executorService.awaitTermination(properties.awaitTerminationSeconds(), TimeUnit.SECONDS)) {
                List<Runnable> pendingTasks = executorService.shutdownNow();
                log.warn("Forced shutdown for executor: {}. Pending tasks: {}", executor, pendingTasks.size());

                if (!executorService.awaitTermination(properties.awaitTerminationSeconds(), TimeUnit.SECONDS))
                    log.error("Executor did not terminate: {}", executor);
            }
        } catch (InterruptedException exception) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
            log.warn("Executor shutdown interrupted: {}", executor, exception);
        } finally {
            AsyncProcessExecutor.evict(executorService);
            ExecutorRegistry.unregister(executor);
        }
    }
}