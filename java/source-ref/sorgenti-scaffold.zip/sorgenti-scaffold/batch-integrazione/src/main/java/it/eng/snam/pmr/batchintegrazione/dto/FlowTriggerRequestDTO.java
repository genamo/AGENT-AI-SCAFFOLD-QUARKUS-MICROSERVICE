package it.eng.snam.pmr.batchintegrazione.dto;

import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Builder;

@Builder
public record FlowTriggerRequestDTO(
    String flow,
    String transactionId,
    String processType,
    String messageKey,
    JsonNode payload,
    Map<String, String> extraHeaders
) {}
