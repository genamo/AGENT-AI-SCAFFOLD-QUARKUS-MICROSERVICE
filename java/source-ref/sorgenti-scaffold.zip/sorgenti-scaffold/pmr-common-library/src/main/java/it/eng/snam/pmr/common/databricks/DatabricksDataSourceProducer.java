package it.eng.snam.pmr.common.databricks;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import javax.sql.DataSource;

@ApplicationScoped
public class DatabricksDataSourceProducer {

    // BASE CONFIG
    @ConfigProperty(name = "databricks.datasource.host")
    String host;

    @ConfigProperty(name = "databricks.datasource.port", defaultValue = "443")
    int port;

    @ConfigProperty(name = "databricks.datasource.httpPath")
    String httpPath;

    // PAT (Personal Access Token)
    @ConfigProperty(name = "databricks.datasource.pat")
    String pat;

    // DRIVER
    @ConfigProperty(name = "databricks.datasource.driver")
    String driver;

    // POOL CONFIG
    @ConfigProperty(name = "databricks.datasource.pool.max-size", defaultValue = "10")
    int maxPoolSize;

    @ConfigProperty(name = "databricks.datasource.pool.min-idle", defaultValue = "2")
    int minIdle;

    @ConfigProperty(name = "databricks.datasource.pool.connection-timeout", defaultValue = "30000")
    long connectionTimeout;

    @ConfigProperty(name = "databricks.datasource.pool.max-lifetime", defaultValue = "300000")
    long maxLifetime;

    @ConfigProperty(name = "databricks.datasource.pool.idle-timeout", defaultValue = "120000")
    long idleTimeout;

    @Produces
    @ApplicationScoped
    @DatabricksDS
    public DataSource dataSource() {

        // 1) Normalizza host per JDBC (solo hostname, niente https://, niente path)
        String jdbcHost = normalizeHostForJdbc(host);

        // 2) Normalizza httpPath: deve iniziare con "/"
        String normalizedHttpPath = normalizeHttpPath(httpPath);

        // 3) Validazioni minime
        if (pat == null || pat.isBlank()) {
            throw new IllegalStateException("databricks.datasource.pat NOT configured");
        }

        // 4) JDBC URL con AuthMech=3 (PAT)
        //    Nota: NON mettiamo PAT nella URL; user/pass li settiamo su Hikari
        String jdbcUrl = String.format(
                "jdbc:databricks://%s:%d/default;" +
                "httpPath=%s;" +
                "transportMode=http;" +
                "ssl=1;" +
                "AuthMech=3;" +
                "LogLevel=0;" +
                "EnableArrow=0;",
                jdbcHost,
                port,
                normalizedHttpPath
        );

        HikariConfig config = new HikariConfig();

        // JDBC
        config.setJdbcUrl(jdbcUrl);
        config.setDriverClassName(driver);

        // CREDENZIALI (PAT)
        // UID deve essere "token", PWD è il personal access token
        config.setUsername("token");
        config.setPassword(pat);

        // POOL
        config.setMaximumPoolSize(maxPoolSize);
        config.setMinimumIdle(minIdle);
        config.setConnectionTimeout(connectionTimeout);
        config.setMaxLifetime(maxLifetime);
        config.setIdleTimeout(idleTimeout);
        config.setPoolName("databricks");

        // ROBUSTEZZA
        config.setInitializationFailTimeout(-1);
        config.setConnectionTestQuery("SELECT 1");

        return new HikariDataSource(config);
    }

    static String normalizeHostForJdbc(String rawHost) {
        if (rawHost == null) return null;
        String h = rawHost.trim();

        if (h.startsWith("https://")) h = h.substring("https://".length());
        else if (h.startsWith("http://")) h = h.substring("http://".length());

        int slash = h.indexOf('/');
        if (slash >= 0) h = h.substring(0, slash);

        int colon = h.indexOf(':');
        if (colon >= 0) h = h.substring(0, colon);

        return h;
    }

    static String normalizeHttpPath(String rawPath) {
        if (rawPath == null) return null;
        String p = rawPath.trim();
        if (!p.startsWith("/")) p = "/" + p;
        return p;
    }
}