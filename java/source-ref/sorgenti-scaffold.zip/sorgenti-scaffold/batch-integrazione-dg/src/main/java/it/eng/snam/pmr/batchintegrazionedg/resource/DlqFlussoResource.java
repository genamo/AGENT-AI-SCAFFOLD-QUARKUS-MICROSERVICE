package it.eng.snam.pmr.batchintegrazionedg.resource;

import java.util.List;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoRequestDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoResponseDTO;
import it.eng.snam.pmr.batchintegrazionedg.service.DlqFlussoService;
import it.eng.snam.pmr.batchintegrazionedg.utils.Utility;
import it.eng.snam.pmr.common.annotation.LogPmr;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;

@Path("/dlq-flussi")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@LogPmr
@RunOnVirtualThread
public class DlqFlussoResource extends AbstractResource {

    @Inject
    DlqFlussoService service;

    @Context
    ContainerRequestContext ctx;

    @POST
    @Path("/save")
    public Response save(DlqFlussoRequestDTO request) {

        ReqContext c = init(ctx, "/save");

        if (request == null) {
            return Utility.badRequest(
                    "request obbligatoria",
                    c.path(), c.kl(), c.tid(),
                    c.modAsync(), c.processType(), c.start()
            );
        }

        // transactionId NON è più obbligatorio
        // La chiave tecnica di controllo adesso è controlKey
        if (request.controlKey() == null || request.controlKey().isBlank()) {
            return Utility.badRequest(
                    "controlKey obbligatoria",
                    c.path(), c.kl(), c.tid(),
                    c.modAsync(), c.processType(), c.start()
            );
        }

        DlqFlussoResponseDTO dto = service.save(request);

        return Response.ok(dto).build();
    }

    @GET
    @Path("/search")
    public Response search(@QueryParam("transactionId") String transactionId) {

        ReqContext c = init(ctx, "/search");

        if (transactionId == null || transactionId.isBlank()) {
            return Utility.badRequest(
                    "transactionId obbligatorio",
                    c.path(), c.kl(), c.tid(),
                    c.modAsync(), c.processType(), c.start()
            );
        }

        List<DlqFlussoDTO> entities = service.findAllByTransactionId(transactionId);

        return Response.ok(entities == null ? List.of() : entities).build();
    }

    @GET
    @Path("/control-key")
    public Response findByControlKey(@QueryParam("controlKey") String controlKey) {

        ReqContext c = init(ctx, "/control-key");

        if (controlKey == null || controlKey.isBlank()) {
            return Utility.badRequest(
                    "controlKey obbligatoria",
                    c.path(), c.kl(), c.tid(),
                    c.modAsync(), c.processType(), c.start()
            );
        }

        List<DlqFlussoDTO> entities = service.findByControlKey(controlKey);

        return Response.ok(entities == null ? List.of() : entities).build();
    }

    @GET
    @Path("/control-key/count")
    public Response countByControlKey(@QueryParam("controlKey") String controlKey) {

        ReqContext c = init(ctx, "/control-key/count");

        if (controlKey == null || controlKey.isBlank()) {
            return Utility.badRequest(
                    "controlKey obbligatoria",
                    c.path(), c.kl(), c.tid(),
                    c.modAsync(), c.processType(), c.start()
            );
        }

        long count = service.countByControlKey(controlKey);

        return Response.ok(count).build();
    }

    @GET
    @Path("/status")
    public Response findByStatus(@QueryParam("status") String status) {

        ReqContext c = init(ctx, "/status");

        if (status == null || status.isBlank()) {
            return Utility.badRequest(
                    "status obbligatorio",
                    c.path(), c.kl(), c.tid(),
                    c.modAsync(), c.processType(), c.start()
            );
        }

        List<DlqFlussoDTO> entities = service.findByStatus(status);

        return Response.ok(entities == null ? List.of() : entities).build();
    }

    @GET
    @Path("/latest")
    public Response latest(@QueryParam("limit") @DefaultValue("20") int limit) {

        ReqContext c = init(ctx, "/latest");

        if (limit <= 0) {
            return Utility.badRequest(
                    "limit deve essere maggiore di 0",
                    c.path(), c.kl(), c.tid(),
                    c.modAsync(), c.processType(), c.start()
            );
        }

        List<DlqFlussoDTO> entities = service.findLatest(limit);

        return Response.ok(entities == null ? List.of() : entities).build();
    }
}