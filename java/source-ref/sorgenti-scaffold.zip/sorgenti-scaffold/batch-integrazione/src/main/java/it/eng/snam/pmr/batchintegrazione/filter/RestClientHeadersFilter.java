package it.eng.snam.pmr.batchintegrazione.filter;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;

import org.apache.commons.lang3.StringUtils;

import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.B2BTokenUtils;
import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.ext.Provider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Provider
@Priority(Priorities.AUTHENTICATION + 10)
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class RestClientHeadersFilter implements ClientRequestFilter {

    private static final String BEARER = "Bearer ";

    private final B2BTokenUtils tokenUtil;
    private final RequestHeadersContext ctx;

    @Override
    public void filter(ClientRequestContext requestContext) {
        String keyLogic = contextOrMdc(ctx::getKeyLogic, CommonConstants.LogParams.KL);
        String transactionId = contextOrMdc(ctx::getTransactionId, CommonConstants.LogParams.TN);
        String processType = contextOrMdc(ctx::getProcessType, CommonConstants.LogParams.PT);
        String messageKey = contextOrMdc(() -> StringUtils.EMPTY, CommonConstants.LogParams.MK);
        String modeAsync = contextOrMdc(() -> String.valueOf(ctx.isModAsync()), CommonConstants.LogParams.MA);
        String userId = contextOrMdc(() -> StringUtils.EMPTY, AuthorizationUtils.USER_ID);

        putIfNotNull(requestContext, CommonConstants.Headers.KEYLOGIC, keyLogic);
        putIfNotNull(requestContext, CommonConstants.Headers.TRANSACTION_ID, transactionId);
        putIfNotNull(requestContext, CommonConstants.Headers.PROCESS_TYPE, processType);
        putIfNotNull(requestContext, CommonConstants.Headers.MESSAGE_KEY, messageKey);
        requestContext.getHeaders().putSingle(CommonConstants.Headers.MOD_ASYNC, String.valueOf(modeAsync));
        putIfNotNull(requestContext, AuthorizationUtils.USER_ID, userId);

        if (hasAuthorization(requestContext)) {
            log.debug("JWT already present in request, skipping further operations");
            return;
        }

        log.debug("JWT not present in request, executing further operations");
        putAuthorization(requestContext, fetchAuthTokenJWT());
    }

    private String contextOrMdc(Supplier<String> contextSupplier, String mdcKey) {
        Supplier<String> mdcSupplier = () -> StringUtils.defaultString(MdcManager.getHeader(mdcKey));
        try {
            return Optional.ofNullable(contextSupplier.get()).filter(StringUtils::isNotBlank)
                           .orElse(mdcSupplier.get());
        } catch (Exception ignored) {
            // RequestScoped non attivo: fallback su MDC
            return mdcSupplier.get();
        }
    }

    private void putIfNotNull(ClientRequestContext requestContext, String key, String value) {
        if (value != null)
            requestContext.getHeaders().putSingle(key, value);
    }

    private boolean hasAuthorization(ClientRequestContext requestContext) {
        List<Object> values = requestContext.getHeaders().get(HttpHeaders.AUTHORIZATION);
        return values != null && values.stream().filter(Objects::nonNull).map(Object::toString)
                                       .anyMatch(StringUtils::isNotBlank);
    }

    private String fetchAuthTokenJWT() {
        String jwt = MdcManager.getHeader(AuthorizationUtils.JWT_AUTHZ);
        if (StringUtils.isNotBlank(jwt)) {
            log.debug("JWT token successfully retrieved from MDC");
            return jwt;
        } else {
            log.debug("JWT token not retrieved from MDC, generating SuperUser token");
            return tokenUtil.generateSuperUserToken();
        }
    }

    private void putAuthorization(ClientRequestContext requestContext, String token) {
        log.debug("Normalizing token if necessary");
        String normalizedToken = normalizeBearer(token);

        log.debug("Attaching normalized token to request: {}", normalizedToken);
        requestContext.getHeaders().putSingle(HttpHeaders.AUTHORIZATION, normalizedToken);
    }

    private String normalizeBearer(String auth) {
        return Optional.ofNullable(auth).filter(StringUtils::isNotBlank).map(String::trim)
                       .map(value -> value.startsWith(BEARER) ? value : StringUtils.join(BEARER, value))
                       .orElseThrow(() -> new IllegalStateException("Authorization token is blank"));
    }
}