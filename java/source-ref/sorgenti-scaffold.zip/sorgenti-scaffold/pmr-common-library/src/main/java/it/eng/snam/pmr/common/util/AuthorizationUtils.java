package it.eng.snam.pmr.common.util;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;

import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.container.ContainerRequestContext;
import lombok.experimental.UtilityClass;

@UtilityClass
public class AuthorizationUtils {

    public final String USER_ID = "userId";
    public final String JWT_AUTHZ = "jwt";
    public final String PROFILE = "profile";

    public final String CLAIM_USER_ID = "UserID";

    // =========================================================
    // BEARER HEADER
    // =========================================================
    public String getBearer(ContainerRequestContext req) {
        String header = req.getHeaderString("Authorization");
        if (header == null || header.isBlank())
            throw new NotAuthorizedException("Missing Authorization header");

        return header;
    }

    public String extractToken(String bearer) {
        return bearer.startsWith("Bearer ") ? bearer.substring(7) : bearer;
    }

    // =========================================================
    // JWT PARSING
    // =========================================================
    public DecodedJWT decode(String bearer) {
        return JWT.decode(extractToken(bearer));
    }

    // =========================================================
    // USER ID
    // =========================================================
    public String resolveUserId(DecodedJWT jwt) {
        if (jwt == null)
            return null;

        // 1) claim tecnici più affidabili
        List<String> claimNames = List.of(CLAIM_USER_ID);
        for (String claim : claimNames) {
            String value = normalizeTechnicalUserId(jwt.getClaim(claim).asString());
            if (notBlank(value))
                return value;
        }

        // 2) fallback standard JWT
        String subject = normalizeTechnicalUserId(jwt.getSubject());
        if (notBlank(subject))
            return subject;

        // 3) fallback finale "name" (display name)
        String name = jwt.getClaim("name").asString();
        return notBlank(name) ? name.trim() : null;
    }

    // =========================================================
    // ROLES
    // =========================================================
    public Set<String> resolveRoles(DecodedJWT jwt) {
        Set<String> roles = new HashSet<>();
        if (jwt == null)
            return roles;

        List<String> list = jwt.getClaim("roles").asList(String.class);
        if (list != null)
            roles.addAll(list);

        String role = jwt.getClaim("role").asString();
        if (notBlank(role))
            roles.add(role);

        return roles;
    }

    // =========================================================
    // HELPERS
    // =========================================================
    private String normalizeTechnicalUserId(String value) {
        if (!notBlank(value))
            return null;

        String normalized = value.trim();

        int idx = Math.max(normalized.lastIndexOf('\\'), normalized.lastIndexOf('/'));
        if (idx >= 0 && idx < normalized.length() - 1)
            normalized = normalized.substring(idx + 1);

        return normalized.toLowerCase(Locale.ROOT);
    }

    private boolean notBlank(String s) {
        return s != null && !s.trim().isEmpty();
    }
}
