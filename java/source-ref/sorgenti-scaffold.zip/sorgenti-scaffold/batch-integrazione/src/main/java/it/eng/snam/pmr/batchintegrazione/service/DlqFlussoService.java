package it.eng.snam.pmr.batchintegrazione.service;

import java.util.List;
import java.util.function.Supplier;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;
import org.jboss.resteasy.reactive.ClientWebApplicationException;

import com.fasterxml.jackson.core.type.TypeReference;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.DlqFlussoDTO;
import it.eng.snam.pmr.batchintegrazione.dto.DlqFlussoRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.DlqFlussoResponseDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class DlqFlussoService extends AbstractService {

    private static final Logger LOG = Logger.getLogger(DlqFlussoService.class);

    private static final TypeReference<List<DlqFlussoDTO>> LIST_TYPE =
        new TypeReference<>() {};

    @Inject
    @RestClient
    BatchIntegrazioneDgClient client;

    public DlqFlussoResponseDTO save(DlqFlussoRequestDTO request) {
        try (Response resp = client.saveDlqFlusso(request)) {
            int status = resp.getStatus();

            if (status == Response.Status.OK.getStatusCode()) {
                return readSaveResponse(resp.readEntity(String.class));
            }

            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                throw badRequest("DLQ save", resp);
            }

            throw remoteError("POST /dlq-flussi/save", status, resp);
        }
    }

    public List<DlqFlussoDTO> findByTransactionId(String transactionId) {
        return executeListCall(
            () -> client.findDlqFlussiByTransactionId(transactionId),
            "GET /dlq-flussi/search",
            "DLQ search by transactionId",
            true
        );
    }

    public List<DlqFlussoDTO> findByControlKey(String controlKey) {
        return executeListCall(
            () -> client.findDlqFlussiByControlKey(controlKey),
            "GET /dlq-flussi/control-key",
            "DLQ search by controlKey",
            true
        );
    }

    public long countByControlKey(String controlKey) {
        try (Response resp = client.countDlqFlussiByControlKey(controlKey)) {
            int status = resp.getStatus();

            if (status == Response.Status.OK.getStatusCode()) {
                return readLongResponse(resp.readEntity(String.class));
            }

            if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
                throw badRequest("DLQ count by controlKey", resp);
            }

            throw remoteError("GET /dlq-flussi/control-key/count", status, resp);
        }
    }

    public List<DlqFlussoDTO> findByStatus(String statusValue) {
        return executeListCall(
            () -> client.findDlqFlussiByStatus(statusValue),
            "GET /dlq-flussi/status",
            "DLQ search by status",
            false
        );
    }

    public List<DlqFlussoDTO> findLatest(int limit) {
        return executeListCall(
            () -> client.findLatestDlqFlussi(limit),
            "GET /dlq-flussi/latest",
            "DLQ latest",
            false
        );
    }

    private List<DlqFlussoDTO> executeListCall(
            Supplier<Response> responseSupplier,
            String operation,
            String badRequestPrefix,
            boolean notFoundAsEmpty) {

        try (Response resp = responseSupplier.get()) {
            return handleListResponse(resp, operation, badRequestPrefix, notFoundAsEmpty);
        } catch (ClientWebApplicationException e) {
            if (notFoundAsEmpty && isNotFound(e.getResponse())) {
                return List.of();
            }
            throw e;
        }
    }

    private List<DlqFlussoDTO> handleListResponse(
            Response resp,
            String operation,
            String badRequestPrefix,
            boolean notFoundAsEmpty) {

        int status = resp.getStatus();

        if (status == Response.Status.OK.getStatusCode()) {
            return readDlqFlussoList(resp.readEntity(String.class));
        }

        if (notFoundAsEmpty && status == Response.Status.NOT_FOUND.getStatusCode()) {
            return List.of();
        }

        if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
            throw badRequest(badRequestPrefix, resp);
        }

        throw remoteError(operation, status, resp);
    }

    private IllegalArgumentException badRequest(String prefix, Response resp) {
        String body = safeReadBody(resp);
        return new IllegalArgumentException(
            prefix + " 400: " + (body.isBlank() ? "Bad Request" : body)
        );
    }

    private boolean isNotFound(Response resp) {
        return resp != null && resp.getStatus() == Response.Status.NOT_FOUND.getStatusCode();
    }

    private DlqFlussoResponseDTO readSaveResponse(String json) {
        if (json == null || json.isBlank()) {
            throw new RemoteCallException("Risposta vuota da dlq-flussi/save");
        }

        try {
            return objectMapper.readValue(json, DlqFlussoResponseDTO.class);
        } catch (Exception e) {
            throw new RemoteCallException(
                "Impossibile deserializzare DlqFlussoResponseDTO",
                e
            );
        }
    }

    private List<DlqFlussoDTO> readDlqFlussoList(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }

        try {
            return objectMapper.readValue(json, LIST_TYPE);
        } catch (Exception e) {
            throw new RemoteCallException(
                "Impossibile deserializzare lista DlqFlussoDTO",
                e
            );
        }
    }

    private long readLongResponse(String body) {
        if (body == null || body.isBlank()) {
            return 0L;
        }

        try {
            return objectMapper.readValue(body, Long.class);
        } catch (Exception first) {
            try {
                return Long.parseLong(body.trim());
            } catch (Exception second) {
                throw new RemoteCallException(
                    "Impossibile deserializzare count long",
                    second
                );
            }
        }
    }
}
