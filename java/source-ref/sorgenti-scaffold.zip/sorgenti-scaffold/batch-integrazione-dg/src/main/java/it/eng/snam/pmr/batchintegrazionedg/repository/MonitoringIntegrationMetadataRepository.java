package it.eng.snam.pmr.batchintegrazionedg.repository;

import java.util.Optional;

import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import it.eng.snam.pmr.batchintegrazionedg.entity.MonitoringIntegrationMetadata;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MonitoringIntegrationMetadataRepository implements PanacheRepositoryBase<MonitoringIntegrationMetadata, Long> {

    public Optional<MonitoringIntegrationMetadata> findByIntegrationRequestId(Long integrationRequestId) {
        return find("integrationRequestId = ?1", integrationRequestId)
                .firstResultOptional();
    }
}
