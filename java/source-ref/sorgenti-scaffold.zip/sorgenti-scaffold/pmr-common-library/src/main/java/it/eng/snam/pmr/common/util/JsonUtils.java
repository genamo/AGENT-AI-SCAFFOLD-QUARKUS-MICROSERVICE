package it.eng.snam.pmr.common.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import it.eng.snam.pmr.common.exception.JsonParsingException;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class JsonUtils {

    private static final ObjectMapper MAPPER;

    static {
        ObjectMapper tempMapper = new ObjectMapper();
        tempMapper.registerModule(new JavaTimeModule());
        tempMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        tempMapper.setDefaultPropertyInclusion(Include.NON_NULL);
        tempMapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
        tempMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        tempMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        tempMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        MAPPER = tempMapper;
    }

    public ObjectMapper mapper() {
        return MAPPER;
    }

    public String writeAsJsonStringWithoutNull(Object payload) {
        try {
            return payload != null ? MAPPER.writeValueAsString(payload) : null;
        } catch (JsonProcessingException ex) {
            log.error("Error while trying to convert object to JSON string", ex);
            return null;
        }
    }

    public String writeAsJsonPrettyLogStringWithoutNull(Object payload) {
        try {
            return payload != null ? MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(payload) : null;
        } catch (JsonProcessingException ex) {
            log.error("Error while trying to convert object to pretty JSON string", ex);
            return null;
        }
    }

    public byte[] writeAsJsonBytesWithoutNull(Object payload) {
        String json = writeAsJsonStringWithoutNull(payload);
        return json != null ? json.getBytes(StandardCharsets.UTF_8) : null;
    }

    public byte[] writeAsJsonPrettyBytesWithoutNull(Object payload) {
        String json = writeAsJsonPrettyLogStringWithoutNull(payload);
        return json != null ? json.getBytes(StandardCharsets.UTF_8) : null;
    }

    public <T> T getObject(String value, Class<T> clazz) throws IOException {
        return StringUtils.isBlank(value) ? null : getObject(value.getBytes(StandardCharsets.UTF_8), clazz);
    }

    public <T> T getObject(byte[] bytes, Class<T> clazz) throws IOException {
        return ArrayUtils.isEmpty(bytes) ? null : MAPPER.readValue(bytes, clazz);
    }

    public <T> T getObject(String value, TypeReference<T> typeReference) throws IOException {
        return StringUtils.isBlank(value) ? null : getObject(value.getBytes(StandardCharsets.UTF_8), typeReference);
    }

    public <T> T getObject(byte[] bytes, TypeReference<T> typeReference) throws IOException {
        return ArrayUtils.isEmpty(bytes) ? null : MAPPER.readValue(bytes, typeReference);
    }

    public boolean isJson(String value) {
        return !StringUtils.isBlank(value) && isJson(value.getBytes(StandardCharsets.UTF_8));
    }

    public boolean isJson(byte[] bytes) {
        try {
            if (ArrayUtils.isEmpty(bytes))
                return false;

            MAPPER.readTree(bytes);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public <T> T readValue(String operation, String json, TypeReference<T> typeReference) {
        try {
            return JsonUtils.getObject(json, typeReference);
        } catch (Exception e) {
            throw new JsonParsingException(operation + ": cannot deserialize json. " + e.getMessage());
        }
    }
}
