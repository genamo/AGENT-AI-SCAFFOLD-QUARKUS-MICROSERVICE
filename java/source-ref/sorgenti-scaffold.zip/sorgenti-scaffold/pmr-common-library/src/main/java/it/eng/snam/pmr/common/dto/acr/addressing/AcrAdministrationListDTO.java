package it.eng.snam.pmr.common.dto.acr.addressing;

import lombok.Builder;

@Builder
public record AcrAdministrationListDTO(
        Long administrationListId,
        String name
) {}
