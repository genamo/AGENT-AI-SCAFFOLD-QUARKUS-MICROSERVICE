package it.eng.snam.pmr.batchintegrazione.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import it.eng.snam.pmr.batchintegrazione.service.abstracts.FlussoHandler;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Any;
import jakarta.enterprise.inject.Instance;
import jakarta.inject.Inject;

@ApplicationScoped
public class FlussoRegistry {

    private final Map<String, FlussoHandler> handlers;

    @Inject
    public FlussoRegistry(@Any Instance<FlussoHandler> handlerInstance) {
        List<FlussoHandler> handlerList = handlerInstance.stream().toList();

        this.handlers = handlerList.stream()
                .collect(Collectors.toMap(
                        FlussoHandler::getFlowType,
                        h -> h
                ));
    }

    public FlussoHandler get(String flow) {
        return handlers.get(flow);
    }
}
