package it.eng.snam.pmr.batchintegrazione.dto;

import lombok.Builder;

@Builder
public record DlqFlussoRequestDTO(
    String transactionId,
    String flowId,
    String controlKey,
    String keyLogic,
    String originalTopic,
    Integer originalPartition,
    Long originalOffset,
    String processType,
    String messageKey,
    String errorType,
    String errorMessage,
    String payload,
    String status
) {}