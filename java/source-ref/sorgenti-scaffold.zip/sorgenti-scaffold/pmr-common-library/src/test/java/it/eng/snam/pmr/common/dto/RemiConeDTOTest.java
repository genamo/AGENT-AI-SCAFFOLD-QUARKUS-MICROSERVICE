package it.eng.snam.pmr.common.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

class RemiConeDTOTest {

    @Test
    void normalizedSet_trimsUppercasesAndRemovesBlankOrNullValues() {
        RemiConeDTO dto = new RemiConeDTO(
                false,
                Arrays.asList(" remi01 ", "REMI01", "remi02", "  ", null)
        );

        Set<String> normalized = dto.normalizedSet();

        assertThat(normalized).containsExactlyInAnyOrder("REMI01", "REMI02");
    }

    @Test
    void normalizedSet_withNullList_returnsEmptySet() {
        RemiConeDTO dto = new RemiConeDTO(false, null);

        assertThat(dto.normalizedSet()).isEmpty();
    }

    @Test
    void allows_whenUnrestricted_returnsTrueForAnyValue() {
        RemiConeDTO dto = new RemiConeDTO(true, List.of());

        assertThat(dto.allows("REMI01")).isTrue();
        assertThat(dto.allows("  ")).isTrue();
        assertThat(dto.allows(null)).isTrue();
    }

    @Test
    void allows_whenRestricted_matchesCaseInsensitiveTrimmedValues() {
        RemiConeDTO dto = new RemiConeDTO(false, List.of(" remi01 ", "REMI02"));

        assertThat(dto.allows("remi01")).isTrue();
        assertThat(dto.allows("  remi02  ")).isTrue();
        assertThat(dto.allows("REMI03")).isFalse();
    }

    @Test
    void allows_blankOrNullInput_returnsTrueWhenRestricted() {
        RemiConeDTO dto = new RemiConeDTO(false, List.of("REMI01"));

        assertThat(dto.allows(null)).isTrue();
        assertThat(dto.allows("")).isTrue();
        assertThat(dto.allows("   ")).isTrue();
    }

    @Test
    void allowsAll_whenUnrestricted_returnsTrue() {
        RemiConeDTO dto = new RemiConeDTO(true, List.of());

        assertThat(dto.allowsAll(List.of("A", "B"))).isTrue();
    }

    @Test
    void allowsAll_whenRestricted_requiresAllNormalizedValuesToBePresent() {
        RemiConeDTO dto = new RemiConeDTO(false, List.of(" remi01 ", "REMI02"));

        assertThat(dto.allowsAll(List.of("REMI01", " remi02 "))).isTrue();
        assertThat(dto.allowsAll(List.of("REMI01", "REMI03"))).isFalse();
    }

    @Test
    void allowsAll_ignoresBlankAndNullEntries() {
        RemiConeDTO dto = new RemiConeDTO(false, List.of("REMI01"));

        assertThat(dto.allowsAll(Arrays.asList(null, "", "   ", "REMI01"))).isTrue();
    }

    @Test
    void allowsAll_nullOrEmptyCollection_returnsTrue() {
        RemiConeDTO dto = new RemiConeDTO(false, List.of("REMI01"));

        assertThat(dto.allowsAll(null)).isTrue();
        assertThat(dto.allowsAll(List.of())).isTrue();
    }
}
