package it.eng.snam.pmr.batchintegrazione.kafka;

import java.util.Map;
import java.util.concurrent.CompletionStage;

import org.eclipse.microprofile.reactive.messaging.Acknowledgment;
import org.eclipse.microprofile.reactive.messaging.Incoming;
import org.eclipse.microprofile.reactive.messaging.Message;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.dto.flussi.DateRiepiloghiPayloadDTO;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.TopicService;
import it.eng.snam.pmr.batchintegrazione.service.monitoring.integration.DateRiepiloghiService;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import it.eng.snam.pmr.common.functional.interfaces.kafka.consumer.MessageHandlerFactory;
import it.eng.snam.pmr.common.util.kafka.consumer.MessageProcessor;
import it.eng.snam.pmr.common.util.kafka.producer.MessageContextInitializer;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class KafkaConsumer {

    private final TopicService topicService;
    private final DateRiepiloghiService dateRiepiloghiService;

    private Map<String, MessageHandlerFactory> handlers;

    @PostConstruct
    void init() {
        handlers = Map.of(topicService.getRealTopic(Constants.Topic.DATE_RIEPILOGHI_SUMMER_IN_TOPIC),
                          MessageHandlerFactory.json(DateRiepiloghiPayloadDTO.class, dateRiepiloghiService::saveDateRiepiloghi));
        handlers.keySet().forEach(topic -> log.info("Message handler registered for topic: {}", topic));
    }

    @RunOnVirtualThread
    @Incoming("date-riepiloghi-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    public CompletionStage<Void> consumeDateRiepiloghi(Message<byte[]> message) {
        return process(message);
    }

    private CompletionStage<Void> process(Message<byte[]> message) {
        MdcManager.putKafkaHeaders(MessageContextInitializer.incoming(message).getHeaders());
        return MessageProcessor.manual(message, handlers);
    }
}
