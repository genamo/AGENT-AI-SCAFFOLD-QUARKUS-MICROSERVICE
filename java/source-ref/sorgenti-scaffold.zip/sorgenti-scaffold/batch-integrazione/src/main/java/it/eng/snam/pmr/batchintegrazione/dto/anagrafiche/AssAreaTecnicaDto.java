package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AssAreaTecnicaDto(
        String codiceAreaTecnica,
        String codicePolo,
        String descrizione,
        String descrizione2,
        String indirizzo,
        String centro,
        String telefono,
        String telefono2,
        String cellulare,
        String fax,
        String email,
        String valido,
        String cap,
        String citta,
        String provincia,
        String comune,
        String flagDisattivaVerifica,
        String flagDisattivaCdm,
        LocalDateTime dataDisabilitazioneCdm,
        LocalDateTime dataInserimento,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {}