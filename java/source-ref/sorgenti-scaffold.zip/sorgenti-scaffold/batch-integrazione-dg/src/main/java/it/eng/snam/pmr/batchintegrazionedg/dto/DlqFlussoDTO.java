package it.eng.snam.pmr.batchintegrazionedg.dto;

import java.time.LocalDateTime;

import lombok.Builder;
@Builder
public record DlqFlussoDTO(
    Long id,
    String transactionId,
    String flowId,
    String controlKey,
    String keyLogic,
    String originalTopic,
    Integer originalPartition,
    Long originalOffset,
    String processType,
    String messageKey,
    String errorType,
    String errorMessage,
    String payload,
    String status,
    LocalDateTime createdAt,
    LocalDateTime updatedAt
) {}