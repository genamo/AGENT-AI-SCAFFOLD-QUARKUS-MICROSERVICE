package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AnagRemiPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AnagRemiHandler extends AbstractFlussoHandler<AnagRemiPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AnagRemiPayloadDto> getDtoClass() {
        return AnagRemiPayloadDto.class;
    }

    @Override
    protected void handle(AnagRemiPayloadDto dto) {
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAnagRemi(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteAnagRemi(dto.data().getFirst().remiAssoluto());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}	
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ANAG_REMI_FLOW;
    }
}