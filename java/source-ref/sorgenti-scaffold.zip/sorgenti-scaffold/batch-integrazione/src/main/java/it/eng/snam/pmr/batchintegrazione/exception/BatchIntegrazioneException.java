package it.eng.snam.pmr.batchintegrazione.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class BatchIntegrazioneException extends RuntimeException {
    @Serial
    private static final long serialVersionUID = 4656961893439107255L;
}
