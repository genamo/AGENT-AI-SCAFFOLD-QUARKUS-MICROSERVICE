package it.eng.snam.pmr.common.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record RemiExternalUserConeScenarioDTO(
        String profilo,
        boolean fullAccess,
        List<RemiSpecializzazioneResponseDTO> conoRemiClientiList
) {}
