package it.eng.snam.pmr.batchintegrazione.utils.blob.storage;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileDataRequest;
import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import lombok.experimental.UtilityClass;

@UtilityClass
public class BlobMetadataBuilder {

    public Map<String, String> build(FileDataRequest request) {
        Map<String, String> metadata = new LinkedHashMap<>();
        metadata.put("transactionId", MdcManager.getHeader(CommonConstants.LogParams.TN));
        metadata.put("executioner", request.getExecutioner());
        metadata.put("activity", request.getActivity());
        metadata.put("sourceSystem", request.getSourceSystem());
        metadata.put("createdAtUTC", LocalDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        return metadata;
    }
}
