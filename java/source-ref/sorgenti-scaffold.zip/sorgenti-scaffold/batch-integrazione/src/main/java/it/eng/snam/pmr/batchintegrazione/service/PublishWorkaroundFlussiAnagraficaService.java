package it.eng.snam.pmr.batchintegrazione.service;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.fasterxml.jackson.databind.JsonNode;

import it.eng.snam.pmr.batchintegrazione.dto.DlqFlussoDTO;
import it.eng.snam.pmr.batchintegrazione.dto.FlowTriggerRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.FlowTriggerResponseDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringFlussiDTO;
import it.eng.snam.pmr.batchintegrazione.kafka.KafkaGenericProducer;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import it.eng.snam.pmr.common.dto.kafka.produce.MessageHeaderContext;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.NotFoundException;

@ApplicationScoped
public class PublishWorkaroundFlussiAnagraficaService extends AbstractService {

    private static final int MAX_PAYLOAD_BYTES = 1_000_000;

    @Inject
    KafkaGenericProducer producer;

    @Inject
    FlowTopicRoutingService routingService;

    @Inject
    DlqFlussoService dlqFlussoService;

    @Inject
    MonitoringFlussiService monitoringFlussiService;

    public FlowTriggerResponseDTO publish(FlowTriggerRequestDTO request) {
        validate(request);

        String flow = request.flow();
        String logicalTopic = routingService.resolveTopic(flow);

        String transactionId = defaultIfBlank(request.transactionId(), UUID.randomUUID().toString());
        String processType = defaultIfBlank(request.processType(), "GUI");
        String messageKey = defaultIfBlank(request.messageKey(), UUID.randomUUID().toString());

        byte[] payload;
        try {
            payload = objectMapper.writeValueAsBytes(request.payload());
        } catch (Exception e) {
            throw new IllegalArgumentException("Payload non serializzabile", e);
        }

        if (payload.length > MAX_PAYLOAD_BYTES) {
            throw new IllegalArgumentException("Payload troppo grande");
        }

        MessageHeaderContext context = MessageHeaderContext.builder().transactionId(transactionId).processType(processType).flowType(flow).messageKey(messageKey).build();
        producer.sendEventWithHeaders(logicalTopic, context, payload, request.extraHeaders() != null ? request.extraHeaders() : Map.of());

        return FlowTriggerResponseDTO.builder()
            .flow(flow)
            .resolvedTopic(logicalTopic)
            .transactionId(transactionId)
            .messageKey(messageKey)
            .status("PUBLISHED")
            .build();
    }

    public FlowTriggerRequestDTO buildDownloadFromDlqRequest(String controlKey) {
        if (controlKey == null || controlKey.isBlank()) {
            throw new IllegalArgumentException("Campo 'controlKey' obbligatorio");
        }

        List<DlqFlussoDTO> records = dlqFlussoService.findByControlKey(controlKey);

        if (records == null || records.isEmpty()) {
            throw new NotFoundException("Nessun record DLQ trovato per controlKey=" + controlKey);
        }

        DlqFlussoDTO dlq = records.get(0);

        return buildDownloadRequest(
            dlq.flowId(),
            dlq.payload(),
            "controlKey",
            controlKey
        );
    }

    public FlowTriggerRequestDTO buildDownloadFromFlussiMonitoringRequest(String transactionId) {
        if (transactionId == null || transactionId.isBlank()) {
            throw new IllegalArgumentException("Campo 'transactionId' obbligatorio");
        }

        var monitoringOpt = monitoringFlussiService.getByTransactionId(transactionId);
        MonitoringFlussiDTO monitoring = java.util.Optional.ofNullable(monitoringOpt)
            .flatMap(opt -> opt)
            .orElseThrow(() -> new NotFoundException(
                "Nessun monitoring flusso trovato per transactionId=" + transactionId
            ));

        return buildDownloadRequest(
            monitoring.flowId(),
            monitoring.fileFlusso(),
            "transactionId",
            transactionId
        );
    }


    private FlowTriggerRequestDTO buildDownloadRequest(
            String flow,
            String payloadBase64,
            String sourceName,
            String sourceValue) {

        if (payloadBase64 == null || payloadBase64.isBlank()) {
            throw new IllegalStateException(
                "Payload vuoto per " + sourceName + "=" + sourceValue
            );
        }

        JsonNode payloadNode;
        try {
            byte[] decodedBytes = Base64.getDecoder().decode(payloadBase64);
            String decodedJson = new String(decodedBytes, StandardCharsets.UTF_8);
            payloadNode = objectMapper.readTree(decodedJson);
        } catch (Exception e) {
            throw new IllegalStateException(
                "Payload non decodificabile o non valido per " + sourceName + "=" + sourceValue,
                e
            );
        }


		String transactionId=null;
		if (flow == null || flow.isBlank()) {
		    transactionId = UUID.randomUUID().toString();
		} else {
			String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"));
			transactionId = flow + "_" + timestamp;
		}

        
        return FlowTriggerRequestDTO.builder()
            .flow(defaultIfBlank(flow, ""))
            .transactionId(transactionId)
            .processType("GUI")
            .messageKey(UUID.randomUUID().toString())
            .payload(payloadNode)
            .extraHeaders(Map.of())
            .build();
    }

    private void validate(FlowTriggerRequestDTO request) {
        if (request == null) {
            throw new IllegalArgumentException("Body mancante");
        }
        if (request.flow() == null || request.flow().isBlank()) {
            throw new IllegalArgumentException("Campo 'flow' obbligatorio");
        }
        if (!Constants.Flussi.isValidFlow(request.flow())) {
            throw new IllegalArgumentException("Flow non valido: " + request.flow());
        }
        if (request.payload() == null || request.payload().isNull()) {
            throw new IllegalArgumentException("Campo 'payload' obbligatorio");
        }
    }

    private String defaultIfBlank(String value, String def) {
        return (value == null || value.isBlank()) ? def : value;
    }
}
