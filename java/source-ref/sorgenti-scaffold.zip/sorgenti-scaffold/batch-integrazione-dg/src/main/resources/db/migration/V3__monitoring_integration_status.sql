USE [pmrintegrazione];

/* ============================================================
   AZURE SQL - MONITORING INTEGRATION STATUS TRACKING
   Prefix tabelle: monitoring_integration_
   ============================================================ */
IF OBJECT_ID('dbo.monitoring_integration_status') IS NULL
BEGIN
    CREATE TABLE dbo.monitoring_integration_status (
        integration_request_id  BIGINT NOT NULL,
        status                  INT NULL,
        status_message          NVARCHAR(2000) NULL,
        content_type            NVARCHAR(1000) NULL,
        created_at_utc          DATETIME2(3) NOT NULL
            CONSTRAINT df_monitoring_integration_status_created_at_utc
            DEFAULT SYSUTCDATETIME(),
        updated_at_utc          DATETIME2(3) NULL,

        CONSTRAINT pk_monitoring_integration_status
            PRIMARY KEY CLUSTERED (integration_request_id),

        CONSTRAINT fk_monitoring_integration_status_request
            FOREIGN KEY (integration_request_id)
                REFERENCES dbo.monitoring_integration_request (id));

    /* ============================================================
       INDICI monitoring_integration_status
       ============================================================ */
    CREATE NONCLUSTERED INDEX ix_monitoring_integration_status_request_id
    ON dbo.monitoring_integration_status (integration_request_id);

    CREATE NONCLUSTERED INDEX ix_monitoring_integration_status_status_created_at
    ON dbo.monitoring_integration_status (status, created_at_utc DESC);
END
