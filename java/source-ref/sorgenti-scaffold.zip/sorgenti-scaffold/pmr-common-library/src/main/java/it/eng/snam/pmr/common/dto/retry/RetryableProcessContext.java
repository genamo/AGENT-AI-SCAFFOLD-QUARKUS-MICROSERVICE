package it.eng.snam.pmr.common.dto.retry;

import java.time.Duration;
import java.util.function.Predicate;

import it.eng.snam.pmr.common.functional.interfaces.ExceptionFactory;
import it.eng.snam.pmr.common.util.retry.RetryableProcessDomain;
import lombok.Value;

@Value(staticConstructor = "of")
public class RetryableProcessContext {

    String operationName;
    Predicate<Throwable> retryPredicate;
    ExceptionFactory exceptionFactory;
    Integer retryLimit;
    Duration retryDelay;

    public static RetryableProcessContext of(String operationName, ExceptionFactory exceptionFactory) {
        return new RetryableProcessContext(operationName, RetryableProcessDomain.RETRY_PREDICATE, exceptionFactory, RetryableProcessDomain.RETRY_LIMIT, RetryableProcessDomain.RETRY_DELAY);
    }

    public static RetryableProcessContext of(String operationName, Predicate<Throwable> retryPredicate, ExceptionFactory exceptionFactory) {
        return new RetryableProcessContext(operationName, retryPredicate, exceptionFactory, RetryableProcessDomain.RETRY_LIMIT, RetryableProcessDomain.RETRY_DELAY);
    }
}
