package it.eng.snam.pmr.common.response.swagger;

import java.io.Serial;
import java.util.List;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import it.eng.snam.pmr.common.response.GenericResponse;

@Schema(name = "StringListResponse")
public class LongListResponse extends GenericResponse<List<Long>> {
    @Serial
    private static final long serialVersionUID = 4795099629409323389L;
}
