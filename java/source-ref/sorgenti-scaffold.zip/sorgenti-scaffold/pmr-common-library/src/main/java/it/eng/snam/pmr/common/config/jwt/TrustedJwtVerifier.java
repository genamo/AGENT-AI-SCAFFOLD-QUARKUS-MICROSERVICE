package it.eng.snam.pmr.common.config.jwt;

import com.auth0.jwt.interfaces.JWTVerifier;

public record TrustedJwtVerifier(String providerName, String issuer, JWTVerifier verifier) {
}