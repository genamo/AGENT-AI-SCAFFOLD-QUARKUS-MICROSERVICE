package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Optional;

import org.jboss.logging.MDC;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.client.AnagraficheClient;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagAreaTecnicaDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagClientiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagMacroPoloDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagPoloDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagRaggruppamentiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagTipoStatoRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssAreaTecnicaDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRaggruppamentiRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiAopDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiClientiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiTipoBilancioTecnicoDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiTitolariDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssStatoRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.ContattoDto;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.B2BTokenUtils;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class AnagraficheServiceTest {

    private static final String AUTH = "Bearer test-token";

    @Mock
    AnagraficheClient anagraficheClient;

    @Mock
    ObjectMapper objectMapper;

    @Mock
    RequestHeadersContext headersCtx;

    @Mock
    B2BTokenUtils tokenUtil;

    @InjectMocks
    AnagraficheService service;

    @BeforeEach
    void injectAbstractDependencies() throws Exception {
        injectAbstractField("headersCtx", headersCtx);
        injectAbstractField("objectMapper", objectMapper);

        MDC.remove(AuthorizationUtils.JWT_AUTHZ);
        when(tokenUtil.generateSuperUserToken()).thenReturn(AUTH);
    }

    @AfterEach
    void tearDown() {
        MDC.remove(AuthorizationUtils.JWT_AUTHZ);
    }

    private void injectAbstractField(String fieldName, Object value) throws Exception {
        Field field = AbstractService.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(service, value);
    }

    private Response mockResp(int status) {
        Response r = mock(Response.class);
        when(r.getStatus()).thenReturn(status);
        return r;
    }

    private void mockHeadersForRemoteError() {
        when(headersCtx.getKeyLogic()).thenReturn("kl");
        when(headersCtx.getTransactionId()).thenReturn("tx");
        when(headersCtx.getProcessType()).thenReturn("PT");
    }

    // ---- DTO factory methods ----

    private static AnagAreaTecnicaDto areaDto() {
        return new AnagAreaTecnicaDto("C01", null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    }

    private static AnagClientiDto clienteDto() {
        return new AnagClientiDto("CLI01", null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null);
    }

    private static AnagMacroPoloDto macroPoloDto() {
        return new AnagMacroPoloDto("MP01", null, null, null, null);
    }

    private static AnagPoloDto poloDto() {
        return new AnagPoloDto("P01", null, null, "MP01", null, null, null);
    }

    private static AnagRaggruppamentiDto raggruppamentiDto() {
        return new AnagRaggruppamentiDto("3000120", "R01", null, null, null, null);
    }

    private static AnagRemiDto remiDto() {
        return new AnagRemiDto("REMI001", null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null, null);
    }

    private static AnagTipoStatoRemiDto tipoStatoRemiDto() {
        return new AnagTipoStatoRemiDto("S01", null, null, null, null);
    }

    private static AssAreaTecnicaDto assAreaTecnicaDto() {
        return new AssAreaTecnicaDto("AT01", null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    }

    private static AssRaggruppamentiRemiDto assRaggrDto() {
        return new AssRaggruppamentiRemiDto("REMI001", null, null, null, null);
    }

    private static AssRemiAopDto assRemiAopDto() {
        return new AssRemiAopDto(null, "REMI001", 20240101L, null, null, null, null, null, null, null);
    }

    private static AssRemiClientiDto assRemiClientiDto() {
        return new AssRemiClientiDto("REMI001", null, 20240101L, "CLI01", null, null, null, null, null);
    }

    private static AssRemiTipoBilancioTecnicoDto assTipoBilancioDto() {
        return new AssRemiTipoBilancioTecnicoDto("REMI001", null, 20240101L, null, null, null, null, null, null, null);
    }

    private static AssRemiTitolariDto assTitolariDto() {
        return new AssRemiTitolariDto("REMI001", null, 20240101L, "CLI01", null, null, null, null, null);
    }

    private static AssStatoRemiDto assStatoRemiDto() {
        return new AssStatoRemiDto("REMI001", null, "S01", null, null, null, null);
    }

    private static ContattoDto contattoDto() {
        return new ContattoDto(1, null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null);
    }

    // ==========================================================================
    // ANAG AREA TECNICA — copertura completa (rappresentativa di tutti i pattern)
    // ==========================================================================

    @Test
    void getAllAnagAreaTecnica_204_returnsEmpty() {
        Response r1_204 = mockResp(204);

        when(anagraficheClient.getAllAnagAreaTecnica(AUTH)).thenReturn(r1_204);
        assertTrue(service.getAllAnagAreaTecnica().isEmpty());
    }

    @Test
    void getAllAnagAreaTecnica_200_emptyJson_returnsEmpty() {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("");
        when(anagraficheClient.getAllAnagAreaTecnica(AUTH)).thenReturn(resp);
        assertTrue(service.getAllAnagAreaTecnica().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAllAnagAreaTecnica_200_validJson_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(anagraficheClient.getAllAnagAreaTecnica(AUTH)).thenReturn(resp);
        AnagAreaTecnicaDto dto = areaDto();
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(dto));
        List<AnagAreaTecnicaDto> result = service.getAllAnagAreaTecnica();
        assertEquals(1, result.size());
        assertEquals("C01", result.get(0).codiceArea());
    }

    @Test
    void getAllAnagAreaTecnica_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(anagraficheClient.getAllAnagAreaTecnica(AUTH)).thenReturn(resp);
        assertThrows(IllegalArgumentException.class, () -> service.getAllAnagAreaTecnica());
    }

    @Test
    void getAllAnagAreaTecnica_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(anagraficheClient.getAllAnagAreaTecnica(AUTH)).thenReturn(resp);
        mockHeadersForRemoteError();
        assertThrows(RemoteCallException.class, () -> service.getAllAnagAreaTecnica());
    }

    @Test
    void findAnagAreaTecnicaByCodiceArea_404_returnsEmpty() {
        Response r2_404 = mockResp(404);

        when(anagraficheClient.findAnagAreaTecnicaByCodiceArea(AUTH, "C01")).thenReturn(r2_404);
        assertTrue(service.findAnagAreaTecnicaByCodiceArea("C01").isEmpty());
    }

    @Test
    void findAnagAreaTecnicaByCodiceArea_200_returnsDto() {
        AnagAreaTecnicaDto dto = areaDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagAreaTecnicaDto.class)).thenReturn(dto);
        when(anagraficheClient.findAnagAreaTecnicaByCodiceArea(AUTH, "C01")).thenReturn(resp);
        Optional<AnagAreaTecnicaDto> result = service.findAnagAreaTecnicaByCodiceArea("C01");
        assertTrue(result.isPresent());
        assertEquals("C01", result.get().codiceArea());
    }

    @Test
    void findAnagAreaTecnicaByCodiceArea_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(anagraficheClient.findAnagAreaTecnicaByCodiceArea(AUTH, "C01")).thenReturn(resp);
        assertThrows(IllegalArgumentException.class, () -> service.findAnagAreaTecnicaByCodiceArea("C01"));
    }

    @Test
    void findAnagAreaTecnicaByCodiceArea_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(anagraficheClient.findAnagAreaTecnicaByCodiceArea(AUTH, "C01")).thenReturn(resp);
        mockHeadersForRemoteError();
        assertThrows(RemoteCallException.class, () -> service.findAnagAreaTecnicaByCodiceArea("C01"));
    }

    @Test
    void saveAnagAreaTecnica_200_returnsDto() {
        AnagAreaTecnicaDto dto = areaDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagAreaTecnicaDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAnagAreaTecnica(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAnagAreaTecnica(dto));
    }

    @Test
    void saveAnagAreaTecnica_201_returnsDto() {
        AnagAreaTecnicaDto dto = areaDto();
        Response resp = mockResp(201);
        when(resp.readEntity(AnagAreaTecnicaDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAnagAreaTecnica(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAnagAreaTecnica(dto));
    }

    @Test
    void saveAnagAreaTecnica_400_throwsIllegalArgument() {
        AnagAreaTecnicaDto dto = areaDto();
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(anagraficheClient.saveAnagAreaTecnica(AUTH, dto)).thenReturn(resp);
        assertThrows(IllegalArgumentException.class, () -> service.saveAnagAreaTecnica(dto));
    }

    @Test
    void saveAnagAreaTecnica_500_throwsRemoteCallException() {
        AnagAreaTecnicaDto dto = areaDto();
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(anagraficheClient.saveAnagAreaTecnica(AUTH, dto)).thenReturn(resp);
        mockHeadersForRemoteError();
        assertThrows(RemoteCallException.class, () -> service.saveAnagAreaTecnica(dto));
    }

    @Test
    void deleteAnagAreaTecnica_200_returnsDto() {
        AnagAreaTecnicaDto dto = areaDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagAreaTecnicaDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAnagAreaTecnica(AUTH, "C01")).thenReturn(resp);
        assertSame(dto, service.deleteAnagAreaTecnica("C01"));
    }

    @Test
    void deleteAnagAreaTecnica_400_throwsIllegalArgument() {
        Response resp = mockResp(400);
        when(resp.hasEntity()).thenReturn(false);
        when(anagraficheClient.deleteAnagAreaTecnica(AUTH, "C01")).thenReturn(resp);
        assertThrows(IllegalArgumentException.class, () -> service.deleteAnagAreaTecnica("C01"));
    }

    @Test
    void deleteAnagAreaTecnica_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(anagraficheClient.deleteAnagAreaTecnica(AUTH, "C01")).thenReturn(resp);
        mockHeadersForRemoteError();
        assertThrows(RemoteCallException.class, () -> service.deleteAnagAreaTecnica("C01"));
    }

    @Test
    void restoreAnagAreaTecnica_200_returnsDto() {
        AnagAreaTecnicaDto dto = areaDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagAreaTecnicaDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAnagAreaTecnica(AUTH, "C01")).thenReturn(resp);
        assertSame(dto, service.restoreAnagAreaTecnica("C01"));
    }

    @Test
    void restoreAnagAreaTecnica_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(anagraficheClient.restoreAnagAreaTecnica(AUTH, "C01")).thenReturn(resp);
        mockHeadersForRemoteError();
        assertThrows(RemoteCallException.class, () -> service.restoreAnagAreaTecnica("C01"));
    }

    // ==========================================================================
    // ANAG CLIENTI
    // ==========================================================================

    @Test
    void getAllAnagClienti_204_returnsEmpty() {
        Response r3_204 = mockResp(204);

        when(anagraficheClient.getAllAnagClienti(AUTH)).thenReturn(r3_204);
        assertTrue(service.getAllAnagClienti().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAllAnagClienti_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(anagraficheClient.getAllAnagClienti(AUTH)).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(clienteDto()));
        assertEquals(1, service.getAllAnagClienti().size());
    }

    @Test
    void getAllAnagClienti_500_throwsRemoteCallException() {
        Response resp = mockResp(500);
        when(resp.hasEntity()).thenReturn(false);
        when(anagraficheClient.getAllAnagClienti(AUTH)).thenReturn(resp);
        mockHeadersForRemoteError();
        assertThrows(RemoteCallException.class, () -> service.getAllAnagClienti());
    }

    @Test
    void findAnagClientiByCodiceCliente_404_returnsEmpty() {
        Response r4_404 = mockResp(404);

        when(anagraficheClient.findAnagClientiByCodiceCliente(AUTH, "CLI01")).thenReturn(r4_404);
        assertTrue(service.findAnagClientiByCodiceCliente("CLI01").isEmpty());
    }

    @Test
    void findAnagClientiByCodiceCliente_200_returnsDto() {
        AnagClientiDto dto = clienteDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagClientiDto.class)).thenReturn(dto);
        when(anagraficheClient.findAnagClientiByCodiceCliente(AUTH, "CLI01")).thenReturn(resp);
        assertTrue(service.findAnagClientiByCodiceCliente("CLI01").isPresent());
    }

    @Test
    void saveAnagClienti_200_returnsDto() {
        AnagClientiDto dto = clienteDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagClientiDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAnagClienti(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAnagClienti(dto));
    }

    @Test
    void saveAnagClienti_201_returnsDto() {
        AnagClientiDto dto = clienteDto();
        Response resp = mockResp(201);
        when(resp.readEntity(AnagClientiDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAnagClienti(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAnagClienti(dto));
    }

    @Test
    void deleteAnagClienti_200_returnsDto() {
        AnagClientiDto dto = clienteDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagClientiDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAnagClienti(AUTH, "CLI01")).thenReturn(resp);
        assertSame(dto, service.deleteAnagClienti("CLI01"));
    }

    @Test
    void restoreAnagClienti_200_returnsDto() {
        AnagClientiDto dto = clienteDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagClientiDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAnagClienti(AUTH, "CLI01")).thenReturn(resp);
        assertSame(dto, service.restoreAnagClienti("CLI01"));
    }

    // ==========================================================================
    // ANAG MACRO POLO
    // ==========================================================================

    @Test
    void getAllAnagMacroPolo_204_returnsEmpty() {
        Response r5_204 = mockResp(204);

        when(anagraficheClient.getAllAnagMacroPolo(AUTH)).thenReturn(r5_204);
        assertTrue(service.getAllAnagMacroPolo().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAllAnagMacroPolo_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(anagraficheClient.getAllAnagMacroPolo(AUTH)).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(macroPoloDto()));
        assertEquals(1, service.getAllAnagMacroPolo().size());
    }

    @Test
    void findAnagMacroPoloByCodiceMacroPolo_404_returnsEmpty() {
        Response r6_404 = mockResp(404);

        when(anagraficheClient.findAnagMacroPoloByCodiceMacroPolo(AUTH, "MP01")).thenReturn(r6_404);
        assertTrue(service.findAnagMacroPoloByCodiceMacroPolo("MP01").isEmpty());
    }

    @Test
    void findAnagMacroPoloByCodiceMacroPolo_200_returnsDto() {
        AnagMacroPoloDto dto = macroPoloDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagMacroPoloDto.class)).thenReturn(dto);
        when(anagraficheClient.findAnagMacroPoloByCodiceMacroPolo(AUTH, "MP01")).thenReturn(resp);
        assertTrue(service.findAnagMacroPoloByCodiceMacroPolo("MP01").isPresent());
    }

    @Test
    void saveAnagMacroPolo_200_returnsDto() {
        AnagMacroPoloDto dto = macroPoloDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagMacroPoloDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAnagMacroPolo(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAnagMacroPolo(dto));
    }

    @Test
    void deleteAnagMacroPolo_200_returnsDto() {
        AnagMacroPoloDto dto = macroPoloDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagMacroPoloDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAnagMacroPolo(AUTH, "MP01")).thenReturn(resp);
        assertSame(dto, service.deleteAnagMacroPolo("MP01"));
    }

    @Test
    void restoreAnagMacroPolo_200_returnsDto() {
        AnagMacroPoloDto dto = macroPoloDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagMacroPoloDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAnagMacroPolo(AUTH, "MP01")).thenReturn(resp);
        assertSame(dto, service.restoreAnagMacroPolo("MP01"));
    }

    // ==========================================================================
    // ANAG POLO (ha findByFk che restituisce List)
    // ==========================================================================

    @Test
    void getAllAnagPolo_204_returnsEmpty() {
        Response r7_204 = mockResp(204);

        when(anagraficheClient.getAllAnagPolo(AUTH)).thenReturn(r7_204);
        assertTrue(service.getAllAnagPolo().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAllAnagPolo_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(anagraficheClient.getAllAnagPolo(AUTH)).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(poloDto()));
        assertEquals(1, service.getAllAnagPolo().size());
    }

    @Test
    void findAnagPoloByCodicePolo_404_returnsEmpty() {
        Response r8_404 = mockResp(404);

        when(anagraficheClient.findAnagPoloByCodicePolo(AUTH, "P01")).thenReturn(r8_404);
        assertTrue(service.findAnagPoloByCodicePolo("P01").isEmpty());
    }

    @Test
    void findAnagPoloByCodicePolo_200_returnsDto() {
        AnagPoloDto dto = poloDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagPoloDto.class)).thenReturn(dto);
        when(anagraficheClient.findAnagPoloByCodicePolo(AUTH, "P01")).thenReturn(resp);
        assertTrue(service.findAnagPoloByCodicePolo("P01").isPresent());
    }

    @Test
    void findAnagPoloByCodiceMacroPolo_204_returnsEmpty() {
        Response r9_204 = mockResp(204);

        when(anagraficheClient.findAnagPoloByCodiceMacroPolo(AUTH, "MP01")).thenReturn(r9_204);
        assertTrue(service.findAnagPoloByCodiceMacroPolo("MP01").isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void findAnagPoloByCodiceMacroPolo_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(anagraficheClient.findAnagPoloByCodiceMacroPolo(AUTH, "MP01")).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(poloDto()));
        assertEquals(1, service.findAnagPoloByCodiceMacroPolo("MP01").size());
    }

    @Test
    void saveAnagPolo_200_returnsDto() {
        AnagPoloDto dto = poloDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagPoloDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAnagPolo(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAnagPolo(dto));
    }

    // ==========================================================================
    // ANAG RAGGRUPPAMENTI
    // ==========================================================================

    @Test
    void getAllAnagRaggruppamenti_204_returnsEmpty() {
        Response r10_204 = mockResp(204);

        when(anagraficheClient.getAllAnagRaggruppamenti(AUTH)).thenReturn(r10_204);
        assertTrue(service.getAllAnagRaggruppamenti().isEmpty());
    }

    @Test
    void findAnagRaggruppamentiByCodiceRaggrRemi_404_returnsEmpty() {
        Response r11_404 = mockResp(404);

        when(anagraficheClient.findAnagRaggruppamentiByCodiceRaggrRemi(AUTH, "R01")).thenReturn(r11_404);
        assertTrue(service.findAnagRaggruppamentiByCodiceRaggrRemi("R01").isEmpty());
    }

    @Test
    void findAnagRaggruppamentiByCodiceRaggrRemi_200_returnsDto() {
        AnagRaggruppamentiDto dto = raggruppamentiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagRaggruppamentiDto.class)).thenReturn(dto);
        when(anagraficheClient.findAnagRaggruppamentiByCodiceRaggrRemi(AUTH, "R01")).thenReturn(resp);
        assertTrue(service.findAnagRaggruppamentiByCodiceRaggrRemi("R01").isPresent());
    }

    @Test
    void saveAnagRaggruppamenti_200_returnsDto() {
        AnagRaggruppamentiDto dto = raggruppamentiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagRaggruppamentiDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAnagRaggruppamenti(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAnagRaggruppamenti(dto));
    }

    @Test
    void deleteAnagRaggruppamenti_200_returnsDto() {
        AnagRaggruppamentiDto dto = raggruppamentiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagRaggruppamentiDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAnagRaggruppamenti(AUTH, "R01")).thenReturn(resp);
        assertSame(dto, service.deleteAnagRaggruppamenti("R01"));
    }

    @Test
    void restoreAnagRaggruppamenti_200_returnsDto() {
        AnagRaggruppamentiDto dto = raggruppamentiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagRaggruppamentiDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAnagRaggruppamenti(AUTH, "R01")).thenReturn(resp);
        assertSame(dto, service.restoreAnagRaggruppamenti("R01"));
    }

    // ==========================================================================
    // ANAG REMI
    // ==========================================================================

    @Test
    void getAllAnagRemi_204_returnsEmpty() {
        Response r12_204 = mockResp(204);

        when(anagraficheClient.getAllAnagRemi(AUTH)).thenReturn(r12_204);
        assertTrue(service.getAllAnagRemi().isEmpty());
    }

    @Test
    void findAnagRemiByRemiAssoluto_404_returnsEmpty() {
        Response r13_404 = mockResp(404);

        when(anagraficheClient.findAnagRemiByRemiAssoluto(AUTH, "REMI001")).thenReturn(r13_404);
        assertTrue(service.findAnagRemiByRemiAssoluto("REMI001").isEmpty());
    }

    @Test
    void findAnagRemiByRemiAssoluto_200_returnsDto() {
        AnagRemiDto dto = remiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.findAnagRemiByRemiAssoluto(AUTH, "REMI001")).thenReturn(resp);
        assertTrue(service.findAnagRemiByRemiAssoluto("REMI001").isPresent());
    }

    @Test
    void saveAnagRemi_200_returnsDto() {
        AnagRemiDto dto = remiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAnagRemi(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAnagRemi(dto));
    }

    @Test
    void deleteAnagRemi_200_returnsDto() {
        AnagRemiDto dto = remiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAnagRemi(AUTH, "REMI001")).thenReturn(resp);
        assertSame(dto, service.deleteAnagRemi("REMI001"));
    }

    @Test
    void restoreAnagRemi_200_returnsDto() {
        AnagRemiDto dto = remiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAnagRemi(AUTH, "REMI001")).thenReturn(resp);
        assertSame(dto, service.restoreAnagRemi("REMI001"));
    }

    // ==========================================================================
    // ANAG TIPO STATO REMI
    // ==========================================================================

    @Test
    void getAllAnagTipoStatoRemi_204_returnsEmpty() {
        Response r14_204 = mockResp(204);

        when(anagraficheClient.getAllAnagTipoStatoRemi(AUTH)).thenReturn(r14_204);
        assertTrue(service.getAllAnagTipoStatoRemi().isEmpty());
    }

    @Test
    void findAnagTipoStatoRemiByCodiceStato_404_returnsEmpty() {
        Response r15_404 = mockResp(404);

        when(anagraficheClient.findAnagTipoStatoRemiByCodiceStato(AUTH, "S01")).thenReturn(r15_404);
        assertTrue(service.findAnagTipoStatoRemiByCodiceStato("S01").isEmpty());
    }

    @Test
    void findAnagTipoStatoRemiByCodiceStato_200_returnsDto() {
        AnagTipoStatoRemiDto dto = tipoStatoRemiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagTipoStatoRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.findAnagTipoStatoRemiByCodiceStato(AUTH, "S01")).thenReturn(resp);
        assertTrue(service.findAnagTipoStatoRemiByCodiceStato("S01").isPresent());
    }

    @Test
    void saveAnagTipoStatoRemi_200_returnsDto() {
        AnagTipoStatoRemiDto dto = tipoStatoRemiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagTipoStatoRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAnagTipoStatoRemi(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAnagTipoStatoRemi(dto));
    }

    @Test
    void deleteAnagTipoStatoRemi_200_returnsDto() {
        AnagTipoStatoRemiDto dto = tipoStatoRemiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagTipoStatoRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAnagTipoStatoRemi(AUTH, "S01")).thenReturn(resp);
        assertSame(dto, service.deleteAnagTipoStatoRemi("S01"));
    }

    @Test
    void restoreAnagTipoStatoRemi_200_returnsDto() {
        AnagTipoStatoRemiDto dto = tipoStatoRemiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AnagTipoStatoRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAnagTipoStatoRemi(AUTH, "S01")).thenReturn(resp);
        assertSame(dto, service.restoreAnagTipoStatoRemi("S01"));
    }

    // ==========================================================================
    // ASS AREA TECNICA
    // ==========================================================================

    @Test
    void getAllAssAreaTecnica_204_returnsEmpty() {
        Response r16_204 = mockResp(204);

        when(anagraficheClient.getAllAssAreaTecnica(AUTH)).thenReturn(r16_204);
        assertTrue(service.getAllAssAreaTecnica().isEmpty());
    }

    @Test
    void findAssAreaTecnicaByCodiceAreaTecnica_404_returnsEmpty() {
        Response r17_404 = mockResp(404);

        when(anagraficheClient.findAssAreaTecnicaByCodiceAreaTecnica(AUTH, "AT01")).thenReturn(r17_404);
        assertTrue(service.findAssAreaTecnicaByCodiceAreaTecnica("AT01").isEmpty());
    }

    @Test
    void findAssAreaTecnicaByCodiceAreaTecnica_200_returnsDto() {
        AssAreaTecnicaDto dto = assAreaTecnicaDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssAreaTecnicaDto.class)).thenReturn(dto);
        when(anagraficheClient.findAssAreaTecnicaByCodiceAreaTecnica(AUTH, "AT01")).thenReturn(resp);
        assertTrue(service.findAssAreaTecnicaByCodiceAreaTecnica("AT01").isPresent());
    }

    @Test
    void saveAssAreaTecnica_200_returnsDto() {
        AssAreaTecnicaDto dto = assAreaTecnicaDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssAreaTecnicaDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAssAreaTecnica(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAssAreaTecnica(dto));
    }

    @Test
    void deleteAssAreaTecnica_200_returnsDto() {
        AssAreaTecnicaDto dto = assAreaTecnicaDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssAreaTecnicaDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAssAreaTecnica(AUTH, "AT01")).thenReturn(resp);
        assertSame(dto, service.deleteAssAreaTecnica("AT01"));
    }

    @Test
    void restoreAssAreaTecnica_200_returnsDto() {
        AssAreaTecnicaDto dto = assAreaTecnicaDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssAreaTecnicaDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAssAreaTecnica(AUTH, "AT01")).thenReturn(resp);
        assertSame(dto, service.restoreAssAreaTecnica("AT01"));
    }

    // ==========================================================================
    // ASS RAGGRUPPAMENTI REMI
    // ==========================================================================

    @Test
    void getAllAssRaggruppamentiRemi_204_returnsEmpty() {
        Response r18_204 = mockResp(204);

        when(anagraficheClient.getAllAssRaggruppamentiRemi(AUTH)).thenReturn(r18_204);
        assertTrue(service.getAllAssRaggruppamentiRemi().isEmpty());
    }

    @Test
    void findAssRaggruppamentiRemiByRemiAssoluto_404_returnsEmpty() {
        Response r19_404 = mockResp(404);

        when(anagraficheClient.findAssRaggruppamentiRemiByRemiAssoluto(AUTH, "REMI001")).thenReturn(r19_404);
        assertTrue(service.findAssRaggruppamentiRemiByRemiAssoluto("REMI001").isEmpty());
    }

    @Test
    void findAssRaggruppamentiRemiByRemiAssoluto_200_returnsDto() {
        AssRaggruppamentiRemiDto dto = assRaggrDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRaggruppamentiRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.findAssRaggruppamentiRemiByRemiAssoluto(AUTH, "REMI001")).thenReturn(resp);
        assertTrue(service.findAssRaggruppamentiRemiByRemiAssoluto("REMI001").isPresent());
    }

    @Test
    void saveAssRaggruppamentiRemi_200_returnsDto() {
        AssRaggruppamentiRemiDto dto = assRaggrDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRaggruppamentiRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAssRaggruppamentiRemi(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAssRaggruppamentiRemi(dto));
    }

    @Test
    void deleteAssRaggruppamentiRemi_200_returnsDto() {
        AssRaggruppamentiRemiDto dto = assRaggrDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRaggruppamentiRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAssRaggruppamentiRemi(AUTH, "REMI001", "")).thenReturn(resp);
        assertSame(dto, service.deleteAssRaggruppamentiRemi("REMI001", ""));
    }

    @Test
    void restoreAssRaggruppamentiRemi_200_returnsDto() {
        AssRaggruppamentiRemiDto dto = assRaggrDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRaggruppamentiRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAssRaggruppamentiRemi(AUTH, "REMI001")).thenReturn(resp);
        assertSame(dto, service.restoreAssRaggruppamentiRemi("REMI001"));
    }

    // ==========================================================================
    // ASS REMI AOP (PK composita: Long codiceAop, String remiAssoluto, Integer dataInizioAopInt)
    // ==========================================================================

    @Test
    void getAllAssRemiAop_204_returnsEmpty() {
        Response r20_204 = mockResp(204);

        when(anagraficheClient.getAllAssRemiAop(AUTH)).thenReturn(r20_204);
        assertTrue(service.getAllAssRemiAop().isEmpty());
    }

    @Test
    void findAssRemiAopByRemiAssoluto_204_returnsEmpty() {
        Response r21_204 = mockResp(204);

        when(anagraficheClient.findAssRemiAopByRemiAssoluto(AUTH, "REMI001")).thenReturn(r21_204);
        assertTrue(service.findAssRemiAopByRemiAssoluto("REMI001").isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void findAssRemiAopByRemiAssoluto_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(anagraficheClient.findAssRemiAopByRemiAssoluto(AUTH, "REMI001")).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(assRemiAopDto()));
        assertEquals(1, service.findAssRemiAopByRemiAssoluto("REMI001").size());
    }

    @Test
    void findAssRemiAopByPk_404_returnsEmpty() {
        Response r22_404 = mockResp(404);

        when(anagraficheClient.findAssRemiAopByPk(AUTH, 99L, "REMI001", 20240101L)).thenReturn(r22_404);
        assertTrue(service.findAssRemiAopByPk(99L, "REMI001", 20240101L).isEmpty());
    }

    @Test
    void findAssRemiAopByPk_200_returnsDto() {
        AssRemiAopDto dto = assRemiAopDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiAopDto.class)).thenReturn(dto);
        when(anagraficheClient.findAssRemiAopByPk(AUTH, 99L, "REMI001", 20240101L)).thenReturn(resp);
        assertTrue(service.findAssRemiAopByPk(99L, "REMI001", 20240101L).isPresent());
    }

    @Test
    void saveAssRemiAop_200_returnsDto() {
        AssRemiAopDto dto = assRemiAopDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiAopDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAssRemiAop(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAssRemiAop(dto));
    }

    @Test
    void deleteAssRemiAop_200_returnsDto() {
        AssRemiAopDto dto = assRemiAopDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiAopDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAssRemiAop(AUTH, 99L, "REMI001", 20240101L)).thenReturn(resp);
        assertSame(dto, service.deleteAssRemiAop(99L, "REMI001", 20240101L));
    }

    @Test
    void restoreAssRemiAop_200_returnsDto() {
        AssRemiAopDto dto = assRemiAopDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiAopDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAssRemiAop(AUTH, 99L, "REMI001", 20240101L)).thenReturn(resp);
        assertSame(dto, service.restoreAssRemiAop(99L, "REMI001", 20240101L));
    }

    // ==========================================================================
    // ASS REMI CLIENTI
    // ==========================================================================

    @Test
    void saveAssRemiClienti_200_returnsDto() {
        AssRemiClientiDto dto = assRemiClientiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiClientiDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAssRemiClienti(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAssRemiClienti(dto));
    }

    @Test
    void saveAssRemiClienti_201_returnsDto() {
        AssRemiClientiDto dto = assRemiClientiDto();
        Response resp = mockResp(201);
        when(resp.readEntity(AssRemiClientiDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAssRemiClienti(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAssRemiClienti(dto));
    }

    // ==========================================================================
    // ASS REMI TIPO BILANCIO TECNICO (PK composita: String remiAssoluto, Integer dataInizioInt)
    // ==========================================================================

    @Test
    void getAllAssRemiTipoBilancioTecnico_204_returnsEmpty() {
        Response r23_204 = mockResp(204);

        when(anagraficheClient.getAllAssRemiTipoBilancioTecnico(AUTH)).thenReturn(r23_204);
        assertTrue(service.getAllAssRemiTipoBilancioTecnico().isEmpty());
    }

    @Test
    void findAssRemiTipoBilancioTecnicoByPk_404_returnsEmpty() {
        Response r24_404 = mockResp(404);

        when(anagraficheClient.findAssRemiTipoBilancioTecnicoByPk(AUTH, "REMI001", 20240101L)).thenReturn(r24_404);
        assertTrue(service.findAssRemiTipoBilancioTecnicoByPk("REMI001", 20240101L).isEmpty());
    }

    @Test
    void findAssRemiTipoBilancioTecnicoByPk_200_returnsDto() {
        AssRemiTipoBilancioTecnicoDto dto = assTipoBilancioDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiTipoBilancioTecnicoDto.class)).thenReturn(dto);
        when(anagraficheClient.findAssRemiTipoBilancioTecnicoByPk(AUTH, "REMI001", 20240101L)).thenReturn(resp);
        assertTrue(service.findAssRemiTipoBilancioTecnicoByPk("REMI001", 20240101L).isPresent());
    }

    @Test
    void saveAssRemiTipoBilancioTecnico_200_returnsDto() {
        AssRemiTipoBilancioTecnicoDto dto = assTipoBilancioDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiTipoBilancioTecnicoDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAssRemiTipoBilancioTecnico(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAssRemiTipoBilancioTecnico(dto));
    }

    @Test
    void deleteAssRemiTipoBilancioTecnico_200_returnsDto() {
        AssRemiTipoBilancioTecnicoDto dto = assTipoBilancioDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiTipoBilancioTecnicoDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAssRemiTipoBilancioTecnico(AUTH, "REMI001", 20240101L)).thenReturn(resp);
        assertSame(dto, service.deleteAssRemiTipoBilancioTecnico("REMI001", 20240101L));
    }

    @Test
    void restoreAssRemiTipoBilancioTecnico_200_returnsDto() {
        AssRemiTipoBilancioTecnicoDto dto = assTipoBilancioDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiTipoBilancioTecnicoDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAssRemiTipoBilancioTecnico(AUTH, "REMI001", 20240101L)).thenReturn(resp);
        assertSame(dto, service.restoreAssRemiTipoBilancioTecnico("REMI001", 20240101L));
    }

    // ==========================================================================
    // ASS REMI TITOLARI (PK composita: String remiAssoluto, Integer dataInizioValiditaInt)
    // ==========================================================================

    @Test
    void getAllAssRemiTitolari_204_returnsEmpty() {
        Response r25_204 = mockResp(204);

        when(anagraficheClient.getAllAssRemiTitolari(AUTH)).thenReturn(r25_204);
        assertTrue(service.getAllAssRemiTitolari().isEmpty());
    }

    @Test
    void findAssRemiTitolariByCodiceCliente_204_returnsEmpty() {
        Response r26_204 = mockResp(204);

        when(anagraficheClient.findAssRemiTitolariByCodiceCliente(AUTH, "CLI01")).thenReturn(r26_204);
        assertTrue(service.findAssRemiTitolariByCodiceCliente("CLI01").isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void findAssRemiTitolariByCodiceCliente_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(anagraficheClient.findAssRemiTitolariByCodiceCliente(AUTH, "CLI01")).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(assTitolariDto()));
        assertEquals(1, service.findAssRemiTitolariByCodiceCliente("CLI01").size());
    }

    @Test
    void findAssRemiTitolariByPk_404_returnsEmpty() {
        Response r27_404 = mockResp(404);

        when(anagraficheClient.findAssRemiTitolariByPk(AUTH, "REMI001", 20240101L)).thenReturn(r27_404);
        assertTrue(service.findAssRemiTitolariByPk("REMI001", 20240101L).isEmpty());
    }

    @Test
    void findAssRemiTitolariByPk_200_returnsDto() {
        AssRemiTitolariDto dto = assTitolariDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiTitolariDto.class)).thenReturn(dto);
        when(anagraficheClient.findAssRemiTitolariByPk(AUTH, "REMI001", 20240101L)).thenReturn(resp);
        assertTrue(service.findAssRemiTitolariByPk("REMI001", 20240101L).isPresent());
    }

    @Test
    void saveAssRemiTitolari_200_returnsDto() {
        AssRemiTitolariDto dto = assTitolariDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiTitolariDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAssRemiTitolari(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAssRemiTitolari(dto));
    }

    @Test
    void deleteAssRemiTitolari_200_returnsDto() {
        AssRemiTitolariDto dto = assTitolariDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiTitolariDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAssRemiTitolari(AUTH, "REMI001", 20240101L)).thenReturn(resp);
        assertSame(dto, service.deleteAssRemiTitolari("REMI001", 20240101L));
    }

    @Test
    void restoreAssRemiTitolari_200_returnsDto() {
        AssRemiTitolariDto dto = assTitolariDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssRemiTitolariDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAssRemiTitolari(AUTH, "REMI001", 20240101L)).thenReturn(resp);
        assertSame(dto, service.restoreAssRemiTitolari("REMI001", 20240101L));
    }

    // ==========================================================================
    // ASS STATO REMI (PK composita: String remiAssoluto, String dataEvento)
    // ==========================================================================

    @Test
    void getAllAssStatoRemi_204_returnsEmpty() {
        Response r28_204 = mockResp(204);

        when(anagraficheClient.getAllAssStatoRemi(AUTH)).thenReturn(r28_204);
        assertTrue(service.getAllAssStatoRemi().isEmpty());
    }

    @Test
    void findAssStatoRemiByRemiAssoluto_204_returnsEmpty() {
        Response r29_204 = mockResp(204);

        when(anagraficheClient.findAssStatoRemiByRemiAssoluto(AUTH, "REMI001")).thenReturn(r29_204);
        assertTrue(service.findAssStatoRemiByRemiAssoluto("REMI001").isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void findAssStatoRemiByRemiAssoluto_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(anagraficheClient.findAssStatoRemiByRemiAssoluto(AUTH, "REMI001")).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(assStatoRemiDto()));
        assertEquals(1, service.findAssStatoRemiByRemiAssoluto("REMI001").size());
    }

    @Test
    void findAssStatoRemiByRemiAssolutoAndDataEvento_404_returnsEmpty() {
        Response r404 = mockResp(404);
        when(anagraficheClient.findAssStatoRemiByRemiAssolutoAndDataEvento(AUTH, "REMI001", "2024-01-01"))
                .thenReturn(r404);
        assertTrue(service.findAssStatoRemiByRemiAssolutoAndDataEvento("REMI001", "2024-01-01").isEmpty());
    }

    @Test
    void findAssStatoRemiByRemiAssolutoAndDataEvento_200_returnsDto() {
        AssStatoRemiDto dto = assStatoRemiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssStatoRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.findAssStatoRemiByRemiAssolutoAndDataEvento(AUTH, "REMI001", "2024-01-01")).thenReturn(resp);
        assertTrue(service.findAssStatoRemiByRemiAssolutoAndDataEvento("REMI001", "2024-01-01").isPresent());
    }

    @Test
    void saveAssStatoRemi_200_returnsDto() {
        AssStatoRemiDto dto = assStatoRemiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssStatoRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.saveAssStatoRemi(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveAssStatoRemi(dto));
    }

    @Test
    void deleteAssStatoRemi_200_returnsDto() {
        AssStatoRemiDto dto = assStatoRemiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssStatoRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteAssStatoRemi(AUTH, "REMI001", "2024-01-01")).thenReturn(resp);
        assertSame(dto, service.deleteAssStatoRemi("REMI001", "2024-01-01"));
    }

    @Test
    void restoreAssStatoRemi_200_returnsDto() {
        AssStatoRemiDto dto = assStatoRemiDto();
        Response resp = mockResp(200);
        when(resp.readEntity(AssStatoRemiDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreAssStatoRemi(AUTH, "REMI001", "2024-01-01")).thenReturn(resp);
        assertSame(dto, service.restoreAssStatoRemi("REMI001", "2024-01-01"));
    }

    // ==========================================================================
    // CONTATTO (PK Integer)
    // ==========================================================================

    @Test
    void getAllContatto_204_returnsEmpty() {
        Response r30_204 = mockResp(204);

        when(anagraficheClient.getAllContatto(AUTH)).thenReturn(r30_204);
        assertTrue(service.getAllContatto().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void getAllContatto_200_returnsList() throws Exception {
        Response resp = mockResp(200);
        when(resp.readEntity(String.class)).thenReturn("[{}]");
        when(anagraficheClient.getAllContatto(AUTH)).thenReturn(resp);
        when(objectMapper.readValue(eq("[{}]"), any(TypeReference.class))).thenReturn(List.of(contattoDto()));
        assertEquals(1, service.getAllContatto().size());
    }

    @Test
    void findContattoByIdContatto_404_returnsEmpty() {
        Response r31_404 = mockResp(404);

        when(anagraficheClient.findContattoByIdContatto(AUTH, 1)).thenReturn(r31_404);
        assertTrue(service.findContattoByIdContatto(1).isEmpty());
    }

    @Test
    void findContattoByIdContatto_200_returnsDto() {
        ContattoDto dto = contattoDto();
        Response resp = mockResp(200);
        when(resp.readEntity(ContattoDto.class)).thenReturn(dto);
        when(anagraficheClient.findContattoByIdContatto(AUTH, 1)).thenReturn(resp);
        assertTrue(service.findContattoByIdContatto(1).isPresent());
    }

    @Test
    void saveContatto_200_returnsDto() {
        ContattoDto dto = contattoDto();
        Response resp = mockResp(200);
        when(resp.readEntity(ContattoDto.class)).thenReturn(dto);
        when(anagraficheClient.saveContatto(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveContatto(dto));
    }

    @Test
    void saveContatto_201_returnsDto() {
        ContattoDto dto = contattoDto();
        Response resp = mockResp(201);
        when(resp.readEntity(ContattoDto.class)).thenReturn(dto);
        when(anagraficheClient.saveContatto(AUTH, dto)).thenReturn(resp);
        assertSame(dto, service.saveContatto(dto));
    }

    @Test
    void deleteContatto_200_returnsDto() {
        ContattoDto dto = contattoDto();
        Response resp = mockResp(200);
        when(resp.readEntity(ContattoDto.class)).thenReturn(dto);
        when(anagraficheClient.deleteContatto(AUTH, 1)).thenReturn(resp);
        assertSame(dto, service.deleteContatto(1));
    }

    @Test
    void restoreContatto_200_returnsDto() {
        ContattoDto dto = contattoDto();
        Response resp = mockResp(200);
        when(resp.readEntity(ContattoDto.class)).thenReturn(dto);
        when(anagraficheClient.restoreContatto(AUTH, 1)).thenReturn(resp);
        assertSame(dto, service.restoreContatto(1));
    }
}
