package it.eng.snam.pmr.batchintegrazionedg.service;

import java.util.List;
import java.util.Optional;

import org.jboss.logging.Logger;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.domain.MonitoringFlussi;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringFlussiDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringFlussiSearchDTO;
import it.eng.snam.pmr.batchintegrazionedg.mapper.MonitoringFlussiMapper;
import it.eng.snam.pmr.batchintegrazionedg.repository.MonitoringFlussiRepository;
import it.eng.snam.pmr.batchintegrazionedg.service.abstracts.AbstractMonitoringCrudService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.transaction.Transactional.TxType;

@ApplicationScoped
@RunOnVirtualThread
public class MonitoringFlussiService
        extends AbstractMonitoringCrudService<MonitoringFlussiDTO, MonitoringFlussi, MonitoringFlussiSearchDTO> {

    private static final Logger LOG = Logger.getLogger(MonitoringFlussiService.class);

    @Inject
    MonitoringFlussiRepository repository;

    @Inject
    MonitoringFlussiMapper mapper;

    @Override
    protected List<MonitoringFlussi> listAllEntities() {
        return repository.listAll();
    }

    @Override
    protected MonitoringFlussi findEntityById(Long id) {
        return repository.findById(id);
    }

    @Override
    protected Optional<MonitoringFlussi> findEntityByTransactionId(String transactionId) {
        return repository.findByTransactionId(transactionId);
    }

    @Override
    protected List<MonitoringFlussi> findLastExecutionsEntities(int limit) {
        return repository.findLastExecutionsNoLock(limit);
    }

    @Override
    protected List<MonitoringFlussi> findByPeriodEntities(Integer monthNumber, Integer dayNumber) {
        return repository.findByPeriod(monthNumber, dayNumber);
    }

    @Override
    protected List<MonitoringFlussi> findByCustomSearchEntities(MonitoringFlussiSearchDTO search) {
        return repository.findByCustomSearchReadUncommitted(search);
    }

    @Override
    protected List<MonitoringFlussiDTO> toDtoList(List<MonitoringFlussi> entities) {
        return mapper.toDtoList(entities);
    }

    @Override
    protected MonitoringFlussiDTO toDto(MonitoringFlussi entity) {
        return mapper.toDto(entity);
    }

    @Transactional(TxType.REQUIRES_NEW)
    @Override
    protected MonitoringFlussiDTO saveAttempt(MonitoringFlussiDTO dto) {
        Optional<MonitoringFlussi> existing = repository.findByTransactionId(dto.transactionId());

        MonitoringFlussi entityToSave;

        if (existing.isPresent()) {
            entityToSave = existing.get();
            mapper.updateEntityFromDto(dto, entityToSave);
            repository.flush();
        } else {
            entityToSave = mapper.toEntity(dto);
            repository.persistAndFlush(entityToSave);
        }

        return mapper.toDto(entityToSave);
    }

    public void processSaveMonitoringFlussi(String payload) {
        processPayload(payload, MonitoringFlussiDTO.class, "Error processing message");
    }

    @Override
    protected Logger logger() {
        return LOG;
    }

    @Override
    protected String transactionIdOf(MonitoringFlussiDTO request) {
        return request == null ? null : request.transactionId();
    }

    @Override
    protected MonitoringFlussiDTO fallbackError(MonitoringFlussiDTO request, String reason) {
        if (request == null) {
            return MonitoringFlussiDTO.builder()
                    .statusDescription("ERROR_" + reason)
                    .isDeleted(0)
                    .build();
        }

        return request.toBuilder()
                .statusDescription("ERROR_" + reason)
                .isDeleted(request.isDeleted() == null ? 0 : request.isDeleted())
                .build();
    }

    @Override
    protected String interruptedRetryLogMessage() {
        return "Retry DB MonitoringFlussi interrotto";
    }
}
