package it.eng.snam.pmr.batchintegrazionedg.entity;

import java.time.LocalDateTime;
import java.util.Objects;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity
@ToString
@Table(name = "monitoring_integration_request", schema = "dbo")
public class MonitoringIntegrationRequest extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "transaction_id", nullable = false, length = 100)
    private String transactionId;

    @Column(name = "user_id", nullable = false, length = 100)
    private String userId;

    @Column(name = "integration_type", length = 100)
    private String integrationType;

    @CreationTimestamp
    @Column(name = "created_at_utc", nullable = false)
    private LocalDateTime createdAtUtc;

    @UpdateTimestamp
    @Column(name = "updated_at_utc")
    private LocalDateTime updatedAtUtc;

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass())
            return false;
        MonitoringIntegrationRequest that = (MonitoringIntegrationRequest) o;
        return Objects.equals(getId(), that.getId()) && Objects.equals(getTransactionId(), that.getTransactionId())
               && Objects.equals(getUserId(), that.getUserId()) && Objects.equals(getIntegrationType(), that.getIntegrationType())
               && Objects.equals(getCreatedAtUtc(), that.getCreatedAtUtc()) && Objects.equals(getUpdatedAtUtc(), that.getUpdatedAtUtc());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getTransactionId(), getUserId(), getIntegrationType(), getCreatedAtUtc(), getUpdatedAtUtc());
    }
}
