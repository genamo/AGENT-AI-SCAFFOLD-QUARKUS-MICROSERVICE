package it.eng.snam.pmr.batchintegrazionedg.test.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazionedg.domain.IntegrazioneParametriSistema;
import it.eng.snam.pmr.batchintegrazionedg.dto.IntegrazioneParametriSistemaDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.ParametriSistemaRequestSearch;
import it.eng.snam.pmr.batchintegrazionedg.mapper.IntegrazioneParametriSistemaMapper;
import it.eng.snam.pmr.batchintegrazionedg.repository.ParametriSistemaRepository;
import it.eng.snam.pmr.batchintegrazionedg.service.ParametriService;

@ExtendWith(MockitoExtension.class)
class ParametriServiceTest {

    @Mock
    IntegrazioneParametriSistemaMapper mapper;

    @Mock
    ParametriSistemaRepository repository;

    @InjectMocks
    ParametriService service;

    private IntegrazioneParametriSistema buildEntity() {
        IntegrazioneParametriSistema e = new IntegrazioneParametriSistema();
        e.setId(1L);
        e.setCodice("PARAM_001");
        e.setValore("valore");
        e.setDataInizio(LocalDate.now().minusDays(30));
        e.setDataFine(LocalDate.now().plusDays(30));
        e.setIsDeleted(0);
        return e;
    }

    private IntegrazioneParametriSistemaDTO buildDto() {
        return new IntegrazioneParametriSistemaDTO(1L, "PARAM_001", "valore",
                LocalDate.now().minusDays(30), LocalDate.now().plusDays(30),
                null, null, 0);
    }

    @Test
    void search_withDataRiferimento_usesProvidedDate() {
        LocalDate dataRif = LocalDate.of(2026, 5, 22);
        ParametriSistemaRequestSearch request = new ParametriSistemaRequestSearch(dataRif, List.of("PARAM_001"));
        IntegrazioneParametriSistema entity = buildEntity();
        IntegrazioneParametriSistemaDTO dto = buildDto();

        when(repository.findParametriSistema(dataRif, List.of("PARAM_001"))).thenReturn(List.of(entity));
        when(mapper.toDtoList(List.of(entity))).thenReturn(List.of(dto));

        List<IntegrazioneParametriSistemaDTO> result = service.search(request);

        assertEquals(1, result.size());
        assertEquals("PARAM_001", result.get(0).codice());
    }

    @Test
    void search_withNullDataRiferimento_usesToday() {
        ParametriSistemaRequestSearch request = new ParametriSistemaRequestSearch(null, List.of("PARAM_001"));

        when(repository.findParametriSistema(any(LocalDate.class), eq(List.of("PARAM_001"))))
                .thenReturn(List.of());
        when(mapper.toDtoList(List.of())).thenReturn(List.of());

        List<IntegrazioneParametriSistemaDTO> result = service.search(request);

        assertNotNull(result);
        verify(repository).findParametriSistema(argThat(d -> !d.isAfter(LocalDate.now())),
                eq(List.of("PARAM_001")));
    }

    @Test
    void search_withNullCodici_returnsAll() {
        ParametriSistemaRequestSearch request = new ParametriSistemaRequestSearch(LocalDate.now(), null);
        when(repository.findParametriSistema(any(), isNull())).thenReturn(List.of());
        when(mapper.toDtoList(List.of())).thenReturn(List.of());

        List<IntegrazioneParametriSistemaDTO> result = service.search(request);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void search_withMultipleCodici_returnsMatchingList() {
        List<String> codici = List.of("PARAM_001", "PARAM_002");
        ParametriSistemaRequestSearch request = new ParametriSistemaRequestSearch(LocalDate.now(), codici);
        IntegrazioneParametriSistemaDTO dto = buildDto();

        when(repository.findParametriSistema(any(), eq(codici))).thenReturn(List.of(buildEntity()));
        when(mapper.toDtoList(anyList())).thenReturn(List.of(dto, dto));

        List<IntegrazioneParametriSistemaDTO> result = service.search(request);
        assertEquals(2, result.size());
    }
}
