package it.eng.snam.pmr.common.util.mdc;

import java.nio.charset.StandardCharsets;

import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.slf4j.MDC;

import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CommonConstants;
import lombok.experimental.UtilityClass;

@UtilityClass
public class MdcManager {

    public void clear() {
        MDC.clear();
    }

    public String getHeader(String key) {
        return MDC.get(key);
    }

    public void putHeader(String key, String value) {
        MDC.put(key, value);
    }

    public void putKafkaHeaders(Headers headers) {
        MDC.put(CommonConstants.LogParams.TN, extractHeader(headers, CommonConstants.KafkaHeaders.TRANSACTION_ID));
        MDC.put(CommonConstants.LogParams.KL, extractHeader(headers, CommonConstants.KafkaHeaders.KEYLOGIC));
        MDC.put(CommonConstants.LogParams.PT, extractHeader(headers, CommonConstants.KafkaHeaders.PROCESS_TYPE));
        MDC.put(CommonConstants.LogParams.MK, extractHeader(headers, CommonConstants.KafkaHeaders.MESSAGE_KEY));
        MDC.put(CommonConstants.LogParams.FT, extractHeader(headers, CommonConstants.KafkaHeaders.FLOW_TYPE));
        MDC.put(CommonConstants.LogParams.KT, extractHeader(headers, CommonConstants.KafkaHeaders.TOPIC));
        MDC.put(AuthorizationUtils.USER_ID, extractHeader(headers, CommonConstants.KafkaHeaders.USER_ID));
    }

    private String extractHeader(Headers headers, String name) {
        if (headers == null)
            return "";
        Header header = headers.lastHeader(name);
        return header != null ? new String(header.value(), StandardCharsets.UTF_8) : "";
    }
}
