package it.eng.snam.pmr.batchintegrazione.dto.datiprimari;

import java.time.LocalDateTime;

public record AnalisiQualitaGasGiornSearchDto(
        String remiAssoluto,
        LocalDateTime dataIniAnalisi
) {}
