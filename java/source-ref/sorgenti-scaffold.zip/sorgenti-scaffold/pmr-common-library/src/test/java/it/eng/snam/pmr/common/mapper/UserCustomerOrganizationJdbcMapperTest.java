package it.eng.snam.pmr.common.mapper;

import it.eng.snam.pmr.common.dto.UserCustomerOrganizationDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserCustomerOrganizationJdbcMapperTest {

    @Mock
    ResultSet rs;

    @Test
    void map_allFieldsSet_mapsCorrectly() throws SQLException {
        Instant now = Instant.parse("2024-06-15T10:00:00Z");
        Timestamp ts = Timestamp.from(now);

        when(rs.getObject("OrganizationId")).thenReturn(10L);
        when(rs.getObject("OrganizationCode")).thenReturn(200L);
        when(rs.getString("RoleDescription")).thenReturn("Admin");
        when(rs.getObject("FlowId")).thenReturn(3L);
        when(rs.getObject("EntityId")).thenReturn(4L);
        when(rs.getTimestamp("Datastamp")).thenReturn(ts);
        when(rs.getString("CustomerOrganizationCode")).thenReturn("ORG001");
        when(rs.getString("TelephoneNumber")).thenReturn("0123456789");
        when(rs.getString("UserCode")).thenReturn("USR001");
        when(rs.getObject("UserCustomerOrganizationId")).thenReturn(99L);
        when(rs.getString("PositionDescription")).thenReturn("Director");
        when(rs.getString("UserTypeDescription")).thenReturn("Internal");
        when(rs.getString("PkSource")).thenReturn("SRC");
        when(rs.getObject("Denominatore")).thenReturn(1);
        when(rs.getObject("Penalita")).thenReturn(0);
        when(rs.getString("IdErrore")).thenReturn(null);
        when(rs.getString("UserTypeCode")).thenReturn("INT");
        when(rs.getString("UserDescription")).thenReturn("User Desc");
        when(rs.getObject("CancelledFlag")).thenReturn(0);

        UserCustomerOrganizationDTO dto = UserCustomerOrganizationJdbcMapper.map(rs);

        assertThat(dto.organizationId()).isEqualTo(10L);
        assertThat(dto.organizationCode()).isEqualTo(200L);
        assertThat(dto.roleDescription()).isEqualTo("Admin");
        assertThat(dto.flowId()).isEqualTo(3L);
        assertThat(dto.entityId()).isEqualTo(4L);
        assertThat(dto.datastamp()).isEqualTo(now);
        assertThat(dto.customerOrganizationCode()).isEqualTo("ORG001");
        assertThat(dto.telephoneNumber()).isEqualTo("0123456789");
        assertThat(dto.userCode()).isEqualTo("USR001");
        assertThat(dto.userCustomerOrganizationId()).isEqualTo(99L);
        assertThat(dto.positionDescription()).isEqualTo("Director");
        assertThat(dto.userTypeDescription()).isEqualTo("Internal");
        assertThat(dto.pkSource()).isEqualTo("SRC");
        assertThat(dto.denominatore()).isEqualTo(1);
        assertThat(dto.penalita()).isEqualTo(0);
        assertThat(dto.idErrore()).isNull();
        assertThat(dto.userTypeCode()).isEqualTo("INT");
        assertThat(dto.userDescription()).isEqualTo("User Desc");
        assertThat(dto.cancelledFlag()).isEqualTo(0);
    }

    @Test
    void map_nullableFieldsNull_setsThemNull() throws SQLException {
        when(rs.getObject("OrganizationId")).thenReturn(null);
        when(rs.getObject("OrganizationCode")).thenReturn(null);
        when(rs.getString("RoleDescription")).thenReturn(null);
        when(rs.getObject("FlowId")).thenReturn(null);
        when(rs.getObject("EntityId")).thenReturn(null);
        when(rs.getTimestamp("Datastamp")).thenReturn(null);
        when(rs.getString("CustomerOrganizationCode")).thenReturn(null);
        when(rs.getString("TelephoneNumber")).thenReturn(null);
        when(rs.getString("UserCode")).thenReturn(null);
        when(rs.getObject("UserCustomerOrganizationId")).thenReturn(null);
        when(rs.getString("PositionDescription")).thenReturn(null);
        when(rs.getString("UserTypeDescription")).thenReturn(null);
        when(rs.getString("PkSource")).thenReturn(null);
        when(rs.getObject("Denominatore")).thenReturn(null);
        when(rs.getObject("Penalita")).thenReturn(null);
        when(rs.getString("IdErrore")).thenReturn(null);
        when(rs.getString("UserTypeCode")).thenReturn(null);
        when(rs.getString("UserDescription")).thenReturn(null);
        when(rs.getObject("CancelledFlag")).thenReturn(null);

        UserCustomerOrganizationDTO dto = UserCustomerOrganizationJdbcMapper.map(rs);

        assertThat(dto.organizationId()).isNull();
        assertThat(dto.datastamp()).isNull();
        assertThat(dto.denominatore()).isNull();
        assertThat(dto.cancelledFlag()).isNull();
    }
}
