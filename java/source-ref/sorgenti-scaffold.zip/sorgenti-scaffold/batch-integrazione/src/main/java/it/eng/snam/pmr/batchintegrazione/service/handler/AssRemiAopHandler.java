package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AssRemiAopPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AssRemiAopHandler extends AbstractFlussoHandler<AssRemiAopPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AssRemiAopPayloadDto> getDtoClass() {
        return AssRemiAopPayloadDto.class;
    }

    @Override
    protected void handle(AssRemiAopPayloadDto dto) {
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAssRemiAop(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteAssRemiAop(dto.data().getFirst().codiceAop(), dto.data().getFirst().remiAssoluto(), dto.data().getFirst().dataInizioAopInt());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}	
    	
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ASS_REMI_AOP_FLOW;
    }
}