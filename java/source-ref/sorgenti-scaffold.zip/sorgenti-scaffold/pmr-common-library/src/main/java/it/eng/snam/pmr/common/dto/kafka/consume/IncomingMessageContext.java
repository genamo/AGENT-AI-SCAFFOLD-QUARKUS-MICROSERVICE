package it.eng.snam.pmr.common.dto.kafka.consume;

import org.apache.kafka.common.header.Headers;

import io.smallrye.reactive.messaging.kafka.api.IncomingKafkaRecordMetadata;
import lombok.Value;

@Value(staticConstructor = "of")
public class IncomingMessageContext {

    String topic;
    Headers headers;
    byte[] payload;
    Integer size;
    IncomingKafkaRecordMetadata<String, byte[]> metadata;
}
