package it.eng.snam.pmr.batchintegrazionedg.mapper;


import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.MappingTarget;

import it.eng.snam.pmr.batchintegrazionedg.domain.MonitoringFlussi;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringFlussiDTO;


@Mapper(componentModel = MappingConstants.ComponentModel.CDI)
public interface MonitoringFlussiMapper {

    // Entity -> DTO
    // DTO NON ha "id" => non mappare/ignorare "id" qui
    MonitoringFlussiDTO toDto(MonitoringFlussi entity);

    // DTO -> Entity
    // Entity ha "id" identity => non valorizzarlo dal DTO
    @Mapping(target = "id", ignore = true)
    MonitoringFlussi toEntity(MonitoringFlussiDTO dto);

    // Liste Entity -> DTO (niente id)
    List<MonitoringFlussiDTO> toDtoList(List<MonitoringFlussi> entities);

    // Update DTO -> Entity (non sovrascrivere l'ID identity)
    @Mapping(target = "id", ignore = true)
    void updateEntityFromDto(MonitoringFlussiDTO dto, @MappingTarget MonitoringFlussi entity);
}

