package it.eng.snam.pmr.common.response.swagger;

import java.io.Serial;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import it.eng.snam.pmr.common.response.GenericResponse;

@Schema(name = "LongResponse")
public class LongResponse extends GenericResponse<Long> {
    @Serial
    private static final long serialVersionUID = -7237637865712889441L;
}
