package it.eng.snam.pmr.batchintegrazione.dto;

import java.time.LocalDateTime;

import lombok.Builder;

@Builder
public record MonitoringBatchDTO(
    String transactionId,
    String correlationId,
    String flowId,
    Integer dayNumber,
    Integer monthNumber,
    String granularita,
    String sender,
    Boolean isWorkaround,
    String statusDescription,
    String fileBatch,  // Contenuto del file nvarchar(max)
    String fileOutput, // Contenuto del file nvarchar(max)
    Integer status,
    LocalDateTime actionDate,
    String userAction,
    Integer isDeleted
) {}
