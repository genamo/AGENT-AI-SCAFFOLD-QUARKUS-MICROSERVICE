package it.eng.snam.pmr.batchintegrazione.service.external;

import com.fasterxml.jackson.core.type.TypeReference;
import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.external.SummerPmrIntegrationClient;
import it.eng.snam.pmr.batchintegrazione.dto.external.*;
import it.eng.snam.pmr.common.service.abstracts.AbstractService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.List;

@Slf4j
@ApplicationScoped
@RunOnVirtualThread
public class SummerPmrIntegrationService extends AbstractService {

    @Inject
    @RestClient
    SummerPmrIntegrationClient client;

    public List<AssoMailRemiDTO> filteredSearch(AssoMailRemiFilter filter) {
        return executeRawClientCall(() -> client.filteredSearch(filter), new TypeReference<>() {});
    }

    public List<String> findRemiByIdMail(Long idMail) {
        return executeRawClientCall(() -> client.findRemiByIdMail(idMail), new TypeReference<>() {});
    }

    public List<MailMonitoraggioVerbaliMisuraDTO> filteredSearch(MailMonitoraggioVerbaliMisuraFilter filter) {
        return executeRawClientCall(() -> client.filteredSearch(filter), new TypeReference<>() {});
    }

    public List<VerbaliMisuraDTO> filteredSearch(VerbaliMisuraFilter filter) {
        return executeRawClientCall(() -> client.filteredSearch(filter), new TypeReference<>() {});
    }
}
