package it.eng.snam.pmr.batchintegrazionedg.resource;

import java.util.Optional;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.dto.IdempotenzaRequestDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.IdempotenzaResponseDTO;
import it.eng.snam.pmr.batchintegrazionedg.domain.IdempotenzaFlussi;
import it.eng.snam.pmr.batchintegrazionedg.service.IdempotenzaFlussiService;
import it.eng.snam.pmr.batchintegrazionedg.utils.Utility;
import it.eng.snam.pmr.common.annotation.LogPmr;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.*;

@Path("/idempotenza-flussi")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@LogPmr
@RunOnVirtualThread
public class IdempotenzaFlussiResource extends AbstractResource {

    @Inject
    IdempotenzaFlussiService service;

    @Context
    ContainerRequestContext ctx;

    
    @POST
    @Path("/idempotenza-flussi-insert")
    public Response insert(IdempotenzaRequestDTO request) {

        ReqContext c = init(ctx, "/");

        if (request == null || request.transactionId() == null || request.transactionId().isBlank()) {
            return Utility.badRequest(
                    "transactionId obbligatorio",
                    c.path(), c.kl(), c.tid(),
                    c.modAsync(), c.processType(), c.start()
            );
        }

        IdempotenzaResponseDTO dto = service.start(request);

        return Response.ok(dto).build();
    }

    @POST
    @Path("/idempotenza-flussi-update")
    public Response upsert(IdempotenzaRequestDTO request) {

        ReqContext c = init(ctx, "/");

        if (request == null || request.transactionId() == null || request.transactionId().isBlank()) {
            return Utility.badRequest(
                    "transactionId obbligatorio",
                    c.path(), c.kl(), c.tid(),
                    c.modAsync(), c.processType(), c.start()
            );
        }

        IdempotenzaResponseDTO dto = service.updateStatus(request);

        return Response.ok(dto).build();
    }

    
    
    // ✅ SEARCH
    @GET
    @Path("/search")
    public Response search(@QueryParam("transactionId") String transactionId) {

        ReqContext c = init(ctx, "/search");

        if (transactionId == null || transactionId.isBlank()) {
            return Utility.badRequest(
                    "transactionId obbligatorio",
                    c.path(), c.kl(), c.tid(),
                    c.modAsync(), c.processType(), c.start()
            );
        }

        Optional<IdempotenzaFlussi> entity = service.findByTransactionId(transactionId);

        return Utility.okOrNotFound(
                entity,
                "Record non trovato",
                c.path(), c.kl(), c.tid(),
                c.modAsync(), c.processType(), c.start()
        );
    }
}