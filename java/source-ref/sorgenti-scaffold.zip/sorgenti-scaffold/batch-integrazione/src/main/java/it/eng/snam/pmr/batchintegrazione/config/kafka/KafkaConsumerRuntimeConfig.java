package it.eng.snam.pmr.batchintegrazione.config.kafka;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class KafkaConsumerRuntimeConfig {

    @ConfigProperty(name = "app.kafka.skip-message", defaultValue = "false")
    boolean skipMessage;

    public boolean isSkipMessage() {
        return skipMessage;
    }
}
