package it.eng.snam.pmr.common.annotation;

public enum UserType {
    INTERNAL,
    EXTERNAL
}

