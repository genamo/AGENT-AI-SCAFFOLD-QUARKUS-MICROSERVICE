package it.eng.snam.pmr.batchintegrazionedg.test.service.abstracts;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.lang.reflect.Field;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazionedg.kafka.KafkaTopic;
import it.eng.snam.pmr.batchintegrazionedg.service.abstracts.KafkaTopicResolver;

@ExtendWith(MockitoExtension.class)
class KafkaTopicResolverTest {

    private KafkaTopicResolver kafkaTopicResolver;

    @BeforeEach
    void setUp() throws Exception {
        kafkaTopicResolver = new KafkaTopicResolver();
        setPrivateField(kafkaTopicResolver, "kafkaTopicPrefix", "local");
        kafkaTopicResolver.init();
    }

    @Test
    void findRealTopic_shouldReturnRealTopic_whenTopicExists() {
        String result = kafkaTopicResolver.findRealTopic(KafkaTopic.MONITORING_INTEGRATION);
        assertEquals("local-monitoringintegration", result);
    }

    @Test
    void findRealTopic_shouldThrowException_whenTopicNameIsNull() {
        assertThrows(IllegalArgumentException.class, () -> kafkaTopicResolver.findRealTopic(null));
    }

    @Test
    void findRealTopic_shouldThrowException_whenTopicIsUnknown() {
        assertThrows(IllegalArgumentException.class, () -> kafkaTopicResolver.findRealTopic(KafkaTopic.UNKNOWN));
    }

    @Test
    void init_shouldThrowException_whenPrefixIsBlank() throws Exception {
        KafkaTopicResolver resolver = new KafkaTopicResolver();
        setPrivateField(resolver, "kafkaTopicPrefix", " ");
        assertThrows(IllegalArgumentException.class, resolver::init);
    }

    private static void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}
