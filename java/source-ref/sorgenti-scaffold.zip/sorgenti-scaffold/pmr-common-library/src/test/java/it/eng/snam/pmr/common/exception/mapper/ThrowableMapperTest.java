package it.eng.snam.pmr.common.exception.mapper;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.NoSuchElementException;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.common.exception.RemoteCallException;
import it.eng.snam.pmr.common.exception.RetryableRemoteException;
import it.eng.snam.pmr.common.util.Utility;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Path;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.ServiceUnavailableException;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class ThrowableMapperTest {

    @Mock
    Utility utility;

    @InjectMocks
    ThrowableMapper mapper;

    @InjectMocks
    ConstraintViolationMapper violationMapper;

    @Test
    void toResponse_badRequest_maps400() {
        Response expected = Response.status(Response.Status.BAD_REQUEST).build();
        when(utility.errorResponse("bad", Response.Status.BAD_REQUEST)).thenReturn(expected);

        mapper.toResponse(new BadRequestException("bad"));

        verify(utility).errorResponse("bad", Response.Status.BAD_REQUEST);
    }

    @Test
    void toResponse_notFound_maps404() {
        Response expected = Response.status(Response.Status.NOT_FOUND).build();
        when(utility.errorResponse("missing", Response.Status.NOT_FOUND)).thenReturn(expected);

        mapper.toResponse(new NoSuchElementException("missing"));

        verify(utility).errorResponse("missing", Response.Status.NOT_FOUND);
    }

    @Test
    void toResponse_remote_maps502() {
        Response expected = Response.status(Response.Status.BAD_GATEWAY).build();
        when(utility.errorResponse("remote", Response.Status.BAD_GATEWAY)).thenReturn(expected);

        mapper.toResponse(new RemoteCallException("remote"));

        verify(utility).errorResponse("remote", Response.Status.BAD_GATEWAY);
    }

    @Test
    void toResponse_retryableRemote_maps502() {
        Response expected = Response.status(Response.Status.BAD_GATEWAY).build();
        when(utility.errorResponse("retry", Response.Status.BAD_GATEWAY)).thenReturn(expected);

        mapper.toResponse(new RetryableRemoteException("retry"));

        verify(utility).errorResponse("retry", Response.Status.BAD_GATEWAY);
    }

    @Test
    void toResponse_serviceUnavailable_maps503() {
        Response expected = Response.status(Response.Status.SERVICE_UNAVAILABLE).build();
        when(utility.errorResponse("down", Response.Status.SERVICE_UNAVAILABLE)).thenReturn(expected);

        mapper.toResponse(new ServiceUnavailableException("down"));

        verify(utility).errorResponse("down", Response.Status.SERVICE_UNAVAILABLE);
    }

    @Test
    void toResponse_generic_maps500() {
        Response expected = Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        when(utility.errorResponse("boom", Response.Status.INTERNAL_SERVER_ERROR)).thenReturn(expected);

        mapper.toResponse(new Exception("boom"));

        verify(utility).errorResponse("boom", Response.Status.INTERNAL_SERVER_ERROR);
    }

    @Test
    void toResponse_constraintViolation_maps400WithViolationDetails() {
        String expectedMessage = "[indirizzoMail: must not be blank: invalidValue()]";
        Response expected = Response.status(Response.Status.BAD_REQUEST).entity(expectedMessage).build();

        @SuppressWarnings("unchecked") ConstraintViolation<Object> violation = mock(ConstraintViolation.class);
        Path path = mock(Path.class);

        when(path.toString()).thenReturn("indirizzoMail");
        when(violation.getPropertyPath()).thenReturn(path);
        when(violation.getMessage()).thenReturn("must not be blank");
        when(violation.getInvalidValue()).thenReturn("");

        ConstraintViolationException exception = new ConstraintViolationException("Validation failed",
                                                                                  Set.of(violation));

        when(utility.errorResponse(expectedMessage, Response.Status.BAD_REQUEST)).thenReturn(expected);

        violationMapper.toResponse(exception);

        verify(utility).errorResponse(expectedMessage, Response.Status.BAD_REQUEST);
    }
}
