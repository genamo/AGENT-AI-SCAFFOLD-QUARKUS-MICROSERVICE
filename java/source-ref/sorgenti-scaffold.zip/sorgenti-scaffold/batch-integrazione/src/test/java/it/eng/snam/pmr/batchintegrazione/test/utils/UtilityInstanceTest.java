package it.eng.snam.pmr.batchintegrazione.test.utils;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import it.eng.snam.pmr.common.response.GenericResponse;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class UtilityInstanceTest {

    @Mock RequestHeadersContext headersCtx;
    @InjectMocks Utility utility;

    @BeforeEach
    void setupContext() {
        lenient().when(headersCtx.getPath()).thenReturn("/test");
        lenient().when(headersCtx.getStartNanos()).thenReturn(System.nanoTime() - 1_000_000L);
        lenient().when(headersCtx.getKeyLogic()).thenReturn("kl");
        lenient().when(headersCtx.getTransactionId()).thenReturn("tid");
        lenient().when(headersCtx.isModAsync()).thenReturn(false);
        lenient().when(headersCtx.getProcessType()).thenReturn("BATCH");
    }

    private Response.ResponseBuilder stubBuilder() {
        Response.ResponseBuilder builder = mock(Response.ResponseBuilder.class);
        Response response = mock(Response.class);
        lenient().when(builder.entity(any())).thenReturn(builder);
        lenient().when(builder.header(anyString(), any())).thenReturn(builder);
        lenient().when(builder.build()).thenReturn(response);
        return builder;
    }

    @Test
    void notFound_setsMessageTypeError() {
        Response.ResponseBuilder builder = stubBuilder();
        try (MockedStatic<Response> mockedResp = mockStatic(Response.class)) {
            mockedResp.when(() -> Response.status(Response.Status.NOT_FOUND)).thenReturn(builder);
            Response result = utility.notFound("not found");
            assertNotNull(result);
        }
    }

    @Test
    void badRequest_setsMessageTypeError() {
        Response.ResponseBuilder builder = stubBuilder();
        try (MockedStatic<Response> mockedResp = mockStatic(Response.class)) {
            mockedResp.when(() -> Response.status(Response.Status.BAD_REQUEST)).thenReturn(builder);
            Response result = utility.badRequest("bad request");
            assertNotNull(result);
        }
    }

    @Test
    void badGateway_setsMessageTypeError() {
        Response.ResponseBuilder builder = stubBuilder();
        RemoteCallException ex = new RemoteCallException("upstream error");
        try (MockedStatic<Response> mockedResp = mockStatic(Response.class)) {
            mockedResp.when(() -> Response.status(Response.Status.BAD_GATEWAY)).thenReturn(builder);
            Response result = utility.badGateway(ex);
            assertNotNull(result);
        }
    }

    @Test
    void okOrNotFound_emptyOptional_callsNotFound() {
        Response.ResponseBuilder builder = stubBuilder();
        try (MockedStatic<Response> mockedResp = mockStatic(Response.class)) {
            mockedResp.when(() -> Response.status(Response.Status.NOT_FOUND)).thenReturn(builder);
            Response result = utility.okOrNotFound(Optional.empty(), "not found");
            assertNotNull(result);
        }
    }

    @Test
    void okOrNotFoundWithCustomMessage_emptyOptional_callsNotFound() {
        Response.ResponseBuilder builder = stubBuilder();
        GenericResponse.Message msg = new GenericResponse.Message();
        try (MockedStatic<Response> mockedResp = mockStatic(Response.class)) {
            mockedResp.when(() -> Response.status(Response.Status.NOT_FOUND)).thenReturn(builder);
            Response result = utility.okOrNotFoundWithCustomMessage(Optional.empty(), msg);
            assertNotNull(result);
        }
    }

    @Test
    void okOrNotFound_presentOptional_callsOk() {
        Response.ResponseBuilder builder = stubBuilder();
        try (MockedStatic<Response> mockedResp = mockStatic(Response.class)) {
            mockedResp.when(() -> Response.ok(any())).thenReturn(builder);
            Response result = utility.okOrNotFound(Optional.of("data"), "not found");
            assertNotNull(result);
        }
    }

    @Test
    void okOrNotFoundWithCustomMessage_presentOptional_callsOkWithMessage() {
        Response.ResponseBuilder builder = stubBuilder();
        GenericResponse.Message msg = new GenericResponse.Message();
        try (MockedStatic<Response> mockedResp = mockStatic(Response.class)) {
            mockedResp.when(() -> Response.ok(any())).thenReturn(builder);
            Response result = utility.okOrNotFoundWithCustomMessage(Optional.of("data"), msg);
            assertNotNull(result);
        }
    }
}
