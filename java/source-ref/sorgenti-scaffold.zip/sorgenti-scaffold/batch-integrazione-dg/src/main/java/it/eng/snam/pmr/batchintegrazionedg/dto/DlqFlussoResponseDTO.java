package it.eng.snam.pmr.batchintegrazionedg.dto;

public record DlqFlussoResponseDTO(
    boolean saved,
    Long id,
    String transactionId,
    String status
) {}
