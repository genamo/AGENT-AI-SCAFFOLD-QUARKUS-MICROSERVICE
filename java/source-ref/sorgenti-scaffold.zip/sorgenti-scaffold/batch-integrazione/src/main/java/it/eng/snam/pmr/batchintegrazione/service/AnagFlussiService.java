package it.eng.snam.pmr.batchintegrazione.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;
import org.jboss.resteasy.reactive.ClientWebApplicationException;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.BatchIntegrazioneDgClient;
import it.eng.snam.pmr.batchintegrazione.dto.AnagFlussiDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.response.CustomResponse;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.response.ExternalUserProfileResponse;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.service.DataPlatformService;
import it.eng.snam.pmr.common.util.JsonUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class AnagFlussiService extends AbstractService {

    private static final Logger LOG = Logger.getLogger(AnagFlussiService.class);

    @Inject
    @RestClient
    BatchIntegrazioneDgClient client;
    
    @Inject
    DataPlatformService dataPlatformService;

    @Inject
    ObjectMapper objectMapper;

    /**
     * Ritorna la lista dei flussi.
     * - 200: lista valorizzata
     * - 204: lista vuota
     * - altri: eccezione
     */
    public List<AnagFlussiDTO> getAll() {
        try (Response resp = client.getAll()) {

            int status = resp.getStatus();
            
            try {
            	//Esempio di recupero profile
        		ExternalUserProfileResponse profileObj = dataPlatformService.getExternalUserProfiles("RIE3WHO");
        		LOG.infof("TEST: Profile recuperato da DataPlatform per user RIE3WHO : %s", JsonUtils.writeAsJsonPrettyLogStringWithoutNull(profileObj));
    		 } catch (Exception e) {
    			LOG.error("Error databricks....", e);
    		}

            if (status == Response.Status.NO_CONTENT.getStatusCode()) {
                return List.of();
            }

            if (status == Response.Status.OK.getStatusCode()) {
                String json = resp.readEntity(String.class);
                return readList(json);
            }

            String errorBody = safeReadBody(resp);
            
            LOG.errorf(
                    "GET /anag-flussi fallita. processType=%s HTTP=%d body=%s",
                    headersCtx.getProcessType(), // ✅ preso dal context
                    status,
                    errorBody
            );

            throw new RemoteCallException(
                    "Errore getAll AnagFlussi: HTTP " + status + " - " + errorBody
            );
        }
    }


    /**
     * Ricerca per flowId.
     * - 200: Optional.of(dto)
     * - 404: Optional.empty()
     * - altri: eccezione
     */
    public CustomResponse<Optional<AnagFlussiDTO>> findByFlowId(String flowId) {

        try (Response resp = client.findByFlowId(flowId)) {

            int status = resp.getStatus();

            if (status == Response.Status.OK.getStatusCode()) {
                AnagFlussiDTO dto = resp.readEntity(AnagFlussiDTO.class);

                CustomResponse<Optional<AnagFlussiDTO>> response = new CustomResponse<>();
                response.setResponseData(Optional.ofNullable(dto));
                return response;
            }

            String errorBody = safeReadBody(resp);

            LOG.errorf(
                "GET /anag-flussi/search fallita. flowId=%s processType=%s HTTP=%d body=%s",
                flowId,
                headersCtx.getProcessType(), // ✅ context
                status,
                errorBody
            );

            throw new RemoteCallException(
                "Errore findByFlowId AnagFlussi: HTTP " + status + " - " + errorBody
            );

        } catch (ClientWebApplicationException e) {

            if (e.getResponse() != null &&
                e.getResponse().getStatus() == Response.Status.NOT_FOUND.getStatusCode()) {

                CustomResponse<Optional<AnagFlussiDTO>> response = new CustomResponse<>();
                response.setResponseData(Optional.empty());

                GenericResponse.Message message = new GenericResponse.Message();
                message.setMessageType("NOT_FOUND");
                message.setMessageCode("INFO01");
                message.setMessageDescription(
                    "Nessun flusso trovato per flowId=" + flowId
                );
                message.setMessagePlaceholder(Arrays.asList(flowId));

                response.setMessage(message);
                return response;
            }

            throw e;
        }
    }


    // =========================
    // Helpers
    // =========================

    private List<AnagFlussiDTO> readList(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return objectMapper.readValue(
                    json,
                    new TypeReference<List<AnagFlussiDTO>>() {}
            );
        } catch (Exception e) {
            throw new RemoteCallException(
                    "Impossibile deserializzare lista AnagFlussiDTO",
                    e
            );
        }
    }
}