package it.eng.snam.pmr.common.dto;

import java.time.LocalDateTime;

public record AdministrationListDTO(
        Long id,
        Integer listaId,
        String name,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {
}
