package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AssRemiAopDto(
        Long codiceAop,
        String remiAssoluto,
        Long dataInizioAopInt,
        LocalDateTime dataInizioAop,
        LocalDateTime dataFineAop,
        Long dataFineAopInt,
        LocalDateTime dataInserimento,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {}