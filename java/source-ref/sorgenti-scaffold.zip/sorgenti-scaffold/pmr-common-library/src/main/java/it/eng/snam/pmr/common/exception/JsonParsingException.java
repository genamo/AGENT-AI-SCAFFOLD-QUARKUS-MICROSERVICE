package it.eng.snam.pmr.common.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class JsonParsingException extends RuntimeException {
    @Serial
    private static final long serialVersionUID = -8836684493055047439L;
}
