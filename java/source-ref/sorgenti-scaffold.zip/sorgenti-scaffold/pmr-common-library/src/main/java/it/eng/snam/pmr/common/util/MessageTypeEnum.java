package it.eng.snam.pmr.common.util;

public enum MessageTypeEnum {
    OK                  ("Info",  "1"),
    ERROR_GESTITO_SEARCH("Info",  "4"),
    ERROR_GESTITO       ("Error", "2"),
    ERROR_NON_GESTITO   ("Error", "3"),
    ERROR_BUSINESS_LOGIC("Error", "7");

    private final String messageType;
    private final String messageCode;
    MessageTypeEnum(String t, String c) { this.messageType = t; this.messageCode = c; }
    public String getMessageType() { return messageType; }
    public String getMessageCode() { return messageCode; }
}
