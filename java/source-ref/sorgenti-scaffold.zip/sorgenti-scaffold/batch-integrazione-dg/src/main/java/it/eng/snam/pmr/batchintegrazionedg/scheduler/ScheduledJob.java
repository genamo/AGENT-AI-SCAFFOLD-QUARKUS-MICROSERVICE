package it.eng.snam.pmr.batchintegrazionedg.scheduler;

import java.time.Duration;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

import org.jboss.logging.Logger;

import io.quarkus.runtime.StartupEvent;
import io.quarkus.scheduler.Scheduled;
import io.quarkus.scheduler.Scheduler;
import it.eng.snam.pmr.batchintegrazionedg.domain.CronJobConfiguration;
import it.eng.snam.pmr.batchintegrazionedg.repository.CronJobConfigurationRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.control.ActivateRequestContext;
import jakarta.enterprise.event.Observes;
import jakarta.enterprise.inject.Instance;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.transaction.Transactional.TxType;
import net.javacrumbs.shedlock.core.LockConfiguration;
import net.javacrumbs.shedlock.core.LockProvider;

@ApplicationScoped
public class ScheduledJob {

	private static final Logger LOG = Logger.getLogger(ScheduledJob.class);

	private static final LockSettings DEFAULT_LOCK_SETTINGS = new LockSettings(Duration.ofMinutes(1), Duration.ofSeconds(30));

	private static final Map<String, LockSettings> LOCK_SETTINGS_BY_JOB = Map.of(
			"cron.batch.001", new LockSettings(Duration.ofMinutes(1), Duration.ofSeconds(15)),
			"cron.batch.002", new LockSettings(Duration.ofMinutes(1), Duration.ofSeconds(15)));

	// Cache cron attuale
	private final Map<String, String> currentCronByJob = new ConcurrentHashMap<>();

	// Registry handler
	private final Map<String, Runnable> handlers = new ConcurrentHashMap<>();

	// Flag init completato
	private final AtomicBoolean initDone = new AtomicBoolean(false);

	// Lock anti race
	private final ReentrantLock refreshLock = new ReentrantLock();

	@Inject
	Scheduler scheduler;
	@Inject
	CronJobConfigurationRepository repo;
	@Inject
	LockProvider lockProvider;
	@Inject
	CronJobHandlers jobHandlers;

	@Inject
	Instance<ScheduledJob> self;

	void onStart(@Observes StartupEvent ev) {
		handlers.put("cron.batch.001", jobHandlers::startBatch001);
		handlers.put("cron.batch.002", jobHandlers::startBatch002);

		try {
			refreshFromDbAndApply(true);
		} catch (Exception e) {
			LOG.error("Errore refresh iniziale scheduler", e);
		} finally {
			initDone.set(true);
		}
	}

	@Scheduled(every = "900s", delayed = "15s", concurrentExecution = Scheduled.ConcurrentExecution.SKIP)
	void refreshTick() {
		if (!initDone.get()) {
			LOG.debug("Init non completato, skip refresh");
			return;
		}

		try {
			refreshFromDbAndApply(false);
		} catch (Exception e) {
			LOG.error("Errore refresh scheduler", e);
		}
	}

	void refreshFromDbAndApply(boolean firstLoad) {
		if (!refreshLock.tryLock()) {
			LOG.debug("Refresh già in corso -> skip");
			return;
		}

		try {
			List<CronJobConfiguration> rows = self.get().loadJobsFromDb();

			Set<String> dbJobs = new HashSet<>();
			Set<String> processed = new HashSet<>();

			for (CronJobConfiguration cfg : rows) {
				String jobName = cfg.getJobName();

				if (!processed.add(jobName)) {
					LOG.warnf("Duplicato DB job=%s -> skip", jobName);
					continue;
				}

				String cron = cfg.getCronExpression();
				dbJobs.add(jobName);

				Runnable handler = handlers.get(jobName);
				if (handler == null) {
					LOG.warnf("Job non gestito da questo MS: %s", jobName);
					continue;
				}

				applySingleJob(jobName, cron, handler, firstLoad);
			}

			for (String cachedJob : new HashSet<>(currentCronByJob.keySet())) {
				if (!dbJobs.contains(cachedJob)) {
					try {
						scheduler.unscheduleJob(identityOf(cachedJob));
					} catch (Exception e) {
						LOG.warnf(e, "Errore unschedule job=%s", cachedJob);
					} finally {
						currentCronByJob.remove(cachedJob);
					}
				}
			}

		} finally {
			refreshLock.unlock();
		}
	}

	@Transactional(TxType.REQUIRES_NEW)
	@ActivateRequestContext
	List<CronJobConfiguration> loadJobsFromDb() {
		return repo.listAllJobs();
	}

	private void applySingleJob(String jobName, String cron, Runnable handler, boolean firstLoad) {
		String old = currentCronByJob.get(jobName);
		String identity = identityOf(jobName);

		if (cron == null || cron.isBlank() || "off".equalsIgnoreCase(cron) || "disabled".equalsIgnoreCase(cron)) {
			try {
				scheduler.unscheduleJob(identity);
			} catch (Exception e) {
				LOG.debugf("Unschedule già eseguito %s", identity);
			}

			currentCronByJob.remove(jobName);
			LOG.infof("Job disabilitato: %s", jobName);
			return;
		}

		if (!firstLoad && cron.equals(old)) {
			return;
		}

		try {
			scheduler.unscheduleJob(identity);
		} catch (Exception e) {
			LOG.debugf("Unschedule non necessario %s", identity);
		}

		try {
			scheduler.newJob(identity).setCron(cron).setTask(ctx -> runWithLock(jobName, handler)).schedule();

			currentCronByJob.put(jobName, cron);
			LOG.infof("Job schedulato: %s cron=%s", jobName, cron);

		} catch (IllegalStateException e) {
			LOG.warnf("Job già schedulato identity=%s -> skip (race)", identity);
		}
	}

	private void runWithLock(String jobName, Runnable handler) {
		LockConfiguration lock = buildLockConfiguration(jobName);

		var maybeLock = lockProvider.lock(lock);
		if (maybeLock.isEmpty()) {
			LOG.infof("Skip job=%s: lock non acquisito", jobName);
			return;
		}

		try {
			self.get().runHandlerInNewTx(jobName, handler);
		} finally {
			maybeLock.get().unlock();
		}
	}

	private LockConfiguration buildLockConfiguration(String jobName) {
		String lockName = "LOCK_" + jobName;
		LockSettings settings = LOCK_SETTINGS_BY_JOB.getOrDefault(jobName, DEFAULT_LOCK_SETTINGS);

		return new LockConfiguration(Instant.now(), lockName, settings.lockAtMostFor(), settings.lockAtLeastFor());
	}

	@Transactional(TxType.REQUIRES_NEW)
	@ActivateRequestContext
	void runHandlerInNewTx(String jobName, Runnable handler) {
		try {
			handler.run();
		} catch (Exception e) {
			LOG.errorf(e, "Errore handler job=%s", jobName);
			throw e;
		}
	}

	private static String identityOf(String jobName) {
		return "dyn-" + jobName.replace('.', '-');
	}

	private record LockSettings(Duration lockAtMostFor, Duration lockAtLeastFor) {
	}
}