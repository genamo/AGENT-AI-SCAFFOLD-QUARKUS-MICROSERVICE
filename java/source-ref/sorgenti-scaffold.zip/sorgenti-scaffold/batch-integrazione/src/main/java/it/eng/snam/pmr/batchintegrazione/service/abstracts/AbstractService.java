package it.eng.snam.pmr.batchintegrazione.service.abstracts;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jboss.logging.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

public abstract class AbstractService {

    @Inject
    protected RequestHeadersContext headersCtx;

    @Inject
    protected ObjectMapper objectMapper;

    protected static String safeReadBody(Response resp) {
        try {
            return resp.hasEntity() ? resp.readEntity(String.class) : "";
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Estrae un messaggio leggibile dal body di errore remoto.
     * Se presente il nodo "message", prova a costruire:
     * [messageType - messageCode] messageDescription
     * In fallback restituisce il body grezzo.
     */
    protected String extractErrorDetail(String body) {
        if (body == null || body.isBlank()) {
            return "";
        }

        try {
            JsonNode root = objectMapper.readTree(body);
            JsonNode messageNode = root.path("message");

            if (!messageNode.isMissingNode() && !messageNode.isNull()) {
                String messageType = messageNode.path("messageType").asText("");
                String messageCode = messageNode.path("messageCode").asText("");
                String messageDescription = messageNode.path("messageDescription").asText("");

                if (!messageDescription.isBlank() || !messageCode.isBlank() || !messageType.isBlank()) {
                    StringBuilder sb = new StringBuilder();

                    if (!messageType.isBlank() || !messageCode.isBlank()) {
                        sb.append("[");
                        if (!messageType.isBlank()) {
                            sb.append(messageType);
                        }
                        if (!messageCode.isBlank()) {
                            if (!messageType.isBlank()) {
                                sb.append(" - ");
                            }
                            sb.append(messageCode);
                        }
                        sb.append("]");
                    }

                    if (!messageDescription.isBlank()) {
                        if (!sb.isEmpty()) {
                            sb.append(" ");
                        }
                        sb.append(messageDescription);
                    }

                    String extracted = sb.toString().trim();
                    if (!extracted.isBlank()) {
                        return extracted;
                    }
                }

                // se il nodo message esiste ma non ha i campi attesi, restituisco almeno il suo contenuto json
                return messageNode.toString();
            }
        } catch (Exception e) {
            // fallback sotto al body grezzo
        }

        return body;
    }

    protected String extractErrorDetail(Response resp) {
        return extractErrorDetail(safeReadBody(resp));
    }

    protected RemoteCallException remoteError(String operation, int status, Response resp) {
        String body = safeReadBody(resp);
        String detail = extractErrorDetail(body);

        Logger.getLogger(getClass()).errorf(
                "%s fallita. KL=%s TID=%s PT=%s HTTP=%d body=%s",
                operation,
                headersCtx.getKeyLogic(),
                headersCtx.getTransactionId(),
                headersCtx.getProcessType(),
                status,
                body
        );

        return new RemoteCallException(
                operation + " errore HTTP " + status + (detail.isBlank() ? "" : (" - " + detail))
        );
    }

    @SuppressWarnings("unchecked")
    protected <T> T handleResponse(Response resp, TypeReference<T> typeReference, String operation) {
        int status = resp.getStatus();

        if (status == Response.Status.NO_CONTENT.getStatusCode()) {
            Class<?> rawClass = objectMapper.getTypeFactory().constructType(typeReference).getRawClass();

            if (List.class.isAssignableFrom(rawClass))
                return (T) List.of();

            if (Set.class.isAssignableFrom(rawClass))
                return (T) Set.of();

            if (Map.class.isAssignableFrom(rawClass))
                return (T) Map.of();

            return null;
        }

        if (status == Response.Status.OK.getStatusCode()) {
            String json = resp.readEntity(String.class);
            return readValue(json, typeReference);
        }

        if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
            String body = safeReadBody(resp);
            String detail = extractErrorDetail(body);
            throw new IllegalArgumentException(operation + ": richiesta non valida. " + detail);
        }

        throw remoteError(operation, status, resp);
    }

    private <T> T readValue(String json, TypeReference<T> typeReference) {
        if (json == null || json.isBlank())
            return null;

        try {
            return objectMapper.readValue(json, typeReference);
        } catch (Exception e) {
            throw new RemoteCallException("Impossibile deserializzare json", e);
        }
    }
}
