package it.eng.snam.pmr.batchintegrazionedg.config;

import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.enums.ParameterIn;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.servers.Server;

@OpenAPIDefinition(
    info = @Info(
        title = "Batch Integrazione DG API",
        version = "1.0"
    ),
    servers = @Server(url = "/"),
    components = @org.eclipse.microprofile.openapi.annotations.Components(
        parameters = {
            @Parameter(
                name = "keyLogic",
                in = ParameterIn.HEADER,
                description = "Chiave di correlazione tecnica",
                required = false
            ),
            @Parameter(
                name = "transactionId",
                in = ParameterIn.HEADER,
                description = "Transaction id tecnico",
                required = false
            ),
            @Parameter(
                name = "modAsync",
                in = ParameterIn.HEADER,
                description = "Modalità asincrona",
                required = false
            ),
            @Parameter(
                name = "processType",
                in = ParameterIn.HEADER,
                description = "Tipo processo (GUI | FLUSSO | N/A)",
                required = false
            )
        }
    )
)
public class OpenApiConfig {}