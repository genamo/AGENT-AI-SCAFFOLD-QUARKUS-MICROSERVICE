package it.eng.snam.pmr.batchintegrazione.test.service;

import java.util.Map;

import io.quarkus.test.junit.QuarkusTestProfile;

public class NoSecurityTestProfile implements QuarkusTestProfile {
    @Override
    public Map<String, String> getConfigOverrides() {
        return Map.of("quarkus.oidc.enabled", "false", "quarkus.arc.validate", "false");
    }
}
