package it.eng.snam.pmr.common.util.kafka.producer;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.eclipse.microprofile.reactive.messaging.Message;

import io.smallrye.reactive.messaging.kafka.api.OutgoingKafkaRecordMetadata;
import it.eng.snam.pmr.common.dto.kafka.produce.MessageHeaderContext;
import it.eng.snam.pmr.common.functional.interfaces.kafka.producer.MessageHeaderFactory;
import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.JsonUtils;
import it.eng.snam.pmr.common.util.retry.RetryableProcessDomain;
import it.eng.snam.pmr.common.util.retry.RetryableProcessExecutor;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class MessagePublisher {

    public void send(String realTopic, MessageHeaderFactory headerFactory, Object objectPayload, Consumer<Message<byte[]>> publisher, Map<String, String> additionalHeaders) {
        Message<byte[]> message = RetryableProcessExecutor.execute(RetryableProcessDomain.KAFKA, () -> construct(realTopic, headerFactory, objectPayload, additionalHeaders));
        publisher.accept(message);
    }

    private Message<byte[]> construct(String realTopic, MessageHeaderFactory headerFactory, Object objectPayload, Map<String, String> additionalHeaders) {
        MessageHeaderContext context = MessageHeaderFactory.resolve(headerFactory);
        log.debug("RealTopic: {}", realTopic);
        log.debug("MessageHeaderContext: {}", context);
        log.debug("AdditionalHeaders: {}", additionalHeaders);

        Headers kafkaHeaders = toKafkaHeaders(context, additionalHeaders);
        OutgoingKafkaRecordMetadata<String> metadata = OutgoingKafkaRecordMetadata.<String>builder().withTopic(realTopic).withKey(context.getMessageKey()).withHeaders(kafkaHeaders).build();
        byte[] payload = toJsonBytes(objectPayload);
        log.debug("Payload: {}", StringUtils.toEncodedString(payload, StandardCharsets.UTF_8));

        Message<byte[]> message = Message.of(payload).addMetadata(metadata);
        log.info("Sending message to topic '{}' with messageKey '{}' and transactionId '{}'", realTopic, context.getMessageKey(), context.getTransactionId());

        return message;
    }

    private Headers toKafkaHeaders(MessageHeaderContext context, Map<String, String> additionalHeaders) {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put(CommonConstants.KafkaHeaders.TRANSACTION_ID, context.getTransactionId());
        headers.put(CommonConstants.KafkaHeaders.TID, context.getTransactionId());
        headers.put(CommonConstants.KafkaHeaders.USER_ID, context.getUserId());
        headers.put(CommonConstants.KafkaHeaders.UID, context.getUserId());
        headers.put(CommonConstants.KafkaHeaders.KEYLOGIC, context.getKeyLogic());
        headers.put(CommonConstants.KafkaHeaders.PROCESS_TYPE, context.getProcessType());
        headers.put(CommonConstants.KafkaHeaders.FLOW_TYPE, context.getFlowType());
        headers.put(CommonConstants.KafkaHeaders.MESSAGE_KEY, context.getMessageKey());
        headers.put(CommonConstants.KafkaHeaders.CONTENT_TYPE, CommonConstants.MediaType.APP_JSON);
        headers.put(CommonConstants.KafkaHeaders.TIMESTAMP, String.valueOf(System.currentTimeMillis()));

        if (additionalHeaders != null && !additionalHeaders.isEmpty())
            headers.putAll(additionalHeaders);

        Headers kafkaHeaders = new RecordHeaders();
        headers.forEach((key, value) -> {
            if (StringUtils.isNotBlank(key) && value != null)
                kafkaHeaders.add(key, value.getBytes(StandardCharsets.UTF_8));
        });

        return kafkaHeaders;
    }

    private byte[] toJsonBytes(Object payload) {
        return switch (payload) {
            case null -> throw new IllegalArgumentException("ObjectPayload must be valued properly.");
            case byte[] bytes when JsonUtils.isJson(bytes) -> bytes;
            case String text when JsonUtils.isJson(text) -> text.getBytes(StandardCharsets.UTF_8);
            default -> Optional.ofNullable(JsonUtils.writeAsJsonPrettyBytesWithoutNull(payload))
                               .filter(ArrayUtils::isNotEmpty)
                               .orElseThrow(() -> new IllegalArgumentException("JsonBytePayload must be valued properly."));
        };
    }
}
