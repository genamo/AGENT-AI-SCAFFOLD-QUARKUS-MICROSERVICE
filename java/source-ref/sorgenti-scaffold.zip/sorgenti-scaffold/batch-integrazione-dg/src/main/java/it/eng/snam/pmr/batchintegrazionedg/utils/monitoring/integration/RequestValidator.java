package it.eng.snam.pmr.batchintegrazionedg.utils.monitoring.integration;

import org.apache.commons.lang3.StringUtils;

import it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class RequestValidator {

    public void validate(MonitoringIntegration integrationRequest) {
        if (integrationRequest == null)
            throw new IllegalArgumentException("UploadRequest must be valued");

        String transactionId = MdcManager.getHeader(CommonConstants.LogParams.TN);
        if (StringUtils.isBlank(transactionId))
            throw new IllegalArgumentException("TransactionId must be valued");

        String userId = MdcManager.getHeader(AuthorizationUtils.USER_ID);
        if (StringUtils.isBlank(userId.toLowerCase()))
            throw new IllegalArgumentException("UserId must be valued");

        if (StringUtils.isBlank(integrationRequest.getIntegrationType()))
            throw new IllegalArgumentException("IntegrationType must be valued");

        if (StringUtils.isBlank(integrationRequest.getRequestBody()))
            throw new IllegalArgumentException("RequestBody must be valued");

        log.info("Request received. userId={}, transaction={}", userId, transactionId);
    }
}
