package it.eng.snam.pmr.batchintegrazionedg.test.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazionedg.domain.AnagFlussi;
import it.eng.snam.pmr.batchintegrazionedg.dto.AnagFlussiDTO;
import it.eng.snam.pmr.batchintegrazionedg.mapper.AnagFlussiMapper;
import it.eng.snam.pmr.batchintegrazionedg.repository.AnagFlussiRepository;
import it.eng.snam.pmr.batchintegrazionedg.service.AnagFlussiService;

@ExtendWith(MockitoExtension.class)
class AnagFlussiServiceTest {

    @Mock
    AnagFlussiRepository repository;

    @Mock
    AnagFlussiMapper mapper;

    @InjectMocks
    AnagFlussiService service;

    private AnagFlussi buildEntity(String flowId) {
        AnagFlussi e = new AnagFlussi();
        e.setId(1L);
        e.setFlowId(flowId);
        e.setDescFlow("Desc");
        e.setGranularita("G");
        e.setVerso("IN");
        e.setProcessType("N/A");
        e.setActionDate(LocalDateTime.now());
        e.setIsDeleted(0);
        return e;
    }

    private AnagFlussiDTO buildDto(String flowId) {
        return new AnagFlussiDTO(1L, flowId, "Desc", "G", "IN", "N/A",
                null, null, LocalDateTime.now(), "SYSTEM", 0);
    }

    @Test
    void getAll_returnsListFromRepository() {
        AnagFlussi entity = buildEntity("FLOW-001");
        AnagFlussiDTO dto = buildDto("FLOW-001");
        when(repository.list("isDeleted = 0")).thenReturn(List.of(entity));
        when(mapper.toDtoList(List.of(entity))).thenReturn(List.of(dto));

        List<AnagFlussiDTO> result = service.getAll();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("FLOW-001", result.get(0).flowId());
        verify(repository).list("isDeleted = 0");
    }

    @Test
    void getAll_emptyRepository_returnsEmptyList() {
        when(repository.list("isDeleted = 0")).thenReturn(List.of());
        when(mapper.toDtoList(List.of())).thenReturn(List.of());

        List<AnagFlussiDTO> result = service.getAll();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void findByFlowId_found_returnsDto() {
        AnagFlussi entity = buildEntity("FLOW-001");
        AnagFlussiDTO dto = buildDto("FLOW-001");
        when(repository.findByFlowId("FLOW-001")).thenReturn(Optional.of(entity));
        when(mapper.toDto(entity)).thenReturn(dto);

        AnagFlussiDTO result = service.findByFlowId("FLOW-001");

        assertNotNull(result);
        assertEquals("FLOW-001", result.flowId());
    }

    @Test
    void findByFlowId_notFound_returnsNull() {
        when(repository.findByFlowId("UNKNOWN")).thenReturn(Optional.empty());

        AnagFlussiDTO result = service.findByFlowId("UNKNOWN");

        assertNull(result);
        verify(repository).findByFlowId("UNKNOWN");
    }

    @Test
    void findByFlowId_multipleEntities_returnFirstMatch() {
        AnagFlussi entity = buildEntity("FLOW-002");
        AnagFlussiDTO dto = buildDto("FLOW-002");
        when(repository.findByFlowId("FLOW-002")).thenReturn(Optional.of(entity));
        when(mapper.toDto(entity)).thenReturn(dto);

        AnagFlussiDTO result = service.findByFlowId("FLOW-002");

        assertEquals("FLOW-002", result.flowId());
    }
}
