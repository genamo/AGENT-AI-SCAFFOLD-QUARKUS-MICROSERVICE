package it.eng.snam.pmr.common.response;
public enum ResponseStatus {
    ELABORATO("ELABORATO"), IN_ELABORAZIONE("IN ELABORAZIONE"),
    IN_ERRORE("IN ERRORE"),  PRESO_IN_CARICO("PRESO IN CARICO");
    private final String status;
    ResponseStatus(String s) { this.status = s; }
    public String getStatus() { return status; }
}
