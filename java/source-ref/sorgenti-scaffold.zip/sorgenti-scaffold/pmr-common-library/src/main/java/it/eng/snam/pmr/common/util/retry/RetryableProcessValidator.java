package it.eng.snam.pmr.common.util.retry;

import org.apache.commons.lang3.StringUtils;

import it.eng.snam.pmr.common.dto.retry.RetryableProcessContext;
import it.eng.snam.pmr.common.functional.interfaces.RetryableCommand;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class RetryableProcessValidator {

    public <T> void validate(RetryableProcessContext context, RetryableCommand<T> command) {
        if (context == null)
            throw new IllegalArgumentException("Context must be valued");

        if (StringUtils.isBlank(context.getOperationName()))
            throw new IllegalArgumentException("OperationName must be valued");

        if (context.getRetryPredicate() == null)
            throw new IllegalArgumentException("RetryPredicate must be valued");

        if (context.getExceptionFactory() == null)
            throw new IllegalArgumentException("ExceptionFactory must be valued");

        if (command == null)
            throw new IllegalArgumentException("Command must be valued");
    }
}
