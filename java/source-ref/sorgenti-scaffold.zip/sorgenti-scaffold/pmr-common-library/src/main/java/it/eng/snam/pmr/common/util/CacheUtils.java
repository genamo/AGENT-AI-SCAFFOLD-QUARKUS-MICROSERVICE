package it.eng.snam.pmr.common.util;

import java.util.Objects;
import java.util.UUID;
import java.util.function.Supplier;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.quarkus.redis.datasource.RedisDataSource;
import io.quarkus.redis.datasource.keys.KeyCommands;
import io.quarkus.redis.datasource.value.ValueCommands;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/**
 * Utility Redis distribuita per cache-aside.
 *
 * Funzionalita:
 * - GET / PUT / EVICT JSON tipizzati
 * - cache-aside
 * - protezione cache stampede tramite distributed lock Redis
 *
 * Compatibile con Quarkus 3.34.x.
 */
@ApplicationScoped
public class CacheUtils {

    private static final Logger LOG = Logger.getLogger(CacheUtils.class);

    private static final String LOCK_PREFIX = "lock:";

    private static final String RELEASE_LOCK_SCRIPT =
            "if redis.call('GET', KEYS[1]) == ARGV[1] then " +
            "  return redis.call('DEL', KEYS[1]) " +
            "else " +
            "  return 0 " +
            "end";

    private final RedisDataSource redisDS;
    private final ObjectMapper objectMapper;
    private final ValueCommands<String, String> values;
    private final KeyCommands<String> keys;

    @ConfigProperty(name = "app.cache.redis.prefix", defaultValue = "cache")
    String prefix;

    /**
     * TTL del lock distribuito.
     *
     * Deve essere maggiore del tempo medio/massimo del supplier.
     */
    @ConfigProperty(name = "app.cache.redis.lock.ttl-seconds", defaultValue = "30")
    int lockTtlSeconds;

    /**
     * Tempo massimo di attesa per i nodi che non ottengono il lock.
     */
    @ConfigProperty(name = "app.cache.redis.lock.wait-timeout-ms", defaultValue = "5000")
    long lockWaitTimeoutMs;

    /**
     * Sleep minimo fra un polling e l'altro.
     */
    @ConfigProperty(name = "app.cache.redis.lock.sleep-min-ms", defaultValue = "50")
    long lockSleepMinMs;

    /**
     * Sleep massimo fra un polling e l'altro.
     */
    @ConfigProperty(name = "app.cache.redis.lock.sleep-max-ms", defaultValue = "150")
    long lockSleepMaxMs;

    @Inject
    public CacheUtils(RedisDataSource redisDS, ObjectMapper objectMapper) {
        this.redisDS = redisDS;
        this.objectMapper = objectMapper;
        this.values = redisDS.value(String.class);
        this.keys = redisDS.key();
    }

    // -------------------------------------------------
    // Key builder
    // -------------------------------------------------

    public String key(String domain, String feature, String... parts) {
        StringBuilder sb = new StringBuilder(prefix)
                .append(":").append(sanitize(domain))
                .append(":").append(sanitize(feature));

        if (parts != null) {
            for (String p : parts) {
                if (p != null && !p.isBlank()) {
                    sb.append(":").append(sanitize(p));
                }
            }
        }

        return sb.toString();
    }

    private String sanitize(String s) {
        return s.trim().replace(" ", "_");
    }

    private String lockKey(String key) {
        return LOCK_PREFIX + key;
    }

    // -------------------------------------------------
    // GET / PUT JSON tipizzati
    // -------------------------------------------------

    public <T> T get(String key, TypeReference<T> typeRef) {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(typeRef, "typeRef");

        try {
            String json = values.get(key);

            if (json == null || json.isBlank()) {
                return null;
            }

            return objectMapper.readValue(json, typeRef);

        } catch (Exception e) {
            /*
             * Per una cache, in caso di errore conviene degradare a cache miss.
             */
            LOG.debugf(e, "Cache GET fallita (key=%s)", key);
            return null;
        }
    }

    public <T> void put(String key, T value, int ttlSeconds) {
        Objects.requireNonNull(key, "key");

        if (ttlSeconds <= 0) {
            LOG.debugf("Cache PUT skipped (ttlSeconds<=0) key=%s", key);
            return;
        }

        /*
         * Non cacheiamo null.
         *
         * Se serializzassimo null, Jackson produrrebbe "null", ma get()
         * ritornerebbe comunque null. Quindi non distingueremmo:
         * - cache miss
         * - valore null cacheato
         */
        if (value == null) {
            LOG.debugf("Cache PUT skipped (value=null) key=%s", key);
            return;
        }

        try {
            String json = objectMapper.writeValueAsString(value);
            values.setex(key, (long) ttlSeconds, json);

        } catch (Exception e) {
            LOG.infof(e, "Cache PUT fallita (key=%s)", key);
        }
    }

    // -------------------------------------------------
    // EVICT
    // -------------------------------------------------

    public boolean evict(String key) {
        Objects.requireNonNull(key, "key");

        try {
            return keys.del(key) > 0;

        } catch (Exception e) {
            LOG.infof(e, "Cache EVICT fallita (key=%s)", key);
            return false;
        }
    }

    public boolean evict(String domain, String feature, String... parts) {
        return evict(key(domain, feature, parts));
    }

    // -------------------------------------------------
    // Cache-aside con protezione cache stampede
    // -------------------------------------------------

    public <T> T getOrCompute(
            String key,
            TypeReference<T> typeRef,
            int ttlSeconds,
            Supplier<T> supplier) {

        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(typeRef, "typeRef");
        Objects.requireNonNull(supplier, "supplier");

        /*
         * Primo GET normale.
         */
        T cached = get(key, typeRef);

        if (cached != null) {
            LOG.infof("Cache HIT in getOrCompute (key=%s)", key);
            return cached;
        }

        String redisLockKey = lockKey(key);
        String token = UUID.randomUUID().toString();

        /*
         * Solo una JVM / istanza deve calcolare il dato.
         */
        if (acquireLock(redisLockKey, token, lockTtlSeconds)) {
            try {
                /*
                 * Double-check:
                 * tra il primo GET e l'acquisizione del lock,
                 * un altro nodo potrebbe avere gia popolato la cache.
                 */
                cached = get(key, typeRef);

                if (cached != null) {
                    LOG.infof("Cache HIT after lock acquisition in getOrCompute (key=%s)", key);
                    return cached;
                }

                LOG.infof("Cache MISS, computing value with distributed lock (key=%s)", key);

                T computed = supplier.get();
                put(key, computed, ttlSeconds);

                return computed;

            } finally {
                releaseLock(redisLockKey, token);
            }
        }

        /*
         * Un altro nodo sta calcolando.
         * Aspettiamo che popoli la cache.
         */
        LOG.debugf("Cache MISS, waiting for another node to populate cache (key=%s)", key);

        T waited = waitForValue(key, typeRef, lockWaitTimeoutMs);

        if (waited != null) {
            LOG.infof("Cache populated by another node (key=%s)", key);
            return waited;
        }

        /*
         * Fallback:
         * il nodo che aveva il lock potrebbe essere fallito oppure il supplier
         * potrebbe avere impiegato piu del timeout di attesa.
         *
         * Proviamo ad acquisire nuovamente il lock.
         */
        token = UUID.randomUUID().toString();

        if (acquireLock(redisLockKey, token, lockTtlSeconds)) {
            try {
                cached = get(key, typeRef);

                if (cached != null) {
                    LOG.infof("Cache HIT after second lock acquisition (key=%s)", key);
                    return cached;
                }

                LOG.infof("Cache recompute after wait timeout with distributed lock (key=%s)", key);

                T computed = supplier.get();
                put(key, computed, ttlSeconds);

                return computed;

            } finally {
                releaseLock(redisLockKey, token);
            }
        }

        /*
         * Ultimo fallback di disponibilita.
         *
         * In scenario degradato puo esserci un ricalcolo concorrente,
         * ma evitiamo di bloccare indefinitamente la richiesta.
         */
        LOG.warnf("Cache lock unavailable after wait; computing without lock (key=%s)", key);

        T computed = supplier.get();
        put(key, computed, ttlSeconds);

        return computed;
    }

    public <T> T recreate(
            String key,
            TypeReference<T> typeRef,
            int ttlSeconds,
            Supplier<T> supplier) {

        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(typeRef, "typeRef");
        Objects.requireNonNull(supplier, "supplier");

        String redisLockKey = lockKey(key);
        String token = UUID.randomUUID().toString();

        /*
         * recreate forza il refresh.
         * Usiamo il lock per evitare refresh paralleli della stessa chiave.
         */
        if (acquireLock(redisLockKey, token, lockTtlSeconds)) {
            try {
                T cached = get(key, typeRef);

                if (cached != null) {
                    LOG.infof("Cache HIT in recreate, evicting before recompute (key=%s)", key);
                    evict(key);
                } else {
                    LOG.infof("Cache MISS in recreate, computing value (key=%s)", key);
                }

                T computed = supplier.get();
                put(key, computed, ttlSeconds);

                return computed;

            } finally {
                releaseLock(redisLockKey, token);
            }
        }

        /*
         * Un altro nodo sta gia facendo recreate.
         * Aspettiamo che finisca e poi leggiamo il valore aggiornato.
         */
        LOG.debugf("Recreate already in progress on another node, waiting (key=%s)", key);

        T refreshed = waitForLockReleaseThenGet(redisLockKey, key, typeRef, lockWaitTimeoutMs);

        if (refreshed != null) {
            LOG.infof("Cache refreshed by another node in recreate (key=%s)", key);
            return refreshed;
        }

        /*
         * Fallback: tentiamo di acquisire nuovamente il lock.
         */
        token = UUID.randomUUID().toString();

        if (acquireLock(redisLockKey, token, lockTtlSeconds)) {
            try {
                evict(key);

                T computed = supplier.get();
                put(key, computed, ttlSeconds);

                return computed;

            } finally {
                releaseLock(redisLockKey, token);
            }
        }

        /*
         * Ultimo fallback di disponibilita.
         */
        LOG.warnf("Recreate lock unavailable after wait; computing without lock (key=%s)", key);

        evict(key);

        T computed = supplier.get();
        put(key, computed, ttlSeconds);

        return computed;
    }

    // -------------------------------------------------
    // Distributed lock Redis
    // -------------------------------------------------

    private boolean acquireLock(String redisLockKey, String token, int ttlSeconds) {
        if (ttlSeconds <= 0) {
            throw new IllegalArgumentException("lock ttlSeconds must be > 0");
        }

        try {
            /*
             * Redis:
             *
             * SET redisLockKey token NX EX ttlSeconds
             *
             * NX = set solo se la chiave non esiste
             * EX = TTL in secondi
             *
             * Operazione atomica.
             *
             * In Quarkus 3.34.x redisDS.execute(...) restituisce
             * io.vertx.mutiny.redis.client.Response.
             * Usiamo var per evitare mismatch con io.vertx.redis.client.Response.
             */
            var response = redisDS.execute(
                    "SET",
                    redisLockKey,
                    token,
                    "NX",
                    "EX",
                    String.valueOf(ttlSeconds)
            );

            return response != null && "OK".equalsIgnoreCase(response.toString());

        } catch (Exception e) {
            LOG.infof(e, "Redis LOCK acquire fallita (lockKey=%s)", redisLockKey);
            return false;
        }
    }

    private boolean releaseLock(String redisLockKey, String token) {
        try {
            /*
             * Rilascio sicuro:
             * cancella il lock solo se il valore corrente coincide con il token
             * generato da questa istanza.
             *
             * Evita che un nodo cancelli il lock di un altro nodo se il primo
             * lock e scaduto ed e stato riacquisito da un'altra istanza.
             */
            var response = redisDS.execute(
                    "EVAL",
                    RELEASE_LOCK_SCRIPT,
                    "1",
                    redisLockKey,
                    token
            );

            return response != null && !"0".equals(response.toString());

        } catch (Exception e) {
            LOG.infof(e, "Redis LOCK release fallita (lockKey=%s)", redisLockKey);
            return false;
        }
    }

    private boolean lockExists(String redisLockKey) {
        try {
            String value = values.get(redisLockKey);
            return value != null;

        } catch (Exception e) {
            LOG.debugf(e, "Redis LOCK exists check fallita (lockKey=%s)", redisLockKey);
            return false;
        }
    }

    // -------------------------------------------------
    // Wait helpers
    // -------------------------------------------------

    private <T> T waitForValue(
            String key,
            TypeReference<T> typeRef,
            long timeoutMs) {

        long deadline = System.currentTimeMillis() + Math.max(0L, timeoutMs);

        while (System.currentTimeMillis() < deadline) {
            T value = get(key, typeRef);

            if (value != null) {
                return value;
            }

            sleepWithJitter();

            if (Thread.currentThread().isInterrupted()) {
                return null;
            }
        }

        return null;
    }

    private <T> T waitForLockReleaseThenGet(
            String redisLockKey,
            String cacheKey,
            TypeReference<T> typeRef,
            long timeoutMs) {

        long deadline = System.currentTimeMillis() + Math.max(0L, timeoutMs);

        while (System.currentTimeMillis() < deadline) {
            if (!lockExists(redisLockKey)) {
                return get(cacheKey, typeRef);
            }

            sleepWithJitter();

            if (Thread.currentThread().isInterrupted()) {
                return null;
            }
        }

        return get(cacheKey, typeRef);
    }

    private void sleepWithJitter() {

        try {
            Thread.sleep(Math.max(1L, lockSleepMinMs));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}