package it.eng.snam.pmr.common.util.dto;

import java.util.List;
import java.util.function.Function;

import it.eng.snam.pmr.common.dto.page.PageDTO;
import lombok.experimental.UtilityClass;

@UtilityClass
public class PageInitializer {

    public <E, D> PageDTO<D> dto(PageDTO<E> entityPage, Function<List<E>, List<D>> mapper) {
        return page(entityPage, mapper);
    }

    public <E, D> PageDTO<E> entity(PageDTO<D> dtoPage, Function<List<D>, List<E>> mapper) {
        return page(dtoPage, mapper);
    }

    private <A, B> PageDTO<B> page(PageDTO<A> entityPage, Function<List<A>, List<B>> mapper) {
        List<B> list = mapper.apply(entityPage.getElements());
        return new PageDTO<>(list, entityPage.getElementsSize(), entityPage.getElementsAmount(), entityPage.getCurrentPage(), entityPage.getTotalPages());
    }
}
