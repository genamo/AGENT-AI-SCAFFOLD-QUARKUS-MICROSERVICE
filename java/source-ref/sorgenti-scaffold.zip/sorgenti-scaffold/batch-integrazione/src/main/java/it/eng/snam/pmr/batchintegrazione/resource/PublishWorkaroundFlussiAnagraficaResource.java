package it.eng.snam.pmr.batchintegrazione.resource;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.jboss.resteasy.reactive.RestForm;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.dto.FlowTriggerRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.FlowTriggerResponseDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.service.PublishWorkaroundFlussiAnagraficaService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import it.eng.snam.pmr.common.annotation.AuthzRead;
import it.eng.snam.pmr.common.annotation.AuthzWrite;
import it.eng.snam.pmr.common.annotation.LogPmr;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.response.swagger.CommonApiErrorResponses;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;

@Path("/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RunOnVirtualThread
@LogPmr
@RequiredArgsConstructor(onConstructor_ = @Inject)
@Tag(name = "PublishWorkaroundFlussiAnagraficaResource", description = "API per pubblicazione e download payload dei flussi workaround anagrafica")
public class PublishWorkaroundFlussiAnagraficaResource {

	private static final String CONTROL_KEY_PARAM = "controlKey";
	private static final String TRANSACTION_ID_PARAM = "transactionId";
	private static final String DOWNLOAD_FROM_DLQ_PREFIX = "downloadfromdlq_";
	private static final String DOWNLOAD_FROM_FLUSSI_MONITORING_PREFIX = "downloadfromflussimonitoring_";
	private static final String JSON_EXTENSION = ".json";
	private static final String FILE_READ_ERROR_MESSAGE = "Errore lettura file: ";
	private static final String DLQ_FILE_ERROR_MESSAGE = "Errore generazione file DLQ: ";
	private static final String FLUSSI_MONITORING_FILE_ERROR_MESSAGE = "Errore generazione file monitoring flussi: ";

	private final PublishWorkaroundFlussiAnagraficaService service;
	private final Utility utility;
	private final ObjectMapper objectMapper;

	@POST
	@Path("/bi_flussi-workaround_publish")
	@AuthzWrite
	@Operation(summary = "Pubblica un messaggio workaround tramite payload JSON")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "202", description = "Richiesta presa in carico correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = FlowTriggerGenericResponse.class)))
	public Response publish(

			@RequestBody(description = "Payload del flusso da pubblicare", required = true, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = FlowTriggerRequestDTO.class))) FlowTriggerRequestDTO request

	) {

		if (request == null) {
			return utility.badRequest("Body mancante o non valido");
		}

		return handlePublish(() -> utility.inCarico(service.publish(request)));
	}

	@POST
	@Path("/bi_flussi-workaround_publishfromfile")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	@AuthzWrite
	@Operation(summary = "Pubblica un messaggio workaround tramite upload file JSON")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "202", description = "Richiesta presa in carico correttamente", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = FlowTriggerGenericResponse.class)))
	public Response publishFromFile(

			@RestForm("file") InputStream file

	) {

		if (file == null) {
			return utility.badRequest("File mancante o non valido");
		}

		return handlePublishFromFile(file);
	}

	@GET
	@Path("/bi_flussi-workaround_downloadfromdlq")
	@Produces(MediaType.APPLICATION_JSON)
	@AuthzRead
	@Operation(summary = "Genera il payload JSON partendo da un record DLQ")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "File JSON generato correttamente")
	public Response downloadFromDlq(

			@QueryParam(CONTROL_KEY_PARAM) @Parameter(description = "Control key del record presente in DLQ", required = true, example = "CTRL-123456", schema = @Schema(type = SchemaType.STRING)) String controlKey

	) {

		Response validationError = validateRequiredQueryParam(CONTROL_KEY_PARAM, controlKey);
		if (validationError != null) {
			return validationError;
		}

		return handleDownload(() -> buildJsonAttachment(service.buildDownloadFromDlqRequest(controlKey), buildFileName(DOWNLOAD_FROM_DLQ_PREFIX, controlKey)), DLQ_FILE_ERROR_MESSAGE);
	}

	@GET
	@Path("/bi_flussi-workaround_downloadfromflussimonitoring")
	@Produces(MediaType.APPLICATION_JSON)
	@AuthzRead
	@Operation(summary = "Genera il payload JSON partendo dal monitoring flussi")
	@CommonApiErrorResponses
	@APIResponse(responseCode = "200", description = "File JSON generato correttamente")
	public Response downloadFromFlussiMonitoring(

			@QueryParam(TRANSACTION_ID_PARAM) @Parameter(description = "TransactionId del flusso monitorato", required = true, example = "TX123456", schema = @Schema(type = SchemaType.STRING)) String transactionId

	) {

		Response validationError = validateRequiredQueryParam(TRANSACTION_ID_PARAM, transactionId);
		if (validationError != null) {
			return validationError;
		}

		return handleDownload(() -> buildJsonAttachment(service.buildDownloadFromFlussiMonitoringRequest(transactionId), buildFileName(DOWNLOAD_FROM_FLUSSI_MONITORING_PREFIX, transactionId)), FLUSSI_MONITORING_FILE_ERROR_MESSAGE);
	}

	private Response handlePublish(ResponseSupplier action) {
		try {
			return action.get();
		} catch (IllegalArgumentException e) {
			return utility.badRequest(e.getMessage());
		} catch (Exception e) {
			return utility.badRequest(FILE_READ_ERROR_MESSAGE + e.getMessage());
		}
	}

	private Response handlePublishFromFile(InputStream file) {
		return handlePublish(() -> {
			FlowTriggerRequestDTO request = readRequestFromFile(file);
			return utility.inCarico(service.publish(request));
		});
	}

	private Response handleDownload(ResponseSupplier action, String serverErrorMessagePrefix) {
		try {
			return action.get();
		} catch (NotFoundException e) {
			return utility.notFound(e.getMessage());
		} catch (IllegalArgumentException e) {
			return utility.badRequest(e.getMessage());
		} catch (RemoteCallException e) {
			return utility.badGateway(e);
		} catch (Exception e) {
			return Response.serverError().entity(serverErrorMessagePrefix + e.getMessage()).build();
		}
	}

	private FlowTriggerRequestDTO readRequestFromFile(InputStream file) throws IOException {
		try (InputStream is = file) {
			String json = new String(is.readAllBytes(), StandardCharsets.UTF_8);
			return objectMapper.readValue(json, FlowTriggerRequestDTO.class);
		}
	}

	private Response buildJsonAttachment(FlowTriggerRequestDTO dto, String fileName) throws IOException {

		byte[] jsonBytes = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(dto);

		return Response.ok(jsonBytes, MediaType.APPLICATION_JSON).header("Content-Disposition", "attachment; filename=\"" + fileName + "\"").build();
	}

	private Response validateRequiredQueryParam(String paramName, String value) {
		if (value == null || value.isBlank()) {
			return utility.badRequest("Query param '" + paramName + "' obbligatorio");
		}
		return null;
	}

	private String buildFileName(String prefix, String value) {
		return prefix + sanitizeFileName(value) + JSON_EXTENSION;
	}

	private String sanitizeFileName(String value) {

		if (value == null || value.isBlank()) {
			return "unknown";
		}

		return value.replaceAll("[^a-zA-Z0-9._-]", "_");
	}

	@FunctionalInterface
	private interface ResponseSupplier {
		Response get() throws Exception;
	}

	@Schema(name = "FlowTriggerGenericResponse")
	public static class FlowTriggerGenericResponse extends GenericResponse<FlowTriggerResponseDTO> {

		private static final long serialVersionUID = 1L;
	}
}
