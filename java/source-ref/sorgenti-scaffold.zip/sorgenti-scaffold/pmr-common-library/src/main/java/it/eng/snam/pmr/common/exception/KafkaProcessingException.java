package it.eng.snam.pmr.common.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class KafkaProcessingException extends RuntimeException {
    @Serial
    private static final long serialVersionUID = 5913363983024791602L;
}
