USE [pmrintegrazione];

/* ============================================================
   AZURE SQL - MONITORING INTEGRATION TRACKING
   Prefix tabelle: monitoring_integration_
   ============================================================ */
IF OBJECT_ID('dbo.monitoring_integration_metadata') IS NULL
BEGIN
    CREATE TABLE dbo.monitoring_integration_metadata (
        id                      BIGINT IDENTITY(1,1) NOT NULL,
        integration_request_id  BIGINT NOT NULL,
        request                 NVARCHAR(4000) NULL,
        response                NVARCHAR(4000) NULL,
        created_at_utc          DATETIME2(3) NOT NULL
            CONSTRAINT df_monitoring_integration_metadata_created_at_utc
            DEFAULT SYSUTCDATETIME(),
        updated_at_utc          DATETIME2(3) NULL,

        CONSTRAINT pk_monitoring_integration_metadata
            PRIMARY KEY CLUSTERED (id),

        CONSTRAINT fk_monitoring_integration_metadata_request
            FOREIGN KEY (integration_request_id)
                REFERENCES dbo.monitoring_integration_request (id));

    /* ============================================================
       INDICI monitoring_integration_metadata
       ============================================================ */
    CREATE NONCLUSTERED INDEX ix_monitoring_integration_metadata_request_id
    ON dbo.monitoring_integration_metadata (integration_request_id);
END
