package it.eng.snam.pmr.common.exception.mapper;

import java.util.Map;

import it.eng.snam.pmr.common.util.exception.mapper.ThrowableDomain;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;

@Provider
public class ThrowableMapper extends AbstractExceptionMapper<Throwable> {

    @Override
    protected Map<Class<? extends Throwable>, Response.Status> getStatusRules() {
        return ThrowableDomain.STATUS_RULES;
    }
}
