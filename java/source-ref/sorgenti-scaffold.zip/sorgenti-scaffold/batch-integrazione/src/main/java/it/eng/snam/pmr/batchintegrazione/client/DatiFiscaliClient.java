package it.eng.snam.pmr.batchintegrazione.client;

import java.time.LocalDateTime;

import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.annotation.RegisterProviders;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration.DateRiepiloghiDTO;
import it.eng.snam.pmr.batchintegrazione.filter.RestClientHeadersFilter;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@RegisterRestClient(configKey = "dati-fiscali-client")
@RegisterProviders(value = {@RegisterProvider(RestClientHeadersFilter.class)})
public interface DatiFiscaliClient {

    @POST
    @Path("/df_monitoring-integration_save-date-riepiloghi")
    Response saveDateRiepiloghi(DateRiepiloghiDTO dateRiepiloghiDTO);

    // ======================================================
    // VERBALI MISURA
    // ======================================================

    @GET
    @Path("/df_verbali-misura_getall")
    Response getAllVerbaliMisura();

    @GET
    @Path("/df_verbali-misura_find")
    Response findVerbaleMisuraById(
            @QueryParam("remiAssoluto") String remiAssoluto,
            @QueryParam("dataInitVerbale") LocalDateTime dataInitVerbale);

    @POST
    @Path("/df_verbali-misura_save")
    Response saveVerbaleMisura(Object dto);

    @DELETE
    @Path("/df_verbali-misura_delete")
    Response deleteVerbaleMisura(
            @QueryParam("remiAssoluto") String remiAssoluto,
            @QueryParam("dataInitVerbale") LocalDateTime dataInitVerbale);

    @PUT
    @Path("/df_verbali-misura_restore")
    Response restoreVerbaleMisura(
            @QueryParam("remiAssoluto") String remiAssoluto,
            @QueryParam("dataInitVerbale") LocalDateTime dataInitVerbale);

    // ======================================================
    // VERBALI MISURA GIORN
    // ======================================================

    @GET
    @Path("/df_verbali-misura-giorn_getall")
    Response getAllVerbaliMisuraGiorn();

    @GET
    @Path("/df_verbali-misura-giorn_find")
    Response findVerbaleMisuraGiornById(
            @QueryParam("remiAssoluto") String remiAssoluto,
            @QueryParam("dataVolPunta") LocalDateTime dataVolPunta,
            @QueryParam("dataIniVerb") LocalDateTime dataIniVerb);

    @POST
    @Path("/df_verbali-misura-giorn_save")
    Response saveVerbaleMisuraGiorn(Object dto);

    @DELETE
    @Path("/df_verbali-misura-giorn_delete")
    Response deleteVerbaleMisuraGiorn(
            @QueryParam("remiAssoluto") String remiAssoluto,
            @QueryParam("dataVolPunta") LocalDateTime dataVolPunta,
            @QueryParam("dataIniVerb") LocalDateTime dataIniVerb);

    @PUT
    @Path("/df_verbali-misura-giorn_restore")
    Response restoreVerbaleMisuraGiorn(
            @QueryParam("remiAssoluto") String remiAssoluto,
            @QueryParam("dataVolPunta") LocalDateTime dataVolPunta,
            @QueryParam("dataIniVerb") LocalDateTime dataIniVerb);
}
