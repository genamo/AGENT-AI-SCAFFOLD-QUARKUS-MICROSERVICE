package it.eng.snam.pmr.batchintegrazionedg.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

import it.eng.snam.pmr.batchintegrazionedg.domain.IntegrazioneParametriSistema;
import it.eng.snam.pmr.batchintegrazionedg.dto.IntegrazioneParametriSistemaDTO;

@Mapper(componentModel = MappingConstants.ComponentModel.CDI)
public interface IntegrazioneParametriSistemaMapper {

    // Da Entity a DTO
    IntegrazioneParametriSistemaDTO toDto(IntegrazioneParametriSistema entity);

    // Da DTO a Entity
    IntegrazioneParametriSistema toEntity(IntegrazioneParametriSistemaDTO dto);

    // Mapping di liste
    List<IntegrazioneParametriSistemaDTO> toDtoList(List<IntegrazioneParametriSistema> entities);
}
