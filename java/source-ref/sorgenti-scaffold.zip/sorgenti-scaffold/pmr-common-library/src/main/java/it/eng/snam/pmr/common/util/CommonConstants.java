package it.eng.snam.pmr.common.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CommonConstants {

    public final String TIMESTAMP_FORMAT = "yyyyMMddHHmmssSSS";
    public final String MSG_ERROR = "Error";

    @UtilityClass
    public class Headers {
        public final String TRANSACTION_ID = "TRANSACTION-ID";
        public final String KEYLOGIC = "KEY-LOGIC";
        public final String MOD_ASYNC = "MOD-ASYNC";
        public final String PROCESS_TYPE = "PROCESS-TYPE";
        public final String MESSAGE_KEY = "MESSAGE-KEY";
        public final String JWT = "JWT";
        public final String AUTHORIZATION = "Authorization";
        public final String FLOW = "FLOW";
    }

    @UtilityClass
    public class KafkaHeaders {
        public final String TRANSACTION_ID = "TRANSACTION-ID";
        public final String KEYLOGIC = "KEY-LOGIC";
        public final String USER_ID = "USER-ID";
        public final String PROCESS_TYPE = "PROCESS-TYPE";
        public final String MESSAGE_KEY = "MESSAGE-KEY";
        public final String FLOW_TYPE = "FLOW";
        public final String TOPIC = "TOPIC";
        public final String CONTENT_TYPE = "content-type";
        public final String TIMESTAMP = "timestamp";
        public final String TID = "transactionId";
        public final String UID = "userId";
    }

    @UtilityClass
    public class LogParams {
        public final String TN = "TN";
        public final String KL = "KL";
        public final String API = "API";
        public final String MK = "MK";
        public final String PT = "PT";
        public final String MA = "MA";
        public final String FT = "FT";
        public final String KT = "KT";
    }

    @UtilityClass
    public class MediaType {
        public final String APP_JSON = "application/json";
    }
}
