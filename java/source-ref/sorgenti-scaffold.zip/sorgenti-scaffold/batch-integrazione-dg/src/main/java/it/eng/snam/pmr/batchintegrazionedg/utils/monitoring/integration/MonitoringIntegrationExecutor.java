package it.eng.snam.pmr.batchintegrazionedg.utils.monitoring.integration;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

import org.springframework.util.CollectionUtils;

import it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration.MonitoringIntegrationOutcome;
import it.eng.snam.pmr.batchintegrazionedg.entity.MonitoringIntegrationMetadata;
import it.eng.snam.pmr.batchintegrazionedg.entity.MonitoringIntegrationRequest;
import it.eng.snam.pmr.batchintegrazionedg.entity.MonitoringIntegrationStatus;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class MonitoringIntegrationExecutor {

    public void persistRequest(String integrationType, String userId, String transactionId, LocalDateTime now, Consumer<MonitoringIntegrationRequest> persister) {
        log.info("Persisting MonitoringIntegration, transactionId={} integrationType={} userId={}", transactionId, integrationType, userId);
        MonitoringIntegrationRequest request = new MonitoringIntegrationRequest();
        request.setIntegrationType(integrationType);
        request.setTransactionId(transactionId);
        request.setUserId(userId);
        request.setCreatedAtUtc(now);
        persister.accept(request);
    }

    public Long retrieveRequestId(String transactionId, Function<String, Optional<Long>> retriever) {
        return retriever.apply(transactionId).orElseThrow();
    }

    public void persistMetadata(String transactionId, String request, Long id, LocalDateTime now, Consumer<MonitoringIntegrationMetadata> persister) {
        log.info("Persisting MonitoringIntegrationMetadata, transactionId={}", transactionId);
        MonitoringIntegrationMetadata metadata = new MonitoringIntegrationMetadata();
        metadata.setIntegrationRequestId(id);
        metadata.setRequest(request);
        metadata.setCreatedAtUtc(now);
        persister.accept(metadata);
    }

    public void persistMetadata(String transactionId, MonitoringIntegration integrationRequest, Long id, LocalDateTime now, Consumer<List<MonitoringIntegrationMetadata>> persister) {
        log.info("Persisting MonitoringIntegrationMetadata list, transactionId={}", transactionId);
        List<MonitoringIntegrationMetadata> metadataList = new LinkedList<>();

        if (!CollectionUtils.isEmpty(integrationRequest.getAdditionalMetadata()))
            metadataList.addAll(integrationRequest.getAdditionalMetadata().entrySet().stream().map(entry -> {
                MonitoringIntegrationMetadata metadata = new MonitoringIntegrationMetadata();
                metadata.setIntegrationRequestId(id);
                metadata.setRequest(entry.getKey());
                metadata.setResponse(entry.getValue());
                metadata.setCreatedAtUtc(now);
                return metadata;
            }).toList());

        if (!CollectionUtils.isEmpty(metadataList))
            persister.accept(metadataList);
    }

    public void persistStatus(String transactionId, Long id, LocalDateTime now, Consumer<MonitoringIntegrationStatus> persister) {
        log.info("Persisting MonitoringIntegrationStatus, transactionId={}", transactionId);
        MonitoringIntegrationStatus status = new MonitoringIntegrationStatus();
        status.setIntegrationRequestId(id);
        status.setCreatedAtUtc(now);
        persister.accept(status);
    }


    public void updateRequest(MonitoringIntegrationRequest request, MonitoringIntegrationOutcome payload, LocalDateTime now, Consumer<MonitoringIntegrationRequest> persister) {
        request.setIntegrationType(payload.getIntegrationType());
        request.setUpdatedAtUtc(now);

        persister.accept(request);
    }

    public void updateMetadata(Long id, MonitoringIntegrationOutcome payload, LocalDateTime now, Function<Long, Optional<MonitoringIntegrationMetadata>> finder, Consumer<MonitoringIntegrationMetadata> persister) {
        MonitoringIntegrationMetadata metadata = finder.apply(id).orElseThrow();
        metadata.setResponse(payload.getResponseBody());
        metadata.setUpdatedAtUtc(now);

        persister.accept(metadata);
    }

    public void updateStatus(Long id, MonitoringIntegrationOutcome payload, LocalDateTime now, Function<Long, Optional<MonitoringIntegrationStatus>> finder, Consumer<MonitoringIntegrationStatus> persister) {
        MonitoringIntegrationStatus status = finder.apply(id).orElseThrow();
        status.setContentType(payload.getContentType());
        status.setStatus(payload.getResponseStatusCode());
        status.setStatusMessage(payload.getResponseStatus());
        status.setUpdatedAtUtc(now);

        persister.accept(status);
    }
}
