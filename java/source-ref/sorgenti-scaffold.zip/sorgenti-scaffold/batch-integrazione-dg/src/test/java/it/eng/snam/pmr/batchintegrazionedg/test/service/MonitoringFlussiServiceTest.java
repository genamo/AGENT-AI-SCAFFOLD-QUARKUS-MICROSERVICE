package it.eng.snam.pmr.batchintegrazionedg.test.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazionedg.domain.MonitoringFlussi;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringFlussiDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringFlussiSearchDTO;
import it.eng.snam.pmr.batchintegrazionedg.mapper.MonitoringFlussiMapper;
import it.eng.snam.pmr.batchintegrazionedg.repository.MonitoringFlussiRepository;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringFlussiService;
import jakarta.persistence.PersistenceException;

@ExtendWith(MockitoExtension.class)
class MonitoringFlussiServiceTest {

    @Mock
    MonitoringFlussiRepository repository;

    @Mock
    MonitoringFlussiMapper mapper;

    @InjectMocks
    MonitoringFlussiService service;

    private MonitoringFlussi buildEntity(String txId) {
        MonitoringFlussi e = new MonitoringFlussi();
        e.setId(1L);
        e.setTransactionId(txId);
        e.setCorrelationId(txId);
        e.setFlowId("FLOW-001");
        e.setDayNumber(20260522);
        e.setMonthNumber(202605);
        e.setGranularita("G");
        e.setSender("PMR");
        e.setIsWorkaround(false);
        e.setStatusDescription("OK");
        e.setFileFlusso("{file}");
        e.setFileOutput("{out}");
        e.setStatus(1);
        e.setActionDate(LocalDateTime.of(2026, 5, 22, 10, 0));
        e.setUserAction("batch");
        e.setIsDeleted(0);
        return e;
    }

    private MonitoringFlussiDTO buildDto(String txId) {
        return MonitoringFlussiDTO.builder()
                .transactionId(txId)
                .correlationId(txId)
                .flowId("FLOW-001")
                .dayNumber(20260522)
                .monthNumber(202605)
                .granularita("G")
                .sender("PMR")
                .isWorkaround(false)
                .statusDescription("OK")
                .fileFlusso("{file}")
                .fileOutput("{out}")
                .status(1)
                .actionDate(LocalDateTime.of(2026, 5, 22, 10, 0))
                .userAction("batch")
                .isDeleted(0)
                .build();
    }

    @Test
    void getAll_returnsAllDtos() {
        MonitoringFlussi entity = buildEntity("TXN-001");
        MonitoringFlussiDTO dto = buildDto("TXN-001");

        when(repository.listAll()).thenReturn(List.of(entity));
        when(mapper.toDtoList(List.of(entity))).thenReturn(List.of(dto));

        List<MonitoringFlussiDTO> result = service.getAll();

        assertEquals(1, result.size());
        assertEquals("TXN-001", result.get(0).transactionId());
    }

    @Test
    void getById_found_returnsDto() {
        MonitoringFlussi entity = buildEntity("TXN-001");
        MonitoringFlussiDTO dto = buildDto("TXN-001");

        when(repository.findById(1L)).thenReturn(entity);
        when(mapper.toDto(entity)).thenReturn(dto);

        MonitoringFlussiDTO result = service.getById(1L);

        assertNotNull(result);
        assertEquals("TXN-001", result.transactionId());
    }

    @Test
    void getById_notFound_returnsNull() {
        when(repository.findById(99L)).thenReturn(null);
        when(mapper.toDto(null)).thenReturn(null);

        assertNull(service.getById(99L));
    }

    @Test
    void getByTransactionId_found_returnsDto() {
        MonitoringFlussi entity = buildEntity("TXN-002");
        MonitoringFlussiDTO dto = buildDto("TXN-002");

        when(repository.findByTransactionId("TXN-002")).thenReturn(Optional.of(entity));
        when(mapper.toDto(entity)).thenReturn(dto);

        MonitoringFlussiDTO result = service.getByTransactionId("TXN-002");

        assertNotNull(result);
        assertEquals("TXN-002", result.transactionId());
    }

    @Test
    void getByTransactionId_notFound_returnsNull() {
        when(repository.findByTransactionId("UNKNOWN")).thenReturn(Optional.empty());

        assertNull(service.getByTransactionId("UNKNOWN"));
    }

    @Test
    void getLastExecutions_returnsDtos() {
        MonitoringFlussi entity = buildEntity("TXN-003");
        MonitoringFlussiDTO dto = buildDto("TXN-003");

        when(repository.findLastExecutionsNoLock(5)).thenReturn(List.of(entity));
        when(mapper.toDtoList(List.of(entity))).thenReturn(List.of(dto));

        List<MonitoringFlussiDTO> result = service.getLastExecutions(5);

        assertEquals(1, result.size());
        assertEquals("TXN-003", result.get(0).transactionId());
    }

    @Test
    void getByPeriod_returnsDtos() {
        MonitoringFlussi entity = buildEntity("TXN-004");
        MonitoringFlussiDTO dto = buildDto("TXN-004");

        when(repository.findByPeriod(202605, 20260522)).thenReturn(List.of(entity));
        when(mapper.toDtoList(List.of(entity))).thenReturn(List.of(dto));

        List<MonitoringFlussiDTO> result = service.getByPeriod(202605, 20260522);

        assertEquals(1, result.size());
        assertEquals("TXN-004", result.get(0).transactionId());
    }

    @Test
    void getByPeriod_nullParams_delegatesToRepository() {
        when(repository.findByPeriod(null, null)).thenReturn(List.of());
        when(mapper.toDtoList(List.of())).thenReturn(List.of());

        assertTrue(service.getByPeriod(null, null).isEmpty());
    }

    @Test
    void findByCustomSearch_returnsDtos() {
        MonitoringFlussiSearchDTO search = MonitoringFlussiSearchDTO.builder()
                .flowId("FLOW-001")
                .status(1)
                .build();

        MonitoringFlussi entity = buildEntity("TXN-005");
        MonitoringFlussiDTO dto = buildDto("TXN-005");

        when(repository.findByCustomSearchReadUncommitted(search)).thenReturn(List.of(entity));
        when(mapper.toDtoList(List.of(entity))).thenReturn(List.of(dto));

        List<MonitoringFlussiDTO> result = service.findByCustomSearch(search);

        assertEquals(1, result.size());
        assertEquals("TXN-005", result.get(0).transactionId());
    }

    @Test
    void save_nullRequest_returnsFallbackError() {
        MonitoringFlussiDTO result = service.save(null);

        assertNotNull(result);
        assertEquals("ERROR_NULL_REQUEST", result.statusDescription());
        assertEquals(0, result.isDeleted());
        verifyNoInteractions(repository, mapper);
    }

    @Test
    void save_existingTransaction_updatesEntityAndFlushes() {
        MonitoringFlussiDTO dto = buildDto("TXN-EXIST");
        MonitoringFlussi entity = buildEntity("TXN-EXIST");

        when(repository.findByTransactionId("TXN-EXIST")).thenReturn(Optional.of(entity));
        doNothing().when(mapper).updateEntityFromDto(dto, entity);
        when(mapper.toDto(entity)).thenReturn(dto);

        MonitoringFlussiDTO result = service.save(dto);

        assertNotNull(result);
        verify(mapper).updateEntityFromDto(dto, entity);
        verify(repository).flush();
        verify(repository, never()).persistAndFlush(any(MonitoringFlussi.class));
    }

    @Test
    void save_newTransaction_persistsEntity() {
        MonitoringFlussiDTO dto = buildDto("TXN-NEW");
        MonitoringFlussi entity = buildEntity("TXN-NEW");

        when(repository.findByTransactionId("TXN-NEW")).thenReturn(Optional.empty());
        when(mapper.toEntity(dto)).thenReturn(entity);
        doNothing().when(repository).persistAndFlush(entity);
        when(mapper.toDto(entity)).thenReturn(dto);

        MonitoringFlussiDTO result = service.save(dto);

        assertNotNull(result);
        verify(repository).persistAndFlush(entity);
        verify(repository, never()).flush();
    }

    @Test
    void save_retryablePersistenceError_retriesAndEventuallySucceeds() {
        MonitoringFlussiDTO dto = buildDto("TXN-RETRY");
        MonitoringFlussi entity = buildEntity("TXN-RETRY");
        AtomicInteger calls = new AtomicInteger();

        when(repository.findByTransactionId("TXN-RETRY")).thenReturn(Optional.empty());
        when(mapper.toEntity(dto)).thenReturn(entity);
        when(mapper.toDto(entity)).thenReturn(dto);

        doAnswer(invocation -> {
            if (calls.getAndIncrement() == 0) {
                throw new PersistenceException("1205");
            }
            return null;
        }).when(repository).persistAndFlush(entity);

        MonitoringFlussiDTO result = service.save(dto);

        verify(repository, times(2)).persistAndFlush(entity);
        assertNotNull(result);
        assertEquals("TXN-RETRY", result.transactionId());
        assertEquals("OK", result.statusDescription());
    }

    @Test
    void save_retryablePersistenceError_exhausted_returnsFallbackError() {
        MonitoringFlussiDTO dto = buildDto("TXN-RETRY-KO");
        MonitoringFlussi entity = buildEntity("TXN-RETRY-KO");

        when(repository.findByTransactionId("TXN-RETRY-KO")).thenReturn(Optional.empty());
        when(mapper.toEntity(dto)).thenReturn(entity);

        doThrow(new PersistenceException("lock request time out period exceeded"))
                .when(repository).persistAndFlush(entity);

        MonitoringFlussiDTO result = service.save(dto);

        verify(repository, times(5)).persistAndFlush(entity);
        assertNotNull(result);
        assertEquals("TXN-RETRY-KO", result.transactionId());
        assertEquals("ERROR_DB_RETRY_EXHAUSTED_SAVE", result.statusDescription());
    }

    @Test
    void save_nonTransientPersistenceError_returnsFallbackError() {
        MonitoringFlussiDTO dto = buildDto("TXN-DB-ERR");
        MonitoringFlussi entity = buildEntity("TXN-DB-ERR");

        when(repository.findByTransactionId("TXN-DB-ERR")).thenReturn(Optional.empty());
        when(mapper.toEntity(dto)).thenReturn(entity);

        doThrow(new PersistenceException("generic db error"))
                .when(repository).persistAndFlush(entity);

        MonitoringFlussiDTO result = service.save(dto);

        verify(repository).persistAndFlush(entity);
        assertNotNull(result);
        assertEquals("TXN-DB-ERR", result.transactionId());
        assertEquals("ERROR_DB_ERROR_SAVE", result.statusDescription());
    }

    @Test
    void save_unexpectedError_returnsFallbackError() {
        MonitoringFlussiDTO dto = buildDto("TXN-UNEXPECTED");

        when(repository.findByTransactionId("TXN-UNEXPECTED"))
                .thenThrow(new RuntimeException("boom"));

        MonitoringFlussiDTO result = service.save(dto);

        assertNotNull(result);
        assertEquals("TXN-UNEXPECTED", result.transactionId());
        assertEquals("ERROR_UNEXPECTED_SAVE", result.statusDescription());
        verify(repository, never()).persistAndFlush(any(MonitoringFlussi.class));
    }

    @SuppressWarnings("unchecked")
	@Test
    void save_duplicateKey_returnsExistingRecord() {
        MonitoringFlussiDTO request = buildDto("TXN-DUP");
        MonitoringFlussi toPersist = buildEntity("TXN-DUP");
        MonitoringFlussi existing = buildEntity("TXN-DUP");

        MonitoringFlussiDTO existingDto = MonitoringFlussiDTO.builder()
                .transactionId("TXN-DUP")
                .correlationId("TXN-DUP")
                .flowId("FLOW-001")
                .dayNumber(20260522)
                .monthNumber(202605)
                .granularita("G")
                .sender("PMR")
                .isWorkaround(false)
                .statusDescription("ACQUISITO")
                .fileFlusso("{file}")
                .fileOutput("{out}")
                .status(220)
                .actionDate(LocalDateTime.of(2026, 5, 22, 10, 0))
                .userAction("batch")
                .isDeleted(0)
                .build();

        when(repository.findByTransactionId("TXN-DUP"))
                .thenReturn(Optional.empty(), Optional.of(existing));
        when(mapper.toEntity(request)).thenReturn(toPersist);
        when(mapper.toDto(existing)).thenReturn(existingDto);

        doThrow(new PersistenceException("2627 duplicate"))
                .when(repository).persistAndFlush(toPersist);

        MonitoringFlussiDTO result = service.save(request);

        verify(repository).persistAndFlush(toPersist);
        verify(repository, times(2)).findByTransactionId("TXN-DUP");
        verify(mapper).toDto(existing);

        assertNotNull(result);
        assertEquals("TXN-DUP", result.transactionId());
        assertEquals(220, result.status());
        assertEquals("ACQUISITO", result.statusDescription());
    }

    @SuppressWarnings("unchecked")
	@Test
    void save_duplicateKey_whenRecordNotFound_returnsFallbackError() {
        MonitoringFlussiDTO dto = buildDto("TXN-DUP-404");
        MonitoringFlussi entity = buildEntity("TXN-DUP-404");

        when(repository.findByTransactionId("TXN-DUP-404"))
                .thenReturn(Optional.empty(), Optional.empty());
        when(mapper.toEntity(dto)).thenReturn(entity);

        doThrow(new PersistenceException("2601 duplicate"))
                .when(repository).persistAndFlush(entity);

        MonitoringFlussiDTO result = service.save(dto);

        verify(repository).persistAndFlush(entity);
        verify(repository, times(2)).findByTransactionId("TXN-DUP-404");

        assertNotNull(result);
        assertEquals("TXN-DUP-404", result.transactionId());
        assertEquals("ERROR_DUPLICATE_BUT_NOT_FOUND", result.statusDescription());
    }

    @Test
    void save_duplicateKey_whenReadFails_returnsFallbackError() {
        MonitoringFlussiDTO dto = buildDto("TXN-DUP-ERR");
        MonitoringFlussi entity = buildEntity("TXN-DUP-ERR");

        when(repository.findByTransactionId("TXN-DUP-ERR"))
                .thenReturn(Optional.empty())
                .thenThrow(new RuntimeException("read error"));
        when(mapper.toEntity(dto)).thenReturn(entity);

        doThrow(new PersistenceException("2627 duplicate"))
                .when(repository).persistAndFlush(entity);

        MonitoringFlussiDTO result = service.save(dto);

        verify(repository).persistAndFlush(entity);
        verify(repository, times(2)).findByTransactionId("TXN-DUP-ERR");

        assertNotNull(result);
        assertEquals("TXN-DUP-ERR", result.transactionId());
        assertEquals("ERROR_ERROR_READ_AFTER_DUPLICATE", result.statusDescription());
    }

    @Test
    void processSaveMonitoringFlussi_validPayload_savesDto() {
        MonitoringFlussi entity = buildEntity("TXN-KAFKA");
        MonitoringFlussiDTO dto = buildDto("TXN-KAFKA");

        when(repository.findByTransactionId("TXN-KAFKA")).thenReturn(Optional.empty());
        when(mapper.toEntity(any(MonitoringFlussiDTO.class))).thenReturn(entity);
        doNothing().when(repository).persistAndFlush(entity);
        when(mapper.toDto(entity)).thenReturn(dto);

        String json = "{\"transactionId\":\"TXN-KAFKA\",\"correlationId\":\"TXN-KAFKA\","
                + "\"flowId\":\"FLOW-001\",\"dayNumber\":20260522,\"monthNumber\":202605,"
                + "\"granularita\":\"G\",\"sender\":\"PMR\",\"isWorkaround\":false,"
                + "\"statusDescription\":\"OK\",\"status\":1,"
                + "\"actionDate\":\"2026-05-22T10:00:00\",\"userAction\":\"batch\",\"isDeleted\":0}";

        assertDoesNotThrow(() -> service.processSaveMonitoringFlussi(json));
        verify(repository).persistAndFlush(entity);
    }

    @Test
    void processSaveMonitoringFlussi_invalidPayload_doesNotThrow() {
        assertDoesNotThrow(() -> service.processSaveMonitoringFlussi("invalid json {{"));
        verifyNoInteractions(repository, mapper);
    }
}
