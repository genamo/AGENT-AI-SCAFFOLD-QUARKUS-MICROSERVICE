package it.eng.snam.pmr.common.dto;

import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

public record RemiConeDTO(
        boolean fullAccess,
        List<String> remiAssoluti
) {
    public Set<String> normalizedSet() {
        return remiAssoluti == null ? Set.of() :
                remiAssoluti.stream()
                        .filter(s -> s != null && !s.isBlank())
                        .map(s -> s.trim().toUpperCase(Locale.ROOT))
                        .collect(Collectors.toSet());
    }

    public boolean allows(String remi) {
        if (fullAccess) return true;
        if (remi == null || remi.isBlank()) return true;
        return normalizedSet().contains(remi.trim().toUpperCase(Locale.ROOT));
    }

    public boolean allowsAll(Collection<String> remiList) {
        if (fullAccess) return true;
        if (remiList == null || remiList.isEmpty()) return true;
        Set<String> allowed = normalizedSet();
        return remiList.stream()
                .filter(s -> s != null && !s.isBlank())
                .map(s -> s.trim().toUpperCase(Locale.ROOT))
                .allMatch(allowed::contains);
    }
}
