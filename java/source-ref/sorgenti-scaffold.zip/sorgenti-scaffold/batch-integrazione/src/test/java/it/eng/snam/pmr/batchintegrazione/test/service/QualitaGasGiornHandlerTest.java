package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import it.eng.snam.pmr.batchintegrazione.dto.datifiscali.VerbaliMisuraGiornDto;
import it.eng.snam.pmr.batchintegrazione.dto.flussi.VerbaliMisuraGiornPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.DatiFiscaliService;
import it.eng.snam.pmr.batchintegrazione.service.handler.VerbaliMisuraGiornHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;

class VerbaliMisuraGiornHandlerTest {

    private VerbaliMisuraGiornHandler handler;
    private DatiFiscaliService datiFiscaliService;

    @BeforeEach
    void setUp() throws Exception {
        handler = new VerbaliMisuraGiornHandler();
        datiFiscaliService = Mockito.mock(DatiFiscaliService.class);
        injectField(VerbaliMisuraGiornHandler.class, handler, "datiFiscaliService", datiFiscaliService);
    }

    @Test
    void getFlowTypeReturnsExpectedValue() {
        assertEquals(Constants.Flussi.VERBALI_MISURA_GIORN_FLOW, handler.getFlowType());
    }

    @Test
    void getDtoClassReturnsExpectedType() throws Exception {
        Class<?> dtoClass = (Class<?>) invokeProtectedMethod(handler, "getDtoClass", new Class<?>[0]);
        assertEquals(VerbaliMisuraGiornPayloadDto.class, dtoClass);
    }

    @Test
    void handleInsertCallsSaveWhenDataIsPresent() {
        VerbaliMisuraGiornDto data = Mockito.mock(VerbaliMisuraGiornDto.class);

        VerbaliMisuraGiornPayloadDto dto = VerbaliMisuraGiornPayloadDto.builder()
                .summerTransactionId("TX-101")
                .operation("INSERT")
                .data(List.of(data))
                .build();

        assertDoesNotThrow(() -> invokeProtectedMethod(handler, "handle", new Class<?>[] { VerbaliMisuraGiornPayloadDto.class }, dto));

        verify(datiFiscaliService).saveVerbaleMisuraGiorn(data);
    }

    @Test
    void handleDeleteCallsDeleteWhenDataIsPresent() {
        VerbaliMisuraGiornDto data = Mockito.mock(VerbaliMisuraGiornDto.class);
        String remiAssoluto = "1001";
        LocalDateTime dataVolPunta = LocalDateTime.of(2026, 7, 15, 0, 0);
        LocalDateTime dataIniVerb = LocalDateTime.of(2026, 7, 14, 0, 0);

        Mockito.when(data.remiAssoluto()).thenReturn(remiAssoluto);
        Mockito.when(data.dataVolPunta()).thenReturn(dataVolPunta);
        Mockito.when(data.dataIniVerb()).thenReturn(dataIniVerb);

        VerbaliMisuraGiornPayloadDto dto = VerbaliMisuraGiornPayloadDto.builder()
                .summerTransactionId("TX-102")
                .operation("DELETE")
                .data(List.of(data))
                .build();

        assertDoesNotThrow(() -> invokeProtectedMethod(handler, "handle", new Class<?>[] { VerbaliMisuraGiornPayloadDto.class }, dto));

        verify(datiFiscaliService).deleteVerbaleMisuraGiorn(remiAssoluto, dataVolPunta, dataIniVerb);
    }

    @Test
    void handleInsertDoesNothingWhenDataIsNull() {
        VerbaliMisuraGiornPayloadDto dto = VerbaliMisuraGiornPayloadDto.builder()
                .summerTransactionId("TX-103")
                .operation("INSERT")
                .data(null)
                .build();

        assertDoesNotThrow(() -> invokeProtectedMethod(handler, "handle", new Class<?>[] { VerbaliMisuraGiornPayloadDto.class }, dto));

        verifyNoInteractions(datiFiscaliService);
    }

    @Test
    void handleDeleteDoesNothingWhenDataIsEmpty() {
        VerbaliMisuraGiornPayloadDto dto = VerbaliMisuraGiornPayloadDto.builder()
                .summerTransactionId("TX-104")
                .operation("DELETE")
                .data(List.of())
                .build();

        assertDoesNotThrow(() -> invokeProtectedMethod(handler, "handle", new Class<?>[] { VerbaliMisuraGiornPayloadDto.class }, dto));

        verifyNoInteractions(datiFiscaliService);
    }

    @Test
    void handleThrowsExceptionWhenOperationIsNull() {
        VerbaliMisuraGiornPayloadDto dto = VerbaliMisuraGiornPayloadDto.builder()
                .summerTransactionId("TX-105")
                .operation(null)
                .data(List.of())
                .build();

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> invokeProtectedMethod(handler, "handle", new Class<?>[] { VerbaliMisuraGiornPayloadDto.class }, dto)
        );

        assertEquals("Operation field is required", ex.getMessage());
        verifyNoInteractions(datiFiscaliService);
    }

    @Test
    void handleThrowsExceptionWhenOperationIsEmpty() {
        VerbaliMisuraGiornPayloadDto dto = VerbaliMisuraGiornPayloadDto.builder()
                .summerTransactionId("TX-106")
                .operation("")
                .data(List.of())
                .build();

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> invokeProtectedMethod(handler, "handle", new Class<?>[] { VerbaliMisuraGiornPayloadDto.class }, dto)
        );

        assertEquals("Operation field is required", ex.getMessage());
        verifyNoInteractions(datiFiscaliService);
    }

    @Test
    void handleThrowsExceptionWhenOperationIsInvalid() {
        VerbaliMisuraGiornPayloadDto dto = VerbaliMisuraGiornPayloadDto.builder()
                .summerTransactionId("TX-107")
                .operation("UPDATE")
                .data(List.of())
                .build();

        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> invokeProtectedMethod(handler, "handle", new Class<?>[] { VerbaliMisuraGiornPayloadDto.class }, dto)
        );

        assertEquals("Invalid operation: UPDATE", ex.getMessage());
        verifyNoInteractions(datiFiscaliService);
    }

    private static void injectField(Class<?> declaringClass, Object target, String fieldName, Object value) throws Exception {
        Field field = declaringClass.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private static Object invokeProtectedMethod(Object target, String methodName, Class<?>[] parameterTypes, Object... args) throws Exception {
        try {
            Method method = target.getClass().getDeclaredMethod(methodName, parameterTypes);
            method.setAccessible(true);
            return method.invoke(target, args);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof Exception ex) {
                throw ex;
            }
            throw e;
        }
    }
}
