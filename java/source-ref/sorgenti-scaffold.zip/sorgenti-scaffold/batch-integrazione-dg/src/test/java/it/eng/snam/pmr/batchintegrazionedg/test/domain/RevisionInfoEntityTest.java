package it.eng.snam.pmr.batchintegrazionedg.test.domain;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import it.eng.snam.pmr.batchintegrazionedg.domain.RevisionInfo;

class RevisionInfoEntityTest {

    @Test
    void gettersAndSetters_workCorrectly() {
        RevisionInfo r = new RevisionInfo();
        r.setRev(1);
        r.setRevtstmp(1234567890L);

        assertEquals(1, r.getRev());
        assertEquals(1234567890L, r.getRevtstmp());
    }

    @Test
    void nullsInitially() {
        RevisionInfo r = new RevisionInfo();
        assertNull(r.getRev());
        assertNull(r.getRevtstmp());
    }
}
