package it.eng.snam.pmr.batchintegrazionedg.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazionedg.domain.DlqFlusso;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoRequestDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoResponseDTO;
import it.eng.snam.pmr.batchintegrazionedg.repository.DlqFlussoRepository;
import it.eng.snam.pmr.batchintegrazionedg.service.DlqFlussoService;
import jakarta.persistence.PersistenceException;

@ExtendWith(MockitoExtension.class)
class DlqFlussoServiceTest {

    @Mock
    DlqFlussoRepository repository;

    @InjectMocks
    DlqFlussoService service;

    @Test
    void save_newRecord_persistsEntityWithDefaultsAndTruncation() throws Exception {
        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder()
                .transactionId(repeat("T", 60))
                .flowId(repeat("F", 60))
                .controlKey(repeat("C", 80))
                .keyLogic(repeat("K", 300))
                .originalTopic(repeat("O", 300))
                .originalPartition(2)
                .originalOffset(99L)
                .processType(repeat("P", 120))
                .messageKey(repeat("M", 300))
                .errorType(repeat("E", 150))
                .errorMessage(repeat("X", 2200))
                .payload(repeat("Y", 5000))
                .status(" ")
                .build();

        doAnswer(invocation -> {
            DlqFlusso entity = invocation.getArgument(0);
            setId(entity, 123L);
            return null;
        }).when(repository).persistAndFlush(any(DlqFlusso.class));

        DlqFlussoResponseDTO response = service.save(request);

        ArgumentCaptor<DlqFlusso> captor = ArgumentCaptor.forClass(DlqFlusso.class);
        verify(repository).persistAndFlush(captor.capture());

        DlqFlusso persisted = captor.getValue();

        assertEquals(50, persisted.getTransactionId().length());
        assertEquals(50, persisted.getFlowId().length());
        assertEquals(64, persisted.getControlKey().length());
        assertEquals(255, persisted.getKeyLogic().length());
        assertEquals(255, persisted.getOriginalTopic().length());
        assertEquals(100, persisted.getProcessType().length());
        assertEquals(255, persisted.getMessageKey().length());
        assertEquals(100, persisted.getErrorType().length());
        assertEquals(2000, persisted.getErrorMessage().length());
        assertEquals(5000, persisted.getPayload().length());

        assertEquals(Integer.valueOf(2), persisted.getOriginalPartition());
        assertEquals(Long.valueOf(99L), persisted.getOriginalOffset());
        assertEquals("RECEIVED", persisted.getStatus());
        assertEquals("SYSTEM", persisted.getUserAction());
        assertEquals(Integer.valueOf(0), persisted.getIsDeleted());

        assertTrue(response.saved());
        assertEquals(123L, response.id());
        assertEquals(repeat("T", 50), response.transactionId());
        assertEquals("RECEIVED", response.status());
    }

    @Test
    void save_withExplicitStatus_preservesStatus() {
        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder()
                .transactionId("TXN-001")
                .flowId("FLOW-001")
                .controlKey("CK-001")
                .status("ERROR")
                .build();

        DlqFlussoResponseDTO response = service.save(request);

        ArgumentCaptor<DlqFlusso> captor = ArgumentCaptor.forClass(DlqFlusso.class);
        verify(repository).persistAndFlush(captor.capture());

        DlqFlusso persisted = captor.getValue();
        assertEquals("ERROR", persisted.getStatus());

        assertTrue(response.saved());
        assertEquals("TXN-001", response.transactionId());
        assertEquals("ERROR", response.status());
    }

    @Test
    void save_retryablePersistenceError_retriesAndEventuallySucceeds() {
        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder()
                .transactionId("TXN-002")
                .flowId("FLOW-002")
                .controlKey("CK-002")
                .build();

        AtomicInteger calls = new AtomicInteger();

        doAnswer(invocation -> {
            if (calls.getAndIncrement() == 0) {
                throw new PersistenceException("1205");
            }
            return null;
        }).when(repository).persistAndFlush(any(DlqFlusso.class));

        DlqFlussoResponseDTO response = service.save(request);

        verify(repository, times(2)).persistAndFlush(any(DlqFlusso.class));
        assertTrue(response.saved());
        assertEquals("TXN-002", response.transactionId());
        assertEquals("RECEIVED", response.status());
    }

    @Test
    void save_retryablePersistenceError_exhausted_returnsFallbackError() {
        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder()
                .transactionId("TXN-003")
                .flowId("FLOW-003")
                .controlKey("CK-003")
                .build();

        doThrow(new PersistenceException("lock request time out period exceeded"))
                .when(repository).persistAndFlush(any(DlqFlusso.class));

        DlqFlussoResponseDTO response = service.save(request);

        verify(repository, times(5)).persistAndFlush(any(DlqFlusso.class));
        assertFalse(response.saved());
        assertNull(response.id());
        assertEquals("TXN-003", response.transactionId());
        assertEquals("ERROR_DB_RETRY_EXHAUSTED_SAVE", response.status());
    }

    @Test
    void save_nonTransientPersistenceError_returnsFallbackError() {
        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder()
                .transactionId("TXN-004")
                .flowId("FLOW-004")
                .controlKey("CK-004")
                .build();

        doThrow(new PersistenceException("generic db error"))
                .when(repository).persistAndFlush(any(DlqFlusso.class));

        DlqFlussoResponseDTO response = service.save(request);

        verify(repository).persistAndFlush(any(DlqFlusso.class));
        assertFalse(response.saved());
        assertNull(response.id());
        assertEquals("TXN-004", response.transactionId());
        assertEquals("ERROR_DB_ERROR_SAVE", response.status());
    }

    @Test
    void save_unexpectedError_returnsFallbackError() {
        DlqFlussoRequestDTO request = DlqFlussoRequestDTO.builder()
                .transactionId("TXN-005")
                .flowId("FLOW-005")
                .controlKey("CK-005")
                .build();

        doThrow(new RuntimeException("unexpected"))
                .when(repository).persistAndFlush(any(DlqFlusso.class));

        DlqFlussoResponseDTO response = service.save(request);

        verify(repository).persistAndFlush(any(DlqFlusso.class));
        assertFalse(response.saved());
        assertNull(response.id());
        assertEquals("TXN-005", response.transactionId());
        assertEquals("ERROR_UNEXPECTED_SAVE", response.status());
    }

    @Test
    void findAllByTransactionId_mapsEntitiesToDtos() {
        DlqFlusso entity = dlqEntity(1L, "TXN-100", "FLOW-100", "CK-100", "ERROR");

        when(repository.findAllByTransactionId("TXN-100"))
                .thenReturn(List.of(entity));

        List<DlqFlussoDTO> result = service.findAllByTransactionId("TXN-100");

        verify(repository).findAllByTransactionId("TXN-100");
        assertEquals(1, result.size());
        assertEquals("TXN-100", result.get(0).transactionId());
        assertEquals("FLOW-100", result.get(0).flowId());
        assertEquals("CK-100", result.get(0).controlKey());
        assertEquals("ERROR", result.get(0).status());
    }

    @Test
    void findByStatus_mapsEntitiesToDtos() {
        DlqFlusso entity = dlqEntity(2L, "TXN-101", "FLOW-101", "CK-101", "ERROR");

        when(repository.findByStatus("ERROR"))
                .thenReturn(List.of(entity));

        List<DlqFlussoDTO> result = service.findByStatus("ERROR");

        verify(repository).findByStatus("ERROR");
        assertEquals(1, result.size());
        assertEquals("ERROR", result.get(0).status());
    }

    @Test
    void findLatest_mapsEntitiesToDtos() {
        DlqFlusso entity = dlqEntity(3L, "TXN-102", "FLOW-102", "CK-102", "RECEIVED");

        when(repository.findLatest(10))
                .thenReturn(List.of(entity));

        List<DlqFlussoDTO> result = service.findLatest(10);

        verify(repository).findLatest(10);
        assertEquals(1, result.size());
        assertEquals(3L, result.get(0).id());
    }

    @Test
    void findByControlKey_mapsEntitiesToDtos() {
        DlqFlusso entity = dlqEntity(4L, "TXN-103", "FLOW-103", "CK-103", "ERROR");

        when(repository.findByControlKey("CK-103"))
                .thenReturn(List.of(entity));

        List<DlqFlussoDTO> result = service.findByControlKey("CK-103");

        verify(repository).findByControlKey("CK-103");
        assertEquals(1, result.size());
        assertEquals("CK-103", result.get(0).controlKey());
    }

    @Test
    void countByControlKey_delegatesToRepository() {
        when(repository.countByControlKey("CK-200"))
                .thenReturn(7L);

        long result = service.countByControlKey("CK-200");

        verify(repository).countByControlKey("CK-200");
        assertEquals(7L, result);
    }

    private DlqFlusso dlqEntity(
            Long id,
            String transactionId,
            String flowId,
            String controlKey,
            String status) {

        DlqFlusso entity = new DlqFlusso();
        setId(entity, id);
        entity.setTransactionId(transactionId);
        entity.setFlowId(flowId);
        entity.setControlKey(controlKey);
        entity.setKeyLogic("KL");
        entity.setOriginalTopic("topic");
        entity.setOriginalPartition(1);
        entity.setOriginalOffset(10L);
        entity.setProcessType("PROC");
        entity.setMessageKey("MSG");
        entity.setErrorType("TECH");
        entity.setErrorMessage("Errore");
        entity.setPayload("{json}");
        entity.setStatus(status);
        entity.setUserAction("SYSTEM");
        entity.setIsDeleted(0);
        return entity;
    }

    private static void setId(DlqFlusso entity, Long id) {
        try {
            Field field = DlqFlusso.class.getDeclaredField("id");
            field.setAccessible(true);
            field.set(entity, id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static String repeat(String value, int times) {
        return value.repeat(times);
    }
}
