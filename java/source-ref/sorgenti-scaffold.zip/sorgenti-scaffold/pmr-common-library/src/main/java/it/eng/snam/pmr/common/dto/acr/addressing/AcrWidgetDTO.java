package it.eng.snam.pmr.common.dto.acr.addressing;

import lombok.Builder;

@Builder
public record AcrWidgetDTO(
        Integer widgetId,
        String widgetName,
        String widgetDescription
) {}
