package it.eng.snam.pmr.batchintegrazionedg.test.resource;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;

import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.TestProfile;
import io.restassured.http.ContentType;
import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringFlussiDTO;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringFlussiService;
import it.eng.snam.pmr.batchintegrazionedg.test.service.NoSecurityTestProfile;

@QuarkusTest
@TestProfile(NoSecurityTestProfile.class)
class MonitoringFlussiResourceTest {

    @InjectMock
    MonitoringFlussiService service;

    private MonitoringFlussiDTO buildDto(String txId) {
        return MonitoringFlussiDTO.builder()
                .transactionId(txId)
                .correlationId(txId)
                .flowId("FLOW-001")
                .dayNumber(20260522)
                .monthNumber(202605)
                .granularita("G")
                .sender("PMR")
                .isWorkaround(false)
                .statusDescription("OK")
                .status(1)
                .actionDate(LocalDateTime.now())
                .userAction("batch")
                .isDeleted(0)
                .build();
    }

    // ====== GET ALL ======

    @Test
    void getAll_withData_returns200() {
        when(service.getAll()).thenReturn(List.of(buildDto("TXN-001")));

        given()
            .when().get("/monitoring-flussi")
            .then()
            .statusCode(200);
    }

    @Test
    void getAll_empty_returns200() {
        when(service.getAll()).thenReturn(List.of());

        given()
            .when().get("/monitoring-flussi")
            .then()
            .statusCode(200);
    }

    // ====== GET BY ID ======

    @Test
    void getById_found_returns200() {
        when(service.getById(1L)).thenReturn(buildDto("TXN-001"));

        given()
            .when().get("/monitoring-flussi/1")
            .then()
            .statusCode(200);
    }

    @Test
    void getById_notFound_returns404() {
        when(service.getById(99L)).thenReturn(null);

        given()
            .when().get("/monitoring-flussi/99")
            .then()
            .statusCode(404);
    }

    @Test
    void getById_invalidId_returns400() {
        given()
            .when().get("/monitoring-flussi/0")
            .then()
            .statusCode(400);
    }

    // ====== GET BY TRANSACTION ID ======

    @Test
    void getByTransactionId_found_returns200() {
        when(service.getByTransactionId("TXN-001"))
                .thenReturn(buildDto("TXN-001"));

        given()
            .when().get("/monitoring-flussi/transaction/TXN-001")
            .then()
            .statusCode(200);
    }

    @Test
    void getByTransactionId_notFound_returns404() {
        when(service.getByTransactionId("UNKNOWN")).thenReturn(null);

        given()
            .when().get("/monitoring-flussi/transaction/UNKNOWN")
            .then()
            .statusCode(404);
    }

    // ====== GET LAST EXECUTIONS ======

    @Test
    void getLastExecutions_defaultLimit_returns200() {
        when(service.getLastExecutions(10))
                .thenReturn(List.of(buildDto("TXN-001")));

        given()
            .when().get("/monitoring-flussi/last-executions")
            .then()
            .statusCode(200);
    }

    @Test
    void getLastExecutions_customLimit_returns200() {
        when(service.getLastExecutions(5)).thenReturn(List.of());

        given()
            .queryParam("limit", "5")
            .when().get("/monitoring-flussi/last-executions")
            .then()
            .statusCode(200);
    }

    @Test
    void getLastExecutions_limitZero_returns400() {
        given()
            .queryParam("limit", "0")
            .when().get("/monitoring-flussi/last-executions")
            .then()
            .statusCode(400);
    }

    @Test
    void getLastExecutions_negativeLimit_returns400() {
        given()
            .queryParam("limit", "-1")
            .when().get("/monitoring-flussi/last-executions")
            .then()
            .statusCode(400);
    }

    // ====== GET BY PERIOD ======

    @Test
    void getByPeriod_withParams_returns200() {
        when(service.getByPeriod(202605, 20260522))
                .thenReturn(List.of(buildDto("TXN-001")));

        given()
            .queryParam("monthNumber", "202605")
            .queryParam("dayNumber", "20260522")
            .when().get("/monitoring-flussi/period")
            .then()
            .statusCode(200);
    }

    @Test
    void getByPeriod_noParams_returns200() {
        when(service.getByPeriod(null, null)).thenReturn(List.of());

        given()
            .when().get("/monitoring-flussi/period")
            .then()
            .statusCode(200);
    }

    // ====== SAVE ======

    @Test
    void save_newRecord_returns201() {
        MonitoringFlussiDTO dto = buildDto("TXN-NEW");

        when(service.getByTransactionId("TXN-NEW")).thenReturn(null);
        when(service.save(any())).thenReturn(dto);

        given()
            .contentType(ContentType.JSON)
            .body("{\"transactionId\":\"TXN-NEW\",\"correlationId\":\"TXN-NEW\"," +
                  "\"flowId\":\"FLOW-001\",\"dayNumber\":20260522,\"monthNumber\":202605," +
                  "\"granularita\":\"G\",\"sender\":\"PMR\",\"isWorkaround\":false," +
                  "\"statusDescription\":\"OK\",\"status\":1," +
                  "\"actionDate\":\"2026-05-22T10:00:00\",\"userAction\":\"batch\",\"isDeleted\":0}")
            .when().post("/monitoring-flussi/save")
            .then()
            .statusCode(201);
    }

    @Test
    void save_existingRecord_returns200() {
        MonitoringFlussiDTO dto = buildDto("TXN-EXIST");

        when(service.getByTransactionId("TXN-EXIST")).thenReturn(dto);
        when(service.save(any())).thenReturn(dto);

        given()
            .contentType(ContentType.JSON)
            .body("{\"transactionId\":\"TXN-EXIST\",\"correlationId\":\"TXN-EXIST\"," +
                  "\"flowId\":\"FLOW-001\",\"dayNumber\":20260522,\"monthNumber\":202605," +
                  "\"granularita\":\"G\",\"sender\":\"PMR\",\"isWorkaround\":false," +
                  "\"statusDescription\":\"OK\",\"status\":1," +
                  "\"actionDate\":\"2026-05-22T10:00:00\",\"userAction\":\"batch\",\"isDeleted\":0}")
            .when().post("/monitoring-flussi/save")
            .then()
            .statusCode(200);
    }

    // ====== CUSTOM SEARCH ======

    @Test
    void findByCustomSearch_withCriteria_returns200() {
        when(service.findByCustomSearch(any()))
                .thenReturn(List.of(buildDto("TXN-001")));

        given()
            .contentType(ContentType.JSON)
            .body("{\"flowId\":\"FLOW-001\",\"status\":1}")
            .when().post("/monitoring-flussi/search")
            .then()
            .statusCode(200);
    }

    @Test
    void findByCustomSearch_emptyResult_returns200() {
        when(service.findByCustomSearch(any())).thenReturn(List.of());

        given()
            .contentType(ContentType.JSON)
            .body("{}")
            .when().post("/monitoring-flussi/search")
            .then()
            .statusCode(200);
    }

    // ====== HEADERS ======

    @Test
    void getAll_responseHeaders_present() {
        when(service.getAll()).thenReturn(List.of());

        given()
            .when().get("/monitoring-flussi")
            .then()
            .statusCode(200)

            // ✅ FIX DEFINITIVO
            .header("KEY-LOGIC", notNullValue())
            .header("TRANSACTION-ID", notNullValue())
            .header("MOD-ASYNC", notNullValue())
            .header("PROCESS-TYPE", notNullValue());
    }
}
