package it.eng.snam.pmr.batchintegrazionedg.kafka;

import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.CreateTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.errors.TopicExistsException;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;

import io.quarkus.runtime.StartupEvent;
import it.eng.snam.pmr.batchintegrazionedg.service.TopicService;
import it.eng.snam.pmr.batchintegrazionedg.utils.Constants.Topic;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;

@ApplicationScoped
public class DevKafkaTopicInitializer {

    private static final Logger LOG = Logger.getLogger(DevKafkaTopicInitializer.class);
    private static final long ADMIN_TIMEOUT_SECONDS = 10;

    @Inject
    TopicService topicService;

    @ConfigProperty(name = "kafka.bootstrap.servers")
    String bootstrapServers;

    @ConfigProperty(name = "kafka.topics.auto-create", defaultValue = "false")
    boolean autoCreateTopics;

    @ConfigProperty(name = "kafka.topics.partitions", defaultValue = "1")
    int partitions;

    @ConfigProperty(name = "kafka.topics.replication-factor", defaultValue = "1")
    short replicationFactor;

    void onStart(@Observes StartupEvent event) {

        if (!autoCreateTopics) {
            LOG.debug("Kafka DEV topic auto-creation disabled");
            return;
        }

        LOG.info("DEV profile detected -> Kafka topic auto-creation enabled");

        List<String> topicsToEnsure = List.of(
                topicService.getRealTopic(Topic.INTEGRAZIONE_FLUSSI_TOPIC)
        ).stream()
         .filter(t -> t != null && !t.isBlank())
         .distinct()
         .toList();

        if (topicsToEnsure.isEmpty()) {
            LOG.warn("No DEV Kafka topics to ensure (topic list is empty)");
            return;
        }

        Properties props = new Properties();
        props.put("bootstrap.servers", bootstrapServers);

        try (AdminClient admin = AdminClient.create(props)) {

            Set<String> existingTopics = admin.listTopics()
                    .names()
                    .get(ADMIN_TIMEOUT_SECONDS, TimeUnit.SECONDS);

            List<NewTopic> topicsToCreate = topicsToEnsure.stream()
                    .filter(t -> !existingTopics.contains(t))
                    .map(t -> new NewTopic(t, partitions, replicationFactor))
                    .toList();

            if (topicsToCreate.isEmpty()) {
                LOG.info("All DEV Kafka topics already exist");
                return;
            }

            CreateTopicsResult result = admin.createTopics(topicsToCreate);

            for (NewTopic nt : topicsToCreate) {
                try {
                    result.values()
                          .get(nt.name())
                          .get(ADMIN_TIMEOUT_SECONDS, TimeUnit.SECONDS);

                    LOG.infof("Kafka DEV topic created: %s (partitions=%d, rf=%d)",
                            nt.name(), partitions, replicationFactor);

                } catch (ExecutionException ee) {
                    Throwable cause = ee.getCause();

                    if (cause instanceof TopicExistsException) {
                        LOG.infof("Kafka DEV topic already exists (race condition ignored): %s", nt.name());
                    } else {
                        LOG.errorf(cause, "Error creating Kafka DEV topic: %s", nt.name());
                    }

                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt(); // ✅ fondamentale
                    LOG.errorf(ie, "Thread interrupted while creating Kafka topic: %s", nt.name());
                    return; // ✅ interrompi correttamente il flusso
                }
            }

        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt(); // ✅ fondamentale
            LOG.error("Thread interrupted while initializing Kafka topics", ie);

        } catch (ExecutionException ee) {
            LOG.error("Execution error while initializing Kafka topics", ee);

        } catch (Exception e) {
            LOG.error("Unexpected error while creating Kafka topics in DEV", e);
        }
    }
}