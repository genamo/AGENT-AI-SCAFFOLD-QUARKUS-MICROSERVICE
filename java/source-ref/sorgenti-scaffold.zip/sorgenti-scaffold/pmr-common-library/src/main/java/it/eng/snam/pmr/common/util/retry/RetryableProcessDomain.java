package it.eng.snam.pmr.common.util.retry;

import java.time.Duration;
import java.util.function.Predicate;

import it.eng.snam.pmr.common.dto.retry.RetryableProcessContext;
import it.eng.snam.pmr.common.functional.interfaces.ExceptionFactory;
import lombok.experimental.UtilityClass;

@UtilityClass
public class RetryableProcessDomain {

    public final Integer RETRY_LIMIT = 3;
    public final Duration RETRY_DELAY = Duration.ofSeconds(2L);
    public final Predicate<Throwable> RETRY_PREDICATE = throwable -> true;

    public final RetryableProcessContext DEFAULT = RetryableProcessContext.of("Retryable execution", ExceptionFactory.base());
    public final RetryableProcessContext REST_CLIENT = RetryableProcessContext.of("RestClient execution", ExceptionFactory.restClient());
    public final RetryableProcessContext KAFKA = RetryableProcessContext.of("Kafka execution", ExceptionFactory.kafka());
}
