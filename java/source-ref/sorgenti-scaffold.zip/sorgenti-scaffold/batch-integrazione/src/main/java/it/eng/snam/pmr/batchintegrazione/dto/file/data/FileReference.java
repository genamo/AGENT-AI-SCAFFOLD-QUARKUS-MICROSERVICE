package it.eng.snam.pmr.batchintegrazione.dto.file.data;

import java.io.Serial;
import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FileReference implements Serializable {

    @Serial
    private static final long serialVersionUID = 5210482962439740050L;

    private String fileName;
    private byte[] fileContent;
}
