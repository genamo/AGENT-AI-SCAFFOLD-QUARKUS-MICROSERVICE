package it.eng.snam.pmr.batchintegrazionedg.resource;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration.MonitoringIntegration;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringIntegrationService;
import it.eng.snam.pmr.common.annotation.LogPmr;
import it.eng.snam.pmr.common.util.Utility;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;

@LogPmr
@Path("/")
@RunOnVirtualThread
@RequiredArgsConstructor
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MonitoringIntegrationResource {

    private final MonitoringIntegrationService monitoringIntegrationService;
    private final Utility utility;

    @POST
    @Path("/monitoring-integration")
    public Response sendRequestGenerateSend(MonitoringIntegration integrationRequest) {
        return utility.ok(monitoringIntegrationService.sendRequestGenerateSend(integrationRequest));
    }
}
