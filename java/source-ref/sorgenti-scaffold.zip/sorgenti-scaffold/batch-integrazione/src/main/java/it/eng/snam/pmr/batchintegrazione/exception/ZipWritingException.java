package it.eng.snam.pmr.batchintegrazione.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class ZipWritingException extends BatchIntegrazioneException {
    @Serial
    private static final long serialVersionUID = -4196996167282257386L;
}
