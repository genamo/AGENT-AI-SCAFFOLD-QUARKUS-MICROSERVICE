package it.eng.snam.pmr.batchintegrazionedg.utils.kafka;

import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import it.eng.snam.pmr.batchintegrazionedg.kafka.KafkaTopic;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class KafkaTopicCacheInitializer {

    public Map<KafkaTopic, String> initialize(String prefix) {
        if (StringUtils.isBlank(prefix))
            throw new IllegalArgumentException("'kafka-settings.topics.prefix' not configured");

        Map<KafkaTopic, String> realTopics = Arrays.stream(KafkaTopic.values()).filter(topic -> topic != KafkaTopic.UNKNOWN).collect(
                Collectors.toMap(Function.identity(), topic -> prefix + "-" + topic.getTopic(),
                                 (existing, replacement) -> existing, () -> new EnumMap<>(KafkaTopic.class)));

        log.info("KafkaTopicCache initialized. prefix={} - realTopics={}", prefix, realTopics);
        return realTopics;
    }
}
