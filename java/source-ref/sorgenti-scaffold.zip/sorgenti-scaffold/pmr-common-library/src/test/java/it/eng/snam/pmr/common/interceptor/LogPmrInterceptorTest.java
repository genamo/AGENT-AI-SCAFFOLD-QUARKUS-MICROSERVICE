package it.eng.snam.pmr.common.interceptor;

import jakarta.interceptor.InvocationContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LogPmrInterceptorTest {

    private LogPmrInterceptor interceptor;

    @Mock
    InvocationContext ctx;

    @BeforeEach
    void setUp() {
        interceptor = new LogPmrInterceptor();
    }

    @Test
    void logMethodEntryExit_successPath_returnsResult() throws Exception {
        Method m = String.class.getMethod("toLowerCase");
        when(ctx.getMethod()).thenReturn(m);
        when(ctx.proceed()).thenReturn("result");

        Object result = interceptor.logMethodEntryExit(ctx);

        assertThat(result).isEqualTo("result");
        verify(ctx).proceed();
    }

    @Test
    void logMethodEntryExit_exceptionPath_rethrows() throws Exception {
        Method m = String.class.getMethod("toLowerCase");
        when(ctx.getMethod()).thenReturn(m);
        when(ctx.proceed()).thenThrow(new RuntimeException("boom"));

        assertThatThrownBy(() -> interceptor.logMethodEntryExit(ctx))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("boom");
    }

    @Test
    void logMethodEntryExit_nullReturnValue_returnsNull() throws Exception {
        Method m = String.class.getMethod("toLowerCase");
        when(ctx.getMethod()).thenReturn(m);
        when(ctx.proceed()).thenReturn(null);

        Object result = interceptor.logMethodEntryExit(ctx);
        assertThat(result).isNull();
    }
}
