package it.eng.snam.pmr.common.service;

import java.util.function.Supplier;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.MDC;

import com.fasterxml.jackson.core.type.TypeReference;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.common.client.AuthorizationClient;
import it.eng.snam.pmr.common.dto.acr.roles.AcrRolesResponseDTO;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.CommonConstants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class AcrRolesService extends AbstractService {

    private static final TypeReference<GenericResponse<AcrRolesResponseDTO>> ROLES_TYPE =
            new TypeReference<>() {};

    @Inject
    @RestClient
    AuthorizationClient authorizationClient;

    public AcrRolesResponseDTO getRolesWithUser(String jwtUserId) {
        return execute(
                "GET /acr/data-access/roles_with_user",
                () -> authorizationClient.getRolesWithUser(jwtUserId),
                ROLES_TYPE
        );
    }

    public AcrRolesResponseDTO getRoles(String bearer) {
        return execute(
                "GET /acr/data-access/roles",
                () -> authorizationClient.getRoles(bearer),
                ROLES_TYPE
        );
    }

    private <T> T execute(
            String operation,
            Supplier<Response> call,
            TypeReference<GenericResponse<T>> typeReference
    ) {
        String previousApi = (String) MDC.get(CommonConstants.LogParams.API);

        try {
            MDC.put(CommonConstants.LogParams.API, operation);

            return executeClientCall(call, typeReference);
        } finally {
            restoreApi(previousApi);
        }
    }

    private void restoreApi(String previousApi) {
        if (previousApi == null) {
            MDC.remove(CommonConstants.LogParams.API);
        } else {
            MDC.put(CommonConstants.LogParams.API, previousApi);
        }
    }
}
