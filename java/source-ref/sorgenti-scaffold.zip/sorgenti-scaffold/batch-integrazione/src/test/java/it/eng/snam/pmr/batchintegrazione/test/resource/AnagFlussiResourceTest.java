package it.eng.snam.pmr.batchintegrazione.test.resource;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.dto.AnagFlussiDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.resource.AnagFlussiResource;
import it.eng.snam.pmr.batchintegrazione.response.CustomResponse;
import it.eng.snam.pmr.batchintegrazione.service.AnagFlussiService;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class AnagFlussiResourceTest {

    @Mock AnagFlussiService service;
    @Mock Utility utility;
    @InjectMocks AnagFlussiResource resource;

    // ---- getAll ----

    @Test
    void getAll_emptyList_delegatesToUtility() {
        when(service.getAll()).thenReturn(List.of());
        Response resp = mock(Response.class);
        when(utility.okOrEmpty(List.of())).thenReturn(resp);
        assertSame(resp, resource.getAll());
    }

    @Test
    void getAll_withItems_delegatesToUtility() {
        AnagFlussiDTO dto = new AnagFlussiDTO(1L, "f1", null, null, null, null, null, null, null, null, null);
        List<AnagFlussiDTO> list = List.of(dto);
        when(service.getAll()).thenReturn(list);
        Response resp = mock(Response.class);
        when(utility.okOrEmpty(list)).thenReturn(resp);
        assertSame(resp, resource.getAll());
    }

    @Test
    void getAll_illegalArgument_returnsBadRequest() {
        when(service.getAll()).thenThrow(new IllegalArgumentException("bad param"));
        Response resp = mock(Response.class);
        when(utility.badRequest("bad param")).thenReturn(resp);
        assertSame(resp, resource.getAll());
        verify(service).getAll();
    }

    @Test
    void getAll_remoteCallException_returnsBadGateway() {
        RemoteCallException ex = new RemoteCallException("remote error");
        when(service.getAll()).thenThrow(ex);
        Response resp = mock(Response.class);
        when(utility.badGateway(ex)).thenReturn(resp);
        assertSame(resp, resource.getAll());
    }

    // ---- findByFlowId ----

    @Test
    void findByFlowId_null_returnsBadRequest() {
        Response resp = mock(Response.class);
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.findByFlowId(null));
        verify(service, never()).findByFlowId(any());
    }

    @Test
    void findByFlowId_blank_returnsBadRequest() {
        Response resp = mock(Response.class);
        when(utility.badRequest(anyString())).thenReturn(resp);
        assertSame(resp, resource.findByFlowId("   "));
        verify(service, never()).findByFlowId(any());
    }

    @Test
    void findByFlowId_found_delegatesToUtility() {
        CustomResponse<Optional<AnagFlussiDTO>> cr = new CustomResponse<>();
        cr.setResponseData(Optional.of(new AnagFlussiDTO(1L, "f1", null, null, null, null, null, null, null, null, null)));
        when(service.findByFlowId("f1")).thenReturn(cr);
        Response resp = mock(Response.class);
        when(utility.okOrNotFoundWithCustomMessage(any(), any())).thenReturn(resp);
        assertSame(resp, resource.findByFlowId("f1"));
    }

    @Test
    void findByFlowId_notFound_delegatesToUtility() {
        CustomResponse<Optional<AnagFlussiDTO>> cr = new CustomResponse<>();
        cr.setResponseData(Optional.empty());
        when(service.findByFlowId("missing")).thenReturn(cr);
        Response resp = mock(Response.class);
        when(utility.okOrNotFoundWithCustomMessage(any(), any())).thenReturn(resp);
        assertSame(resp, resource.findByFlowId("missing"));
    }

    @Test
    void findByFlowId_illegalArgument_returnsBadRequest() {
        when(service.findByFlowId("f1")).thenThrow(new IllegalArgumentException("bad"));
        Response resp = mock(Response.class);
        when(utility.badRequest("bad")).thenReturn(resp);
        assertSame(resp, resource.findByFlowId("f1"));
    }

    @Test
    void findByFlowId_remoteCallException_returnsBadGateway() {
        RemoteCallException ex = new RemoteCallException("remote");
        when(service.findByFlowId("f1")).thenThrow(ex);
        Response resp = mock(Response.class);
        when(utility.badGateway(ex)).thenReturn(resp);
        assertSame(resp, resource.findByFlowId("f1"));
    }
}
