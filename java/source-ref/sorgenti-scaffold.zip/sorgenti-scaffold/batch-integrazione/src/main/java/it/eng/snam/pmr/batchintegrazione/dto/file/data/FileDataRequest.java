package it.eng.snam.pmr.batchintegrazione.dto.file.data;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class FileDataRequest implements Serializable {

    @Serial
    private static final long serialVersionUID = -6819359510666817514L;

    private String executioner;
    private String activity;
    private List<FileReference> fileReferences;
    private String sourceSystem;
}

