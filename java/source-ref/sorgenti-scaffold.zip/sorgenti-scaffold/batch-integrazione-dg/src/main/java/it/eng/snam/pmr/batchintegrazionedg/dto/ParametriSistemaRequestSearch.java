package it.eng.snam.pmr.batchintegrazionedg.dto;

import java.time.LocalDate;
import java.util.List;

public record ParametriSistemaRequestSearch(
    LocalDate dataRiferimento,
    List<String> codici
) {}
