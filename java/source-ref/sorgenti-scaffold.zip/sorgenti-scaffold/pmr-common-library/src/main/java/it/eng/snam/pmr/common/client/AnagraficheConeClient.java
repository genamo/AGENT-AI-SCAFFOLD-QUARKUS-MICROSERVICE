package it.eng.snam.pmr.common.client;

import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/")
@RegisterRestClient(configKey = "anagrafiche-client")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface AnagraficheConeClient {

    @GET
    @Path("/an_remi-cone_getCurrentUser")
    Response getCurrentUserCone(@HeaderParam("Authorization") String bearer);

    @GET
    @Path("/an_remi-cone_get-by-external-user")
    Response getConeByExternalUser(
            @HeaderParam("Authorization") String bearer,
            @QueryParam("user-id") String userId
    );
}
