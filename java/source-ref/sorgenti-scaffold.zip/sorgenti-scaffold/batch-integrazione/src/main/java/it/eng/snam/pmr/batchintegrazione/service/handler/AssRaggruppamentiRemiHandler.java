package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.AssRaggruppamentiRemiPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.AnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class AssRaggruppamentiRemiHandler extends AbstractFlussoHandler<AssRaggruppamentiRemiPayloadDto> {

    @Inject
    AnagraficheService anagraficheService;

    @Override
    protected Class<AssRaggruppamentiRemiPayloadDto> getDtoClass() {
        return AssRaggruppamentiRemiPayloadDto.class;
    }

    @Override
    protected void handle(AssRaggruppamentiRemiPayloadDto dto) {
    	if(dto.operation() != null && !dto.operation().isEmpty()) {
    		switch (dto.operation()) {
			case "INSERT":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.saveAssRaggruppamentiRemi(dto.data().getFirst());
	        	}
				break;
			case "DELETE":
				if (dto.data() != null && !dto.data().isEmpty()) {
	        		anagraficheService.deleteAssRaggruppamentiRemi(dto.data().getFirst().remiAssoluto(), dto.data().getFirst().codiceRaggrRemi());
	        	}
				break;
			default:
				throw new IllegalArgumentException("Invalid operation: " + dto.operation());
			}
		}else {
			throw new IllegalArgumentException("Operation field is required");
		}	
        
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.ASS_RAGGRUPPAMENTI_REMI_FLOW;
    }
}