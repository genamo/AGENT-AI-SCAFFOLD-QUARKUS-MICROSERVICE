package it.eng.snam.pmr.batchintegrazione.kafka;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.eclipse.microprofile.reactive.messaging.Acknowledgment;
import org.eclipse.microprofile.reactive.messaging.Incoming;
import org.eclipse.microprofile.reactive.messaging.Message;
import org.jboss.logging.Logger;
import org.jboss.logging.MDC;

import io.smallrye.common.annotation.RunOnVirtualThread;
import io.smallrye.reactive.messaging.kafka.api.IncomingKafkaRecordMetadata;
import it.eng.snam.pmr.batchintegrazione.config.kafka.KafkaConsumerRuntimeConfig;
import it.eng.snam.pmr.batchintegrazione.dto.IdempotenzaRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.IdempotenzaResponseDTO;
import it.eng.snam.pmr.batchintegrazione.exception.ControlledDlqException;
import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.FlussiAnagraficheService;
import it.eng.snam.pmr.batchintegrazione.service.IdempotenzaService;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class KafkaGenericConsumer {

    private static final Logger LOG = Logger.getLogger(KafkaGenericConsumer.class);
    private static final AtomicBoolean SKIP_LOGGED = new AtomicBoolean(false);

    private static final int MAX_PAYLOAD_BYTES = 1_000_000;
    private static final long HANDLE_TIMEOUT_SECONDS = 30L;

    @Inject
    FlussiAnagraficheService flussiService;

    @Inject
    IdempotenzaService idempotenzaService;

    @Inject
    protected RequestHeadersContext headersCtx;

    @Inject
    KafkaConsumerRuntimeConfig kafkaConsumerRuntimeConfig;

    @Incoming("anag-remi-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAnagRemi(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("anag-clienti-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAnagClienti(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("ass-remi-clienti-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAssRemiClienti(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("ass-remi-titolari-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAssRemiTitolari(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("ass-remi-aop-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAssRemiAop(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("ass-stato-remi-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAssStatoRemi(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("ass-remi-bilancio-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAssRemiBilancio(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("anag-area-tec-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAreaTecnica(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("anag-polo-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAnagPolo(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("anag-macro-polo-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAnagMacroPolo(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("contatto-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeContatto(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("anag-raggruppamenti-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAnagRaggruppamenti(Message<byte[]> message) {
        return consumeWithDlq(message);
    }

    @Incoming("ass-raggruppamenti-remi-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAssRaggruppamentiRemi(Message<byte[]> message) {
        return consumeWithDlq(message);
    }
    
    //FLUSSI DATI FISCALI

    @Incoming("verbali-misura-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeVerbaliMisura(Message<byte[]> message) {
        return consumeWithDlq(message);
    }
    @Incoming("verbali-giorn-misura-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeVerbaliMisuraGiorn(Message<byte[]> message) {
        return consumeWithDlq(message);
    }
    
  //FLUSSI DATI PRIMARI

    @Incoming("qualita-gasday-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeQualitaGasday(Message<byte[]> message) {
        return consumeWithDlq(message);
    }
    @Incoming("analisi-qualita-gasday-flusso-in")
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    @RunOnVirtualThread
    public CompletionStage<Void> consumeAnalisiQualitaGasday(Message<byte[]> message) {
        return consumeWithDlq(message);
    }
    
    
    private CompletionStage<Void> consumeWithDlq(Message<byte[]> message) {
        if (kafkaConsumerRuntimeConfig.isSkipMessage()) {
            logSkipOnce();
            return message.ack();
        }

        try {
            handle(message);
            return message.ack();

        } catch (ControlledDlqException e) {
            LOG.warnf(
                    "Caso controllato verso DLQ code=%s transactionId=%s msg=%s",
                    e.getCode(),
                    e.getTransactionId(),
                    e.getMessage()
            );
            return message.nack(e);

        } catch (Exception e) {
            LOG.error("Errore non gestito nel consumer, nack verso DLQ Kafka", e);
            return message.nack(e);
        }
    }

    private void logSkipOnce() {
        if (SKIP_LOGGED.compareAndSet(false, true)) {
            LOG.warn("app.kafka.skip-message=true: tutti i messaggi Kafka verranno ACKati senza eseguire la logica del consumer.");
        }
    }

    private void handle(Message<byte[]> message) {
        IncomingKafkaRecordMetadata<?, ?> metadata =
                message.getMetadata(IncomingKafkaRecordMetadata.class).orElse(null);

        String topic = metadata != null ? metadata.getTopic() : "unknown";
        Headers headers = metadata != null ? metadata.getHeaders() : new RecordHeaders();
        int partition = metadata != null ? metadata.getPartition() : -1;
        long offset = metadata != null ? metadata.getOffset() : -1L;
        byte[] payloadBytes = message.getPayload();
        int size = payloadBytes == null ? 0 : payloadBytes.length;

        String flow = extractHeader(headers, Constants.KafkaHeaders.FLOW_TYPE);
        String transactionId = extractHeader(headers, Constants.KafkaHeaders.TRANSACTION_ID);
        String processType = extractHeader(headers, Constants.KafkaHeaders.PROCESS_TYPE);
        String messageKey = extractHeader(headers, Constants.KafkaHeaders.MESSAGE_KEY);

        // Validazioni obbligatorie
        if (size > MAX_PAYLOAD_BYTES) {
            LOG.errorf("Payload troppo grande (%d bytes) topic=%s", size, topic);
            return;
        }

        if (flow == null || flow.isBlank()) {
            throw new ControlledDlqException(
                    "FLOW_HEADER_MISSING",
                    transactionId,
                    "FLOW header mancante"
            );
        }

        if (!Constants.Flussi.isValidFlow(flow)) {
            throw new ControlledDlqException(
                    "FLOW_INVALID",
                    transactionId,
                    "Flow non valido: " + flow
            );
        }

        if (transactionId == null || transactionId.isBlank()) {
            throw new ControlledDlqException(
                    "TRANSACTION_ID_MISSING",
                    null,
                    "TRANSACTION_ID header mancante"
            );
        }

        String keyLogic = flow + "_" + topic + "_" + partition + "_" + offset;

        headersCtx.setTransactionId(transactionId);
        headersCtx.setProcessType(processType);
        headersCtx.setKeyLogic(keyLogic);

        MDC.put(Constants.LogParams.TN, transactionId);
        MDC.put(Constants.LogParams.KL, keyLogic);
        MDC.put(Constants.LogParams.PT, processType);
        MDC.put(Constants.LogParams.MK, messageKey);

        try {
            IdempotenzaResponseDTO startResp =
                    idempotenzaService.insert(buildIdempotenzaRequest(transactionId, flow, keyLogic, null, null));

            if (isTechnicalFallback(startResp)) {
                String status = startResp == null ? "null" : startResp.status();
                LOG.errorf(
                        "Fallback tecnico su insert idempotenza transactionId=%s flow=%s status=%s",
                        transactionId,
                        flow,
                        status
                );
                throw new RuntimeException("IDEMPOTENZA_START_FAILED: " + status);
            }

            if (isDuplicateOutcome(startResp)) {
                LOG.infof(
                        "Duplicate skipped transactionId=%s status=%s",
                        transactionId,
                        startResp.status()
                );
                throw new ControlledDlqException(
                        "DUPLICATE_TX",
                        transactionId,
                        "TRANSACTION_ID duplicato"
                );
            }

            String payload = payloadBytes == null
                    ? ""
                    : new String(payloadBytes, StandardCharsets.UTF_8);

            String finalFlow = flow;
            String finalTransactionId = transactionId;
            String finalKeyLogic = keyLogic;
            RequestHeadersContext.Snapshot snapshot = headersCtx.snapshot();

            try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
                Future<?> future = executor.submit(() -> {
                    headersCtx.restore(snapshot);
                    try {
                        flussiService.process(finalFlow, payload);
                    } finally {
                        headersCtx.clear();
                    }
                });

                try {
                    future.get(HANDLE_TIMEOUT_SECONDS, TimeUnit.SECONDS);

                    boolean completedUpdated = updateIdempotenzaSafe(
                            finalTransactionId,
                            finalFlow,
                            finalKeyLogic,
                            "COMPLETED",
                            null
                    );

                    if (!completedUpdated) {
                        LOG.errorf(
                                "Business completato ma chiusura idempotenza COMPLETED non riuscita transactionId=%s flow=%s",
                                finalTransactionId,
                                finalFlow
                        );
                    } else {
                        LOG.infof("Processing completato transactionId=%s", finalTransactionId);
                    }

                } catch (TimeoutException te) {
                    future.cancel(true);

                    LOG.errorf(
                            "Timeout (%ds) processing flow=%s transactionId=%s",
                            HANDLE_TIMEOUT_SECONDS,
                            finalFlow,
                            finalTransactionId
                    );

                    updateIdempotenzaSafe(finalTransactionId, finalFlow, finalKeyLogic, "ERROR", "TIMEOUT");
                    throw new RuntimeException("TIMEOUT", te);

                } catch (ExecutionException ee) {
                    Throwable cause = ee.getCause() != null ? ee.getCause() : ee;

                    LOG.error("Errore durante processing business", cause);

                    updateIdempotenzaSafe(
                            finalTransactionId,
                            finalFlow,
                            finalKeyLogic,
                            "ERROR",
                            safeMessage(cause)
                    );
                    throw new RuntimeException("EXECUTION", ee);

                } catch (InterruptedException ie) {
                    future.cancel(true);
                    Thread.currentThread().interrupt();

                    LOG.error("Thread interrotto durante processing", ie);

                    updateIdempotenzaSafe(
                            finalTransactionId,
                            finalFlow,
                            finalKeyLogic,
                            "ERROR",
                            "INTERRUPTED"
                    );
                    throw new RuntimeException("INTERRUPTED", ie);
                }
            }

        } catch (ControlledDlqException e) {
            LOG.warnf(
                    "Caso controllato in handle code=%s transactionId=%s msg=%s",
                    e.getCode(),
                    e.getTransactionId(),
                    e.getMessage()
            );
            throw e;

        } catch (Exception e) {
            LOG.error("Errore consumo Kafka", e);
            throw e;

        } finally {
            MDC.clear();
            headersCtx.clear();
        }
    }

    private IdempotenzaRequestDTO buildIdempotenzaRequest(
            String transactionId,
            String flow,
            String keyLogic,
            String status,
            String errorMsg) {

        return new IdempotenzaRequestDTO(
                transactionId,
                flow,
                keyLogic,
                status,
                errorMsg
        );
    }

    private boolean updateIdempotenzaSafe(
            String transactionId,
            String flow,
            String keyLogic,
            String status,
            String errorMsg) {

        try {
            IdempotenzaResponseDTO response =
                    idempotenzaService.update(buildIdempotenzaRequest(transactionId, flow, keyLogic, status, errorMsg));

            if (!isExpectedStatus(response, status)) {
                LOG.errorf(
                        "Update idempotenza semanticamente fallito expected=%s actual=%s transactionId=%s flow=%s",
                        status,
                        response == null ? "null" : response.status(),
                        transactionId,
                        flow
                );
                return false;
            }

            return true;

        } catch (Exception ex) {
            LOG.errorf(
                    "Errore aggiornando stato idempotenza a %s per transactionId=%s: %s",
                    status,
                    transactionId,
                    ex.getMessage()
            );
            return false;
        }
    }

    private String extractHeader(Headers headers, String name) {
        if (headers == null) {
            return "";
        }

        Header header = headers.lastHeader(name);
        return header != null
                ? new String(header.value(), StandardCharsets.UTF_8)
                : "";
    }

    private String safeMessage(Throwable throwable) {
        if (throwable == null || throwable.getMessage() == null || throwable.getMessage().isBlank()) {
            return "UNKNOWN_ERROR";
        }
        return throwable.getMessage();
    }

    private boolean isTechnicalFallback(IdempotenzaResponseDTO resp) {
        return resp == null
                || resp.status() == null
                || resp.status().isBlank()
                || resp.status().startsWith("ERROR_");
    }

    private boolean isDuplicateOutcome(IdempotenzaResponseDTO resp) {
        return resp != null
                && !resp.started()
                && !isTechnicalFallback(resp);
    }

    private boolean isExpectedStatus(IdempotenzaResponseDTO resp, String expected) {
        return resp != null
                && resp.status() != null
                && expected != null
                && expected.equalsIgnoreCase(resp.status());
    }
}
