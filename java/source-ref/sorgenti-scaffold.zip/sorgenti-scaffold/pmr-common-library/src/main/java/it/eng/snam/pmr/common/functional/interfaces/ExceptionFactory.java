package it.eng.snam.pmr.common.functional.interfaces;

import java.util.function.BiFunction;

import it.eng.snam.pmr.common.exception.GenericException;
import it.eng.snam.pmr.common.exception.KafkaProcessingException;
import it.eng.snam.pmr.common.exception.RestClientCallException;

@FunctionalInterface
public interface ExceptionFactory {

    BiFunction<String, Throwable, String> MESSAGE_BUILDER = (operationName, cause) -> operationName + " reached retry limit: " + cause.getMessage();

    RuntimeException build(String operationName, Throwable cause);

    static ExceptionFactory base() {
        return (operationName, cause) -> new GenericException(MESSAGE_BUILDER.apply(operationName, cause), cause);
    }

    static ExceptionFactory restClient() {
        return (operationName, cause) -> new RestClientCallException(MESSAGE_BUILDER.apply(operationName, cause), cause);
    }

    static ExceptionFactory kafka() {
        return (operationName, cause) -> new KafkaProcessingException(MESSAGE_BUILDER.apply(operationName, cause), cause);
    }
}
