package it.eng.snam.pmr.common.util.exception.mapper;

import java.io.IOException;
import java.net.UnknownHostException;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import io.quarkus.hibernate.validator.runtime.jaxrs.ResteasyReactiveViolationException;
import it.eng.snam.pmr.common.exception.GenericException;
import it.eng.snam.pmr.common.exception.InternalServerException;
import it.eng.snam.pmr.common.exception.JsonParsingException;
import it.eng.snam.pmr.common.exception.RemoteCallException;
import it.eng.snam.pmr.common.exception.RestClientCallException;
import it.eng.snam.pmr.common.exception.RetryableRemoteException;
import jakarta.validation.ConstraintViolationException;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.ServiceUnavailableException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ThrowableDomain {

    public final Map<Class<? extends Throwable>, Response.Status> STATUS_RULES;
    public final Map<Class<? extends Throwable>, Response.Status> VIOLATION_STATUS_RULES;

    static {
        Map<Class<? extends Throwable>, Response.Status> tempViolationMap = new LinkedHashMap<>();
        tempViolationMap.put(ResteasyReactiveViolationException.class, Response.Status.BAD_REQUEST);
        tempViolationMap.put(ConstraintViolationException.class, Response.Status.BAD_REQUEST);
        VIOLATION_STATUS_RULES = tempViolationMap;

        Map<Class<? extends Throwable>, Response.Status> tempMap = new LinkedHashMap<>(tempViolationMap);
        tempMap.put(BadRequestException.class, Response.Status.BAD_REQUEST);
        tempMap.put(IllegalArgumentException.class, Response.Status.BAD_REQUEST);
        tempMap.put(DateTimeParseException.class, Response.Status.BAD_REQUEST);
        tempMap.put(NotAuthorizedException.class, Response.Status.UNAUTHORIZED);
        tempMap.put(ForbiddenException.class, Response.Status.FORBIDDEN);
        tempMap.put(NotFoundException.class, Response.Status.NOT_FOUND);
        tempMap.put(NoSuchElementException.class, Response.Status.NOT_FOUND);
        tempMap.put(RetryableRemoteException.class, Response.Status.BAD_GATEWAY);
        tempMap.put(RemoteCallException.class, Response.Status.BAD_GATEWAY);
        tempMap.put(ServiceUnavailableException.class, Response.Status.SERVICE_UNAVAILABLE);
        tempMap.put(WebApplicationException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(NullPointerException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(UnknownHostException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(NumberFormatException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(ArrayIndexOutOfBoundsException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(IndexOutOfBoundsException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(IOException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(InternalServerException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(InternalServerErrorException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(IllegalStateException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(JsonParsingException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(RestClientCallException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(GenericException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(RuntimeException.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(Exception.class, Response.Status.INTERNAL_SERVER_ERROR);
        tempMap.put(Throwable.class, Response.Status.INTERNAL_SERVER_ERROR);
        STATUS_RULES = tempMap;
    }
}
