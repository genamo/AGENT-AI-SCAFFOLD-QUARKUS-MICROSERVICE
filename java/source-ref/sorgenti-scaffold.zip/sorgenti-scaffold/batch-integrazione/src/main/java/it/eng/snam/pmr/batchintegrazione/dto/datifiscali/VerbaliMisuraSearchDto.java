package it.eng.snam.pmr.batchintegrazione.dto.datifiscali;

import java.time.LocalDateTime;

public record VerbaliMisuraSearchDto(
        String remiAssoluto,
        LocalDateTime dataInitVerbale
) {}
