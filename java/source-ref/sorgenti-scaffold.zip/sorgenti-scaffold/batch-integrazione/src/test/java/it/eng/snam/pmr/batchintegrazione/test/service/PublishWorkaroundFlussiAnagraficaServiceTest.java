package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.TextNode;

import it.eng.snam.pmr.batchintegrazione.dto.DlqFlussoDTO;
import it.eng.snam.pmr.batchintegrazione.dto.FlowTriggerRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.FlowTriggerResponseDTO;
import it.eng.snam.pmr.batchintegrazione.dto.MonitoringFlussiDTO;
import it.eng.snam.pmr.batchintegrazione.kafka.KafkaGenericProducer;
import it.eng.snam.pmr.batchintegrazione.service.DlqFlussoService;
import it.eng.snam.pmr.batchintegrazione.service.FlowTopicRoutingService;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringFlussiService;
import it.eng.snam.pmr.batchintegrazione.service.PublishWorkaroundFlussiAnagraficaService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import it.eng.snam.pmr.common.dto.kafka.produce.MessageHeaderContext;
import jakarta.ws.rs.NotFoundException;

@ExtendWith(MockitoExtension.class)
class PublishWorkaroundFlussiAnagraficaServiceTest {

    @Mock KafkaGenericProducer producer;
    @Mock FlowTopicRoutingService routingService;
    @Mock DlqFlussoService dlqFlussoService;
    @Mock MonitoringFlussiService monitoringFlussiService;

    @InjectMocks
    PublishWorkaroundFlussiAnagraficaService service;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() throws Exception {
        objectMapper = spy(new ObjectMapper());
        setField(AbstractService.class, service, "objectMapper", objectMapper);
    }

    private static void setField(Class<?> declaringClass, Object target, String fieldName, Object value) throws Exception {
        Field field = declaringClass.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private String base64Json(String json) {
        return Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
    }

    @Test
    void publish_withExplicitValues_sendsToResolvedTopic() throws Exception {
        JsonNode payload = objectMapper.readTree("{\"code\":\"A1\"}");
        Map<String, String> extraHeaders = Map.of("X-CUSTOM", "YES");

        FlowTriggerRequestDTO request = FlowTriggerRequestDTO.builder()
            .flow(Constants.Flussi.ANAG_REMI_FLOW)
            .transactionId("tx-001")
            .processType("API")
            .messageKey("msg-001")
            .payload(payload)
            .extraHeaders(extraHeaders)
            .build();

        when(routingService.resolveTopic(Constants.Flussi.ANAG_REMI_FLOW))
            .thenReturn(Constants.Topic.PMR001A_SUMMER_IN_TOPIC);

        FlowTriggerResponseDTO result = service.publish(request);

        assertNotNull(result);
        assertEquals(Constants.Flussi.ANAG_REMI_FLOW, result.flow());
        assertEquals(Constants.Topic.PMR001A_SUMMER_IN_TOPIC, result.resolvedTopic());
        assertEquals("tx-001", result.transactionId());
        assertEquals("msg-001", result.messageKey());
        assertEquals("PUBLISHED", result.status());

        ArgumentCaptor<byte[]> payloadCaptor = ArgumentCaptor.forClass(byte[].class);

        verify(producer).sendEventWithHeaders(eq(Constants.Topic.PMR001A_SUMMER_IN_TOPIC), any(MessageHeaderContext.class), payloadCaptor.capture(), eq(extraHeaders));

        assertArrayEquals(objectMapper.writeValueAsBytes(payload), payloadCaptor.getValue());
    }

    @Test
    void publish_withBlankOptionalFields_generatesDefaults() throws Exception {
        JsonNode payload = objectMapper.readTree("{\"id\":1}");

        FlowTriggerRequestDTO request = FlowTriggerRequestDTO.builder().flow(Constants.Flussi.ANAG_CLIENTI_FLOW).transactionId(" ")
                                                             .processType(null).messageKey("").payload(payload).extraHeaders(null).build();

        when(routingService.resolveTopic(Constants.Flussi.ANAG_CLIENTI_FLOW)).thenReturn(Constants.Topic.PMR001B_SUMMER_IN_TOPIC);

        FlowTriggerResponseDTO result = service.publish(request);

        ArgumentCaptor<MessageHeaderContext> contextCaptor = ArgumentCaptor.forClass(MessageHeaderContext.class);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<Map<String, String>> headersCaptor = ArgumentCaptor.forClass(Map.class);

        verify(producer).sendEventWithHeaders(eq(Constants.Topic.PMR001B_SUMMER_IN_TOPIC), contextCaptor.capture(), any(byte[].class), headersCaptor.capture());

        MessageHeaderContext context = contextCaptor.getValue();

        assertDoesNotThrow(() -> UUID.fromString(context.getTransactionId()));
        assertEquals("GUI", context.getProcessType());
        assertDoesNotThrow(() -> UUID.fromString(context.getMessageKey()));

        assertEquals(Map.of(), headersCaptor.getValue());

        assertEquals(context.getTransactionId(), result.transactionId());
        assertEquals(context.getMessageKey(), result.messageKey());
        assertEquals("PUBLISHED", result.status());
    }

    @Test
    void publish_nullRequest_throwsIllegalArgumentException() {
        IllegalArgumentException ex = assertThrows(
            IllegalArgumentException.class,
            () -> service.publish(null)
        );

        assertEquals("Body mancante", ex.getMessage());
        verifyNoInteractions(producer);
    }

    @Test
    void publish_missingFlow_throwsIllegalArgumentException() throws Exception {
        FlowTriggerRequestDTO request = FlowTriggerRequestDTO.builder()
            .flow(" ")
            .payload(objectMapper.readTree("{\"x\":1}"))
            .build();

        IllegalArgumentException ex = assertThrows(
            IllegalArgumentException.class,
            () -> service.publish(request)
        );

        assertEquals("Campo 'flow' obbligatorio", ex.getMessage());
        verifyNoInteractions(producer);
    }

    @Test
    void publish_invalidFlow_throwsIllegalArgumentException() throws Exception {
        FlowTriggerRequestDTO request = FlowTriggerRequestDTO.builder()
            .flow("INVALID")
            .payload(objectMapper.readTree("{\"x\":1}"))
            .build();

        IllegalArgumentException ex = assertThrows(
            IllegalArgumentException.class,
            () -> service.publish(request)
        );

        assertEquals("Flow non valido: INVALID", ex.getMessage());
        verifyNoInteractions(producer);
    }

    @Test
    void publish_missingPayload_throwsIllegalArgumentException() {
        FlowTriggerRequestDTO request = FlowTriggerRequestDTO.builder()
            .flow(Constants.Flussi.ANAG_REMI_FLOW)
            .payload(null)
            .build();

        IllegalArgumentException ex = assertThrows(
            IllegalArgumentException.class,
            () -> service.publish(request)
        );

        assertEquals("Campo 'payload' obbligatorio", ex.getMessage());
        verifyNoInteractions(producer);
    }

    @Test
    void publish_payloadNotSerializable_throwsIllegalArgumentException() throws Exception {
        JsonNode payload = objectMapper.readTree("{\"x\":1}");

        FlowTriggerRequestDTO request = FlowTriggerRequestDTO.builder()
            .flow(Constants.Flussi.ANAG_REMI_FLOW)
            .payload(payload)
            .build();

        when(routingService.resolveTopic(Constants.Flussi.ANAG_REMI_FLOW))
            .thenReturn(Constants.Topic.PMR001A_SUMMER_IN_TOPIC);

        doThrow(new RuntimeException("boom"))
            .when(objectMapper).writeValueAsBytes(any());

        IllegalArgumentException ex = assertThrows(
            IllegalArgumentException.class,
            () -> service.publish(request)
        );

        assertEquals("Payload non serializzabile", ex.getMessage());
        assertNotNull(ex.getCause());
    }

    @Test
    void publish_payloadTooLarge_throwsIllegalArgumentException() {
        FlowTriggerRequestDTO request = FlowTriggerRequestDTO.builder()
            .flow(Constants.Flussi.ANAG_REMI_FLOW)
            .payload(TextNode.valueOf("x".repeat(1_000_001)))
            .build();

        when(routingService.resolveTopic(Constants.Flussi.ANAG_REMI_FLOW))
            .thenReturn(Constants.Topic.PMR001A_SUMMER_IN_TOPIC);

        IllegalArgumentException ex = assertThrows(
            IllegalArgumentException.class,
            () -> service.publish(request)
        );

        assertEquals("Payload troppo grande", ex.getMessage());
        verifyNoInteractions(producer);
    }

    @Test
    void buildDownloadFromDlqRequest_blankControlKey_throwsIllegalArgumentException() {
        IllegalArgumentException ex = assertThrows(
            IllegalArgumentException.class,
            () -> service.buildDownloadFromDlqRequest(" ")
        );

        assertEquals("Campo 'controlKey' obbligatorio", ex.getMessage());
    }

    @Test
    void buildDownloadFromDlqRequest_noRecords_throwsNotFoundException() {
        when(dlqFlussoService.findByControlKey("ck-1")).thenReturn(List.of());

        NotFoundException ex = assertThrows(
            NotFoundException.class,
            () -> service.buildDownloadFromDlqRequest("ck-1")
        );

        assertEquals("Nessun record DLQ trovato per controlKey=ck-1", ex.getMessage());
    }

    @Test
    void buildDownloadFromDlqRequest_blankPayload_throwsIllegalStateException() {
        when(dlqFlussoService.findByControlKey("ck-1")).thenReturn(List.of(
            DlqFlussoDTO.builder()
                .flowId(Constants.Flussi.ANAG_REMI_FLOW)
                .payload(" ")
                .build()
        ));

        IllegalStateException ex = assertThrows(
            IllegalStateException.class,
            () -> service.buildDownloadFromDlqRequest("ck-1")
        );

        assertEquals("Payload vuoto per controlKey=ck-1", ex.getMessage());
    }

    @Test
    void buildDownloadFromDlqRequest_invalidPayload_throwsIllegalStateException() {
        when(dlqFlussoService.findByControlKey("ck-1")).thenReturn(List.of(
            DlqFlussoDTO.builder()
                .flowId(Constants.Flussi.ANAG_REMI_FLOW)
                .payload("%%%")
                .build()
        ));

        IllegalStateException ex = assertThrows(
            IllegalStateException.class,
            () -> service.buildDownloadFromDlqRequest("ck-1")
        );

        assertTrue(ex.getMessage().contains("Payload non decodificabile o non valido per controlKey=ck-1"));
    }

    @Test
    void buildDownloadFromDlqRequest_withBlankFlow_generatesUuidTransactionId() {
        when(dlqFlussoService.findByControlKey("ck-1")).thenReturn(List.of(
            DlqFlussoDTO.builder()
                .flowId(" ")
                .payload(base64Json("{\"value\":123}"))
                .build()
        ));

        FlowTriggerRequestDTO result = service.buildDownloadFromDlqRequest("ck-1");

        assertEquals("", result.flow());
        assertDoesNotThrow(() -> UUID.fromString(result.transactionId()));
        assertEquals("GUI", result.processType());
        assertDoesNotThrow(() -> UUID.fromString(result.messageKey()));
        assertEquals(123, result.payload().get("value").asInt());
        assertTrue(result.extraHeaders().isEmpty());
    }

    @Test
    void buildDownloadFromDlqRequest_validRecord_buildsReplayRequest() {
        when(dlqFlussoService.findByControlKey("ck-1")).thenReturn(List.of(
            DlqFlussoDTO.builder()
                .flowId(Constants.Flussi.ANAG_REMI_FLOW)
                .payload(base64Json("{\"customer\":\"ABC\"}"))
                .build()
        ));

        FlowTriggerRequestDTO result = service.buildDownloadFromDlqRequest("ck-1");

        assertEquals(Constants.Flussi.ANAG_REMI_FLOW, result.flow());
        assertTrue(result.transactionId().matches(Constants.Flussi.ANAG_REMI_FLOW + "_\\d{17}"));
        assertEquals("GUI", result.processType());
        assertDoesNotThrow(() -> UUID.fromString(result.messageKey()));
        assertEquals("ABC", result.payload().get("customer").asText());
        assertTrue(result.extraHeaders().isEmpty());
    }

    @Test
    void buildDownloadFromFlussiMonitoringRequest_blankTransactionId_throwsIllegalArgumentException() {
        IllegalArgumentException ex = assertThrows(
            IllegalArgumentException.class,
            () -> service.buildDownloadFromFlussiMonitoringRequest(" ")
        );

        assertEquals("Campo 'transactionId' obbligatorio", ex.getMessage());
    }

    @Test
    void buildDownloadFromFlussiMonitoringRequest_optionalNull_throwsNotFoundException() {
        when(monitoringFlussiService.getByTransactionId("tx-1")).thenReturn(null);

        NotFoundException ex = assertThrows(
            NotFoundException.class,
            () -> service.buildDownloadFromFlussiMonitoringRequest("tx-1")
        );

        assertEquals("Nessun monitoring flusso trovato per transactionId=tx-1", ex.getMessage());
    }

    @Test
    void buildDownloadFromFlussiMonitoringRequest_validRecord_buildsReplayRequest() {
        when(monitoringFlussiService.getByTransactionId("tx-1")).thenReturn(
            Optional.of(
                MonitoringFlussiDTO.builder()
                    .transactionId("tx-1")
                    .flowId(Constants.Flussi.ANAG_CLIENTI_FLOW)
                    .fileFlusso(base64Json("{\"remi\":\"R01\"}"))
                    .build()
            )
        );

        FlowTriggerRequestDTO result = service.buildDownloadFromFlussiMonitoringRequest("tx-1");

        assertEquals(Constants.Flussi.ANAG_CLIENTI_FLOW, result.flow());
        assertTrue(result.transactionId().matches(Constants.Flussi.ANAG_CLIENTI_FLOW + "_\\d{17}"));
        assertEquals("GUI", result.processType());
        assertDoesNotThrow(() -> UUID.fromString(result.messageKey()));
        assertEquals("R01", result.payload().get("remi").asText());
        assertTrue(result.extraHeaders().isEmpty());
    }
}
