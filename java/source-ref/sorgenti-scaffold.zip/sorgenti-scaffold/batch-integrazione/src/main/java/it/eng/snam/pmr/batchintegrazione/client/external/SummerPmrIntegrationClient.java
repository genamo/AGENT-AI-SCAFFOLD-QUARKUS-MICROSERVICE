package it.eng.snam.pmr.batchintegrazione.client.external;

import it.eng.snam.pmr.batchintegrazione.dto.external.MailMonitoraggioVerbaliMisuraFilter;
import it.eng.snam.pmr.batchintegrazione.dto.external.VerbaliMisuraFilter;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.annotation.RegisterProviders;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import it.eng.snam.pmr.batchintegrazione.dto.external.AssoMailRemiFilter;
import it.eng.snam.pmr.batchintegrazione.filter.DynamicAuthorizationHeaderFilter;
import it.eng.snam.pmr.batchintegrazione.filter.RestClientHeadersFilter;
import jakarta.ws.rs.BeanParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/summer-pmr-integration")
@Produces(MediaType.APPLICATION_JSON)
@RegisterRestClient(configKey = "summer-pmr-integration-client")
@RegisterProviders(value = {@RegisterProvider(value = RestClientHeadersFilter.class), @RegisterProvider(value =
        DynamicAuthorizationHeaderFilter.class)})
public interface SummerPmrIntegrationClient {

    @GET
    @Path("/asso-mail-remi/filtered-search")
    Response filteredSearch(@BeanParam AssoMailRemiFilter filter);

    @GET
    @Path("/asso-mail-remi/associated-remi-by-idmail")
    Response findRemiByIdMail(@QueryParam("idMail") Long idMail);

    @GET
    @Path("/mail-verbali/filtered-search")
    Response filteredSearch(@BeanParam MailMonitoraggioVerbaliMisuraFilter filter);

    @GET
    @Path("/verbali/filtered-search")
    Response filteredSearch(@BeanParam VerbaliMisuraFilter filter);
}
