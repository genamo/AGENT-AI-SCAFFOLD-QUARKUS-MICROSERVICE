package it.eng.snam.pmr.batchintegrazione.test.service.blob.storage;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.junit.jupiter.MockitoExtension;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.blob.models.BlobHttpHeaders;
import com.azure.storage.blob.specialized.BlobOutputStream;
import com.azure.storage.blob.specialized.BlockBlobClient;

import it.eng.snam.pmr.batchintegrazione.config.properties.BlobStorageProperties;
import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.BlobUploadStatus;
import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.FileDataContext;
import it.eng.snam.pmr.batchintegrazione.exception.BlobUploadException;
import it.eng.snam.pmr.batchintegrazione.service.blob.storage.BlobStorageUploader;
import it.eng.snam.pmr.batchintegrazione.utils.blob.storage.BlobArgumentsValidator;
import it.eng.snam.pmr.batchintegrazione.utils.blob.storage.BlobConnectionBuilder;

@ExtendWith(MockitoExtension.class)
class BlobStorageUploaderTest {

    @Mock
    private BlobServiceClient blobServiceClient;

    @Mock
    private BlobContainerClient containerClient;

    @Mock
    private BlobClient blobClient;

    @Mock
    private BlockBlobClient blockBlobClient;

    @Mock
    private BlobOutputStream blobOutputStream;

    private BlobStorageUploader uploader;

    @BeforeEach
    void setUp() {
        uploader = new BlobStorageUploader(blobServiceClient);
    }

    @Test
    void uploadAndVerify_whenBlobExists_uploadsZipAppliesPropertiesAndReturnsSuccessStatus() {
        byte[] content = "zip-content".getBytes();

        Map<String, String> metadata = new LinkedHashMap<>();
        metadata.put("transactionId", "TN-001");
        metadata.put("executioner", "BATCH");
        metadata.put("activity", "EXPORT");
        metadata.put("sourceSystem", "PMR");

        FileDataContext context = new FileDataContext("Executioner", "activity", "file.zip", "application/zip",
                                                      new ByteArrayInputStream(content), metadata,
                                                      CompletableFuture.completedFuture(null));

        when(blobServiceClient.getBlobContainerClient("executioner")).thenReturn(containerClient);
        when(containerClient.getBlobContainerUrl()).thenReturn("https://account.blob.core.windows.net/executioner");
        when(containerClient.getBlobClient("activity/file.zip")).thenReturn(blobClient);
        when(blobClient.getBlobUrl()).thenReturn("https://account.blob.core.windows.net/executioner/activity/file.zip");
        when(blobClient.getBlockBlobClient()).thenReturn(blockBlobClient);
        when(blockBlobClient.getBlobOutputStream(true)).thenReturn(blobOutputStream);
        when(blobClient.exists()).thenReturn(true);

        BlobUploadStatus actual = uploader.uploadAndVerify(context);

        assertEquals("activity/file.zip", actual.getBlobPath());
        assertEquals("application/zip", actual.getBlobContentType());
        assertEquals("READY_TO_DOWNLOAD", actual.getStatus());
        assertEquals("Upload terminated successfully", actual.getStatusMessage());

        verify(blobServiceClient).getBlobContainerClient("executioner");
        verify(containerClient).createIfNotExists();
        verify(containerClient).getBlobClient("activity/file.zip");

        ArgumentCaptor<BlobHttpHeaders> headersCaptor = ArgumentCaptor.forClass(BlobHttpHeaders.class);
        verify(blobClient).setHttpHeaders(headersCaptor.capture());
        assertEquals("application/zip", headersCaptor.getValue().getContentType());

        verify(blobClient).setMetadata(metadata);
        verify(blobClient, never()).deleteIfExists();
    }

    @Test
    void uploadAndVerify_whenBlobDoesNotExist_returnsFailedStatus() {

        FileDataContext context = new FileDataContext("Executioner", "activity", "file.zip", null,
                                                      new ByteArrayInputStream("zip-content".getBytes()), null, null);

        when(blobServiceClient.getBlobContainerClient("executioner")).thenReturn(containerClient);
        when(containerClient.getBlobContainerUrl()).thenReturn("container-url");
        when(containerClient.getBlobClient("activity/file.zip")).thenReturn(blobClient);
        when(blobClient.getBlobUrl()).thenReturn("blob-url");
        when(blobClient.getBlockBlobClient()).thenReturn(blockBlobClient);
        when(blockBlobClient.getBlobOutputStream(true)).thenReturn(blobOutputStream);
        when(blobClient.exists()).thenReturn(false);

        BlobUploadStatus actual = uploader.uploadAndVerify(context);

        assertEquals("activity/file.zip", actual.getBlobPath());
        assertEquals("application/zip", actual.getBlobContentType());
        assertEquals("UPLOAD_FAILED", actual.getStatus());
        assertEquals("Upload terminated with failure", actual.getStatusMessage());

        verify(blobClient, never()).setHttpHeaders(any());
        verify(blobClient, never()).setMetadata(any());
        verify(blobClient, never()).deleteIfExists();
    }

    @Test
    void uploadAndVerify_whenExecutionerIsBlank_throwsIllegalArgumentException() {
        FileDataContext context = new FileDataContext(" ", "activity", "file.zip", "application/zip",
                                                      new ByteArrayInputStream("zip-content".getBytes()),
                                                      Map.of("key", "value"), CompletableFuture.completedFuture(null));

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                                                          () -> uploader.uploadAndVerify(context));

        assertEquals("'containerName' must be valued properly.", exception.getMessage());

        verify(blobServiceClient, never()).getBlobContainerClient(any());
    }

    @Test
    void uploadAndVerify_whenInputStreamFails_deletesBlobAndThrowsBlobUploadException() {
        FileDataContext context = new FileDataContext("Executioner", "activity", "file.zip", "application/zip",
                                                      brokenInputStream(), Map.of("key", "value"),
                                                      CompletableFuture.completedFuture(null));

        when(blobServiceClient.getBlobContainerClient("executioner")).thenReturn(containerClient);
        when(containerClient.getBlobContainerUrl()).thenReturn("container-url");
        when(containerClient.getBlobClient("activity/file.zip")).thenReturn(blobClient);
        when(blobClient.getBlobUrl()).thenReturn("blob-url");
        when(blobClient.getBlockBlobClient()).thenReturn(blockBlobClient);
        when(blockBlobClient.getBlobOutputStream(true)).thenReturn(blobOutputStream);
        when(blobClient.getBlobName()).thenReturn("activity/file.zip");

        BlobUploadException exception = assertThrows(BlobUploadException.class,
                                                     () -> uploader.uploadAndVerify(context));

        assertNotNull(exception.getCause());
        assertEquals("Error while writing blob stream: input stream ko", exception.getMessage());

        verify(blobClient).deleteIfExists();
        verify(blobClient, never()).exists();
    }

    @Test
    void uploadAndVerify_whenWriterFutureFails_deletesBlobAndThrowsBlobUploadException() {
        CompletableFuture<Void> writerFuture = new CompletableFuture<>();
        writerFuture.completeExceptionally(new IllegalStateException("zip writer ko"));

        FileDataContext context = new FileDataContext("Executioner", "activity", "file.zip", "application/zip",
                                                      new ByteArrayInputStream("zip-content".getBytes()),
                                                      Map.of("key", "value"), writerFuture);

        when(blobServiceClient.getBlobContainerClient("executioner")).thenReturn(containerClient);
        when(containerClient.getBlobContainerUrl()).thenReturn("container-url");
        when(containerClient.getBlobClient("activity/file.zip")).thenReturn(blobClient);
        when(blobClient.getBlobUrl()).thenReturn("blob-url");
        when(blobClient.getBlockBlobClient()).thenReturn(blockBlobClient);
        when(blockBlobClient.getBlobOutputStream(true)).thenReturn(blobOutputStream);
        when(blobClient.getBlobName()).thenReturn("activity/file.zip");

        BlobUploadException exception = assertThrows(BlobUploadException.class,
                                                     () -> uploader.uploadAndVerify(context));

        assertEquals("ZIP writer verification failed: zip writer ko", exception.getMessage());
        assertEquals(IllegalStateException.class, exception.getCause().getClass());

        verify(blobClient).deleteIfExists();
        verify(blobClient, never()).setHttpHeaders(any());
        verify(blobClient, never()).setMetadata(any());
        verify(blobClient, never()).exists();
    }

    @Test
    void uploadAndVerify_whenWriterFutureFailsWithoutCause_deletesBlobAndThrowsBlobUploadException() {
        CompletableFuture<Void> writerFuture = new CompletableFuture<>();
        writerFuture.completeExceptionally(new CompletionException("completion ko", null));

        FileDataContext context = new FileDataContext("Executioner", "activity", "file.zip", null,
                                                      new ByteArrayInputStream("zip-content".getBytes()), null,
                                                      writerFuture);

        when(blobServiceClient.getBlobContainerClient("executioner")).thenReturn(containerClient);
        when(containerClient.getBlobContainerUrl()).thenReturn("container-url");
        when(containerClient.getBlobClient("activity/file.zip")).thenReturn(blobClient);
        when(blobClient.getBlobUrl()).thenReturn("blob-url");
        when(blobClient.getBlockBlobClient()).thenReturn(blockBlobClient);
        when(blockBlobClient.getBlobOutputStream(true)).thenReturn(blobOutputStream);
        when(blobClient.getBlobName()).thenReturn("activity/file.zip");

        BlobUploadException exception = assertThrows(BlobUploadException.class,
                                                     () -> uploader.uploadAndVerify(context));

        assertEquals("ZIP writer verification failed: completion ko", exception.getMessage());
        assertEquals(CompletionException.class, exception.getCause().getClass());

        verify(blobClient).deleteIfExists();
        verify(blobClient, never()).exists();
    }

    @Test
    void uploadAndVerify_whenApplyPropertiesFails_deletesBlobAndThrowsBlobUploadException() {
        FileDataContext context = new FileDataContext("Executioner", "activity", "file.zip", "application/zip",
                                                      new ByteArrayInputStream("zip-content".getBytes()),
                                                      Map.of("key", "value"), CompletableFuture.completedFuture(null));

        when(blobServiceClient.getBlobContainerClient("executioner")).thenReturn(containerClient);
        when(containerClient.getBlobContainerUrl()).thenReturn("container-url");
        when(containerClient.getBlobClient("activity/file.zip")).thenReturn(blobClient);
        when(blobClient.getBlobUrl()).thenReturn("blob-url");
        when(blobClient.getBlockBlobClient()).thenReturn(blockBlobClient);
        when(blockBlobClient.getBlobOutputStream(true)).thenReturn(blobOutputStream);
        when(blobClient.getBlobName()).thenReturn("activity/file.zip");
        doThrow(new RuntimeException("metadata ko")).when(blobClient).setMetadata(Map.of("key", "value"));

        BlobUploadException exception = assertThrows(BlobUploadException.class,
                                                     () -> uploader.uploadAndVerify(context));

        assertEquals("Blob uploaded but failed while setting metadata: metadata ko", exception.getMessage());
        assertEquals(RuntimeException.class, exception.getCause().getClass());

        verify(blobClient).setHttpHeaders(any(BlobHttpHeaders.class));
        verify(blobClient).deleteIfExists();
        verify(blobClient, never()).exists();
    }

    private InputStream brokenInputStream() {
        return new InputStream() {
            @Override
            public int read() throws IOException {
                throw new IOException("input stream ko");
            }

            @Override
            public int read(byte[] b, int off, int len) throws IOException {
                throw new IOException("input stream ko");
            }
        };
    }

    @Test
    void validateConnection_whenPropertiesAreValid_doesNotThrowException() {
        BlobStorageProperties properties = mock(BlobStorageProperties.class);

        when(properties.accountName()).thenReturn("account-name");
        when(properties.accountKey()).thenReturn("account-key");

        assertDoesNotThrow(() -> BlobArgumentsValidator.validateConnection(properties));
    }

    @Test
    void validateConnection_whenAccountNameIsBlank_throwsIllegalArgumentException() {
        BlobStorageProperties properties = mock(BlobStorageProperties.class);

        when(properties.accountName()).thenReturn(" ");

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                                                          () -> BlobArgumentsValidator.validateConnection(properties));

        assertEquals("'accountName' must be valued properly.", exception.getMessage());
    }

    @Test
    void validateConnection_whenAccountKeyIsBlank_throwsIllegalArgumentException() {
        BlobStorageProperties properties = mock(BlobStorageProperties.class);

        when(properties.accountName()).thenReturn("account-name");
        when(properties.accountKey()).thenReturn(" ");

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                                                          () -> BlobArgumentsValidator.validateConnection(properties));

        assertEquals("'accountKey' must be valued properly.", exception.getMessage());
    }

    @Test
    void init_whenPropertiesAreValid_buildsBlobServiceClientWithExpectedConnectionString() {
        BlobStorageProperties properties = mock(BlobStorageProperties.class);
        BlobServiceClient expectedClient = mock(BlobServiceClient.class);

        when(properties.accountName()).thenReturn("myaccount");
        when(properties.accountKey()).thenReturn("mykey");
        when(expectedClient.getAccountUrl()).thenReturn("https://myaccount.blob.core.windows.net");

        try (MockedConstruction<BlobServiceClientBuilder> mockedConstruction = mockConstruction(
                BlobServiceClientBuilder.class, (builder, context) -> {
                    when(builder.connectionString(anyString())).thenReturn(builder);
                    when(builder.buildClient()).thenReturn(expectedClient);
                })) {

            BlobServiceClient actual = BlobConnectionBuilder.init(properties);

            assertSame(expectedClient, actual);
            assertEquals(1, mockedConstruction.constructed().size());

            BlobServiceClientBuilder builder = mockedConstruction.constructed().get(0);

            verify(builder).connectionString(
                    "DefaultEndpointsProtocol=https;" + "AccountName=myaccount;" + "AccountKey=mykey;" +
                    "EndpointSuffix=core.windows.net;");

            verify(builder).buildClient();
            verify(expectedClient).getAccountUrl();
        }
    }

    @Test
    void init_whenAccountNameIsBlank_throwsIllegalArgumentExceptionAndDoesNotCreateBuilder() {
        BlobStorageProperties properties = mock(BlobStorageProperties.class);

        when(properties.accountName()).thenReturn(" ");

        try (MockedConstruction<BlobServiceClientBuilder> mockedConstruction = mockConstruction(
                BlobServiceClientBuilder.class)) {

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                                                              () -> BlobConnectionBuilder.init(properties));

            assertEquals("'accountName' must be valued properly.", exception.getMessage());
            assertEquals(0, mockedConstruction.constructed().size());
        }
    }

    @Test
    void init_whenAccountKeyIsBlank_throwsIllegalArgumentExceptionAndDoesNotCreateBuilder() {
        BlobStorageProperties properties = mock(BlobStorageProperties.class);

        when(properties.accountName()).thenReturn("myaccount");
        when(properties.accountKey()).thenReturn("");

        try (MockedConstruction<BlobServiceClientBuilder> mockedConstruction = mockConstruction(
                BlobServiceClientBuilder.class)) {

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                                                              () -> BlobConnectionBuilder.init(properties));

            assertEquals("'accountKey' must be valued properly.", exception.getMessage());
            assertEquals(0, mockedConstruction.constructed().size());
        }
    }
}
