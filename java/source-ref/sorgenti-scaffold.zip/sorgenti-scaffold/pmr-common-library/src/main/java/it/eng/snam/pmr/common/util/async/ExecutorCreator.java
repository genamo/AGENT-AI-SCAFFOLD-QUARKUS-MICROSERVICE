package it.eng.snam.pmr.common.util.async;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadFactory;

import org.apache.commons.lang3.StringUtils;

import it.eng.snam.pmr.common.config.async.DecoratedThreadPoolExecutor;
import it.eng.snam.pmr.common.config.async.ThreadPoolContext;
import it.eng.snam.pmr.common.config.async.decorator.TaskDecorator;
import it.eng.snam.pmr.common.config.async.properties.AsyncProperties;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class ExecutorCreator {

    public Executor createExecutor(AsyncProperties properties, String threadNamePrefix, TaskDecorator decorator) {
        ThreadPoolContext context = ThreadPoolContext.of(properties.corePoolSize(), properties.maxPoolSize(), properties.keepAliveSeconds(),
                                                         properties.queueCapacity(), threadFactory(threadNamePrefix));

        Executor executor = new DecoratedThreadPoolExecutor(context, decorator);
        ExecutorRegistry.register(executor);
        return executor;
    }

    private ThreadFactory threadFactory(String threadNamePrefix) {
        String callerThreadName = Thread.currentThread().getName();
        return runnable -> {
            Thread thread = new Thread(runnable);
            if (callerThreadName != null && StringUtils.isNotBlank(threadNamePrefix)) {
                String callerThreadSuffix = callerThreadName.substring(callerThreadName.lastIndexOf("-") + 1);
                thread.setName(threadNamePrefix + callerThreadSuffix);
            }

            return thread;
        };
    }
}
