package it.eng.snam.pmr.common.service;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;
import org.jboss.logging.MDC;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.common.annotation.UserType;
import it.eng.snam.pmr.common.client.AuthorizationClient;
import it.eng.snam.pmr.common.dto.AdministrationListDTO;
import it.eng.snam.pmr.common.dto.acr.addressing.AcrAdministrationListDTO;
import it.eng.snam.pmr.common.dto.acr.addressing.AcrRecipientRequestDTO;
import it.eng.snam.pmr.common.dto.acr.roles.AcrRoleDTO;
import it.eng.snam.pmr.common.dto.acr.roles.AcrRolesResponseDTO;
import it.eng.snam.pmr.common.filter.B2BTokenFilter;
import it.eng.snam.pmr.common.request.AuthzRequest;
import it.eng.snam.pmr.common.response.AuthzResponse;
import it.eng.snam.pmr.common.response.ExternalUserProfileResponse;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.service.jwt.JwtVerificationService;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CacheUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.ForbiddenException;
import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.ServiceUnavailableException;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
public class AuthzService {

	private static final Logger LOG = Logger.getLogger(AuthzService.class);

	public enum Permit {
		READ, WRITE
	}

	@Context
	ContainerRequestContext req;

	@Inject
	@RestClient
	AuthorizationClient authorizationClient;

	@Inject
	DataPlatformService dataPlatformService;

	@Inject
	AcrRolesService acrRolesService;

	@Inject
	AcrAddressingService acrAddressingService;
	
	@Inject
	AdministrationListService administrationListService;


	@Inject
	CacheUtils cacheUtils;

	@Inject
	ObjectMapper objectMapper;

	@Inject
    JwtVerificationService jwtVerificationService;

	@ConfigProperty(name = "security.authz.bypass", defaultValue = "false")
	boolean authzBypass;
	
	@ConfigProperty(name = "security.verification.jwt.bypass", defaultValue = "true")
	boolean jwtVerificationBypass;

	@ConfigProperty(name = "security.resources.bypass", defaultValue = "false")
	boolean allResourceBypass;


	public void assertAuthorized(String resource, Permit permit, UserType userType) {

		// ✅ bypass B2B
		if (Boolean.TRUE.equals(req.getProperty(B2BTokenFilter.B2B_SUPER_USER_KEY))) {
			LOG.infof("B2B SUPER_USER bypass. context=%s permit=%s userType=%s", resource, permit.name(), userType);
			MDC.put(AuthorizationUtils.USER_ID, "SUPER_USER");
			return;
		}

		// ✅ bypass dev/test
		if (authzBypass) {
			LOG.infof("AuthzBypass attivo -> skip authorization check. context=%s permit=%s userType=%s", resource, permit.name(), userType);
			return;
		}

		String auth = AuthorizationUtils.getBearer(req);
		DecodedJWT jwt = jwtVerificationBypass ? AuthorizationUtils.decode(auth) : jwtVerificationService.verify(auth);
		String userId = AuthorizationUtils.resolveUserId(jwt);

		if (userId == null || userId.isBlank()) {
			throw new NotAuthorizedException("Unable to resolve userId from JWT");
		}

		MDC.put(AuthorizationUtils.USER_ID, userId);
		MDC.put(AuthorizationUtils.JWT_AUTHZ, auth);

		if (isAuthorizationSelfManagedResource(resource)) {
			LOG.infof("Authorization self-managed resource bypass. resource=%s permit=%s userType=%s", resource, permit.name(), userType);
			return;
		}else if(allResourceBypass) {
			LOG.infof("All resource bypass active. resource=%s permit=%s userType=%s", resource, permit.name(), userType);
			return;
		}
		if(resource == null || resource.isBlank()) {
			throw new NotAuthorizedException("Resource is null or blank");
		}
		resource = resource.replaceFirst("^/", "");
		checkAuthorization(resource, permit, userType, auth, userId);
	}

	private void checkAuthorization(String resource, Permit permit, UserType userType, String auth, String userId) {

		String profilo = null;
		Set<String> ruoli = null;
		AcrRolesResponseDTO roleDto = acrRolesService.getRolesWithUser(userId);

		if (userType == UserType.EXTERNAL) {
			LOG.infof("External user authorization check. userId=%s resource=%s permit=%s", userId, resource, permit.name());

			ExternalUserProfileResponse responseExt = dataPlatformService.getExternalUserProfiles(userId);

			if (responseExt == null || responseExt.scenarios() == null || responseExt.scenarios().isEmpty()) {
				throw new NotAuthorizedException("External user has no scenarios. userId=" + userId);
			}

			if (roleDto == null || roleDto.roles() == null || roleDto.roles().isEmpty()) {
				throw new NotAuthorizedException("External user has no roles. userId=" + userId);
			}

			ruoli = roleDto.roles().stream()
					.map(AcrRoleDTO::code)
					.filter(code -> code != null && !code.isBlank())
					.collect(java.util.stream.Collectors.toSet());

			if (ruoli.isEmpty()) {
				throw new NotAuthorizedException("External user has no valid role codes. userId=" + userId);
			}

			Set<String> profiliEsterni = responseExt.scenarios().stream()
					.map(scenario -> scenario.profile())
					.filter(profile -> profile != null && !profile.isBlank())
					.collect(java.util.stream.Collectors.toCollection(java.util.LinkedHashSet::new));

			if (profiliEsterni.isEmpty()) {
				throw new NotAuthorizedException("External user has no valid profiles. userId=" + userId);
			}

			ForbiddenException lastForbidden = null;

			for (String profiloEsterno : profiliEsterni) {
				String profileCode = resolveProfileCode(profiloEsterno);
				AuthzRequest authRequest = new AuthzRequest(profileCode, resource, permit.name(), ruoli, userType.name());
				LOG.debugf("Calling authorization service. userId=%s resource=%s permit=%s userType=%s profile=%s roles=%s",
						userId, resource, permit.name(), userType.name(), authRequest.profile(), authRequest.roles());

				try (Response response = authorizationClient.check(auth, authRequest)) {
					AuthzResponse authResponse = readAuthorizationDecision(response, resource, permit, userType, userId);
					validateAuthorizationResponse(authResponse, resource, permit, userType, userId);
					MDC.put(AuthorizationUtils.PROFILE, profiloEsterno);
					return;

				} catch (ForbiddenException e) {
					lastForbidden = e;
					LOG.infof("Authorization denied for external profile. userId=%s resource=%s permit=%s profile=%s reason=%s",
							userId, resource, permit.name(), profiloEsterno, e.getMessage());

				} catch (NotAuthorizedException e) {
					throw e;

				} catch (jakarta.ws.rs.WebApplicationException e) {
					throw mapWebApplicationException(e, resource, permit, userType, userId);

				} catch (jakarta.ws.rs.ProcessingException e) {
					LOG.errorf(e, "Authorization remote processing error. userId=%s resource=%s permit=%s userType=%s profile=%s",
							userId, resource, permit.name(), userType.name(), profiloEsterno);
					throw new ServiceUnavailableException("Authorization service unavailable");

				} catch (Exception e) {
					LOG.errorf(e, "Authorization service error. userId=%s resource=%s permit=%s userType=%s profile=%s",
							userId, resource, permit.name(), userType.name(), profiloEsterno);
					throw new ServiceUnavailableException("Authorization service unavailable");
				}
			}

			if (lastForbidden != null) {
				throw lastForbidden;
			}

			throw new ForbiddenException("NOT_AUTHORIZED");
		} else if (userType == UserType.INTERNAL) {
			LOG.infof("Internal user authorization check. userId=%s resource=%s permit=%s", userId, resource, permit.name());

			if (roleDto != null && roleDto.roles() != null && !roleDto.roles().isEmpty()) {
				ruoli = roleDto.roles().stream()
						.map(AcrRoleDTO::code)
						.filter(code -> code != null && !code.isBlank())
						.collect(java.util.stream.Collectors.toSet());

				if (ruoli.isEmpty()) {
					throw new NotAuthorizedException("Internal user has no valid role codes. userId=" + userId);
				}

				profilo = retrieveInternalProfile(userId, ruoli);
			} else {
				throw new NotAuthorizedException("Internal user has no roles. userId=" + userId);
			}
		} else {
			throw new NotAuthorizedException("Invalid userType: " + userType);
		}

		if (profilo == null || profilo.isBlank()) {
			throw new NotAuthorizedException("Unable to resolve profile for userId=" + userId);
		}

		AuthzRequest authRequest = new AuthzRequest(profilo, resource, permit.name(), ruoli, userType.name());
		LOG.debugf("Calling authorization service. userId=%s resource=%s permit=%s userType=%s profile=%s roles=%s",
				userId, resource, permit.name(), userType.name(), authRequest.profile(), authRequest.roles());

		try (Response response = authorizationClient.check(auth, authRequest)) {
			AuthzResponse authResponse = readAuthorizationDecision(response, resource, permit, userType, userId);
			validateAuthorizationResponse(authResponse, resource, permit, userType, userId);

		} catch (ForbiddenException | NotAuthorizedException e) {
			throw e;

		} catch (jakarta.ws.rs.WebApplicationException e) {
			throw mapWebApplicationException(e, resource, permit, userType, userId);

		} catch (jakarta.ws.rs.ProcessingException e) {
			LOG.errorf(e, "Authorization remote processing error. userId=%s resource=%s permit=%s userType=%s",
					userId, resource, permit.name(), userType.name());
			throw new ServiceUnavailableException("Authorization service unavailable");

		} catch (Exception e) {
			LOG.errorf(e, "Authorization service error. userId=%s resource=%s permit=%s userType=%s",
					userId, resource, permit.name(), userType.name());
			throw new ServiceUnavailableException("Authorization service unavailable");
		}

		MDC.put(AuthorizationUtils.PROFILE, profilo);
	}


	private String resolveProfileCode(String profiloEsterno) {
		switch (profiloEsterno) {
			case "TITOLARE":
				return "T";
			case "COLLABORATORE":
				return "C";
			case "AZIENDA TERZA":
				return "AT";
			default:
				return "";
		}
	}

	private String retrieveInternalProfile(String userId, Set<String> ruoli) {
	    if (ruoli.contains("pmr_dce") || ruoli.contains("PMR_DCE")) {
	        return "pmr_dce";
	    }
	    if (ruoli.contains("pmr_dua") || ruoli.contains("PMR_DUA")) {
	        return "pmr_dua";
	    }

	    List<AcrAdministrationListDTO> admList = acrAddressingService.getAdministrationLists();

	    List<AdministrationListDTO> authorizationAdministrationLists = administrationListService.getAll();

	    Set<Integer> validListaIds = authorizationAdministrationLists.stream()
	            .filter(dto -> dto != null && Integer.valueOf(0).equals(dto.isDeleted()))
	            .map(AdministrationListDTO::listaId)
	            .filter(Objects::nonNull)
	            .collect(Collectors.toSet());


	    admList = admList.stream()
	            .filter(adm ->
	                    adm != null &&
	                    adm.administrationListId() != null &&
	                    validListaIds.contains(adm.administrationListId().intValue()))
	            .toList();

	    String firstMatch = null;
	    String normalizedUserId = userId != null ? userId.trim() : null;

	    for (AcrAdministrationListDTO adm : admList) {
	        AcrRecipientRequestDTO recipientDto = AcrRecipientRequestDTO.builder()
	                .includeTerritory(false)
	                .excludeChief(true)
	                .administrationLists(List.of(adm.administrationListId().intValue()))
	                .build();

	        boolean matches = acrAddressingService.getRecipients(recipientDto).stream()
	                .anyMatch(recipient ->
	                        recipient.userId() != null &&
	                        normalizedUserId != null &&
	                        recipient.userId().trim().equalsIgnoreCase(normalizedUserId));

	        if (!matches) {
	            continue;
	        }

	        String admName = adm.name();

	        if (admName != null && admName.startsWith("SM")) {
	            return admName;
	        }

	        if (firstMatch == null) {
	            firstMatch = admName;
	        }
	    }

	    return firstMatch;
	}



	private void validateAuthorizationResponse(AuthzResponse response, String resource, Permit permit, UserType userType, String userId) {

		if (response == null) {
			LOG.errorf("Authorization check returned null response. userId=%s resource=%s permit=%s userType=%s", userId, resource, permit.name(), userType.name());
			throw new ServiceUnavailableException("Authorization service unavailable");
		}

		if (!response.enabled()) {
			String reason = normalizeDenyReason(response.reason());

			LOG.infof("Authorization denied. userId=%s resource=%s permit=%s userType=%s reason=%s", userId, resource, permit.name(), userType.name(), reason);

			throw new ForbiddenException(reason);
		}

		LOG.debugf("Authorization granted. userId=%s resource=%s permit=%s userType=%s reason=%s", userId, resource, permit.name(), userType.name(), response.reason());
	}

	private RuntimeException mapWebApplicationException(jakarta.ws.rs.WebApplicationException e, String resource, Permit permit, UserType userType, String userId) {

		int status = e.getResponse() != null ? e.getResponse().getStatus() : -1;

		LOG.errorf(e, "Authorization remote HTTP error. status=%d userId=%s resource=%s permit=%s userType=%s", status, userId, resource, permit.name(), userType.name());

		if (status == 401) {
			return new NotAuthorizedException("Authorization service rejected bearer");
		}

		if (status == 403) {
			return new ForbiddenException("NOT_AUTHORIZED");
		}

		return new ServiceUnavailableException("Authorization service unavailable");
	}

	private String normalizeDenyReason(String reason) {
		return reason == null || reason.isBlank() ? "NOT_AUTHORIZED" : reason;
	}

	// overload
	public void assertAuthorized(String context, Permit permit) {
		assertAuthorized(context, permit, UserType.INTERNAL);
	}

	private boolean isAuthorizationSelfManagedResource(String resource) {
		if (resource == null || resource.isBlank()) {
			return false;
		}

		return resource.startsWith("/acr/addressing") || resource.startsWith("/acr/data-access") || resource.startsWith("/an_remi-cone_")
				|| resource.startsWith("/auth_structure_") || resource.equals("/auth_check") || resource.equals("/auth_structure") || resource.equals("/auth_map");
	}

	private AuthzResponse readAuthorizationDecision(Response response, String resource, Permit permit, UserType userType, String userId) {
		if (response == null) {
			LOG.errorf("Authorization check returned null response. userId=%s resource=%s permit=%s userType=%s", userId, resource, permit.name(), userType.name());
			throw new ServiceUnavailableException("Authorization service unavailable");
		}

		int status = response.getStatus();
		String body = response.hasEntity() ? response.readEntity(String.class) : "";

		if (status == Response.Status.OK.getStatusCode()) {
			if (body == null || body.isBlank()) {
				LOG.errorf("Authorization check returned empty body. userId=%s resource=%s permit=%s userType=%s", userId, resource, permit.name(), userType.name());
				throw new ServiceUnavailableException("Authorization service unavailable");
			}

			try {
				GenericResponse<AuthzResponse> wrapper = objectMapper.readValue(body, new TypeReference<GenericResponse<AuthzResponse>>() {
				});

				return wrapper != null ? wrapper.getData() : null;

			} catch (Exception e) {
				LOG.errorf(e, "Authorization response deserialization error. userId=%s resource=%s permit=%s userType=%s body=%s", userId, resource, permit.name(), userType.name(), body);
				throw new ServiceUnavailableException("Authorization service unavailable");
			}
		}

		LOG.errorf("Authorization remote HTTP error. status=%d userId=%s resource=%s permit=%s userType=%s body=%s", status, userId, resource, permit.name(), userType.name(), body);

		if (status == Response.Status.UNAUTHORIZED.getStatusCode()) {
			throw new NotAuthorizedException("Authorization service rejected bearer");
		}

		if (status == Response.Status.FORBIDDEN.getStatusCode()) {
			throw new ForbiddenException("NOT_AUTHORIZED");
		}

		throw new ServiceUnavailableException("Authorization service unavailable");
	}

}
