package it.eng.snam.pmr.batchintegrazione.service;

import java.util.Map;

import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class FlowTopicRoutingService {

    private static final Map<String, String> FLOW_TO_TOPIC = Map.ofEntries(
        Map.entry(Constants.Flussi.ANAG_REMI_FLOW, Constants.Topic.PMR001A_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ANAG_CLIENTI_FLOW, Constants.Topic.PMR001B_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ASS_REMI_CLIENTI_FLOW, Constants.Topic.PMR001C_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ASS_REMI_TITOLARI_FLOW, Constants.Topic.PMR001D_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ASS_REMI_AOP_FLOW, Constants.Topic.PMR001E_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ASS_STATO_REMI_FLOW, Constants.Topic.PMR001F_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ASS_REMI_TIPO_BILANCIO_TECNICO_FLOW, Constants.Topic.PMR001G_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ANAG_AREA_TECNICA_FLOW, Constants.Topic.PMR001H_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ANAG_POLO_FLOW, Constants.Topic.PMR001I_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ANAG_MACRO_POLO_FLOW, Constants.Topic.PMR001L_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.CONTATTO_FLOW, Constants.Topic.PMR001M_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ANAG_RAGGRUPPAMENTI_FLOW, Constants.Topic.PMR001N_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.ASS_RAGGRUPPAMENTI_REMI_FLOW, Constants.Topic.PMR001O_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.VERBALI_MISURA_FLOW, Constants.Topic.PMR006A_SUMMER_IN_TOPIC),
        Map.entry(Constants.Flussi.VERBALI_MISURA_GIORN_FLOW, Constants.Topic.PMR006B_SUMMER_IN_TOPIC)
    );

    public String resolveTopic(String flow) {
        String topic = FLOW_TO_TOPIC.get(flow);
        if (topic == null) {
            throw new IllegalArgumentException("Flow non supportato: " + flow);
        }
        return topic;
    }
}