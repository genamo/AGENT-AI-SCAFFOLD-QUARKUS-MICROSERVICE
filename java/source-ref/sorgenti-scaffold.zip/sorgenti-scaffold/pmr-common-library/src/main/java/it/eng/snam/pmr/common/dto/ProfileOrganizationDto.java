package it.eng.snam.pmr.common.dto;

import java.util.List;

public record ProfileOrganizationDto(
        String organizationCode,
        String customerOrganizationCode,
        List<ProfileModuleDto> modules
) {}
