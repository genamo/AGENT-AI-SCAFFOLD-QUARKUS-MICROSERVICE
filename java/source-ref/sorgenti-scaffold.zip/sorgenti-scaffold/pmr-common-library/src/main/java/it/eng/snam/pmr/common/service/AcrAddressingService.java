package it.eng.snam.pmr.common.service;

import java.util.List;
import java.util.function.Supplier;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.MDC;

import com.fasterxml.jackson.core.type.TypeReference;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.common.client.AuthorizationClient;
import it.eng.snam.pmr.common.dto.acr.addressing.AcrAdministrationListDTO;
import it.eng.snam.pmr.common.dto.acr.addressing.AcrRecipientDTO;
import it.eng.snam.pmr.common.dto.acr.addressing.AcrRecipientRequestDTO;
import it.eng.snam.pmr.common.dto.acr.addressing.AcrSubProfileDTO;
import it.eng.snam.pmr.common.dto.acr.addressing.AcrTerritoryDTO;
import it.eng.snam.pmr.common.dto.acr.addressing.AcrVerticalDTO;
import it.eng.snam.pmr.common.dto.acr.addressing.AcrWidgetDTO;
import it.eng.snam.pmr.common.response.GenericResponse;
import it.eng.snam.pmr.common.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.CommonConstants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class AcrAddressingService extends AbstractService {

    private static final TypeReference<GenericResponse<List<AcrRecipientDTO>>> RECIPIENT_TYPE =
            new TypeReference<>() {};

    private static final TypeReference<GenericResponse<List<AcrAdministrationListDTO>>> ADMIN_LIST_TYPE =
            new TypeReference<>() {};

    private static final TypeReference<GenericResponse<List<String>>> PROFILE_TYPE =
            new TypeReference<>() {};

    private static final TypeReference<GenericResponse<List<AcrTerritoryDTO>>> TERRITORY_TYPE =
            new TypeReference<>() {};

    private static final TypeReference<GenericResponse<List<AcrWidgetDTO>>> WIDGET_TYPE =
            new TypeReference<>() {};

    private static final TypeReference<GenericResponse<List<AcrVerticalDTO>>> VERTICAL_TYPE =
            new TypeReference<>() {};

    private static final TypeReference<GenericResponse<List<AcrSubProfileDTO>>> SUBPROFILE_TYPE =
            new TypeReference<>() {};

    @Inject
    @RestClient
    AuthorizationClient authorizationClient;

    public List<AcrRecipientDTO> getRecipients(AcrRecipientRequestDTO request) {
        return emptyIfNull(execute(
                "POST /acr/addressing/recipient",
                () -> authorizationClient.getRecipients(request),
                RECIPIENT_TYPE
        ));
    }

    public List<AcrAdministrationListDTO> getAdministrationLists() {
        return emptyIfNull(execute(
                "GET /acr/addressing/administration-list",
                authorizationClient::getAdministrationLists,
                ADMIN_LIST_TYPE
        ));
    }

    public List<String> getProfiles() {
        return emptyIfNull(execute(
                "GET /acr/addressing/profile",
                authorizationClient::getProfiles,
                PROFILE_TYPE
        ));
    }

    public List<AcrTerritoryDTO> getTerritories() {
        return emptyIfNull(execute(
                "GET /acr/addressing/territory",
                authorizationClient::getTerritories,
                TERRITORY_TYPE
        ));
    }

    public List<AcrWidgetDTO> getWidgets() {
        return emptyIfNull(execute(
                "GET /acr/addressing/widget",
                authorizationClient::getWidgets,
                WIDGET_TYPE
        ));
    }

    public List<AcrVerticalDTO> getVerticals() {
        return emptyIfNull(execute(
                "GET /acr/addressing/vertical",
                authorizationClient::getVerticals,
                VERTICAL_TYPE
        ));
    }

    public List<AcrSubProfileDTO> getSubProfiles() {
        return emptyIfNull(execute(
                "GET /acr/addressing/subprofile",
                authorizationClient::getSubProfiles,
                SUBPROFILE_TYPE
        ));
    }

    private <T> T execute(
            String operation,
            Supplier<Response> call,
            TypeReference<GenericResponse<T>> typeReference
    ) {
        String previousApi = (String) MDC.get(CommonConstants.LogParams.API);

        try {
            MDC.put(CommonConstants.LogParams.API, operation);

            return executeClientCall(call, typeReference);
        } finally {
            restoreApi(previousApi);
        }
    }

    private <T> List<T> emptyIfNull(List<T> list) {
        return list == null ? List.of() : list;
    }

    private void restoreApi(String previousApi) {
        if (previousApi == null) {
            MDC.remove(CommonConstants.LogParams.API);
        } else {
            MDC.put(CommonConstants.LogParams.API, previousApi);
        }
    }
}
