package it.eng.snam.pmr.batchintegrazionedg.utils.kafka;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Channels {

    @UtilityClass
    public class Incoming {
        public final String MONITORING_INTEGRATION_OUTCOME = "monitoring-integration-outcome";
        public final String MONITORING_FLUSSI_IN = "monitor-flussi-in";
    }

    @UtilityClass
    public class Outgoing {
        public final String KAFKA_OUT = "kafka-out";
    }
}
