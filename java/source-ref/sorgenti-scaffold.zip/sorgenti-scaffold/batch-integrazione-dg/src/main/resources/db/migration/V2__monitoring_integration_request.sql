USE [pmrintegrazione];

/* ============================================================
   AZURE SQL - MONITORING INTEGRATION TRACKING
   Prefix tabelle: monitoring_integration_
   ============================================================ */
IF OBJECT_ID('dbo.monitoring_integration_request') IS NULL
BEGIN
    CREATE TABLE dbo.monitoring_integration_request (
        id                  BIGINT IDENTITY(1,1) NOT NULL,
        transaction_id      NVARCHAR(100) NOT NULL,
        user_id             NVARCHAR(100) NOT NULL,
        integration_type    NVARCHAR(100) NULL,
        created_at_utc      DATETIME2(3) NOT NULL
            CONSTRAINT df_monitoring_integration_request_created_at_utc
            DEFAULT SYSUTCDATETIME(),
        updated_at_utc      DATETIME2(3) NULL,

        CONSTRAINT pk_monitoring_integration_request
            PRIMARY KEY CLUSTERED (ID));

    /* ============================================================
       INDICI monitoring_integration_request
       ============================================================ */
    CREATE NONCLUSTERED INDEX ix_monitoring_integration_request_transaction_id
    ON dbo.monitoring_integration_request (transaction_id);

    CREATE NONCLUSTERED INDEX ix_monitoring_integration_request_user_id_created_at_utc
    ON dbo.monitoring_integration_request (user_id, created_at_utc DESC);

    CREATE NONCLUSTERED INDEX ix_monitoring_integration_request_source_system
    ON dbo.monitoring_integration_request (source_system)
    WHERE source_system IS NOT NULL;
END
