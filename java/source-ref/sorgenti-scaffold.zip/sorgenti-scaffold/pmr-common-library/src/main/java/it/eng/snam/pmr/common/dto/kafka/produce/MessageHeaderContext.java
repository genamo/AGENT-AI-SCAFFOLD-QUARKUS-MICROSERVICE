package it.eng.snam.pmr.common.dto.kafka.produce;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class MessageHeaderContext {

    String transactionId;
    String userId;
    String keyLogic;
    String processType;
    String flowType;
    String messageKey;
}
