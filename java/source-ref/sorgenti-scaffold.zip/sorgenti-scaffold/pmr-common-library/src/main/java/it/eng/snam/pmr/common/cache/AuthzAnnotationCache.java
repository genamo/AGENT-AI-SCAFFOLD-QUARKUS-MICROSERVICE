package it.eng.snam.pmr.common.cache;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

import it.eng.snam.pmr.common.annotation.AuthzRead;
import it.eng.snam.pmr.common.annotation.AuthzWrite;
import it.eng.snam.pmr.common.annotation.RemiConeCheck;
import jakarta.ws.rs.container.ResourceInfo;

public class AuthzAnnotationCache {

    /**
     * Chiave composita (Method, annotationClass) → ogni annotation type ha
     * la propria entry. Un metodo con più annotation non causa sovrascritture.
     */
    private static final Map<CacheKey, Object> CACHE = new ConcurrentHashMap<>();

    /** Sentinel: indica che la ricerca è già stata fatta e l'annotation è assente. */
    private static final Object ABSENT = new Object();

    public static AuthzRead getAuthzRead(ResourceInfo resourceInfo) {
        return get(resourceInfo, AuthzRead.class);
    }

    public static AuthzWrite getAuthzWrite(ResourceInfo resourceInfo) {
        return get(resourceInfo, AuthzWrite.class);
    }

    public static RemiConeCheck getRemiConeCheck(ResourceInfo resourceInfo) {
        return get(resourceInfo, RemiConeCheck.class);
    }

    private static <T extends Annotation> T get(
            ResourceInfo resourceInfo,
            Class<T> annotationClass) {

        Method method = resourceInfo.getResourceMethod();
        CacheKey key = new CacheKey(method, annotationClass);

        Object cached = CACHE.computeIfAbsent(key, k -> {

            // 1️⃣ annotation sul metodo
            T ann = method.getAnnotation(annotationClass);
            if (ann != null) {
                return ann;
            }

            // 2️⃣ fallback sulla classe
            T classAnn = resourceInfo.getResourceClass().getAnnotation(annotationClass);
            return classAnn != null ? classAnn : ABSENT;
        });

        return cached == ABSENT ? null : annotationClass.cast(cached);
    }

    // ------------------------------------------------------------------
    // Chiave composita thread-safe e immutabile
    // ------------------------------------------------------------------

    private record CacheKey(Method method, Class<? extends Annotation> annotationClass) {

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof CacheKey other)) return false;
            return Objects.equals(method, other.method)
                    && Objects.equals(annotationClass, other.annotationClass);
        }

        @Override
        public int hashCode() {
            return Objects.hash(method, annotationClass);
        }
    }
}
