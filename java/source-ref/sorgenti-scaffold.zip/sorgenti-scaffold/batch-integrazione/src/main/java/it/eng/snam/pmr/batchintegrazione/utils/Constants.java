package it.eng.snam.pmr.batchintegrazione.utils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public final class Constants {

    private Constants() {}

    public static final String TIMESTAMP_FORMAT = "yyyyMMddHHmmssSSS";
    public static final String MSG_ERROR = "Error";

    
    public static final class Flussi {


		private Flussi() {}
		// ======================================================
		// ANAGRAFICHE
		// ======================================================
		public static final String ANAG_REMI_FLOW = "PMR001A";
		public static final String ANAG_CLIENTI_FLOW = "PMR001B";
		public static final String ASS_REMI_CLIENTI_FLOW = "PMR001C";
		public static final String ASS_REMI_TITOLARI_FLOW = "PMR001D";
		public static final String ASS_REMI_AOP_FLOW = "PMR001E";
		public static final String ASS_STATO_REMI_FLOW = "PMR001F";
		public static final String ASS_REMI_TIPO_BILANCIO_TECNICO_FLOW = "PMR001G";
		public static final String ANAG_AREA_TECNICA_FLOW = "PMR001H";
		public static final String ANAG_POLO_FLOW = "PMR001I";
		public static final String ANAG_MACRO_POLO_FLOW = "PMR001L";
		public static final String CONTATTO_FLOW = "PMR001M";
		public static final String ANAG_RAGGRUPPAMENTI_FLOW = "PMR001N";
		public static final String ASS_RAGGRUPPAMENTI_REMI_FLOW = "PMR001O";
		public static final String VERBALI_MISURA_FLOW = "PMR006A";
		public static final String VERBALI_MISURA_GIORN_FLOW = "PMR006B";
		public static final String QUALITA_GASDAY_FLOW = "PMR006C";
		public static final String ANALISI_QUALITA_GASDAY_FLOW = "PMR006D";
		public static final Set<String> VALID_FLOWS = Set.of(ANAG_REMI_FLOW, ANAG_CLIENTI_FLOW, ASS_REMI_CLIENTI_FLOW, ASS_REMI_TITOLARI_FLOW, ASS_REMI_AOP_FLOW, ASS_STATO_REMI_FLOW, ASS_REMI_TIPO_BILANCIO_TECNICO_FLOW, ANAG_AREA_TECNICA_FLOW, ANAG_POLO_FLOW, ANAG_MACRO_POLO_FLOW, CONTATTO_FLOW, ANAG_RAGGRUPPAMENTI_FLOW, ASS_RAGGRUPPAMENTI_REMI_FLOW,VERBALI_MISURA_FLOW,VERBALI_MISURA_GIORN_FLOW,QUALITA_GASDAY_FLOW,ANALISI_QUALITA_GASDAY_FLOW);

		public static boolean isValidFlow(String flow) {
			return flow != null && VALID_FLOWS.contains(flow);
		}
	}
    
    
    public static final class Headers {
        private Headers() {}
        public static final String TRANSACTION_ID = "TRANSACTION-ID";
        public static final String KEYLOGIC = "KEY-LOGIC";
        public static final String MOD_ASYNC = "MOD-ASYNC";
        public static final String PROCESS_TYPE = "PROCESS-TYPE";
        public static final String MESSAGE_KEY = "MESSAGE-KEY";
        public static final String CONTENT_TYPE = "content-type";
        public static final String JWT = "JWT";
        public static final String AUTHORIZATION = "Authorization";
    }
    
    public static final class KafkaHeaders {
        private KafkaHeaders() {}
        public static final String TRANSACTION_ID = "TRANSACTION-ID";
        public static final String KEYLOGIC = "KEY-LOGIC";
        public static final String PROCESS_TYPE = "PROCESS-TYPE";
        public static final String FLOW_TYPE = "FLOW";
        public static final String MESSAGE_KEY = "MESSAGE-KEY";
        public static final String CONTENT_TYPE = "content-type";
        
    }

    public static final class LogParams {
        private LogParams() {}
        public static final String TN = "TN";
        public static final String KL = "KL";
        public static final String API = "API";
        public static final String MK = "MK";
        public static final String PT = "PT";
        public static final String MA = "MA";
    }

    public static final class MEDIATYPE {
        private MEDIATYPE() {}
        public static final String APP_JSON = "application/json";
    }

    public static final class Topic {
        private Topic() {}
        public static final String PMR001A_SUMMER_IN_TOPIC = "anagraficaremisummerin";
        public static final String PMR001B_SUMMER_IN_TOPIC = "anagraficaclientisummerin";
        public static final String PMR001C_SUMMER_IN_TOPIC = "associazioneremiclientisummerin";
        public static final String PMR001D_SUMMER_IN_TOPIC = "associazioneremititolarisummerin";
        public static final String PMR001E_SUMMER_IN_TOPIC = "associazioneremiaopsummerin";
        public static final String PMR001F_SUMMER_IN_TOPIC = "associazionestatoremisummerin";
        public static final String PMR001G_SUMMER_IN_TOPIC = "associazioneremitipobilanciotecnicosummerin";
        public static final String PMR001H_SUMMER_IN_TOPIC = "areatecnicasummerin";
        public static final String PMR001I_SUMMER_IN_TOPIC = "anagraficapolosummerin";
        public static final String PMR001L_SUMMER_IN_TOPIC = "anagraficamacrosummerin";
        public static final String PMR001M_SUMMER_IN_TOPIC = "contattosummerin";
        public static final String PMR001N_SUMMER_IN_TOPIC = "anagraficaraggruppamentisummerin";
        public static final String PMR001O_SUMMER_IN_TOPIC = "associazioneraggruppamentiremisummerin";
        public static final String DATE_RIEPILOGHI_SUMMER_IN_TOPIC = "dateriepiloghisummerin";
        
        public static final String PMR006A_SUMMER_IN_TOPIC = "verbalimisurasummerin";
        public static final String PMR006B_SUMMER_IN_TOPIC = "verbalimisuragiornsummerin";
        
        public static final String PMR006C_SUMMER_IN_TOPIC = "qualitagiornogassummerin";
        public static final String PMR006D_SUMMER_IN_TOPIC = "analisiqualgiorngassummerin";
        
        public static final String GLOBAL_DLQ_TOPIC = "globaldlq";
        
        public static List<String> getAllTopicsValue() throws IllegalArgumentException, IllegalAccessException {
            List<Field> fields = Arrays.asList(Constants.Topic.class.getDeclaredFields());
            List<String> topics = new ArrayList<>();
            for (Field field : fields) {
                if (field.getType() == String.class) {
                    topics.add((String) field.get(null));
                }
            }
            return topics;
        }
    }
}