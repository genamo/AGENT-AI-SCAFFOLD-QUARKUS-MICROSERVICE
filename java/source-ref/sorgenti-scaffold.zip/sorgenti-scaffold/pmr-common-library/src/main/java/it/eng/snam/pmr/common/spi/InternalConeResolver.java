package it.eng.snam.pmr.common.spi;

import it.eng.snam.pmr.common.dto.RemiConeDTO;

/**
 * SPI opzionale per la risoluzione del cono dati di un utente interno.
 *
 * <p>Se questo bean è presente nel contesto CDI del microservizio
 * (es. il MS è {@code anagrafiche} stesso), {@link it.eng.snam.pmr.common.service.RemiConeValidationService}
 * lo usa direttamente evitando la chiamata HTTP remota verso {@code /an_remi-cone_getCurrentUser}.
 *
 * <p>I microservizi che NON implementano questa interfaccia delegano automaticamente
 * alla chiamata HTTP via {@code AnagraficheConeClient}.
 */
public interface InternalConeResolver {

    /**
     * Risolve il cono dati dell'utente interno identificato da {@code userId}.
     *
     * @param userId l'userId già autenticato (da MDC)
     * @return il cono dati dell'utente
     */
    RemiConeDTO resolve(String userId);
}
