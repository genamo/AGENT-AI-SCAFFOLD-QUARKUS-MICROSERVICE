package it.eng.snam.pmr.common.dto.acr.roles;

import java.util.List;

import lombok.Builder;

@Builder
public record AcrRolesResponseDTO(
        String jwtUserId,
        String rawRoles,
        List<AcrRoleDTO> roles
) {}
