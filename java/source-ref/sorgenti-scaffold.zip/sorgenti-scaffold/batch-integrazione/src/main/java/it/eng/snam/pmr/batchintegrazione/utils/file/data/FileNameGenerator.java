package it.eng.snam.pmr.batchintegrazione.utils.file.data;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.function.Supplier;

import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import lombok.experimental.UtilityClass;

@UtilityClass
public class FileNameGenerator {

    private final String SEPARATOR = "_";
    private final String EXTENSION = ".zip";

    private final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH.mm.ss");

    private final Supplier<String> TIMESTAMP = () -> LocalDateTime.now(ZoneOffset.UTC).format(FORMATTER);

    public String generate() {
        return TIMESTAMP.get() + SEPARATOR + MdcManager.getHeader(CommonConstants.LogParams.TN) + EXTENSION;
    }
}