package it.eng.snam.pmr.common.dto;

import org.apache.commons.lang3.StringUtils;

import jakarta.ws.rs.core.Response;
import lombok.Value;

@Value(staticConstructor = "of")
public class ResponseContext {

    String operation;
    int status;
    String body;

    public boolean isOk() {
        return status == Response.Status.OK.getStatusCode();
    }

    public boolean isNoContent() {
        return status == Response.Status.NO_CONTENT.getStatusCode();
    }

    public boolean emptyBody() {
        return isNoContent() || StringUtils.isBlank(body);
    }
}
