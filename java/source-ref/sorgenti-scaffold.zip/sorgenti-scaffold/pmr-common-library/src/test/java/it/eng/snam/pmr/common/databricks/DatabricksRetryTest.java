package it.eng.snam.pmr.common.databricks;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class DatabricksRetryTest {

    private DatabricksRetry retry;

    @BeforeEach
    void setUp() throws Exception {
        retry = new DatabricksRetry();
        setField(retry, "maxAttempts", 3);
        setField(retry, "initialDelayMs", 1L);   // very short for fast tests
        setField(retry, "maxDelayMs", 10L);
        setField(retry, "jitterPct", 0.0);
    }

    private static void setField(Object obj, String name, Object value) throws Exception {
        Field f = DatabricksRetry.class.getDeclaredField(name);
        f.setAccessible(true);
        f.set(obj, value);
    }

    // -----------------------------------------------------------------------
    // Happy path
    // -----------------------------------------------------------------------

    @Test
    void execute_successOnFirstAttempt_returnsResult() {
        String result = retry.execute(() -> "ok");
        assertThat(result).isEqualTo("ok");
    }

    // -----------------------------------------------------------------------
    // Retry on transient error
    // -----------------------------------------------------------------------

    @Test
    void execute_failOnceThenSucceed_retriesAndReturns() {
        AtomicInteger attempts = new AtomicInteger(0);

        String result = retry.execute(() -> {
            if (attempts.incrementAndGet() < 2) {
                throw new SQLException("connection error", "08001"); // retryable
            }
            return "recovered";
        });

        assertThat(result).isEqualTo("recovered");
        assertThat(attempts.get()).isEqualTo(2);
    }

    // -----------------------------------------------------------------------
    // Exhausted retries
    // -----------------------------------------------------------------------

    @Test
    void execute_allAttemptsFail_throwsRuntimeException() {
        AtomicInteger count = new AtomicInteger(0);
        assertThatThrownBy(() ->
            retry.execute(() -> {
                count.incrementAndGet();
                throw new SQLException("busy", "08KD1"); // retryable
            })
        ).isInstanceOf(RuntimeException.class)
         .hasMessageContaining("Databricks query failed");

        assertThat(count.get()).isEqualTo(3);
    }

    // -----------------------------------------------------------------------
    // Non-retryable error
    // -----------------------------------------------------------------------

    @Test
    void execute_nonRetryableError_failsImmediately() {
        AtomicInteger count = new AtomicInteger(0);
        assertThatThrownBy(() ->
            retry.execute(() -> {
                count.incrementAndGet();
                throw new SQLException("table not found", "42P01"); // NOT retryable
            })
        ).isInstanceOf(RuntimeException.class);

        assertThat(count.get()).isEqualTo(1);
    }

    // -----------------------------------------------------------------------
    // Retryable by message (503)
    // -----------------------------------------------------------------------

    @Test
    void execute_503Message_isRetryable() {
        AtomicInteger count = new AtomicInteger(0);
        assertThatThrownBy(() ->
            retry.execute(() -> {
                count.incrementAndGet();
                throw new SQLException("HTTP response code: 503", (String) null);
            })
        ).isInstanceOf(RuntimeException.class);
        assertThat(count.get()).isEqualTo(3);
    }

    // -----------------------------------------------------------------------
    // isRetryable: null sqlState falls back to message
    // -----------------------------------------------------------------------

    @Test
    void execute_nullSqlState_notRetryable() {
        AtomicInteger count = new AtomicInteger(0);
        assertThatThrownBy(() ->
            retry.execute(() -> {
                count.incrementAndGet();
                throw new SQLException("generic error"); // null sqlState, no 503 in message
            })
        ).isInstanceOf(RuntimeException.class);
        assertThat(count.get()).isEqualTo(1);
    }
}
