package it.eng.snam.pmr.common.filter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import it.eng.snam.pmr.common.util.B2BTokenUtils;
import jakarta.ws.rs.container.ContainerRequestContext;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class B2BTokenFilterTest {

    @Mock ContainerRequestContext req;
    @Mock B2BTokenUtils b2bTokenUtils;

    B2BTokenFilter filter;

    @BeforeEach
    void setUp() throws Exception {
        filter = new B2BTokenFilter();
        setField(filter, "b2bTokenUtils", b2bTokenUtils);
        setField(filter, "securityEnabled", true);
    }

    @Test
    void filter_securityDisabled_skipsCompletely() throws Exception {
        setField(filter, "securityEnabled", false);
        filter.filter(req);
        verify(req, never()).getHeaderString(anyString());
        verify(b2bTokenUtils, never()).isValid(anyString());
    }

    @Test
    void filter_noAuthorizationHeader_skips() throws Exception {
        when(req.getHeaderString("Authorization")).thenReturn(null);
        filter.filter(req);
        verify(b2bTokenUtils, never()).isValid(anyString());
    }

    @Test
    void filter_nonBearerHeader_skips() throws Exception {
        when(req.getHeaderString("Authorization")).thenReturn("Basic dXNlcjpwYXNz");
        filter.filter(req);
        verify(b2bTokenUtils, never()).isValid(anyString());
    }

    @Test
    void filter_validB2BToken_setsProperty() throws Exception {
        String token = "Bearer valid.b2b.token";
        when(req.getHeaderString("Authorization")).thenReturn(token);
        when(b2bTokenUtils.isValid(token)).thenReturn(true);
        filter.filter(req);
        verify(req).setProperty(B2BTokenFilter.B2B_SUPER_USER_KEY, Boolean.TRUE);
    }

    @Test
    void filter_invalidB2BToken_doesNotSetProperty() throws Exception {
        String token = "Bearer invalid.token";
        when(req.getHeaderString("Authorization")).thenReturn(token);
        when(b2bTokenUtils.isValid(token)).thenReturn(false);
        filter.filter(req);
        verify(req, never()).setProperty(anyString(), any());
    }

    @Test
    void b2bSuperUserKey_isCorrectConstant() {
        assertThat(B2BTokenFilter.B2B_SUPER_USER_KEY).isEqualTo("b2b.super_user");
    }

    private static void setField(Object obj, String name, Object value) throws Exception {
        Field f = findField(obj.getClass(), name);
        f.setAccessible(true);
        f.set(obj, value);
    }

    private static Field findField(Class<?> clazz, String name) throws NoSuchFieldException {
        try { return clazz.getDeclaredField(name); }
        catch (NoSuchFieldException e) {
            if (clazz.getSuperclass() != null) return findField(clazz.getSuperclass(), name);
            throw e;
        }
    }
}
