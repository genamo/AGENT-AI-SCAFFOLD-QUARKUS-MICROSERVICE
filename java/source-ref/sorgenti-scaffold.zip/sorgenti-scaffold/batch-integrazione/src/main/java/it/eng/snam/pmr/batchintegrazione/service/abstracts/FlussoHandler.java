package it.eng.snam.pmr.batchintegrazione.service.abstracts;

public interface FlussoHandler {
    String getFlowType();
    void process(String payload);
}