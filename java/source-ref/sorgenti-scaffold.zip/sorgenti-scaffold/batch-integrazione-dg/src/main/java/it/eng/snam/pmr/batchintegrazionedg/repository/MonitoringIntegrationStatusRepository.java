package it.eng.snam.pmr.batchintegrazionedg.repository;

import java.util.Optional;

import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import it.eng.snam.pmr.batchintegrazionedg.entity.MonitoringIntegrationStatus;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MonitoringIntegrationStatusRepository implements PanacheRepositoryBase<MonitoringIntegrationStatus, Long> {

    public Optional<MonitoringIntegrationStatus> findByUploadRequestId(Long integrationRequestId) {
        return findByIdOptional(integrationRequestId);
    }
}
