package it.eng.snam.pmr.batchintegrazione.utils;

public enum MessageTypeEnum {

	OK				    ("Info",  "1"),
	ERROR_GESTITO_SEARCH("Info", "4"),
	ERROR_GESTITO       (Constants.MSG_ERROR, "2"),
	ERROR_NON_GESTITO   (Constants.MSG_ERROR, "3"),
	ERROR_BUSINESS_LOGIC(Constants.MSG_ERROR, "7");

	private final String messageType;
	private final String messageCode;

	private MessageTypeEnum(String messageType, String messageCode) {
		this.messageType = messageType;
		this.messageCode = messageCode;
	}


	public String getMessageType() {
		return this.messageType;
	}


	public String getMessageCode() {
		return this.messageCode;
	}

}
