package it.eng.snam.pmr.batchintegrazione.service.abstracts;

public interface ValidationInterface {
	String getCorrelationId();
	int getElementNumber();
}
