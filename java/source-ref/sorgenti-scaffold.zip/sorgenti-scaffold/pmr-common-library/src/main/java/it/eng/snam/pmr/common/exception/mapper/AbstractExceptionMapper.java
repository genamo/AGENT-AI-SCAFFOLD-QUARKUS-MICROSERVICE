package it.eng.snam.pmr.common.exception.mapper;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.Utility;
import it.eng.snam.pmr.common.util.exception.mapper.ConstraintViolationNormalizer;
import it.eng.snam.pmr.common.util.exception.mapper.ThrowableStatusResolver;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import jakarta.inject.Inject;
import jakarta.validation.ConstraintViolationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import lombok.Setter;

@Setter(onMethod_ = @Inject)
public abstract class AbstractExceptionMapper<T extends Throwable> implements ExceptionMapper<T> {

    private Utility utility;

    private Logger log() {
        return LoggerFactory.getLogger(getClass());
    }

    protected abstract Map<Class<? extends Throwable>, Response.Status> getStatusRules();

    @Override
    public Response toResponse(T exception) {
        String api = MdcManager.getHeader(CommonConstants.LogParams.API);
        Response.Status status = ThrowableStatusResolver.resolve(exception, getStatusRules());
        String exceptionMessage = (exception instanceof ConstraintViolationException violationException)
                ? ConstraintViolationNormalizer.normalize(violationException.getConstraintViolations())
                : exception.getMessage();

        log().error("[{}] API error: status='{} {}' - message='{}'", api, status.getStatusCode(), status.getReasonPhrase(), exceptionMessage, exception);
        return utility.errorResponse(exceptionMessage, status);
    }
}
