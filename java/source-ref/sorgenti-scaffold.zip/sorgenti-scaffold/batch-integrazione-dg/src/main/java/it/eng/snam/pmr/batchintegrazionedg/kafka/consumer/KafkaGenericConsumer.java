package it.eng.snam.pmr.batchintegrazionedg.kafka.consumer;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.CompletionStage;

import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.common.header.Headers;
import org.eclipse.microprofile.reactive.messaging.Acknowledgment;
import org.eclipse.microprofile.reactive.messaging.Incoming;
import org.eclipse.microprofile.reactive.messaging.Message;

import io.smallrye.common.annotation.Blocking;
import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration.MonitoringIntegrationOutcome;
import it.eng.snam.pmr.batchintegrazionedg.kafka.KafkaTopic;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringBatchService;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringFlussiService;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringIntegrationService;
import it.eng.snam.pmr.batchintegrazionedg.service.abstracts.KafkaTopicResolver;
import it.eng.snam.pmr.batchintegrazionedg.utils.kafka.Channels;
import it.eng.snam.pmr.common.functional.interfaces.kafka.consumer.MessageHandlerFactory;
import it.eng.snam.pmr.common.util.CommonConstants;
import it.eng.snam.pmr.common.util.kafka.consumer.MessageProcessor;
import it.eng.snam.pmr.common.util.mdc.MdcManager;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class KafkaGenericConsumer {

    private final KafkaTopicResolver kafkaTopicResolver;
    private final MonitoringFlussiService monitoringFlussiService;
    private final MonitoringBatchService monitoringBatchService;
    private final MonitoringIntegrationService monitoringIntegrationService;

    private Map<String, MessageHandlerFactory> handlers;

    @PostConstruct
    void init() {
        handlers = Map.of(kafkaTopicResolver.findRealTopic(KafkaTopic.INTEGRAZIONE_FLUSSI_TOPIC), MessageHandlerFactory.bytes(this::handleMessageMonitoraggio),
                          kafkaTopicResolver.findRealTopic(KafkaTopic.MONITORING_INTEGRATION_OUTCOME), MessageHandlerFactory.json(MonitoringIntegrationOutcome.class, monitoringIntegrationService::persist));
        handlers.keySet().forEach(t -> log.info("Kafka handler registered for topic: {}", t));
    }

    @RunOnVirtualThread
    @Incoming(Channels.Incoming.MONITORING_INTEGRATION_OUTCOME)
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    public CompletionStage<Void> consumeMonitoringIntegrationOutcome(Message<byte[]> message) {
        return MessageProcessor.manual(message, handlers);
    }

    @Blocking
    @Incoming(Channels.Incoming.MONITORING_FLUSSI_IN)
    @Acknowledgment(Acknowledgment.Strategy.MANUAL)
    public CompletionStage<Void> consumeMonitorFlussiIn(Message<byte[]> message) {
        return MessageProcessor.manual(message, handlers);
    }

    private void handleMessageMonitoraggio(byte[] payloadBytes, Headers headers) {
        log.info("handleMessageMonitoraggio.....");

        String flow = MdcManager.getHeader(CommonConstants.LogParams.FT);
        if (StringUtils.isBlank(flow)) {
            log.warn("Missing FLOW header, skipping processing");
            return;
        }
        String payload = payloadBytes == null ? "" : new String(payloadBytes, StandardCharsets.UTF_8);
        if (flow.equals("FLUSSO")) {
            monitoringFlussiService.processSaveMonitoringFlussi(payload);
        }else if (flow.equals("BATCH"))
        	monitoringBatchService.processSaveMonitoringBatch(payload);
        else
            log.warn("Unknown flow '{}' in message headers, skipping processing", flow);
    }
}