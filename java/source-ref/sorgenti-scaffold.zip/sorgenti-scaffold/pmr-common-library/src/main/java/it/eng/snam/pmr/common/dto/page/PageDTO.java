package it.eng.snam.pmr.common.dto.page;

import java.util.List;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "PageDTO", description = "DTO contenente i dati paginati.")
public class PageDTO<T> {

    @Schema(description = "Elementi della pagina corrente.")
    private List<T> elements;

    @Schema(description = "Numero di elementi presenti nella pagina corrente.", examples = "20", minimum = "0")
    private Integer elementsSize;

    @Schema(description = "Numero totale di elementi disponibili.", examples = "153", minimum = "0")
    private Integer elementsAmount;

    @Schema(description = "Indice della pagina corrente (partendo da 0).", examples = "0", minimum = "0")
    private Integer currentPage;

    @Schema(description = "Numero totale di pagine.", examples = "8", minimum = "0")
    private Integer totalPages;
}