package it.eng.snam.pmr.common.exception.mapper;

import java.util.Map;

import it.eng.snam.pmr.common.util.exception.mapper.ThrowableDomain;
import jakarta.validation.ConstraintViolationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;

@Provider
public class ConstraintViolationMapper extends AbstractExceptionMapper<ConstraintViolationException> {

    @Override
    protected Map<Class<? extends Throwable>, Response.Status> getStatusRules() {
        return ThrowableDomain.VIOLATION_STATUS_RULES;
    }
}