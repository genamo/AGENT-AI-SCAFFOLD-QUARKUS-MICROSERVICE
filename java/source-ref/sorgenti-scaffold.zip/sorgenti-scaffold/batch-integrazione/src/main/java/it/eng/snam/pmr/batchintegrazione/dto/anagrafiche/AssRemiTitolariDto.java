package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AssRemiTitolariDto(
        String remiAssoluto,
        LocalDateTime dataInizioValidita,
        Long dataInizioValiditaInt,
        String codiceCliente,
        LocalDateTime dataFineValidita,
        Long dataFineValiditaInt,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {}