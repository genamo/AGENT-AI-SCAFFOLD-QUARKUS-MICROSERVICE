package it.eng.snam.pmr.batchintegrazionedg.test.resource;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;

import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.TestProfile;
import io.restassured.http.ContentType;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.DlqFlussoResponseDTO;
import it.eng.snam.pmr.batchintegrazionedg.service.DlqFlussoService;
import it.eng.snam.pmr.batchintegrazionedg.test.service.NoSecurityTestProfile;

@QuarkusTest
@TestProfile(NoSecurityTestProfile.class)
class DlqFlussoResourceTest {

    @InjectMock
    DlqFlussoService service;

    private DlqFlussoDTO buildDto(String transactionId, String controlKey, String status) {
        return DlqFlussoDTO.builder()
                .id(1L)
                .transactionId(transactionId)
                .flowId("FLOW-001")
                .controlKey(controlKey)
                .keyLogic("KL-001")
                .originalTopic("topic.dlq")
                .originalPartition(1)
                .originalOffset(10L)
                .processType("SYNC")
                .messageKey("MSG-001")
                .errorType("VALIDATION")
                .errorMessage("Errore tecnico")
                .payload("{\"foo\":\"bar\"}")
                .status(status)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    private DlqFlussoResponseDTO buildResponse(String transactionId, String status) {
        return new DlqFlussoResponseDTO(true, 1L, transactionId, status);
    }

    // =========================================================
    // SAVE
    // =========================================================

    @Test
    void save_validRequest_returns200WithBodyAndHeaders() {
        when(service.save(any())).thenReturn(buildResponse("TXN-001", "RECEIVED"));

        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "transactionId": "TXN-001",
                  "flowId": "FLOW-001",
                  "controlKey": "CTRL-001",
                  "keyLogic": "KL-001",
                  "originalTopic": "topic.dlq",
                  "originalPartition": 1,
                  "originalOffset": 10,
                  "processType": "SYNC",
                  "messageKey": "MSG-001",
                  "errorType": "VALIDATION",
                  "errorMessage": "Errore tecnico",
                  "payload": "{\\"foo\\":\\"bar\\"}",
                  "status": "RECEIVED"
                }
                """)
            .when()
                .post("/dlq-flussi/save")
            .then()
                .statusCode(200)
                .body("saved", equalTo(true))
                .body("id", equalTo(1))
                .body("transactionId", equalTo("TXN-001"))
                .body("status", equalTo("RECEIVED"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).save(any());
    }

    @Test
    void save_withoutTransactionId_returns200BecauseOptional() {
        when(service.save(any())).thenReturn(buildResponse(null, "RECEIVED"));

        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "flowId": "FLOW-001",
                  "controlKey": "CTRL-001",
                  "keyLogic": "KL-001",
                  "originalTopic": "topic.dlq",
                  "originalPartition": 1,
                  "originalOffset": 10,
                  "processType": "SYNC",
                  "messageKey": "MSG-001",
                  "errorType": "VALIDATION",
                  "errorMessage": "Errore tecnico",
                  "payload": "{\\"foo\\":\\"bar\\"}",
                  "status": "RECEIVED"
                }
                """)
            .when()
                .post("/dlq-flussi/save")
            .then()
                .statusCode(200)
                .body("saved", equalTo(true))
                .body("id", equalTo(1))
                .body("status", equalTo("RECEIVED"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).save(any());
    }

    @Test
    void save_nullBody_returns400AndDoesNotInvokeService() {
        given()
            .contentType(ContentType.JSON)
            .when()
                .post("/dlq-flussi/save")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("request obbligatoria"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).save(any());
    }

    @Test
    void save_missingControlKey_returns400AndDoesNotInvokeService() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "transactionId": "TXN-001",
                  "flowId": "FLOW-001",
                  "keyLogic": "KL-001"
                }
                """)
            .when()
                .post("/dlq-flussi/save")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("controlKey obbligatoria"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).save(any());
    }

    @Test
    void save_blankControlKey_returns400AndDoesNotInvokeService() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "transactionId": "TXN-001",
                  "flowId": "FLOW-001",
                  "controlKey": "   ",
                  "keyLogic": "KL-001"
                }
                """)
            .when()
                .post("/dlq-flussi/save")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("controlKey obbligatoria"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).save(any());
    }

    // =========================================================
    // SEARCH BY TRANSACTION ID
    // =========================================================

    @Test
    void search_found_returns200WithListAndHeaders() {
        when(service.findAllByTransactionId("TXN-001"))
                .thenReturn(List.of(buildDto("TXN-001", "CTRL-001", "RECEIVED")));

        given()
            .queryParam("transactionId", "TXN-001")
            .when()
                .get("/dlq-flussi/search")
            .then()
                .statusCode(200)
                .body("size()", equalTo(1))
                .body("[0].transactionId", equalTo("TXN-001"))
                .body("[0].controlKey", equalTo("CTRL-001"))
                .body("[0].status", equalTo("RECEIVED"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).findAllByTransactionId("TXN-001");
    }

    @Test
    void search_nullServiceResponse_returns200WithEmptyList() {
        when(service.findAllByTransactionId("TXN-EMPTY")).thenReturn(null);

        given()
            .queryParam("transactionId", "TXN-EMPTY")
            .when()
                .get("/dlq-flussi/search")
            .then()
                .statusCode(200)
                .body("size()", equalTo(0))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).findAllByTransactionId("TXN-EMPTY");
    }

    @Test
    void search_missingTransactionId_returns400AndDoesNotInvokeService() {
        given()
            .when()
                .get("/dlq-flussi/search")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("transactionId obbligatorio"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).findAllByTransactionId(anyString());
    }

    @Test
    void search_blankTransactionId_returns400AndDoesNotInvokeService() {
        given()
            .queryParam("transactionId", "   ")
            .when()
                .get("/dlq-flussi/search")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("transactionId obbligatorio"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).findAllByTransactionId(anyString());
    }

    // =========================================================
    // SEARCH BY CONTROL KEY
    // =========================================================

    @Test
    void findByControlKey_found_returns200WithListAndHeaders() {
        when(service.findByControlKey("CTRL-001"))
                .thenReturn(List.of(buildDto("TXN-001", "CTRL-001", "RECEIVED")));

        given()
            .queryParam("controlKey", "CTRL-001")
            .when()
                .get("/dlq-flussi/control-key")
            .then()
                .statusCode(200)
                .body("size()", equalTo(1))
                .body("[0].controlKey", equalTo("CTRL-001"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).findByControlKey("CTRL-001");
    }

    @Test
    void findByControlKey_missingParam_returns400AndDoesNotInvokeService() {
        given()
            .when()
                .get("/dlq-flussi/control-key")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("controlKey obbligatoria"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).findByControlKey(anyString());
    }

    // =========================================================
    // COUNT BY CONTROL KEY
    // =========================================================

    @Test
    void countByControlKey_validParam_returns200WithCount() {
        when(service.countByControlKey("CTRL-001")).thenReturn(2L);

        String responseBody = given()
            .queryParam("controlKey", "CTRL-001")
            .when()
                .get("/dlq-flussi/control-key/count")
            .then()
                .statusCode(200)
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue())
                .extract()
                .asString();

        assertEquals("2", responseBody);
        verify(service).countByControlKey("CTRL-001");
    }

    @Test
    void countByControlKey_blankParam_returns400AndDoesNotInvokeService() {
        given()
            .queryParam("controlKey", "   ")
            .when()
                .get("/dlq-flussi/control-key/count")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("controlKey obbligatoria"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).countByControlKey(anyString());
    }

    // =========================================================
    // SEARCH BY STATUS
    // =========================================================

    @Test
    void findByStatus_found_returns200WithListAndHeaders() {
        when(service.findByStatus("RECEIVED"))
                .thenReturn(List.of(buildDto("TXN-001", "CTRL-001", "RECEIVED")));

        given()
            .queryParam("status", "RECEIVED")
            .when()
                .get("/dlq-flussi/status")
            .then()
                .statusCode(200)
                .body("size()", equalTo(1))
                .body("[0].status", equalTo("RECEIVED"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).findByStatus("RECEIVED");
    }

    @Test
    void findByStatus_missingParam_returns400AndDoesNotInvokeService() {
        given()
            .when()
                .get("/dlq-flussi/status")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("status obbligatorio"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).findByStatus(anyString());
    }

    // =========================================================
    // LATEST
    // =========================================================

    @Test
    void latest_defaultLimit_returns200AndUsesDefault20() {
        when(service.findLatest(20))
                .thenReturn(List.of(buildDto("TXN-001", "CTRL-001", "RECEIVED")));

        given()
            .when()
                .get("/dlq-flussi/latest")
            .then()
                .statusCode(200)
                .body("size()", equalTo(1))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).findLatest(20);
    }

    @Test
    void latest_customLimit_returns200() {
        when(service.findLatest(5)).thenReturn(List.of());

        given()
            .queryParam("limit", 5)
            .when()
                .get("/dlq-flussi/latest")
            .then()
                .statusCode(200)
                .body("size()", equalTo(0))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service).findLatest(5);
    }

    @Test
    void latest_limitZero_returns400AndDoesNotInvokeService() {
        given()
            .queryParam("limit", 0)
            .when()
                .get("/dlq-flussi/latest")
            .then()
                .statusCode(400)
                .body("messageType", equalTo("ERROR"))
                .body("messageCode", equalTo("BAD_REQUEST"))
                .body("messageDescription", equalTo("limit deve essere maggiore di 0"))
                .header("KEY-LOGIC", notNullValue())
                .header("TRANSACTION-ID", notNullValue())
                .header("MOD-ASYNC", notNullValue())
                .header("PROCESS-TYPE", notNullValue());

        verify(service, never()).findLatest(anyInt());
    }
}
