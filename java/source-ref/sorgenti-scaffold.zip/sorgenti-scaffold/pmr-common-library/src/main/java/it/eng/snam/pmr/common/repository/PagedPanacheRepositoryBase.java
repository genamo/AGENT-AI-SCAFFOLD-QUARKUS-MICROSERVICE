package it.eng.snam.pmr.common.repository;

import java.util.List;

import io.quarkus.hibernate.orm.panache.PanacheQuery;
import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import it.eng.snam.pmr.common.dto.page.PageDTO;
import it.eng.snam.pmr.common.model.PagedSearchQuery;

public abstract class PagedPanacheRepositoryBase<E, K> implements PanacheRepositoryBase<E, K> {

    public PageDTO<E> filteredSearch(PagedSearchQuery searchQuery) {
        PanacheQuery<E> query = find(searchQuery.getJpql(), searchQuery.getParams());
        long totalElements = query.count();

        List<E> elements = query.page(searchQuery.getPage(), searchQuery.getSize()).list();
        int totalPages = totalElements != 0 ? (int) Math.ceil((double) totalElements / searchQuery.getSize()) : 0;

        return new PageDTO<>(elements, elements.size(), Math.toIntExact(totalElements), searchQuery.getPage(), totalPages);
    }
}
