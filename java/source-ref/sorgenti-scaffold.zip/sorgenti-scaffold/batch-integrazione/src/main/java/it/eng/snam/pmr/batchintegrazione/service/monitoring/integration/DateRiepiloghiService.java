package it.eng.snam.pmr.batchintegrazione.service.monitoring.integration;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.common.header.Headers;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.fasterxml.jackson.core.type.TypeReference;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.DatiFiscaliClient;
import it.eng.snam.pmr.batchintegrazione.dto.flussi.DateRiepiloghiPayloadDTO;
import it.eng.snam.pmr.batchintegrazione.dto.monitoring.integration.DateRiepiloghiDTO;
import it.eng.snam.pmr.common.service.abstracts.AbstractService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RunOnVirtualThread
public class DateRiepiloghiService extends AbstractService {

    @Inject
    @RestClient
    private DatiFiscaliClient datiFiscaliClient;

    public void saveDateRiepiloghi(DateRiepiloghiPayloadDTO dateRiepiloghiPayloadDTO, Headers headers) {
        List<DateRiepiloghiDTO> data = extractDateRiepiloghi(dateRiepiloghiPayloadDTO);

        String result = executeClientCall(() -> datiFiscaliClient.saveDateRiepiloghi(data.getFirst()), new TypeReference<>() {});
        log.info("[SummerTransactionID='{}'] RestClient result: '{}'", dateRiepiloghiPayloadDTO.summerTransactionId(), result);
    }

    private List<DateRiepiloghiDTO> extractDateRiepiloghi(DateRiepiloghiPayloadDTO dateRiepiloghiPayloadDTO) {
        if (dateRiepiloghiPayloadDTO == null)
            throw new IllegalArgumentException("'payload' must be valued properly.");

        String summerTransactionId = dateRiepiloghiPayloadDTO.summerTransactionId();
        if (StringUtils.isBlank(summerTransactionId))
            throw new IllegalArgumentException("'summerTransactionId' must be valued properly.");
        log.info("SummerTransactionID: {}", summerTransactionId);

        if (StringUtils.isBlank(dateRiepiloghiPayloadDTO.operation()))
            throw new IllegalArgumentException("'operation' must be valued properly.");

        List<DateRiepiloghiDTO> data = dateRiepiloghiPayloadDTO.data();
        if (CollectionUtils.isEmpty(data))
            throw new IllegalArgumentException("'data' must be valued properly.");

        return data;
    }
}
