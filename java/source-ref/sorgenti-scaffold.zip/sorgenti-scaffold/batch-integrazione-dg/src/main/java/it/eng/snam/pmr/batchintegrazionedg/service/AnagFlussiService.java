package it.eng.snam.pmr.batchintegrazionedg.service;

import java.util.List;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazionedg.dto.AnagFlussiDTO;
import it.eng.snam.pmr.batchintegrazionedg.mapper.AnagFlussiMapper;
import it.eng.snam.pmr.batchintegrazionedg.repository.AnagFlussiRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
@RunOnVirtualThread
public class AnagFlussiService {

    @Inject
    AnagFlussiRepository repository; // Iniezione del repository

    @Inject
    AnagFlussiMapper mapper;

    public List<AnagFlussiDTO> getAll() {
        // Usa il repository invece del metodo statico dell'entità
        return mapper.toDtoList(repository.list("isDeleted = 0"));
    }

    public AnagFlussiDTO findByFlowId(String flowId) {
        return repository.findByFlowId(flowId)
                .map(mapper::toDto)
                .orElse(null);
    }
}
