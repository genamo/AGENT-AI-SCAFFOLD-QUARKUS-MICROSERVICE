package it.eng.snam.pmr.batchintegrazione.dto.anagrafiche;

import java.time.LocalDateTime;

public record AnagTipoStatoRemiDto(
        String codiceStato,
        String descrizioneStato,
        String userAction,
        LocalDateTime actionDate,
        Integer isDeleted
) {}