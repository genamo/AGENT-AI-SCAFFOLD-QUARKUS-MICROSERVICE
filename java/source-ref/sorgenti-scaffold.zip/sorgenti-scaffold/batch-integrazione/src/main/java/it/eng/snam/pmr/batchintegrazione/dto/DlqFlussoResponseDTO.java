package it.eng.snam.pmr.batchintegrazione.dto;

public record DlqFlussoResponseDTO(
    boolean saved,
    Long id,
    String transactionId,
    String status
) {}
