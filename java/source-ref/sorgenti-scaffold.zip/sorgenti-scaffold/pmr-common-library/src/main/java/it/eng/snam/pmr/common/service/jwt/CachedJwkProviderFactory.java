package it.eng.snam.pmr.common.service.jwt;

import java.net.MalformedURLException;
import java.net.URI;
import java.util.concurrent.TimeUnit;

import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.JwkProviderBuilder;

import it.eng.snam.pmr.common.config.jwt.JwtSecurityConfig;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;

@ApplicationScoped
@RequiredArgsConstructor
public class CachedJwkProviderFactory {

    private final JwtSecurityConfig config;

    public JwkProvider create(String jwksUri) {
        try {
            return new JwkProviderBuilder(URI.create(jwksUri).toURL())
                    .cached(config.jwks().cacheSize(), config.jwks().cacheDurationHours(), TimeUnit.HOURS)
                    .rateLimited(config.jwks().rateLimitSize(), config.jwks().rateLimitDurationMinutes(), TimeUnit.MINUTES)
                    .build();
        } catch (MalformedURLException exception) {
            throw new IllegalStateException("Invalid JWKS URI: " + jwksUri, exception);
        }
    }
}