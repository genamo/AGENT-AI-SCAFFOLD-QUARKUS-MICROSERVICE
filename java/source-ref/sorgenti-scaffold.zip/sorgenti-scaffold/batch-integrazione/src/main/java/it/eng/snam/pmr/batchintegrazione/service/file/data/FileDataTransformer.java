package it.eng.snam.pmr.batchintegrazione.service.file.data;

import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import it.eng.snam.pmr.batchintegrazione.config.async.TaskExecutorConfig;
import it.eng.snam.pmr.batchintegrazione.dto.blob.storage.FileDataContext;
import it.eng.snam.pmr.batchintegrazione.dto.file.data.FileDataRequest;
import it.eng.snam.pmr.batchintegrazione.exception.FileDataExtractionException;
import it.eng.snam.pmr.batchintegrazione.utils.blob.storage.BlobMetadataBuilder;
import it.eng.snam.pmr.batchintegrazione.utils.blob.storage.BlobUploadProperties;
import it.eng.snam.pmr.batchintegrazione.utils.file.data.FileNameGenerator;
import it.eng.snam.pmr.batchintegrazione.utils.file.data.ZipGenerator;
import it.eng.snam.pmr.common.config.async.TaskExecutorQualifier;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
public class FileDataTransformer {

    private final Executor executor;

    public FileDataTransformer(@TaskExecutorQualifier(TaskExecutorConfig.ZIP_EXECUTOR) Executor executor) {
        this.executor = executor;
    }

    @SuppressWarnings("all")
    public FileDataContext transform(FileDataRequest request) {
        try {
            PipedInputStream pipedInputStream = new PipedInputStream(BlobUploadProperties.BUFFER_SIZE);
            PipedOutputStream pipedOutputStream = new PipedOutputStream(pipedInputStream);

            CompletableFuture<Void> writerFuture = CompletableFuture.runAsync(() -> ZipGenerator.generate(request, pipedOutputStream), executor);

            return new FileDataContext(request.getExecutioner(), request.getActivity(),
                                       FileNameGenerator.generate(), BlobUploadProperties.ZIP_CONTENT_TYPE,
                                       pipedInputStream, BlobMetadataBuilder.build(request), writerFuture);
        } catch (IOException e) {
            log.error("Error while creating piped stream: {}", e.getMessage());
            throw new FileDataExtractionException("Error while creating piped stream: " + e.getMessage(), e);
        }
    }
}
