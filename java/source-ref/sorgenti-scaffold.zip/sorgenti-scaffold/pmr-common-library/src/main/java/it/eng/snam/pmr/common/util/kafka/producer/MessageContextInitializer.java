package it.eng.snam.pmr.common.util.kafka.producer;

import java.nio.charset.StandardCharsets;

import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.eclipse.microprofile.reactive.messaging.Message;

import io.smallrye.reactive.messaging.kafka.api.IncomingKafkaRecordMetadata;
import it.eng.snam.pmr.common.dto.kafka.consume.IncomingMessageContext;
import it.eng.snam.pmr.common.util.CommonConstants;
import lombok.experimental.UtilityClass;

@UtilityClass
public class MessageContextInitializer {

    @SuppressWarnings("unchecked")
    public IncomingMessageContext incoming(Message<byte[]> message) {
        IncomingKafkaRecordMetadata<String, byte[]> metadata = message.getMetadata(IncomingKafkaRecordMetadata.class).orElse(null);
        String topic = metadata != null ? metadata.getTopic() : "unknown";
        Headers headers = metadata != null ? metadata.getHeaders() : new RecordHeaders();
        byte[] payload = message.getPayload();
        Integer size = payload == null ? 0 : payload.length;
        headers.add(new RecordHeader(CommonConstants.KafkaHeaders.TOPIC, topic.getBytes(StandardCharsets.UTF_8)));

        return IncomingMessageContext.of(topic, headers, payload, size, metadata);
    }
}
