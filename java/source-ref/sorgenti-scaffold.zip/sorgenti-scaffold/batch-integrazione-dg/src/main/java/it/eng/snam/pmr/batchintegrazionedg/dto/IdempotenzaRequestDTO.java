package it.eng.snam.pmr.batchintegrazionedg.dto;

public record IdempotenzaRequestDTO(
    String transactionId,
    String flowId,
    String keyLogic,
    String status,        // opzionale: IN_PROGRESS / COMPLETED / ERROR
    String errorMessage   // opzionale
) {}