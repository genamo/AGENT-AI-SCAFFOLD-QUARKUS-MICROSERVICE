package it.eng.snam.pmr.batchintegrazione.test.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

import it.eng.snam.pmr.batchintegrazione.utils.Constants;

class ConstantsTest {

    @Test
    void rootConstants() {
        assertEquals("yyyyMMddHHmmssSSS", Constants.TIMESTAMP_FORMAT);
        assertEquals("Error", Constants.MSG_ERROR);
    }

    @Test
    void headerConstants() {
        assertEquals("TRANSACTION-ID", Constants.Headers.TRANSACTION_ID);
        assertEquals("KEY-LOGIC", Constants.Headers.KEYLOGIC);
        assertEquals("MOD-ASYNC", Constants.Headers.MOD_ASYNC);
        assertEquals("PROCESS-TYPE", Constants.Headers.PROCESS_TYPE);
        assertEquals("MESSAGE-KEY", Constants.Headers.MESSAGE_KEY);
        assertEquals("content-type", Constants.Headers.CONTENT_TYPE);
        assertEquals("JWT", Constants.Headers.JWT);
        assertEquals("Authorization", Constants.Headers.AUTHORIZATION);
    }

    @Test
    void logParamsConstants() {
        assertEquals("TN", Constants.LogParams.TN);
        assertEquals("KL", Constants.LogParams.KL);
        assertEquals("API", Constants.LogParams.API);
        assertEquals("MK", Constants.LogParams.MK);
        assertEquals("PT", Constants.LogParams.PT);
        assertEquals("MA", Constants.LogParams.MA);
    }

    @Test
    void mediaTypeConstants() {
        assertEquals("application/json", Constants.MEDIATYPE.APP_JSON);
    }

    @Test
    void topicConstants() {
        assertEquals("anagraficaremisummerin", Constants.Topic.PMR001A_SUMMER_IN_TOPIC);
       
    }

    @Test
    void getAllTopicsValue_returnsBothTopics() throws Exception {
        List<String> topics = Constants.Topic.getAllTopicsValue();
        assertNotNull(topics);
        assertEquals(19, topics.size());
        assertTrue(topics.contains(Constants.Topic.PMR001A_SUMMER_IN_TOPIC));
        assertTrue(topics.contains(Constants.Topic.PMR001H_SUMMER_IN_TOPIC));
        assertTrue(topics.contains(Constants.Topic.GLOBAL_DLQ_TOPIC));
    }
}
