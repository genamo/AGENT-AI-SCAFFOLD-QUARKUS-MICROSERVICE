package it.eng.snam.pmr.common.dto.acr.addressing;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class AcrAddressingDtosTest {

    @Test
    void allAddressingDtos_buildCorrectly() {
        AcrAdministrationListDTO administration = AcrAdministrationListDTO.builder()
                .administrationListId(10L)
                .name("ADM")
                .build();

        AcrSubProfileDTO subProfile = AcrSubProfileDTO.builder()
                .subProfileId("SP1")
                .subProfileDescription("Sub profile")
                .build();

        AcrTerritoryDTO territory = AcrTerritoryDTO.builder()
                .territoryId(1)
                .territoryDescription("North")
                .sapTerritoryCode("SAP1")
                .build();

        AcrVerticalDTO vertical = AcrVerticalDTO.builder()
                .verticalId(2)
                .verticalCode("V2")
                .verticalName("Vertical")
                .verticalDescription("Desc")
                .build();

        AcrWidgetDTO widget = AcrWidgetDTO.builder()
                .widgetId(3)
                .widgetName("Widget")
                .widgetDescription("Widget desc")
                .build();

        AcrRecipientDTO recipient = AcrRecipientDTO.builder()
                .userId("u1")
                .firstname("Mario")
                .lastname("Rossi")
                .email("mario.rossi@test.it")
                .profileId("P1")
                .territoryId(1)
                .build();

        AcrRecipientRequestDTO request = AcrRecipientRequestDTO.builder()
                .includeTerritory(true)
                .excludeChief(false)
                .profiles(List.of("P1"))
                .territories(List.of("T1"))
                .widgets(List.of(1, 2))
                .verticals(List.of(10))
                .administrationLists(List.of(100))
                .subProfiles(List.of("SP1"))
                .build();

        assertThat(administration.administrationListId()).isEqualTo(10L);
        assertThat(administration.name()).isEqualTo("ADM");

        assertThat(subProfile.subProfileId()).isEqualTo("SP1");
        assertThat(subProfile.subProfileDescription()).isEqualTo("Sub profile");

        assertThat(territory.territoryId()).isEqualTo(1);
        assertThat(territory.territoryDescription()).isEqualTo("North");
        assertThat(territory.sapTerritoryCode()).isEqualTo("SAP1");

        assertThat(vertical.verticalId()).isEqualTo(2);
        assertThat(vertical.verticalCode()).isEqualTo("V2");
        assertThat(vertical.verticalName()).isEqualTo("Vertical");
        assertThat(vertical.verticalDescription()).isEqualTo("Desc");

        assertThat(widget.widgetId()).isEqualTo(3);
        assertThat(widget.widgetName()).isEqualTo("Widget");
        assertThat(widget.widgetDescription()).isEqualTo("Widget desc");

        assertThat(recipient.userId()).isEqualTo("u1");
        assertThat(recipient.firstname()).isEqualTo("Mario");
        assertThat(recipient.lastname()).isEqualTo("Rossi");
        assertThat(recipient.email()).isEqualTo("mario.rossi@test.it");
        assertThat(recipient.profileId()).isEqualTo("P1");
        assertThat(recipient.territoryId()).isEqualTo(1);

        assertThat(request.includeTerritory()).isTrue();
        assertThat(request.excludeChief()).isFalse();
        assertThat(request.profiles()).containsExactly("P1");
        assertThat(request.territories()).containsExactly("T1");
        assertThat(request.widgets()).containsExactly(1, 2);
        assertThat(request.verticals()).containsExactly(10);
        assertThat(request.administrationLists()).containsExactly(100);
        assertThat(request.subProfiles()).containsExactly("SP1");
    }
}
