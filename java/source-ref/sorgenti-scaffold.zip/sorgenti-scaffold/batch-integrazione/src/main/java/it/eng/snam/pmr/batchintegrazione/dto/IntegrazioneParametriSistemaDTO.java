package it.eng.snam.pmr.batchintegrazione.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record IntegrazioneParametriSistemaDTO(
    Long id,
    String codice,
    String valore,
    LocalDate dataInizio,
    LocalDate dataFine,
    LocalDateTime actionDate,
    String userAction,
    Integer isDeleted
) {}
