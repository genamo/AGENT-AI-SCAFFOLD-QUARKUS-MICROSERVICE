package it.eng.snam.pmr.batchintegrazione.dto;

public record IdempotenzaResponseDTO(
    boolean started,
    String transactionId,
    String status
) {}