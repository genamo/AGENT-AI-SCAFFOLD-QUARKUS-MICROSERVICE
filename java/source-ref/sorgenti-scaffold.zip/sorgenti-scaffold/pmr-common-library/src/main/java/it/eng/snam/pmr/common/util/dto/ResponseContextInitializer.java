package it.eng.snam.pmr.common.util.dto;

import java.util.Optional;

import org.slf4j.MDC;

import it.eng.snam.pmr.common.dto.ResponseContext;
import it.eng.snam.pmr.common.exception.RemoteCallException;
import it.eng.snam.pmr.common.util.CommonConstants;
import jakarta.ws.rs.core.Response;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class ResponseContextInitializer {

    public ResponseContext init(Response response) {
        Object rawOperation = Optional.ofNullable(MDC.get(CommonConstants.LogParams.API))
                                      .orElse(MDC.get(CommonConstants.LogParams.KT));
        String operation = rawOperation != null ? rawOperation.toString() : "N/A";
        if (response == null)
            throw new RemoteCallException(operation + ": response is null");

        int status = response.getStatus();
        String body = safeReadBody(response);

        return ResponseContext.of(operation, status, body);
    }

    private String safeReadBody(Response response) {
        try {
            return response.hasEntity() ? response.readEntity(String.class) : "";
        } catch (Exception e) {
            return "";
        }
    }
}
