package it.eng.snam.pmr.batchintegrazione.service.handler;

import it.eng.snam.pmr.batchintegrazione.dto.flussi.VerbaliMisuraGiornPayloadDto;
import it.eng.snam.pmr.batchintegrazione.service.DatiFiscaliService;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class VerbaliMisuraGiornHandler extends AbstractFlussoHandler<VerbaliMisuraGiornPayloadDto> {

    @Inject
    DatiFiscaliService datiFiscaliService;

    @Override
    protected Class<VerbaliMisuraGiornPayloadDto> getDtoClass() {
        return VerbaliMisuraGiornPayloadDto.class;
    }

    @Override
    protected void handle(VerbaliMisuraGiornPayloadDto dto) {

        if (dto.operation() != null && !dto.operation().isEmpty()) {
            switch (dto.operation()) {
                case "INSERT":
                    if (dto.data() != null && !dto.data().isEmpty()) {
                        datiFiscaliService.saveVerbaleMisuraGiorn(dto.data().getFirst());
                    }
                    break;

                case "DELETE":
                    if (dto.data() != null && !dto.data().isEmpty()) {
                        datiFiscaliService.deleteVerbaleMisuraGiorn(
                                dto.data().getFirst().remiAssoluto(),
                                dto.data().getFirst().dataVolPunta(),
                                dto.data().getFirst().dataIniVerb()
                        );
                    }
                    break;

                default:
                    throw new IllegalArgumentException("Invalid operation: " + dto.operation());
            }
        } else {
            throw new IllegalArgumentException("Operation field is required");
        }
    }

    @Override
    protected String flowType() {
        return Constants.Flussi.VERBALI_MISURA_GIORN_FLOW;
    }
}
