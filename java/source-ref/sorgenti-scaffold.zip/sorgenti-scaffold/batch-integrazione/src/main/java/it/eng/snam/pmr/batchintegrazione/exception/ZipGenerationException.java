package it.eng.snam.pmr.batchintegrazione.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class ZipGenerationException extends BatchIntegrazioneException {
    @Serial
    private static final long serialVersionUID = -8773053370558408534L;
}
