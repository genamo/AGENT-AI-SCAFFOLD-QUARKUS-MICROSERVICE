package it.eng.snam.pmr.batchintegrazionedg.test.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazionedg.service.ExternalUserService;
import it.eng.snam.pmr.batchintegrazionedg.service.MonitoringBatchService;
import it.eng.snam.pmr.common.dto.UserMeterModuleAuthorizationDTO;
import it.eng.snam.pmr.common.service.DataPlatformService;

@ExtendWith(MockitoExtension.class)
class ExternalUserServiceTest {

    @Mock
    DataPlatformService dataPlatformService;

    @Mock
    MonitoringBatchService monitoringBatchService;

    @InjectMocks
    ExternalUserService service;

    // =========================================================
    // HELPER
    // =========================================================

    private UserMeterModuleAuthorizationDTO buildUser(String user, String meter) {
        return new UserMeterModuleAuthorizationDTO(
                1L,
                user,
                1L,
                meter,
                "MID",
                "PMR",
                null,
                null,
                "ORG",
                1L,
                null,
                1L,
                1L,
                0,
                null,
                null,
                null,
                null
        );
    }

    // =========================================================
    // TESTS
    // =========================================================

    @Test
    void getUsersFromDataplatform_success_flow_executesAllSteps() {

        List<UserMeterModuleAuthorizationDTO> mockList = List.of(
                buildUser("user1", "m1"),
                buildUser("user1", "m2"),
                buildUser("user2", "m3")
        );

        when(dataPlatformService.getAllActiveUsers()).thenReturn(mockList);

        assertDoesNotThrow(() -> service.getUsersFromDataplatform());

        // ✅ verifica che il monitoring venga chiamato più volte
        verify(monitoringBatchService, atLeast(1)).save(any());
    }

    @Test
    void getUsersFromDataplatform_emptyList_stillCompletes() {

        when(dataPlatformService.getAllActiveUsers()).thenReturn(List.of());

        assertDoesNotThrow(() -> service.getUsersFromDataplatform());

        verify(monitoringBatchService, atLeast(1)).save(any());
    }

    @Test
    void getUsersFromDataplatform_exception_triggersErrorStatus() {

        when(dataPlatformService.getAllActiveUsers())
                .thenThrow(new RuntimeException("DB ERROR"));

        assertDoesNotThrow(() -> service.getUsersFromDataplatform());

        // deve comunque salvare stato errore
        verify(monitoringBatchService, atLeast(1)).save(any());
    }

    @Test
    void getUsersFromDataplatform_generatesBase64Payload() {

        List<UserMeterModuleAuthorizationDTO> mockList = List.of(
                buildUser("user1", "m1")
        );

        when(dataPlatformService.getAllActiveUsers()).thenReturn(mockList);

        service.getUsersFromDataplatform();

        // 👉 intercettiamo DTO salvati
        verify(monitoringBatchService, atLeast(1)).save(argThat(dto -> {
            if (dto.fileBatch() != null) {
                return dto.fileBatch().length() > 0;
            }
            return true;
        }));
    }

}