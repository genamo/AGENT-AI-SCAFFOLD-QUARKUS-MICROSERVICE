package it.eng.snam.pmr.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record RemiSpecializzazioneDTO(
        String remiAssoluto,
        String specializzazione
) {}
