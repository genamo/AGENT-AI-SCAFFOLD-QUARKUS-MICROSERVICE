package it.eng.snam.pmr.batchintegrazione.utils.blob.storage;

import org.apache.commons.lang3.StringUtils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class BlobContainerNormalizer {

    public String normalize(String containerName) {
        if (StringUtils.isBlank(containerName))
            throw new IllegalArgumentException("'containerName' must be valued properly.");

        return containerName.toLowerCase();
    }
}
