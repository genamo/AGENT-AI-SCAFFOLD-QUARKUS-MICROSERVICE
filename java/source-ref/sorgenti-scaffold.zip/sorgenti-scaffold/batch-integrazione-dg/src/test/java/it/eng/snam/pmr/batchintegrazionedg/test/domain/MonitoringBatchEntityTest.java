package it.eng.snam.pmr.batchintegrazionedg.test.domain;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import it.eng.snam.pmr.batchintegrazionedg.domain.MonitoringBatch;
import java.time.LocalDateTime;

class MonitoringBatchEntityTest {

    @Test
    void gettersAndSetters_workCorrectly() {
        MonitoringBatch e = new MonitoringBatch();
        LocalDateTime now = LocalDateTime.now();

        e.setId(5L);
        e.setTransactionId("TXN-BATCH-001");
        e.setCorrelationId("CORR-001");
        e.setFlowId("FLOW-BATCH");
        e.setDayNumber(20260522);
        e.setMonthNumber(202605);
        e.setGranularita("M");
        e.setSender("SYSNAME");
        e.setIsWorkaround(true);
        e.setStatusDescription("IN_PROGRESS");
        e.setFileBatch("batch file");
        e.setFileOutput("output file");
        e.setStatus(0);
        e.setActionDate(now);
        e.setUserAction("scheduler");
        e.setIsDeleted(0);

        assertEquals(5L, e.getId());
        assertEquals("TXN-BATCH-001", e.getTransactionId());
        assertEquals("CORR-001", e.getCorrelationId());
        assertEquals("FLOW-BATCH", e.getFlowId());
        assertEquals(20260522, e.getDayNumber());
        assertEquals(202605, e.getMonthNumber());
        assertEquals("M", e.getGranularita());
        assertEquals("SYSNAME", e.getSender());
        assertTrue(e.getIsWorkaround());
        assertEquals("IN_PROGRESS", e.getStatusDescription());
        assertEquals("batch file", e.getFileBatch());
        assertEquals("output file", e.getFileOutput());
        assertEquals(0, e.getStatus());
        assertEquals(now, e.getActionDate());
        assertEquals("scheduler", e.getUserAction());
        assertEquals(0, e.getIsDeleted());
    }

    @Test
    void defaultIsDeleted_isZero() {
        MonitoringBatch e = new MonitoringBatch();
        assertEquals(0, e.getIsDeleted());
    }
}
