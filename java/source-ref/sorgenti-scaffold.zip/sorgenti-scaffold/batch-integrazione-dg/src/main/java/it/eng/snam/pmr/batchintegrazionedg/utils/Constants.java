package it.eng.snam.pmr.batchintegrazionedg.utils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class Constants {
	
    private Constants() {}

    public static final String TIMESTAMP_FORMAT = "yyyyMMddHHmmssSSS";
    public static final String MSG_ERROR = "Error";

    public static final class Headers {
        private Headers() {}
        public static final String TRANSACTION_ID = "TRANSACTION-ID";
        public static final String KEYLOGIC = "KEY-LOGIC";
        public static final String MOD_ASYNC = "MOD-ASYNC";
        public static final String PROCESS_TYPE = "PROCESS-TYPE";
        public static final String MESSAGE_KEY = "MESSAGE-KEY";
        public static final String CONTENT_TYPE = "content-type";
        public static final String JWT = "JWT";
        public static final String AUTHORIZATION = "Authorization";
    }
    
    public static final class KafkaHeaders {
        private KafkaHeaders() {}
        public static final String TRANSACTION_ID = "TRANSACTION-ID";
        public static final String KEYLOGIC = "KEY-LOGIC";
        public static final String PROCESS_TYPE = "PROCESS-TYPE";
        public static final String FLOW_TYPE = "FLOW";
        public static final String MESSAGE_KEY = "MESSAGE-KEY";
        public static final String CONTENT_TYPE = "content-type";
        
    }

    public static final class LogParams {
        private LogParams() {}
        public static final String TN = "TN";
        public static final String KL = "KL";
        public static final String API = "API";
        public static final String MK = "MK";
        public static final String PT = "PT";
        public static final String MA = "MA";
    }

    public static final class MEDIATYPE {
        private MEDIATYPE() {}
        public static final String APP_JSON = "application/json";
    }

    public static final class Topic {

        private Topic() {}

        public static final String INTEGRAZIONE_FLUSSI_TOPIC = "integrazioneflussi";
        public static final String DELIBERA_BIOMETANO_TOPIC = "deliberabiometanoengine";

        public static List<String> getAllTopicsValue() throws IllegalAccessException {

            List<Field> fields = Arrays.asList(Constants.Topic.class.getDeclaredFields());
            List<String> topics = new ArrayList<>();

            for (Field field : fields) {
                if (field.getType() == String.class) {
                    topics.add((String) field.get(null));
                }
            }

            return topics;
        }
    }

}
