package it.eng.snam.pmr.batchintegrazione.filter;

import org.jboss.logging.MDC;

import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.CommonConstants;
import jakarta.annotation.Priority;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.ext.Provider;
import lombok.RequiredArgsConstructor;

@Provider
@RequiredArgsConstructor
@Priority(Priorities.AUTHENTICATION)
public class MdcHeadersFilter implements ContainerRequestFilter, ContainerResponseFilter {

    public static final String PROP_KL = "CTX_KL";
    public static final String PROP_TID = "CTX_TID";
    public static final String PROP_MOD_ASYNC = "CTX_MOD_ASYNC";
    public static final String PROP_PROCESS_TYPE = "CTX_PROCESS_TYPE";
    public static final String PROP_USER_ID = "CTX_USER_ID";

    private final RequestHeadersContext requestHeadersContext;

    @Override
    public void filter(ContainerRequestContext req) {
        requestHeadersContext.setStartNanos(System.nanoTime());
        requestHeadersContext.setPath("/" + req.getUriInfo().getPath());

        String kl = Utility.defaultUuidIfBlank(req.getHeaderString(CommonConstants.Headers.KEYLOGIC));
        String tid = Utility.defaultUuidIfBlank(req.getHeaderString(CommonConstants.Headers.TRANSACTION_ID));
        boolean ma = Utility.parseBooleanOrDefault(req.getHeaderString(CommonConstants.Headers.MOD_ASYNC), false);
        String pt = Utility.defaultIfBlank(req.getHeaderString(CommonConstants.Headers.PROCESS_TYPE), "N/A");
        String uid = Utility.defaultIfBlank(req.getHeaderString(AuthorizationUtils.USER_ID), "");

        MultivaluedMap<String, String> h = req.getHeaders();
        putIfBlank(h, CommonConstants.Headers.KEYLOGIC, kl);
        putIfBlank(h, CommonConstants.Headers.TRANSACTION_ID, tid);
        putIfBlank(h, CommonConstants.Headers.MOD_ASYNC, String.valueOf(ma));
        putIfBlank(h, CommonConstants.Headers.PROCESS_TYPE, pt);
        putIfBlank(h, AuthorizationUtils.USER_ID, uid);

        req.setProperty(PROP_KL, kl);
        req.setProperty(PROP_TID, tid);
        req.setProperty(PROP_MOD_ASYNC, ma);
        req.setProperty(PROP_PROCESS_TYPE, pt);
        req.setProperty(PROP_USER_ID, uid);

        MDC.put(CommonConstants.LogParams.KL, kl);
        MDC.put(CommonConstants.LogParams.TN, tid);
        MDC.put(CommonConstants.LogParams.PT, pt);
        MDC.put(CommonConstants.LogParams.MA, String.valueOf(ma));
        MDC.put(CommonConstants.LogParams.API, req.getMethod() + " /" + req.getUriInfo().getPath());
        MDC.put(AuthorizationUtils.USER_ID, uid);

        requestHeadersContext.setKeyLogic(kl);
        requestHeadersContext.setTransactionId(tid);
        requestHeadersContext.setModAsync(ma);
        requestHeadersContext.setProcessType(pt);
    }

    @Override
    public void filter(ContainerRequestContext req, ContainerResponseContext resp) {
        try {
            String kl = (String) req.getProperty(PROP_KL);
            String tid = (String) req.getProperty(PROP_TID);
            Object maObj = req.getProperty(PROP_MOD_ASYNC);
            boolean ma = (maObj instanceof Boolean b) && b;
            String pt = (String) req.getProperty(PROP_PROCESS_TYPE);
            String uid = (String) req.getProperty(PROP_USER_ID);

            resp.getHeaders().putSingle(CommonConstants.Headers.KEYLOGIC, kl);
            resp.getHeaders().putSingle(CommonConstants.Headers.TRANSACTION_ID, tid);
            resp.getHeaders().putSingle(CommonConstants.Headers.MOD_ASYNC, String.valueOf(ma));
            resp.getHeaders().putSingle(CommonConstants.Headers.PROCESS_TYPE, pt);
            resp.getHeaders().putSingle(AuthorizationUtils.USER_ID, uid);
        } finally {
            MDC.clear();
        }
    }

    private static void putIfBlank(MultivaluedMap<String, String> h, String name, String value) {
        String cur = h.getFirst(name);
        if (cur == null || cur.trim().isEmpty())
            h.putSingle(name, value);
    }
}