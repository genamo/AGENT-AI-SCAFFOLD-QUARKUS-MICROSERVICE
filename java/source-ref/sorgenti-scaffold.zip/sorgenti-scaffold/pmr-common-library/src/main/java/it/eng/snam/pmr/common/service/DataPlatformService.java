package it.eng.snam.pmr.common.service;

import java.util.List;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import it.eng.snam.pmr.common.annotation.LogPmr;
import it.eng.snam.pmr.common.dto.ProfileOrganizationDto;
import it.eng.snam.pmr.common.dto.ProfileScenarioDto;
import it.eng.snam.pmr.common.dto.UserCustomerOrganizationDTO;
import it.eng.snam.pmr.common.dto.UserMeterModuleAuthorizationDTO;
import it.eng.snam.pmr.common.dto.ProfileModuleDto;
import it.eng.snam.pmr.common.repository.UserCustomerOrganizationRepository;
import it.eng.snam.pmr.common.repository.UserMeterModuleAuthorizationRepository;
import it.eng.snam.pmr.common.response.ExternalUserProfileResponse;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class DataPlatformService {

	@Inject
	UserMeterModuleAuthorizationRepository userMeterModuleAuthorizationRepository;

	@Inject
	UserCustomerOrganizationRepository userCustomerOrganizationRepository;

	// =========================================================
	// USER METER MODULE AUTHORIZATION
	// =========================================================

	public Optional<UserMeterModuleAuthorizationDTO> getUserMeterModuleAuthorizationById(long id) {
		return userMeterModuleAuthorizationRepository.findById(id);
	}

	public List<UserMeterModuleAuthorizationDTO> getUserMeterModuleAuthorizationByFlowId(long flowId) {
		return userMeterModuleAuthorizationRepository.findByFlowId(flowId);
	}

	public List<UserMeterModuleAuthorizationDTO> getUserMeterModuleAuthorizationByKeys(String userCode, String meterCode, String moduleCode, String organizationCode) {

		return userMeterModuleAuthorizationRepository.findByKeys(userCode, meterCode, moduleCode, organizationCode);
	}

	public List<UserMeterModuleAuthorizationDTO> getUserMeterModuleAuthorizationActiveByKeys(String userCode, String meterCode, String moduleCode, String organizationCode) {

		return userMeterModuleAuthorizationRepository.findActiveByKeys(userCode, meterCode, moduleCode, organizationCode);
	}

	public List<UserMeterModuleAuthorizationDTO> getUserMeterModuleAuthorizationByUserCode(String userCode) {
		return userMeterModuleAuthorizationRepository.findByUserCode(userCode);
	}

	public List<UserMeterModuleAuthorizationDTO> getUserMeterModuleAuthorizationActiveByUserCode(String userCode) {
		return userMeterModuleAuthorizationRepository.findActiveByUserCode(userCode);
	}
	
	public List<UserMeterModuleAuthorizationDTO> getAllUserMeterModuleAuthorizationActive() {
		return userMeterModuleAuthorizationRepository.findAllActive();
	}

	public List<UserMeterModuleAuthorizationDTO> getUserMeterModuleAuthorizationByUserCodePaged(String userCode, int limit, int offset) {

		return userMeterModuleAuthorizationRepository.findByUserCodePaged(userCode, limit, offset);
	}

	public List<UserMeterModuleAuthorizationDTO> getAllActiveUsers() {
		return userMeterModuleAuthorizationRepository.getAllActiveUsers();
	}

	// =========================================================
	// USER CUSTOMER ORGANIZATION
	// =========================================================

	public Optional<UserCustomerOrganizationDTO> getUserCustomerOrganizationById(long id) {
		return userCustomerOrganizationRepository.findById(id);
	}

	public List<UserCustomerOrganizationDTO> getUserCustomerOrganizationByUserCode(String userCode) {
		return userCustomerOrganizationRepository.findByUserCode(userCode);
	}

	public List<UserCustomerOrganizationDTO> getUserCustomerOrganizationActiveByUserCode(String userCode) {
		return userCustomerOrganizationRepository.findActiveByUserCode(userCode);
	}

	public List<UserCustomerOrganizationDTO> getAllUserCustomerOrganizationActive() {
		return userCustomerOrganizationRepository.findAllActive();
	}
	
	public List<UserCustomerOrganizationDTO> getUserCustomerOrganizationByFlowId(long flowId) {
		return userCustomerOrganizationRepository.findByFlowId(flowId);
	}

	public List<UserCustomerOrganizationDTO> getUserCustomerOrganizationByOrganizationCode(Long organizationCode) {
		return userCustomerOrganizationRepository.findByOrganizationCode(organizationCode);
	}

	public List<UserCustomerOrganizationDTO> getUserCustomerOrganizationActiveByOrganizationCode(Long organizationCode) {
		return userCustomerOrganizationRepository.findActiveByOrganizationCode(organizationCode);
	}

	public List<UserCustomerOrganizationDTO> getUserCustomerOrganizationByKeys(String userCode, String customerOrganizationCode) {

		return userCustomerOrganizationRepository.findByKeys(userCode, customerOrganizationCode);
	}

	public List<UserCustomerOrganizationDTO> getUserCustomerOrganizationActiveByKeys(String userCode, String customerOrganizationCode) {

		return userCustomerOrganizationRepository.findActiveByKeys(userCode, customerOrganizationCode);
	}

	public List<UserCustomerOrganizationDTO> getUserCustomerOrganizationByUserCodePaged(String userCode, int limit, int offset) {

		return userCustomerOrganizationRepository.findByUserCodePaged(userCode, limit, offset);
	}
	
	// =========================================================
		// RECUPERO PROFILO UTENTE ESTERNO
	// =========================================================
	@LogPmr
	public ExternalUserProfileResponse getExternalUserProfiles(String userCode) {

	    List<UserCustomerOrganizationDTO> orgList =
	            userCustomerOrganizationRepository.findActiveByUserCode(userCode);

	    List<UserMeterModuleAuthorizationDTO> authList =
	            Optional.ofNullable(userMeterModuleAuthorizationRepository.findActiveByUserCode(userCode))
	                    .orElseGet(List::of);

	    return buildExternalUserProfileResponse(userCode, orgList, authList);
	}


	@LogPmr
	public ExternalUserProfileResponse getExternalUserProfilesOnlyUco(String userCode) {

		List<UserCustomerOrganizationDTO> orgList = userCustomerOrganizationRepository.findActiveByUserCode(userCode);
		if (orgList == null || orgList.isEmpty()) {
			return new ExternalUserProfileResponse(userCode, List.of());
		}
		Map<String, List<UserCustomerOrganizationDTO>> grouped = orgList.stream().collect(Collectors.groupingBy(this::resolveProfile, java.util.LinkedHashMap::new, Collectors.toList()));
		List<ProfileScenarioDto> scenarios = grouped.keySet().stream().map(profile -> new ProfileScenarioDto(profile, null)).toList();
		return new ExternalUserProfileResponse(userCode, scenarios);
	}

	@LogPmr
	public List<ExternalUserProfileResponse> getExternalUserProfilesByPartiteIvaList(List<String> partitaIvaList) {

	    List<String> normalizedPartiteIvaList = Optional.ofNullable(partitaIvaList)
	            .orElseGet(List::of)
	            .stream()
	            .filter(Objects::nonNull)
	            .map(String::trim)
	            .filter(s -> !s.isBlank())
	            .distinct()
	            .toList();

	    if (normalizedPartiteIvaList.isEmpty()) {
	        return List.of();
	    }

	    List<UserCustomerOrganizationDTO> orgList =
	            userCustomerOrganizationRepository.findActiveByCustomerOrganizationCodes(normalizedPartiteIvaList);

	    if (orgList == null || orgList.isEmpty()) {
	        return List.of();
	    }

	    List<UserMeterModuleAuthorizationDTO> authList =
	            Optional.ofNullable(userMeterModuleAuthorizationRepository.findActiveByOrganizationCodes(normalizedPartiteIvaList))
	                    .orElseGet(List::of);

	    Map<String, List<UserCustomerOrganizationDTO>> orgByUserCode = orgList.stream()
	            .filter(uco -> safe(uco.userCode()) != null)
	            .collect(Collectors.groupingBy(
	                    uco -> safe(uco.userCode()),
	                    LinkedHashMap::new,
	                    Collectors.toList()
	            ));

	    Map<String, List<UserMeterModuleAuthorizationDTO>> authByUserCode = authList.stream()
	            .filter(auth -> safe(auth.userCode()) != null)
	            .collect(Collectors.groupingBy(
	                    auth -> safe(auth.userCode()),
	                    LinkedHashMap::new,
	                    Collectors.toList()
	            ));

	    return orgByUserCode.entrySet().stream()
	            .map(entry -> buildExternalUserProfileResponse(
	                    entry.getKey(),
	                    entry.getValue(),
	                    authByUserCode.getOrDefault(entry.getKey(), List.of())
	            ))
	            .toList();
	}

	private ExternalUserProfileResponse buildExternalUserProfileResponse(
	        String userCode,
	        List<UserCustomerOrganizationDTO> orgList,
	        List<UserMeterModuleAuthorizationDTO> authList) {

	    if (orgList == null || orgList.isEmpty()) {
	        return new ExternalUserProfileResponse(userCode, List.of());
	    }

	    Map<String, Map<String, List<UserMeterModuleAuthorizationDTO>>> authByCustomerOrgAndModule =
	            Optional.ofNullable(authList)
	                    .orElseGet(List::of)
	                    .stream()
	                    .filter(a -> safe(a.organizationCode()) != null)
	                    .collect(Collectors.groupingBy(
	                            a -> safe(a.organizationCode()),
	                            LinkedHashMap::new,
	                            Collectors.groupingBy(
	                                    a -> safe(a.moduleCode()),
	                                    LinkedHashMap::new,
	                                    Collectors.toList()
	                            )
	                    ));

	    Map<String, List<UserCustomerOrganizationDTO>> grouped =
	            orgList.stream()
	                    .collect(Collectors.groupingBy(
	                            this::resolveProfile,
	                            LinkedHashMap::new,
	                            Collectors.toList()
	                    ));

	    List<ProfileScenarioDto> scenarios = grouped.entrySet().stream()
	            .map(entry -> {
	                String profile = entry.getKey();
	                List<UserCustomerOrganizationDTO> list = entry.getValue();

	                List<ProfileOrganizationDto> organizations = list.stream()
	                        .map(uco -> {
	                            String orgCode = safe(uco.organizationCode());
	                            String custOrgCode = safe(uco.customerOrganizationCode());

	                            if ("TITOLARE".equals(profile)) {
	                                return new ProfileOrganizationDto(
	                                        orgCode,
	                                        custOrgCode,
	                                        List.of()
	                                );
	                            }

	                            Map<String, List<UserMeterModuleAuthorizationDTO>> authByModule =
	                                    authByCustomerOrgAndModule.getOrDefault(custOrgCode, Map.of());

	                            List<ProfileModuleDto> modules = authByModule.entrySet().stream()
	                                    .map(moduleEntry -> {
	                                        String moduleCode = safe(moduleEntry.getKey());

	                                        List<String> meterList = moduleEntry.getValue().stream()
	                                                .map(UserMeterModuleAuthorizationDTO::meterCode)
	                                                .filter(Objects::nonNull)
	                                                .map(String::trim)
	                                                .filter(s -> !s.isBlank())
	                                                .distinct()
	                                                .sorted()
	                                                .toList();

	                                        return new ProfileModuleDto(moduleCode, meterList);
	                                    })
	                                    .sorted(Comparator.comparing(
	                                            ProfileModuleDto::moduleCode,
	                                            Comparator.nullsLast(String::compareTo)
	                                    ))
	                                    .toList();

	                            return new ProfileOrganizationDto(
	                                    orgCode,
	                                    custOrgCode,
	                                    modules
	                            );
	                        })
	                        .distinct()
	                        .toList();

	                return new ProfileScenarioDto(profile, organizations);
	            })
	            .toList();

	    return new ExternalUserProfileResponse(userCode, scenarios);
	}

	
	
	private String resolveProfile(UserCustomerOrganizationDTO uco) {

	    String desc = safe(uco.userDescription());
	    String org = safe(uco.organizationCode());
	    String cust = safe(uco.customerOrganizationCode());
	    String role = safe(uco.roleDescription());

	    boolean sameOrg = org != null && cust != null && Objects.equals(org, cust);


	    boolean isBase = "Base".equalsIgnoreCase(desc);
	    boolean isSuperuser = "Superuser".equalsIgnoreCase(desc);

	    boolean isSg = "SG".equalsIgnoreCase(role);
	    boolean isMaOrPi = "MA".equalsIgnoreCase(role) || "PI".equalsIgnoreCase(role);

	    if (isSuperuser && (sameOrg || (!sameOrg && isSg))) {
	        return "TITOLARE";
	    }

	    if (isBase && (sameOrg || (!sameOrg && isSg))) {
	        return "COLLABORATORE";
	    }

	    if ((isBase || isSuperuser) && !sameOrg && isMaOrPi) {
	        return "AZIENDA TERZA";
	    }

	    return "UNKNOWN";
	}

	
	
	

	private String safe(Object value) {
		return value == null ? null : value.toString().trim();
	}

}