package it.eng.snam.pmr.common.util.exception;

import java.util.concurrent.CompletionException;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ExceptionUnwrapper {

    public Throwable unwrapCompletion(Throwable throwable) {
        return throwable instanceof CompletionException ? throwable.getCause() : throwable;
    }
}
