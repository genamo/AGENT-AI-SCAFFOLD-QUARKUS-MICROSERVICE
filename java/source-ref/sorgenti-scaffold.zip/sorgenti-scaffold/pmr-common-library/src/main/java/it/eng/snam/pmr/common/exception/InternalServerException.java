package it.eng.snam.pmr.common.exception;

import java.io.Serial;

import lombok.experimental.StandardException;

@StandardException
public class InternalServerException extends RuntimeException {
    @Serial
    private static final long serialVersionUID = -4861238431738570100L;
}
