package it.eng.snam.pmr.common.config.jwt;

import java.util.List;
import java.util.Set;

public interface Provider {

    String issuer();

    Set<String> audiences();

    List<String> jwksUris();
}