package it.eng.snam.pmr.batchintegrazione.test.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import it.eng.snam.pmr.batchintegrazione.utils.Utility;

class UtilityStaticTest {

    // ---- defaultUuidIfBlank ----

    @Test
    void defaultUuidIfBlank_null_generatesUuid() {
        String result = Utility.defaultUuidIfBlank(null);
        assertNotNull(result);
        assertFalse(result.isBlank());
    }

    @Test
    void defaultUuidIfBlank_blank_generatesUuid() {
        String result = Utility.defaultUuidIfBlank("   ");
        assertNotNull(result);
        assertFalse(result.isBlank());
    }

    @Test
    void defaultUuidIfBlank_value_returnsValue() {
        assertEquals("abc-123", Utility.defaultUuidIfBlank("abc-123"));
    }

    // ---- parseBooleanOrDefault ----

    @Test
    void parseBooleanOrDefault_null_returnsDefault() {
        assertTrue(Utility.parseBooleanOrDefault(null, true));
        assertFalse(Utility.parseBooleanOrDefault(null, false));
    }

    @Test
    void parseBooleanOrDefault_blank_returnsDefault() {
        assertTrue(Utility.parseBooleanOrDefault("  ", true));
        assertFalse(Utility.parseBooleanOrDefault("", false));
    }

    @Test
    void parseBooleanOrDefault_true_variants() {
        assertTrue(Utility.parseBooleanOrDefault("true", false));
        assertTrue(Utility.parseBooleanOrDefault("TRUE", false));
        assertTrue(Utility.parseBooleanOrDefault(" True ", false));
    }

    @Test
    void parseBooleanOrDefault_false_variants() {
        assertFalse(Utility.parseBooleanOrDefault("false", true));
        assertFalse(Utility.parseBooleanOrDefault("FALSE", true));
        assertFalse(Utility.parseBooleanOrDefault(" False ", true));
    }

    @Test
    void parseBooleanOrDefault_other_returnsDefault() {
        assertTrue(Utility.parseBooleanOrDefault("yes", true));
        assertFalse(Utility.parseBooleanOrDefault("yes", false));
        assertTrue(Utility.parseBooleanOrDefault("1", true));
    }

    // ---- defaultIfBlank ----

    @Test
    void defaultIfBlank_null_returnsDefault() {
        assertEquals("def", Utility.defaultIfBlank(null, "def"));
    }

    @Test
    void defaultIfBlank_blank_returnsDefault() {
        assertEquals("def", Utility.defaultIfBlank("   ", "def"));
    }

    @Test
    void defaultIfBlank_empty_returnsDefault() {
        assertEquals("def", Utility.defaultIfBlank("", "def"));
    }

    @Test
    void defaultIfBlank_value_returnsValue() {
        assertEquals("hello", Utility.defaultIfBlank("hello", "def"));
    }

    // ---- elapsedMs ----

    @Test
    void elapsedMs_returnsNonNegative() {
        long start = System.nanoTime();
        long elapsed = Utility.elapsedMs(start);
        assertTrue(elapsed >= 0);
    }

    @Test
    void elapsedMs_pastStart_returnsPositive() {
        long start = System.nanoTime() - 1_000_000L; // 1ms in the past
        long elapsed = Utility.elapsedMs(start);
        assertTrue(elapsed >= 0);
    }

    // ---- safe ----

    @Test
    void safe_null_returnsNullString() {
        assertEquals("null", Utility.safe(null));
    }

    @Test
    void safe_blank_returnsBlankString() {
        assertEquals("blank", Utility.safe("   "));
    }

    @Test
    void safe_emptyString_returnsBlankString() {
        assertEquals("blank", Utility.safe(""));
    }

    @Test
    void safe_normalValue_returnsValue() {
        assertEquals("hello", Utility.safe("hello"));
    }

    @Test
    void safe_longValue_truncates() {
        String longStr = "x".repeat(130);
        String result = Utility.safe(longStr);
        assertTrue(result.endsWith("..."));
        assertEquals(123, result.length()); // 120 + "..."
    }

    @Test
    void safe_exactly120_notTruncated() {
        String str = "a".repeat(120);
        assertEquals(str, Utility.safe(str));
    }

    @Test
    void safe_121chars_truncated() {
        String str = "a".repeat(121);
        String result = Utility.safe(str);
        assertTrue(result.endsWith("..."));
    }

    @Test
    void safe_integer_returnsString() {
        assertEquals("42", Utility.safe(42));
    }
}
