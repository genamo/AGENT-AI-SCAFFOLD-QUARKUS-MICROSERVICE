package it.eng.snam.pmr.batchintegrazionedg.service;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.jboss.logging.Logger;

import it.eng.snam.pmr.batchintegrazionedg.dto.MonitoringBatchDTO;
import it.eng.snam.pmr.batchintegrazionedg.dto.UserMetersDTO;
import it.eng.snam.pmr.common.dto.UserMeterModuleAuthorizationDTO;
import it.eng.snam.pmr.common.service.DataPlatformService;
import it.eng.snam.pmr.common.util.JsonUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class ExternalUserService {

    private static final Logger LOG = Logger.getLogger(ExternalUserService.class);

    private static final String FLOW_ID = "BTCH_USERSMETER";
    private static final String SENDER = "PMR";
    private static final String USER_ACTION = "INTEGRATION";

    @Inject
    DataPlatformService dataPlatformService;

    @Inject
    MonitoringBatchService monitoringBatchService;

    // =========================================================
    // MAIN PROCESS
    // =========================================================

    public void getUsersFromDataplatform() {

        String transId = generateTransactionId();

        LocalDate today = LocalDate.now();
        int dayNumber = toDayNumber(today);
        int monthNumber = toMonthNumber(today);

		try {
			saveBatchStatus(transId, dayNumber, monthNumber, BatchStatus.INIT);
			List<UserMeterModuleAuthorizationDTO> externalUserList = dataPlatformService.getAllActiveUsers();
			saveBatchStatus(transId, dayNumber, monthNumber, BatchStatus.BEGIN);
			Map<String, List<String>> userMetersMap = groupUsersByMeters(externalUserList);
			saveBatchStatus(transId, dayNumber, monthNumber, BatchStatus.PROGRESS);
			logUsers(userMetersMap);
			// BUILD OUTPUT
			String fileBatch = buildBase64Batch(userMetersMap);
			String fileOutput = buildBase64Output(userMetersMap);
			saveBatchStatus(transId, dayNumber, monthNumber, BatchStatus.COMPLETED, fileBatch, fileOutput);

		} catch (Exception ex) {

			LOG.error("Errore durante processamento batch utenti-misuratori", ex);
			// salva errore nel monitoring
			saveBatchStatus(transId, dayNumber, monthNumber, BatchStatus.ERROR, null, buildErrorPayload(ex));
		}
    }

    // =========================================================
    // BUSINESS LOGIC
    // =========================================================

    private Map<String, List<String>> groupUsersByMeters(List<UserMeterModuleAuthorizationDTO> list) {
        return list.stream()
                .collect(Collectors.groupingBy(
                        UserMeterModuleAuthorizationDTO::userCode,
                        Collectors.mapping(
                                UserMeterModuleAuthorizationDTO::meterCode,
                                Collectors.toList()
                        )
                ));
    }

    private void logUsers(Map<String, List<String>> map) {
        map.forEach((user, meters) ->
                LOG.infof("Utente: %s - Misuratori autorizzati: %s", user, meters)
        );
    }

    private String buildBase64Batch(Map<String, List<String>> map) {

        List<UserMetersDTO> dtoList = map.entrySet()
                .stream()
                .map(e -> new UserMetersDTO(e.getKey(), e.getValue()))
                .toList();

        return encodeToBase64(dtoList);
    }

    private String buildBase64Output(Map<String, List<String>> map) {

        int totalUsers = map.size();
        int totalMeters = map.values().stream().mapToInt(List::size).sum();

        Map<String, Object> summary = Map.of(
                "totalUsers", totalUsers,
                "totalMeters", totalMeters,
                "timestamp", LocalDateTime.now()
        );

        return encodeToBase64(summary);
    }

    private String buildErrorPayload(Exception ex) {
        return encodeToBase64(Map.of(
                "error", ex.getMessage(),
                "timestamp", LocalDateTime.now()
        ));
    }

    // =========================================================
    // MONITORING
    // =========================================================

    private void saveBatchStatus(String transId, int dayNumber, int monthNumber, BatchStatus status) {
        saveBatchStatus(transId, dayNumber, monthNumber, status, null, null);
    }

    private void saveBatchStatus(String transId, int dayNumber, int monthNumber,
                                 BatchStatus status,
                                 String fileBatch,
                                 String fileOutput) {

        MonitoringBatchDTO dto = MonitoringBatchDTO.builder()
                .transactionId(transId)
                .correlationId(transId)
                .flowId(FLOW_ID)
                .dayNumber(dayNumber)
                .monthNumber(monthNumber)
                .granularita("G")
                .sender(SENDER)
                .isWorkaround(false)
                .fileBatch(fileBatch)
                .fileOutput(fileOutput)
                .status(status.code)
                .statusDescription(status.description)
                .actionDate(LocalDateTime.now())
                .userAction(USER_ACTION)
                .isDeleted(0)
                .build();

        monitoringBatchService.save(dto);
    }

    // =========================================================
    // UTIL
    // =========================================================

    private String generateTransactionId() {
        return FLOW_ID + "_" + System.currentTimeMillis();
    }

    private int toDayNumber(LocalDate date) {
        return date.getYear() * 10000
                + date.getMonthValue() * 100
                + date.getDayOfMonth();
    }

    private int toMonthNumber(LocalDate date) {
        return date.getYear() * 100 + date.getMonthValue();
    }

    private String encodeToBase64(Object obj) {
        String json = JsonUtils.writeAsJsonPrettyLogStringWithoutNull(obj);

        return Base64.getEncoder()
                .encodeToString(json.getBytes(StandardCharsets.UTF_8));
    }

    // =========================================================
    // STATUS ENUM
    // =========================================================

    private enum BatchStatus {
        INIT(0, "INIT"),
        BEGIN(100, "BEGIN"),
        PROGRESS(150, "PROGRESS"),
        COMPLETED(200, "COMPLETED"),
        ERROR(400, "ERROR");

        final int code;
        final String description;

        BatchStatus(int code, String description) {
            this.code = code;
            this.description = description;
        }
    }
}