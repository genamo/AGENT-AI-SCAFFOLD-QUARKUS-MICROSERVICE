package it.eng.snam.pmr.batchintegrazione.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.lang.reflect.Field;
import java.time.LocalDate;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import it.eng.snam.pmr.batchintegrazione.filter.RequestHeadersContext;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringFlussiService;
import it.eng.snam.pmr.batchintegrazione.service.MonitoringFlussiService.FlussiStatus;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractFlussoHandler;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.ValidationInterface;

@ExtendWith(MockitoExtension.class)
class AbstractFlussoHandlerTest {

    private static final String FLOW_TYPE = "TEST_FLOW";
    private static final String PAYLOAD = "{\"id\":\"123\",\"correlationId\":\"corr-123\",\"elementNumber\":1}";

    @Mock
    MonitoringFlussiService monitoring;

    @Mock
    RequestHeadersContext headersCtx;

    private TestFlussoHandler handler;

    @BeforeEach
    void setUp() throws Exception {
        handler = spy(new TestFlussoHandler());
        injectDependencies(handler);
    }

    @AfterEach
    void clearInterruptFlag() {
        Thread.interrupted();
    }

    private void injectDependencies(AbstractFlussoHandler<?> target) throws Exception {
        injectField(target, AbstractFlussoHandler.class, "monitoring", monitoring);
        injectField(target, AbstractFlussoHandler.class, "headersCtx", headersCtx);
    }

    private void injectField(Object target, Class<?> declaringClass, String fieldName, Object value) throws Exception {
        Field field = declaringClass.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    void getFlowType_returnsFlowType() {
        assertEquals(FLOW_TYPE, handler.getFlowType());
    }

    @Test
    void sender_returnsDefaultSender() {
        assertEquals("SUMMER", handler.exposedSender());
    }

    @Test
    void currentDate_returnsToday() {
        LocalDate before = LocalDate.now();
        LocalDate actual = handler.exposedCurrentDate();
        LocalDate after = LocalDate.now();

        assertTrue(!actual.isBefore(before) && !actual.isAfter(after));
    }

    @Test
    void computeDelayMs_multipliesBaseDelayByAttempt() {
        TestFlussoHandler configuredHandler = new TestFlussoHandler(3, 3000L);

        assertEquals(6000L, configuredHandler.exposedComputeDelayMs(2));
    }

    @Test
    void process_happyPath_savesStatusesAndCompletes() {
        handler.process(PAYLOAD);

        InOrder inOrder = inOrder(monitoring, handler);

        inOrder.verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.INIT));

		inOrder.verify(monitoring).saveFlussoStatus(eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.BEGIN));

		inOrder.verify(monitoring).saveFlussoStatus(eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.PROGRESS), eq(PAYLOAD), isNull());

        inOrder.verify(handler).handle(argThat(dto ->
                "123".equals(dto.id)
                        && "corr-123".equals(dto.getCorrelationId())
                        && dto.getElementNumber() == 1));

				inOrder.verify(monitoring).saveFlussoStatus(eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.COMPLETED), eq(PAYLOAD), isNull());

        verify(headersCtx).setCorrelationId("corr-123");

        verify(monitoring, never()).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class),
                eq(FlussiStatus.ERROR), anyString(), anyString());
    }

    @Test
    void process_invalidJson_savesErrorAndDoesNotInvokeHandle() {
        String invalidPayload = "{invalid-json";

        handler.process(invalidPayload);

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.INIT));

        verify(handler, never()).handle(any());

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class),
                eq(FlussiStatus.ERROR),
                eq(invalidPayload),
                argThat(message -> message != null && !message.isBlank()));

        verify(monitoring, never()).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.BEGIN));

        verify(monitoring, never()).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.PROGRESS), eq(PAYLOAD), isNull());

        verify(headersCtx, never()).setCorrelationId(anyString());
    }

    @Test
    void process_handleFailsTwice_thenSucceeds_completesAfterRetries() {
        doThrow(new RuntimeException("boom-1"))
                .doThrow(new RuntimeException("boom-2"))
                .doNothing()
                .when(handler).handle(any(TestDto.class));

        handler.process(PAYLOAD);

        verify(handler, times(3)).handle(any(TestDto.class));

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.INIT));

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.BEGIN));

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.PROGRESS), eq(PAYLOAD), isNull());

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class),
                eq(FlussiStatus.COMPLETED), eq(PAYLOAD), isNull());

        verify(headersCtx).setCorrelationId("corr-123");

        verify(monitoring, never()).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class),
                eq(FlussiStatus.ERROR), anyString(), anyString());
    }

    @Test
    void process_handleAlwaysFails_retriesThreeTimesAndSavesError() {
        doThrow(new RuntimeException("boom")).when(handler).handle(any(TestDto.class));

        handler.process(PAYLOAD);

        verify(handler, times(3)).handle(any(TestDto.class));

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.INIT));

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.BEGIN));

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class), eq(FlussiStatus.PROGRESS), eq(PAYLOAD), isNull());

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class),
                eq(FlussiStatus.ERROR),
                eq(PAYLOAD),
                eq("boom"));

        verify(headersCtx).setCorrelationId("corr-123");

        verify(monitoring, never()).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class),
                eq(FlussiStatus.COMPLETED), anyString(), any());
    }

    @Test
    void process_interruptedDuringRetry_savesError() throws Exception {
        InterruptingFlussoHandler interruptedHandler = spy(new InterruptingFlussoHandler());
        injectDependencies(interruptedHandler);

        doThrow(new RuntimeException("boom")).when(interruptedHandler).handle(any(TestDto.class));

        interruptedHandler.process(PAYLOAD);

        verify(interruptedHandler, times(1)).handle(any(TestDto.class));

        verify(monitoring).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class),
                eq(FlussiStatus.ERROR),
                eq(PAYLOAD),
                eq("Retry interrotto"));

        verify(headersCtx).setCorrelationId("corr-123");

        verify(monitoring, never()).saveFlussoStatus(
                eq(FLOW_TYPE), eq("SUMMER"), any(LocalDate.class),
                eq(FlussiStatus.COMPLETED), anyString(), any());
    }

    static class TestFlussoHandler extends AbstractFlussoHandler<TestDto> {

        TestFlussoHandler() {
            super(3, 0L);
        }

        TestFlussoHandler(int maxRetries, long baseDelayMs) {
            super(maxRetries, baseDelayMs);
        }

        @Override
        protected Class<TestDto> getDtoClass() {
            return TestDto.class;
        }

        @Override
        protected void handle(TestDto dto) {
            // no-op: il comportamento viene controllato nel test con spy/mockito
        }

        @Override
        protected String flowType() {
            return FLOW_TYPE;
        }

        String exposedSender() {
            return sender();
        }

        LocalDate exposedCurrentDate() {
            return currentDate();
        }

        long exposedComputeDelayMs(int attempt) {
            return computeDelayMs(attempt);
        }
    }

    static class InterruptingFlussoHandler extends TestFlussoHandler {

        InterruptingFlussoHandler() {
            super(3, 0L);
        }

        @Override
        protected void sleep(long millis) throws InterruptedException {
            throw new InterruptedException("forced");
        }
    }

    static class TestDto implements ValidationInterface {
        public String id;
        public String correlationId;
        public int elementNumber;

        @Override
        public String getCorrelationId() {
            return correlationId;
        }

        @Override
        public int getElementNumber() {
            return elementNumber;
        }
    }
}
