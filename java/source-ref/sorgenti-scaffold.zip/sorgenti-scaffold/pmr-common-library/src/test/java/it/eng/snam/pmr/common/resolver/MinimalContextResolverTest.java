package it.eng.snam.pmr.common.resolver;

import jakarta.ws.rs.Path;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MinimalContextResolverTest {

    // -----------------------------------------------------------------------
    // Fixture: resource classes with @Path annotations
    // -----------------------------------------------------------------------

    @Path("/anag-flussi")
    static class ResourceWithClassPathOnly {
        public void noMethodPath() {}

        @Path("/list")
        public void withMethodPath() {}

        @Path("list")  // no leading slash
        public void withMethodPathNoSlash() {}
    }

    static class ResourceWithoutClassPath {
        @Path("/sub")
        public void method() {}

        public void noPath() {}
    }

    // -----------------------------------------------------------------------
    // build
    // -----------------------------------------------------------------------

    @Test
    void build_classPathOnly_returnsClassPath() throws Exception {
        Method m = ResourceWithClassPathOnly.class.getMethod("noMethodPath");
        String result = MinimalContextResolver.build(ResourceWithClassPathOnly.class, m);
        assertThat(result).isEqualTo("/anag-flussi");
    }

    @Test
    void build_classAndMethodPath_returnsCombined() throws Exception {
        Method m = ResourceWithClassPathOnly.class.getMethod("withMethodPath");
        String result = MinimalContextResolver.build(ResourceWithClassPathOnly.class, m);
        assertThat(result).isEqualTo("/anag-flussi/list");
    }

    @Test
    void build_methodPathWithoutLeadingSlash_normalizes() throws Exception {
        Method m = ResourceWithClassPathOnly.class.getMethod("withMethodPathNoSlash");
        String result = MinimalContextResolver.build(ResourceWithClassPathOnly.class, m);
        assertThat(result).isEqualTo("/anag-flussi/list");
    }

    @Test
    void build_noClassPath_methodPathOnly() throws Exception {
        Method m = ResourceWithoutClassPath.class.getMethod("method");
        String result = MinimalContextResolver.build(ResourceWithoutClassPath.class, m);
        assertThat(result).isEqualTo("/sub");
    }

    @Test
    void build_noClassPath_noMethodPath_returnsSlash() throws Exception {
        Method m = ResourceWithoutClassPath.class.getMethod("noPath");
        String result = MinimalContextResolver.build(ResourceWithoutClassPath.class, m);
        assertThat(result).isEqualTo("/");
    }

    @Test
    void build_nullMethod_usesClassPathOnly() {
        String result = MinimalContextResolver.build(ResourceWithClassPathOnly.class, null);
        assertThat(result).isEqualTo("/anag-flussi");
    }

    // -----------------------------------------------------------------------
    // buildStrict
    // -----------------------------------------------------------------------

    @Test
    void buildStrict_classWithPath_succeeds() throws Exception {
        Method m = ResourceWithClassPathOnly.class.getMethod("withMethodPath");
        assertThat(MinimalContextResolver.buildStrict(ResourceWithClassPathOnly.class, m))
                .isEqualTo("/anag-flussi/list");
    }

    @Test
    void buildStrict_classWithoutPath_throwsIllegalState() throws Exception {
        Method m = ResourceWithoutClassPath.class.getMethod("method");
        assertThatThrownBy(() -> MinimalContextResolver.buildStrict(ResourceWithoutClassPath.class, m))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Missing @Path");
    }

    // -----------------------------------------------------------------------
    // normalize edge cases
    // -----------------------------------------------------------------------

    @Path("//double//slash//")
    static class ResourceDoubleSlash {
        @Path("//end//")
        public void m() {}
    }

    @Test
    void build_doubleSlashes_normalized() throws Exception {
        Method m = ResourceDoubleSlash.class.getMethod("m");
        String result = MinimalContextResolver.build(ResourceDoubleSlash.class, m);
        // Should collapse double slashes
        assertThat(result).doesNotContain("//");
    }
}
