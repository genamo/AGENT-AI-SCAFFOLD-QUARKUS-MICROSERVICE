package it.eng.snam.pmr.batchintegrazione.test.resource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import it.eng.snam.pmr.batchintegrazione.dto.FlowTriggerRequestDTO;
import it.eng.snam.pmr.batchintegrazione.dto.FlowTriggerResponseDTO;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.resource.PublishWorkaroundFlussiAnagraficaResource;
import it.eng.snam.pmr.batchintegrazione.service.PublishWorkaroundFlussiAnagraficaService;
import it.eng.snam.pmr.batchintegrazione.utils.Constants;
import it.eng.snam.pmr.batchintegrazione.utils.Utility;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@ExtendWith(MockitoExtension.class)
class PublishWorkaroundFlussiAnagraficaResourceTest {

    @Mock PublishWorkaroundFlussiAnagraficaService service;
    @Mock Utility utility;

    @InjectMocks
    PublishWorkaroundFlussiAnagraficaResource resource;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() throws Exception {
        setField(resource, "objectMapper", objectMapper);
    }

    private static void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private FlowTriggerRequestDTO sampleRequest() throws Exception {
        return FlowTriggerRequestDTO.builder()
            .flow(Constants.Flussi.ANAG_REMI_FLOW)
            .transactionId("tx-001")
            .processType("GUI")
            .messageKey("mk-001")
            .payload(objectMapper.readTree("{\"id\":1}"))
            .extraHeaders(Map.of())
            .build();
    }

    private FlowTriggerResponseDTO sampleResponse() {
        return FlowTriggerResponseDTO.builder()
            .flow(Constants.Flussi.ANAG_REMI_FLOW)
            .resolvedTopic(Constants.Topic.PMR001A_SUMMER_IN_TOPIC)
            .transactionId("tx-001")
            .messageKey("mk-001")
            .status("PUBLISHED")
            .build();
    }

    private InputStream brokenStream(String message) {
        return new InputStream() {
            @Override
            public int read() throws IOException {
                throw new IOException(message);
            }
        };
    }

    @Test
    void publish_success_delegatesToUtilityInCarico() throws Exception {
        FlowTriggerRequestDTO request = sampleRequest();
        FlowTriggerResponseDTO serviceResponse = sampleResponse();
        Response expected = mock(Response.class);

        when(service.publish(request)).thenReturn(serviceResponse);
        when(utility.inCarico(serviceResponse)).thenReturn(expected);

        assertSame(expected, resource.publish(request));
    }

    @Test
    void publish_illegalArgument_returnsBadRequest() throws Exception {
        FlowTriggerRequestDTO request = sampleRequest();
        Response expected = mock(Response.class);

        when(service.publish(request)).thenThrow(new IllegalArgumentException("bad request"));
        when(utility.badRequest("bad request")).thenReturn(expected);

        assertSame(expected, resource.publish(request));
    }

    @Test
    void publishFromFile_success_readsJsonAndPublishes() {
        String json = """
            {
              "flow": "PMR001A",
              "payload": {
                "id": 99
              }
            }
            """;

        FlowTriggerResponseDTO serviceResponse = sampleResponse();
        Response expected = mock(Response.class);

        when(service.publish(any())).thenReturn(serviceResponse);
        when(utility.inCarico(serviceResponse)).thenReturn(expected);

        Response result = resource.publishFromFile(
            new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8))
        );

        assertSame(expected, result);

        verify(service).publish(argThat(req ->
            Constants.Flussi.ANAG_REMI_FLOW.equals(req.flow())
                && req.payload() != null
                && req.payload().get("id") != null
                && req.payload().get("id").asInt() == 99
        ));
    }

    @Test
    void publishFromFile_serviceIllegalArgument_returnsBadRequest() {
        String json = """
            {
              "flow": "PMR001A",
              "payload": {
                "id": 1
              }
            }
            """;

        Response expected = mock(Response.class);

        when(service.publish(any())).thenThrow(new IllegalArgumentException("payload errato"));
        when(utility.badRequest("payload errato")).thenReturn(expected);

        Response result = resource.publishFromFile(
            new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8))
        );

        assertSame(expected, result);
    }

    @Test
    void publishFromFile_readError_returnsBadRequest() {
        Response expected = mock(Response.class);

        when(utility.badRequest("Errore lettura file: boom")).thenReturn(expected);

        Response result = resource.publishFromFile(brokenStream("boom"));

        assertSame(expected, result);
        verify(service, never()).publish(any());
    }

    @Test
    void downloadFromDlq_success_withNullControlKey_usesUnknownFilename() throws Exception {
        FlowTriggerRequestDTO dto = sampleRequest();
        when(service.buildDownloadFromDlqRequest(null)).thenReturn(dto);

        Response response = resource.downloadFromDlq(null);

        assertEquals(200, response.getStatus());
        assertEquals(MediaType.APPLICATION_JSON, response.getMediaType().toString());
        assertEquals(
            "attachment; filename=\"downloadfromdlq_unknown.json\"",
            response.getHeaderString("Content-Disposition")
        );

        byte[] entity = (byte[]) response.getEntity();
        JsonNode root = objectMapper.readTree(entity);
        assertEquals(Constants.Flussi.ANAG_REMI_FLOW, root.get("flow").asText());
        assertEquals("tx-001", root.get("transactionId").asText());
    }

    @Test
    void downloadFromDlq_notFound_returnsUtilityNotFound() {
        Response expected = mock(Response.class);

        when(service.buildDownloadFromDlqRequest("ck-1")).thenThrow(new NotFoundException("not found"));
        when(utility.notFound("not found")).thenReturn(expected);

        assertSame(expected, resource.downloadFromDlq("ck-1"));
    }

    @Test
    void downloadFromDlq_illegalArgument_returnsUtilityBadRequest() {
        Response expected = mock(Response.class);

        when(service.buildDownloadFromDlqRequest("ck-1")).thenThrow(new IllegalArgumentException("bad request"));
        when(utility.badRequest("bad request")).thenReturn(expected);

        assertSame(expected, resource.downloadFromDlq("ck-1"));
    }

    @Test
    void downloadFromDlq_remoteCallException_returnsUtilityBadGateway() {
        Response expected = mock(Response.class);
        RemoteCallException ex = new RemoteCallException("gateway err");

        when(service.buildDownloadFromDlqRequest("ck-1")).thenThrow(ex);
        when(utility.badGateway(ex)).thenReturn(expected);

        assertSame(expected, resource.downloadFromDlq("ck-1"));
    }

    @Test
    void downloadFromDlq_genericException_returnsServerError() {
        when(service.buildDownloadFromDlqRequest("ck-1")).thenThrow(new RuntimeException("boom"));

        Response response = resource.downloadFromDlq("ck-1");

        assertEquals(500, response.getStatus());
        assertEquals("Errore generazione file DLQ: boom", response.getEntity());
    }

    @Test
    void downloadFromFlussiMonitoring_success_sanitizesFilename() throws Exception {
        FlowTriggerRequestDTO dto = sampleRequest();
        when(service.buildDownloadFromFlussiMonitoringRequest("tx 1/2")).thenReturn(dto);

        Response response = resource.downloadFromFlussiMonitoring("tx 1/2");

        assertEquals(200, response.getStatus());
        assertEquals(MediaType.APPLICATION_JSON, response.getMediaType().toString());
        assertEquals(
            "attachment; filename=\"downloadfromflussimonitoring_tx_1_2.json\"",
            response.getHeaderString("Content-Disposition")
        );

        byte[] entity = (byte[]) response.getEntity();
        JsonNode root = objectMapper.readTree(entity);
        assertEquals(Constants.Flussi.ANAG_REMI_FLOW, root.get("flow").asText());
        assertEquals("tx-001", root.get("transactionId").asText());
    }

    @Test
    void downloadFromFlussiMonitoring_notFound_returnsUtilityNotFound() {
        Response expected = mock(Response.class);

        when(service.buildDownloadFromFlussiMonitoringRequest("tx-1")).thenThrow(new NotFoundException("not found"));
        when(utility.notFound("not found")).thenReturn(expected);

        assertSame(expected, resource.downloadFromFlussiMonitoring("tx-1"));
    }

    @Test
    void downloadFromFlussiMonitoring_illegalArgument_returnsUtilityBadRequest() {
        Response expected = mock(Response.class);

        when(service.buildDownloadFromFlussiMonitoringRequest("tx-1")).thenThrow(new IllegalArgumentException("bad request"));
        when(utility.badRequest("bad request")).thenReturn(expected);

        assertSame(expected, resource.downloadFromFlussiMonitoring("tx-1"));
    }

    @Test
    void downloadFromFlussiMonitoring_remoteCallException_returnsUtilityBadGateway() {
        Response expected = mock(Response.class);
        RemoteCallException ex = new RemoteCallException("gateway err");

        when(service.buildDownloadFromFlussiMonitoringRequest("tx-1")).thenThrow(ex);
        when(utility.badGateway(ex)).thenReturn(expected);

        assertSame(expected, resource.downloadFromFlussiMonitoring("tx-1"));
    }

    @Test
    void downloadFromFlussiMonitoring_genericException_returnsServerError() {
        when(service.buildDownloadFromFlussiMonitoringRequest("tx-1")).thenThrow(new RuntimeException("boom"));

        Response response = resource.downloadFromFlussiMonitoring("tx-1");

        assertEquals(500, response.getStatus());
        assertEquals("Errore generazione file monitoring flussi: boom", response.getEntity());
        assertTrue(response.hasEntity());
    }
}
