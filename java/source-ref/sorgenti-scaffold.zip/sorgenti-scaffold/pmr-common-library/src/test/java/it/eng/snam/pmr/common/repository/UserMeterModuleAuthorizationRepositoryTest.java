package it.eng.snam.pmr.common.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;
import java.sql.*;
import java.util.List;
import java.util.Optional;

import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import it.eng.snam.pmr.common.databricks.DatabricksRetry;
import it.eng.snam.pmr.common.dto.UserMeterModuleAuthorizationDTO;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserMeterModuleAuthorizationRepositoryTest {

    @Mock DataSource dataSource;
    @Mock DatabricksRetry retry;
    @Mock Connection connection;
    @Mock PreparedStatement preparedStatement;
    @Mock ResultSet resultSet;

    UserMeterModuleAuthorizationRepository repo;

    @BeforeEach
    @SuppressWarnings("unchecked")
    void setUp() throws Exception {
        repo = new UserMeterModuleAuthorizationRepository();
        setField(repo, "schemaForUsermetermoduleauthorization", "testschema");
        setField(repo, "dataSource", dataSource);
        setField(repo, "retry", retry);

        doAnswer(inv -> ((DatabricksRetry.SqlSupplier<?>) inv.getArgument(0)).get())
                .when(retry).execute(any(DatabricksRetry.SqlSupplier.class));

        when(dataSource.getConnection()).thenReturn(connection);
        when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
        when(preparedStatement.executeQuery()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(false);
    }

    private void stubSingleRow() throws SQLException {
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getObject("UserMeterModuleAuthorizationId")).thenReturn(1L);
        when(resultSet.getString("UserCode")).thenReturn("user01");
        when(resultSet.getObject("UserId")).thenReturn(100L);
        when(resultSet.getString("MeterCode")).thenReturn("MTR01");
        when(resultSet.getString("MeterId")).thenReturn("M100");
        when(resultSet.getString("ModuleCode")).thenReturn("MOD01");
        when(resultSet.getTimestamp("InsertDate")).thenReturn(null);
        when(resultSet.getTimestamp("UpdateDate")).thenReturn(null);
        when(resultSet.getString("OrganizationCode")).thenReturn("ORG01");
        when(resultSet.getObject("OrganizationId")).thenReturn(200L);
        when(resultSet.getString("WeakSapCode")).thenReturn("WSAP");
        when(resultSet.getObject("FlowId")).thenReturn(300L);
        when(resultSet.getObject("EntityId")).thenReturn(400L);
        when(resultSet.getObject("CancelledFlag")).thenReturn(0);
        when(resultSet.getString("PkSource")).thenReturn("SRC");
        when(resultSet.getObject("Denominatore")).thenReturn(null);
        when(resultSet.getObject("Penalita")).thenReturn(null);
        when(resultSet.getString("IdErrore")).thenReturn(null);
    }

    @Test
    void findById_found_returnsPresent() throws Exception {
        stubSingleRow();
        Optional<UserMeterModuleAuthorizationDTO> result = repo.findById(1L);
        assertThat(result).isPresent();
        assertThat(result.get().userCode()).isEqualTo("user01");
        verify(preparedStatement).setLong(1, 1L);
    }

    @Test
    void findById_notFound_returnsEmpty() throws Exception {
        Optional<UserMeterModuleAuthorizationDTO> result = repo.findById(999L);
        assertThat(result).isEmpty();
    }

    @Test
    void findByFlowId_returnsResults() throws Exception {
        stubSingleRow();
        List<UserMeterModuleAuthorizationDTO> list = repo.findByFlowId(300L);
        assertThat(list).hasSize(1);
        verify(preparedStatement).setLong(1, 300L);
    }

    @Test
    void findByUserCode_returnsResults() throws Exception {
        stubSingleRow();
        List<UserMeterModuleAuthorizationDTO> list = repo.findByUserCode("user01");
        assertThat(list).hasSize(1);
        verify(preparedStatement).setString(1, "user01");
    }

    @Test
    void findByUserCode_noResults_returnsEmptyList() throws Exception {
        List<UserMeterModuleAuthorizationDTO> list = repo.findByUserCode("nobody");
        assertThat(list).isEmpty();
    }

    @Test
    void findActiveByUserCode_setsCorrectParameters() throws Exception {
        repo.findActiveByUserCode("user01");
        verify(preparedStatement).setString(1, "user01");
    }

    @Test
    void findByKeys_setsCorrectParameters() throws Exception {
        repo.findByKeys("user01", "MTR01", "MOD01", "ORG01");
        verify(preparedStatement).setString(1, "user01");
        verify(preparedStatement).setString(2, "MTR01");
        verify(preparedStatement).setString(3, "MOD01");
        verify(preparedStatement).setString(4, "ORG01");
    }

    @Test
    void findActiveByKeys_setsCorrectParameters() throws Exception {
        repo.findActiveByKeys("user01", "MTR01", "MOD01", "ORG01");
        verify(preparedStatement).setString(1, "user01");
        verify(preparedStatement).setString(2, "MTR01");
        verify(preparedStatement).setString(3, "MOD01");
        verify(preparedStatement).setString(4, "ORG01");
    }

    @Test
    void findByUserCodePaged_setsCorrectParameters() throws Exception {
        repo.findByUserCodePaged("user01", 10, 0);
        verify(preparedStatement).setString(1, "user01");
        verify(preparedStatement).setInt(2, 10);
        verify(preparedStatement).setInt(3, 0);
    }

    @Test
    void schema_blank_throwsIllegalState() throws Exception {
        setField(repo, "schemaForUsermetermoduleauthorization", "");
        assertThatThrownBy(() -> repo.findById(1L))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("databricks.schema");
    }

    private static void setField(Object obj, String name, Object value) throws Exception {
        Field f = findField(obj.getClass(), name);
        f.setAccessible(true);
        f.set(obj, value);
    }

    private static Field findField(Class<?> clazz, String name) throws NoSuchFieldException {
        try { return clazz.getDeclaredField(name); }
        catch (NoSuchFieldException e) {
            if (clazz.getSuperclass() != null) return findField(clazz.getSuperclass(), name);
            throw e;
        }
    }
}
