package it.eng.snam.pmr.batchintegrazione.response;

import java.io.Serializable;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import it.eng.snam.pmr.common.response.GenericResponse.Message;
import lombok.Data;

@Data
@Schema(name = "CustomResponse", description = "Response Wrapper with Custom Message")
@JsonInclude(Include.NON_EMPTY)
public class CustomResponse<T> implements Serializable {

    private static final long serialVersionUID = 5007805106893745317L;

    private transient T responseData;
    @JsonInclude(Include.NON_NULL)
    private Message message;

}
