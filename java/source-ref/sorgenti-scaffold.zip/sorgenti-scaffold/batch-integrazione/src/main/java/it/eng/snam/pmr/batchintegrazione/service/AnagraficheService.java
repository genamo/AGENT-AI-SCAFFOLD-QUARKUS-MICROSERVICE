package it.eng.snam.pmr.batchintegrazione.service;

import java.util.List;
import java.util.Optional;

import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.logging.Logger;
import org.jboss.logging.MDC;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.smallrye.common.annotation.RunOnVirtualThread;
import it.eng.snam.pmr.batchintegrazione.client.AnagraficheClient;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagAreaTecnicaDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagClientiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagMacroPoloDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagPoloDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagRaggruppamentiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AnagTipoStatoRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssAreaTecnicaDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRaggruppamentiRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiAopDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiClientiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiTipoBilancioTecnicoDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssRemiTitolariDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.AssStatoRemiDto;
import it.eng.snam.pmr.batchintegrazione.dto.anagrafiche.ContattoDto;
import it.eng.snam.pmr.batchintegrazione.exception.RemoteCallException;
import it.eng.snam.pmr.batchintegrazione.service.abstracts.AbstractService;
import it.eng.snam.pmr.common.util.AuthorizationUtils;
import it.eng.snam.pmr.common.util.B2BTokenUtils;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;

@ApplicationScoped
@RunOnVirtualThread
public class AnagraficheService extends AbstractService {

    private static final Logger LOG = Logger.getLogger(AnagraficheService.class);

    @Inject
    @RestClient
    AnagraficheClient anagraficheClient;

    @Inject
    ObjectMapper objectMapper;

    @Inject
    B2BTokenUtils tokenUtil;

    private String authorization() {
        return Optional.ofNullable(MDC.get(AuthorizationUtils.JWT_AUTHZ))
                .map(Object::toString)
                .filter(s -> !s.isBlank())
                .orElseGet(tokenUtil::generateSuperUserToken);
    }

    // ======================================================
    // ANAG AREA TECNICA
    // ======================================================

    public List<AnagAreaTecnicaDto> getAllAnagAreaTecnica() {
        try (Response resp = anagraficheClient.getAllAnagAreaTecnica(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AnagAreaTecnicaDto> findAnagAreaTecnicaByCodiceArea(String codiceArea) {
        try (Response resp = anagraficheClient.findAnagAreaTecnicaByCodiceArea(authorization(), codiceArea)) {
            return handleOptionalRespAnagrafiche(resp, AnagAreaTecnicaDto.class);
        }
    }

    public AnagAreaTecnicaDto saveAnagAreaTecnica(AnagAreaTecnicaDto dto) {
        try (Response resp = anagraficheClient.saveAnagAreaTecnica(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AnagAreaTecnicaDto.class);
        }
    }

    public AnagAreaTecnicaDto deleteAnagAreaTecnica(String codiceArea) {
        try (Response resp = anagraficheClient.deleteAnagAreaTecnica(authorization(), codiceArea)) {
            return handleSaveRespAnagrafiche(resp, AnagAreaTecnicaDto.class);
        }
    }

    public AnagAreaTecnicaDto restoreAnagAreaTecnica(String codiceArea) {
        try (Response resp = anagraficheClient.restoreAnagAreaTecnica(authorization(), codiceArea)) {
            return handleSaveRespAnagrafiche(resp, AnagAreaTecnicaDto.class);
        }
    }

    // ======================================================
    // ANAG CLIENTI
    // ======================================================

    public List<AnagClientiDto> getAllAnagClienti() {
        try (Response resp = anagraficheClient.getAllAnagClienti(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AnagClientiDto> findAnagClientiByCodiceCliente(String codiceCliente) {
        try (Response resp = anagraficheClient.findAnagClientiByCodiceCliente(authorization(), codiceCliente)) {
            return handleOptionalRespAnagrafiche(resp, AnagClientiDto.class);
        }
    }

    public AnagClientiDto saveAnagClienti(AnagClientiDto dto) {
        try (Response resp = anagraficheClient.saveAnagClienti(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AnagClientiDto.class);
        }
    }

    public AnagClientiDto deleteAnagClienti(String codiceCliente) {
        try (Response resp = anagraficheClient.deleteAnagClienti(authorization(), codiceCliente)) {
            return handleSaveRespAnagrafiche(resp, AnagClientiDto.class);
        }
    }

    public AnagClientiDto restoreAnagClienti(String codiceCliente) {
        try (Response resp = anagraficheClient.restoreAnagClienti(authorization(), codiceCliente)) {
            return handleSaveRespAnagrafiche(resp, AnagClientiDto.class);
        }
    }

    // ======================================================
    // ANAG MACRO POLO
    // ======================================================

    public List<AnagMacroPoloDto> getAllAnagMacroPolo() {
        try (Response resp = anagraficheClient.getAllAnagMacroPolo(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AnagMacroPoloDto> findAnagMacroPoloByCodiceMacroPolo(String codiceMacroPolo) {
        try (Response resp = anagraficheClient.findAnagMacroPoloByCodiceMacroPolo(authorization(), codiceMacroPolo)) {
            return handleOptionalRespAnagrafiche(resp, AnagMacroPoloDto.class);
        }
    }

    public AnagMacroPoloDto saveAnagMacroPolo(AnagMacroPoloDto dto) {
        try (Response resp = anagraficheClient.saveAnagMacroPolo(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AnagMacroPoloDto.class);
        }
    }

    public AnagMacroPoloDto deleteAnagMacroPolo(String codiceMacroPolo) {
        try (Response resp = anagraficheClient.deleteAnagMacroPolo(authorization(), codiceMacroPolo)) {
            return handleSaveRespAnagrafiche(resp, AnagMacroPoloDto.class);
        }
    }

    public AnagMacroPoloDto restoreAnagMacroPolo(String codiceMacroPolo) {
        try (Response resp = anagraficheClient.restoreAnagMacroPolo(authorization(), codiceMacroPolo)) {
            return handleSaveRespAnagrafiche(resp, AnagMacroPoloDto.class);
        }
    }

    // ======================================================
    // ANAG POLO
    // ======================================================

    public List<AnagPoloDto> getAllAnagPolo() {
        try (Response resp = anagraficheClient.getAllAnagPolo(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AnagPoloDto> findAnagPoloByCodicePolo(String codicePolo) {
        try (Response resp = anagraficheClient.findAnagPoloByCodicePolo(authorization(), codicePolo)) {
            return handleOptionalRespAnagrafiche(resp, AnagPoloDto.class);
        }
    }

    public List<AnagPoloDto> findAnagPoloByCodiceMacroPolo(String codiceMacroPolo) {
        try (Response resp = anagraficheClient.findAnagPoloByCodiceMacroPolo(authorization(), codiceMacroPolo)) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public AnagPoloDto saveAnagPolo(AnagPoloDto dto) {
        try (Response resp = anagraficheClient.saveAnagPolo(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AnagPoloDto.class);
        }
    }

    public AnagMacroPoloDto deleteAnagPolo(String codicePolo) {
        try (Response resp = anagraficheClient.deleteAnagPolo(authorization(), codicePolo)) {
            return handleSaveRespAnagrafiche(resp, AnagMacroPoloDto.class);
        }
    }
    
    // ======================================================
    // ANAG RAGGRUPPAMENTI
    // ======================================================

    public List<AnagRaggruppamentiDto> getAllAnagRaggruppamenti() {
        try (Response resp = anagraficheClient.getAllAnagRaggruppamenti(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AnagRaggruppamentiDto> findAnagRaggruppamentiByCodiceRaggrRemi(String codiceRaggrRemi) {
        try (Response resp = anagraficheClient.findAnagRaggruppamentiByCodiceRaggrRemi(authorization(), codiceRaggrRemi)) {
            return handleOptionalRespAnagrafiche(resp, AnagRaggruppamentiDto.class);
        }
    }

    public AnagRaggruppamentiDto saveAnagRaggruppamenti(AnagRaggruppamentiDto dto) {
        try (Response resp = anagraficheClient.saveAnagRaggruppamenti(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AnagRaggruppamentiDto.class);
        }
    }

    public AnagRaggruppamentiDto deleteAnagRaggruppamenti(String codiceRaggrRemi) {
        try (Response resp = anagraficheClient.deleteAnagRaggruppamenti(authorization(), codiceRaggrRemi)) {
            return handleSaveRespAnagrafiche(resp, AnagRaggruppamentiDto.class);
        }
    }

    public AnagRaggruppamentiDto restoreAnagRaggruppamenti(String codiceRaggrRemi) {
        try (Response resp = anagraficheClient.restoreAnagRaggruppamenti(authorization(), codiceRaggrRemi)) {
            return handleSaveRespAnagrafiche(resp, AnagRaggruppamentiDto.class);
        }
    }

    // ======================================================
    // ANAG REMI
    // ======================================================

    public List<AnagRemiDto> getAllAnagRemi() {
        try (Response resp = anagraficheClient.getAllAnagRemi(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AnagRemiDto> findAnagRemiByRemiAssoluto(String remiAssoluto) {
        try (Response resp = anagraficheClient.findAnagRemiByRemiAssoluto(authorization(), remiAssoluto)) {
            return handleOptionalRespAnagrafiche(resp, AnagRemiDto.class);
        }
    }

    public AnagRemiDto saveAnagRemi(AnagRemiDto dto) {
        try (Response resp = anagraficheClient.saveAnagRemi(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AnagRemiDto.class);
        }
    }

    public AnagRemiDto deleteAnagRemi(String remiAssoluto) {
        try (Response resp = anagraficheClient.deleteAnagRemi(authorization(), remiAssoluto)) {
            return handleSaveRespAnagrafiche(resp, AnagRemiDto.class);
        }
    }

    public AnagRemiDto restoreAnagRemi(String remiAssoluto) {
        try (Response resp = anagraficheClient.restoreAnagRemi(authorization(), remiAssoluto)) {
            return handleSaveRespAnagrafiche(resp, AnagRemiDto.class);
        }
    }

    // ======================================================
    // ANAG TIPO STATO REMI
    // ======================================================

    public List<AnagTipoStatoRemiDto> getAllAnagTipoStatoRemi() {
        try (Response resp = anagraficheClient.getAllAnagTipoStatoRemi(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AnagTipoStatoRemiDto> findAnagTipoStatoRemiByCodiceStato(String codiceStato) {
        try (Response resp = anagraficheClient.findAnagTipoStatoRemiByCodiceStato(authorization(), codiceStato)) {
            return handleOptionalRespAnagrafiche(resp, AnagTipoStatoRemiDto.class);
        }
    }

    public AnagTipoStatoRemiDto saveAnagTipoStatoRemi(AnagTipoStatoRemiDto dto) {
        try (Response resp = anagraficheClient.saveAnagTipoStatoRemi(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AnagTipoStatoRemiDto.class);
        }
    }

    public AnagTipoStatoRemiDto deleteAnagTipoStatoRemi(String codiceStato) {
        try (Response resp = anagraficheClient.deleteAnagTipoStatoRemi(authorization(), codiceStato)) {
            return handleSaveRespAnagrafiche(resp, AnagTipoStatoRemiDto.class);
        }
    }

    public AnagTipoStatoRemiDto restoreAnagTipoStatoRemi(String codiceStato) {
        try (Response resp = anagraficheClient.restoreAnagTipoStatoRemi(authorization(), codiceStato)) {
            return handleSaveRespAnagrafiche(resp, AnagTipoStatoRemiDto.class);
        }
    }

    // ======================================================
    // ASS AREA TECNICA
    // ======================================================

    public List<AssAreaTecnicaDto> getAllAssAreaTecnica() {
        try (Response resp = anagraficheClient.getAllAssAreaTecnica(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AssAreaTecnicaDto> findAssAreaTecnicaByCodiceAreaTecnica(String codiceAreaTecnica) {
        try (Response resp = anagraficheClient.findAssAreaTecnicaByCodiceAreaTecnica(authorization(), codiceAreaTecnica)) {
            return handleOptionalRespAnagrafiche(resp, AssAreaTecnicaDto.class);
        }
    }

    public AssAreaTecnicaDto saveAssAreaTecnica(AssAreaTecnicaDto dto) {
        try (Response resp = anagraficheClient.saveAssAreaTecnica(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AssAreaTecnicaDto.class);
        }
    }

    public AssAreaTecnicaDto deleteAssAreaTecnica(String codiceAreaTecnica) {
        try (Response resp = anagraficheClient.deleteAssAreaTecnica(authorization(), codiceAreaTecnica)) {
            return handleSaveRespAnagrafiche(resp, AssAreaTecnicaDto.class);
        }
    }

    public AssAreaTecnicaDto restoreAssAreaTecnica(String codiceAreaTecnica) {
        try (Response resp = anagraficheClient.restoreAssAreaTecnica(authorization(), codiceAreaTecnica)) {
            return handleSaveRespAnagrafiche(resp, AssAreaTecnicaDto.class);
        }
    }

    // ======================================================
    // ASS RAGGRUPPAMENTI REMI
    // ======================================================

    public List<AssRaggruppamentiRemiDto> getAllAssRaggruppamentiRemi() {
        try (Response resp = anagraficheClient.getAllAssRaggruppamentiRemi(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AssRaggruppamentiRemiDto> findAssRaggruppamentiRemiByRemiAssoluto(String remiAssoluto) {
        try (Response resp = anagraficheClient.findAssRaggruppamentiRemiByRemiAssoluto(authorization(), remiAssoluto)) {
            return handleOptionalRespAnagrafiche(resp, AssRaggruppamentiRemiDto.class);
        }
    }

    public AssRaggruppamentiRemiDto saveAssRaggruppamentiRemi(AssRaggruppamentiRemiDto dto) {
        try (Response resp = anagraficheClient.saveAssRaggruppamentiRemi(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AssRaggruppamentiRemiDto.class);
        }
    }

    public AssRaggruppamentiRemiDto deleteAssRaggruppamentiRemi(String remiAssoluto, String codiceRaggrRemi) {
        try (Response resp = anagraficheClient.deleteAssRaggruppamentiRemi(authorization(), remiAssoluto, codiceRaggrRemi)) {
            return handleSaveRespAnagrafiche(resp, AssRaggruppamentiRemiDto.class);
        }
    }

    public AssRaggruppamentiRemiDto restoreAssRaggruppamentiRemi(String remiAssoluto) {
        try (Response resp = anagraficheClient.restoreAssRaggruppamentiRemi(authorization(), remiAssoluto)) {
            return handleSaveRespAnagrafiche(resp, AssRaggruppamentiRemiDto.class);
        }
    }

    // ======================================================
    // ASS REMI AOP
    // ======================================================

    public List<AssRemiAopDto> getAllAssRemiAop() {
        try (Response resp = anagraficheClient.getAllAssRemiAop(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public List<AssRemiAopDto> findAssRemiAopByRemiAssoluto(String remiAssoluto) {
        try (Response resp = anagraficheClient.findAssRemiAopByRemiAssoluto(authorization(), remiAssoluto)) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AssRemiAopDto> findAssRemiAopByPk(Long codiceAop, String remiAssoluto, Long dataInizioAopInt) {
        try (Response resp = anagraficheClient.findAssRemiAopByPk(authorization(), codiceAop, remiAssoluto, dataInizioAopInt)) {
            return handleOptionalRespAnagrafiche(resp, AssRemiAopDto.class);
        }
    }

    public AssRemiAopDto saveAssRemiAop(AssRemiAopDto dto) {
        try (Response resp = anagraficheClient.saveAssRemiAop(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AssRemiAopDto.class);
        }
    }
    
   

    public AssRemiAopDto deleteAssRemiAop(Long codiceAop, String remiAssoluto, Long dataInizioAopInt) {
        try (Response resp = anagraficheClient.deleteAssRemiAop(authorization(), codiceAop, remiAssoluto, dataInizioAopInt)) {
            return handleSaveRespAnagrafiche(resp, AssRemiAopDto.class);
        }
    }

    public AssRemiAopDto restoreAssRemiAop(Long codiceAop, String remiAssoluto, Long dataInizioAopInt) {
        try (Response resp = anagraficheClient.restoreAssRemiAop(authorization(), codiceAop, remiAssoluto, dataInizioAopInt)) {
            return handleSaveRespAnagrafiche(resp, AssRemiAopDto.class);
        }
    }

 // ======================================================
    // ASS REMI CLIENTI
    // ======================================================
    
    public AssRemiClientiDto saveAssRemiClienti(AssRemiClientiDto dto) {
        try (Response resp = anagraficheClient.saveAssRemiClienti(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AssRemiClientiDto.class);
        }
    }
    public AssRemiClientiDto deleteAssRemiClienti(String remiAssoluto, Long dataInizioValiditaInt) {
        try (Response resp = anagraficheClient.deleteAssRemiClienti(authorization(), remiAssoluto, dataInizioValiditaInt)) {
            return handleSaveRespAnagrafiche(resp, AssRemiClientiDto.class);
        }
    }
    
    // ======================================================
    // ASS REMI TIPO BILANCIO TECNICO
    // ======================================================

    public List<AssRemiTipoBilancioTecnicoDto> getAllAssRemiTipoBilancioTecnico() {
        try (Response resp = anagraficheClient.getAllAssRemiTipoBilancioTecnico(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AssRemiTipoBilancioTecnicoDto> findAssRemiTipoBilancioTecnicoByPk(String remiAssoluto, Long dataInizioInt) {
        try (Response resp = anagraficheClient.findAssRemiTipoBilancioTecnicoByPk(authorization(), remiAssoluto, dataInizioInt)) {
            return handleOptionalRespAnagrafiche(resp, AssRemiTipoBilancioTecnicoDto.class);
        }
    }

    public AssRemiTipoBilancioTecnicoDto saveAssRemiTipoBilancioTecnico(AssRemiTipoBilancioTecnicoDto dto) {
        try (Response resp = anagraficheClient.saveAssRemiTipoBilancioTecnico(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AssRemiTipoBilancioTecnicoDto.class);
        }
    }

    public AssRemiTipoBilancioTecnicoDto deleteAssRemiTipoBilancioTecnico(String remiAssoluto, Long dataInizioInt) {
        try (Response resp = anagraficheClient.deleteAssRemiTipoBilancioTecnico(authorization(), remiAssoluto, dataInizioInt)) {
            return handleSaveRespAnagrafiche(resp, AssRemiTipoBilancioTecnicoDto.class);
        }
    }

    public AssRemiTipoBilancioTecnicoDto restoreAssRemiTipoBilancioTecnico(String remiAssoluto, Long dataInizioInt) {
        try (Response resp = anagraficheClient.restoreAssRemiTipoBilancioTecnico(authorization(), remiAssoluto, dataInizioInt)) {
            return handleSaveRespAnagrafiche(resp, AssRemiTipoBilancioTecnicoDto.class);
        }
    }

    // ======================================================
    // ASS REMI TITOLARI
    // ======================================================

    public List<AssRemiTitolariDto> getAllAssRemiTitolari() {
        try (Response resp = anagraficheClient.getAllAssRemiTitolari(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public List<AssRemiTitolariDto> findAssRemiTitolariByCodiceCliente(String codiceCliente) {
        try (Response resp = anagraficheClient.findAssRemiTitolariByCodiceCliente(authorization(), codiceCliente)) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AssRemiTitolariDto> findAssRemiTitolariByPk(String remiAssoluto, Long dataInizioValiditaInt) {
        try (Response resp = anagraficheClient.findAssRemiTitolariByPk(authorization(), remiAssoluto, dataInizioValiditaInt)) {
            return handleOptionalRespAnagrafiche(resp, AssRemiTitolariDto.class);
        }
    }

    public AssRemiTitolariDto saveAssRemiTitolari(AssRemiTitolariDto dto) {
        try (Response resp = anagraficheClient.saveAssRemiTitolari(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AssRemiTitolariDto.class);
        }
    }

    public AssRemiTitolariDto deleteAssRemiTitolari(String remiAssoluto, Long dataInizioValiditaInt) {
        try (Response resp = anagraficheClient.deleteAssRemiTitolari(authorization(), remiAssoluto, dataInizioValiditaInt)) {
            return handleSaveRespAnagrafiche(resp, AssRemiTitolariDto.class);
        }
    }

    public AssRemiTitolariDto restoreAssRemiTitolari(String remiAssoluto, Long dataInizioValiditaInt) {
        try (Response resp = anagraficheClient.restoreAssRemiTitolari(authorization(), remiAssoluto, dataInizioValiditaInt)) {
            return handleSaveRespAnagrafiche(resp, AssRemiTitolariDto.class);
        }
    }

    // ======================================================
    // ASS STATO REMI
    // ======================================================

    public List<AssStatoRemiDto> getAllAssStatoRemi() {
        try (Response resp = anagraficheClient.getAllAssStatoRemi(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public List<AssStatoRemiDto> findAssStatoRemiByRemiAssoluto(String remiAssoluto) {
        try (Response resp = anagraficheClient.findAssStatoRemiByRemiAssoluto(authorization(), remiAssoluto)) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<AssStatoRemiDto> findAssStatoRemiByRemiAssolutoAndDataEvento(String remiAssoluto, String dataEvento) {
        try (Response resp = anagraficheClient.findAssStatoRemiByRemiAssolutoAndDataEvento(authorization(), remiAssoluto, dataEvento)) {
            return handleOptionalRespAnagrafiche(resp, AssStatoRemiDto.class);
        }
    }

    public AssStatoRemiDto saveAssStatoRemi(AssStatoRemiDto dto) {
        try (Response resp = anagraficheClient.saveAssStatoRemi(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, AssStatoRemiDto.class);
        }
    }

    public AssStatoRemiDto deleteAssStatoRemi(String remiAssoluto, String dataEvento) {
        try (Response resp = anagraficheClient.deleteAssStatoRemi(authorization(), remiAssoluto, dataEvento)) {
            return handleSaveRespAnagrafiche(resp, AssStatoRemiDto.class);
        }
    }

    public AssStatoRemiDto restoreAssStatoRemi(String remiAssoluto, String dataEvento) {
        try (Response resp = anagraficheClient.restoreAssStatoRemi(authorization(), remiAssoluto, dataEvento)) {
            return handleSaveRespAnagrafiche(resp, AssStatoRemiDto.class);
        }
    }

    // ======================================================
    // CONTATTO
    // ======================================================

    public List<ContattoDto> getAllContatto() {
        try (Response resp = anagraficheClient.getAllContatto(authorization())) {
            return handleListRespAnagrafiche(resp, new TypeReference<>() {});
        }
    }

    public Optional<ContattoDto> findContattoByIdContatto(Integer idContatto) {
        try (Response resp = anagraficheClient.findContattoByIdContatto(authorization(), idContatto)) {
            return handleOptionalRespAnagrafiche(resp, ContattoDto.class);
        }
    }

    public ContattoDto saveContatto(ContattoDto dto) {
        try (Response resp = anagraficheClient.saveContatto(authorization(), dto)) {
            return handleSaveRespAnagrafiche(resp, ContattoDto.class);
        }
    }

    public ContattoDto deleteContatto(Integer idContatto) {
        try (Response resp = anagraficheClient.deleteContatto(authorization(), idContatto)) {
            return handleSaveRespAnagrafiche(resp, ContattoDto.class);
        }
    }

    public ContattoDto restoreContatto(Integer idContatto) {
        try (Response resp = anagraficheClient.restoreContatto(authorization(), idContatto)) {
            return handleSaveRespAnagrafiche(resp, ContattoDto.class);
        }
    }
    // ======================================================
    // Helpers generici
    // ======================================================

    private <T> List<T> handleListRespAnagrafiche(Response respAnagrafiche, TypeReference<List<T>> refAnagrafiche) {
        int status = respAnagrafiche.getStatus();

        if (status == Response.Status.NO_CONTENT.getStatusCode()) {
            return List.of();
        }
        if (status == Response.Status.OK.getStatusCode()) {
            String json = respAnagrafiche.readEntity(String.class);
            if (json == null || json.isBlank()) {
                return List.of();
            }
            try {
                return objectMapper.readValue(json, refAnagrafiche);
            } catch (Exception e) {
                throw new RemoteCallException("Impossibile deserializzare la risposta", e);
            }
        }
        if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
            String body = safeReadBody(respAnagrafiche);
            throw new IllegalArgumentException("Richiesta non valida: " + extractErrorDetail(body));
        }
        throw remoteError("anagrafiche", status, respAnagrafiche);
    }

    private <T> Optional<T> handleOptionalRespAnagrafiche(Response respAnagrafiche, Class<T> typeAnagrafiche) {
        int status = respAnagrafiche.getStatus();

        if (status == Response.Status.NOT_FOUND.getStatusCode()
                || status == Response.Status.NO_CONTENT.getStatusCode()) {
            return Optional.empty();
        }
        if (status == Response.Status.OK.getStatusCode()) {
            return Optional.ofNullable(respAnagrafiche.readEntity(typeAnagrafiche));
        }
        if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
            String body = safeReadBody(respAnagrafiche);
            throw new IllegalArgumentException("Richiesta non valida: " + extractErrorDetail(body));
        }
        throw remoteError("anagrafiche", status, respAnagrafiche);
    }

    private <T> T handleSaveRespAnagrafiche(Response respAnagrafiche, Class<T> typeAnagrafiche) {
        int status = respAnagrafiche.getStatus();

        if (status == Response.Status.OK.getStatusCode()
                || status == Response.Status.CREATED.getStatusCode()) {
            return respAnagrafiche.readEntity(typeAnagrafiche);
        }
        if (status == Response.Status.BAD_REQUEST.getStatusCode()) {
            String body = safeReadBody(respAnagrafiche);
            throw new IllegalArgumentException("Richiesta non valida: " + extractErrorDetail(body));
        }
        throw remoteError("anagrafiche", status, respAnagrafiche);
    }

   
}