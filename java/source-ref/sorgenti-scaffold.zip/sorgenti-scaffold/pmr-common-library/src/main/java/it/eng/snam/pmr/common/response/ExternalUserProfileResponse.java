package it.eng.snam.pmr.common.response;

import java.util.List;

import it.eng.snam.pmr.common.dto.ProfileScenarioDto;

public record ExternalUserProfileResponse(
        String userCode,
        List<ProfileScenarioDto> scenarios
) {}

