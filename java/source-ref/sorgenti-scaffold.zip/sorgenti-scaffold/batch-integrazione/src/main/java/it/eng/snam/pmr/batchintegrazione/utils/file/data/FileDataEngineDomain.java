package it.eng.snam.pmr.batchintegrazione.utils.file.data;

import static it.eng.snam.pmr.common.functional.interfaces.ExceptionFactory.MESSAGE_BUILDER;

import it.eng.snam.pmr.batchintegrazione.exception.FileDataExecutionException;
import it.eng.snam.pmr.common.dto.retry.RetryableProcessContext;
import it.eng.snam.pmr.common.functional.interfaces.ExceptionFactory;
import lombok.experimental.UtilityClass;

@UtilityClass
public class FileDataEngineDomain {

    public final RetryableProcessContext ENGINE = RetryableProcessContext.of("FileDataEngine execution", fileDataEngine());

    private static ExceptionFactory fileDataEngine() {
        return (operationName, cause) -> new FileDataExecutionException(MESSAGE_BUILDER.apply(operationName, cause), cause);
    }
}
