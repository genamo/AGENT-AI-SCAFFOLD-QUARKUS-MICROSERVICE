package it.eng.snam.pmr.common.util.exception.mapper;

import java.util.Map;
import java.util.function.BiFunction;

import jakarta.ws.rs.core.Response;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ThrowableStatusResolver {

    private final BiFunction<Throwable, Map<Class<? extends Throwable>, Response.Status>, Response.Status> RESOLVER =
            (throwable, domain) -> domain.entrySet().stream()
                                         .filter(entry -> entry.getKey().isInstance(throwable))
                                         .map(Map.Entry::getValue)
                                         .findFirst().orElse(Response.Status.INTERNAL_SERVER_ERROR);

    public Response.Status resolve(Throwable throwable, Map<Class<? extends Throwable>, Response.Status> statusRules) {
        return RESOLVER.apply(throwable, statusRules);
    }
}
