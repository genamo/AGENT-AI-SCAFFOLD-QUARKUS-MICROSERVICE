package it.eng.snam.pmr.batchintegrazionedg.exception;

public class RetryableRemoteException extends RuntimeException {
    
	private static final long serialVersionUID = -6780349831100401928L;
	public RetryableRemoteException(String message) {
        super(message);
    }
    public RetryableRemoteException(String message, Throwable cause) {
        super(message, cause);
    }
}