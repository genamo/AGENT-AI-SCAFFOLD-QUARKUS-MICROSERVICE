package it.eng.snam.pmr.common.dto.acr.roles;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class AcrRolesResponseDtoTest {

    @Test
    void builder_and_accessors_work() {
        AcrRoleDTO role = AcrRoleDTO.builder()
                .code("ADMIN")
                .build();

        AcrRolesResponseDTO dto = AcrRolesResponseDTO.builder()
                .jwtUserId("user1")
                .rawRoles("ADMIN,USER")
                .roles(List.of(role))
                .build();

        assertThat(role.code()).isEqualTo("ADMIN");
        assertThat(dto.jwtUserId()).isEqualTo("user1");
        assertThat(dto.rawRoles()).isEqualTo("ADMIN,USER");
        assertThat(dto.roles()).containsExactly(role);
    }
}
