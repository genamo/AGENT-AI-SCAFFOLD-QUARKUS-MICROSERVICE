package it.eng.snam.pmr.batchintegrazionedg.dto.monitoring.integration;

import java.io.Serial;
import java.io.Serializable;
import java.util.Map;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MonitoringIntegration implements Serializable {

    @Serial
    private static final long serialVersionUID = -7483697941877469136L;

    private String integrationType;
    private String requestBody;
    private Map<String, String> additionalMetadata;
}
